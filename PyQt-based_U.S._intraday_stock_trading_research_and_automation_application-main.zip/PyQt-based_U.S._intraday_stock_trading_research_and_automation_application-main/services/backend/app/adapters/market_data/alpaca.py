import asyncio
import json
from collections import deque
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
import websockets

from app.adapters.market_data.base import MarketDataUnavailableError
from app.adapters.toss.wts_ranking import TossWtsRankingClient, TossWtsRankingError
from app.core.config import Settings


ALPACA_SCREENER_MAX_TOP = 100
ALPACA_MULTI_SYMBOL_BAR_MAX_PAGES = 3
ALPACA_MAX_INDIVIDUAL_BAR_FALLBACK_SYMBOLS = 8
ALPACA_WEBSOCKET_AUTH_TIMEOUT_SEC = 15
ALPACA_SCREENER_MAX_STALE_SEC = 900


class AlpacaMarketDataProvider:
    provider_name = "alpaca"

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._task: asyncio.Task | None = None
        self._websocket: Any | None = None
        self._status = "stopped"
        self._last_error: str | None = None
        self._last_message_at: str | None = None
        self._last_realtime_at: str | None = None
        self._last_trade_at: str | None = None
        self._last_quote_at: str | None = None
        self._started_at: str | None = None
        self._events: deque[dict] = deque(maxlen=2000)
        self._latest_quotes: dict[str, dict] = {}
        self._latest_trades: dict[str, dict] = {}
        self._subscriptions: set[str] = set()
        self._subscription_started_at: dict[str, datetime] = {}
        self._subscribe_quotes = True
        self._subscribe_trades = True
        self._last_symbol_detail_event_at: dict[str, float] = {}
        self._access_token: str | None = None
        self._access_token_expires_at: datetime | None = None
        self._last_data_error: str | None = None
        self._asset_cache: dict[str, dict] = {}
        self._asset_cache_at: datetime | None = None

    @property
    def rest_base_url(self) -> str:
        endpoint = self.settings.alpaca_endpoint
        if endpoint and endpoint.startswith("http") and "data.alpaca.markets" in endpoint:
            return endpoint.rstrip("/")
        return self.settings.alpaca_rest_base_url.rstrip("/")

    @property
    def websocket_url(self) -> str:
        endpoint = self.settings.alpaca_endpoint
        if endpoint and endpoint.startswith("wss"):
            return endpoint
        return self.settings.alpaca_websocket_url

    @property
    def feed(self) -> str:
        if self.websocket_url.endswith("/iex"):
            return "iex"
        if self.websocket_url.endswith("/delayed_sip"):
            return "delayed_sip"
        return self.settings.alpaca_feed

    def status(self) -> dict:
        configured = bool(self.settings.alpaca_key and self.settings.alpaca_secret)
        return {
            "provider": self.provider_name,
            "provider_display_name": "Alpaca Market Data",
            "configured": configured,
            "status": "configured" if configured else "credentials_missing",
            "feed": self.feed,
            "auth_mode": self._resolved_auth_mode() if configured else self.settings.alpaca_auth_mode,
            "rest_base_url": self.rest_base_url,
            "websocket_url": _redact_url(self.websocket_url),
            "last_data_error": self._last_data_error,
            "message": "Alpaca market data configured." if configured else "ALPACA_KEY/ALPACA_SECRET이 필요합니다.",
            "checked_at": _now_iso(),
        }

    def scanner_rankings(self, exchange: str = "NAS") -> dict:
        del exchange
        self._last_data_error = None
        candidate_limit = max(1, min(int(self.settings.scanner_max_websocket_symbols or 30), 100))
        universe_limit = max(candidate_limit, min(int(self.settings.scanner_candidate_universe_size or 100), 100))
        active_rows = self._primary_seed_rows(limit=universe_limit)
        using_toss_seed = any(str(row.get("screener_source") or "") == "toss_wts_biggest_total_amount" for row in active_rows)
        symbols = self._candidate_symbols_from_rows(active_rows, limit=universe_limit)
        asset_meta = self._assets_for_symbols(symbols)
        active_rows = [
            {**row, **_asset_fields(asset_meta.get(row["symb"]) or {})}
            for row in active_rows
            if _is_allowed_common_stock(row["symb"], asset_meta.get(row["symb"]), self.settings)
        ]
        symbols = [symbol for symbol in symbols if _is_allowed_common_stock(symbol, asset_meta.get(symbol), self.settings)]
        latest_snapshots: dict[str, dict] = {}
        recent_bars: dict[str, list[dict]] = {}
        data_error: str | None = None
        try:
            latest_snapshots = self._snapshots(symbols)
        except MarketDataUnavailableError as exc:
            data_error = _friendly_data_error(str(exc), feed=self.feed)
            self._last_data_error = data_error
        recent_bars = self._recent_minute_bars(symbols, limit=10)
        if not latest_snapshots and not recent_bars and not data_error:
            self._last_data_error = "Alpaca snapshot/bars 응답에 최신 1분봉 또는 tick 데이터가 없습니다."
        rows = []
        for index, symbol in enumerate(symbols, start=1):
            active = next((row for row in active_rows if row["symb"] == symbol), {})
            snapshot = latest_snapshots.get(symbol) or {}
            latest_trade = snapshot.get("latestTrade") or {}
            latest_quote = snapshot.get("latestQuote") or {}
            snapshot_bar = snapshot.get("minuteBar") or {}
            bars = _sort_bars_desc(recent_bars.get(symbol) or [])
            latest_bar = snapshot_bar or (bars[0] if bars else {})
            latest_volume = _to_float(latest_bar.get("v"))
            daily_volume = _to_float(active.get("volume"))
            latest_bar_at = latest_bar.get("t")
            latest_trade_at = latest_trade.get("t")
            latest_quote_at = latest_quote.get("t")
            latest_activity_at = _latest_timestamp(latest_bar_at, latest_trade_at, latest_quote_at)
            last_price = (
                _to_float(latest_bar.get("c"))
                or _to_float(latest_trade.get("p"))
                or _midpoint(_to_float(latest_quote.get("bp")), _to_float(latest_quote.get("ap")))
            )
            volume_10m = _sum_bar_volume(bars)
            notional_10m = _sum_bar_notional(bars)
            notional_1m = _bar_notional(latest_bar)
            notional_velocity_1m = _notional_velocity_1m(bars)
            change_1m_pct = _bar_change_pct(latest_bar)
            change_10m_pct = _bars_change_pct(bars)
            if latest_volume is not None and snapshot_bar:
                volume_source = "provider_snapshot_1m_bar"
            elif latest_volume is not None and data_error:
                volume_source = "provider_delayed_1m_bar"
            elif latest_volume is not None:
                volume_source = "provider_latest_1m_bar"
            elif latest_trade:
                volume_source = "provider_snapshot_trade"
            elif data_error:
                volume_source = "provider_recent_data_error"
            else:
                volume_source = "provider_most_actives"
            rows.append(
                {
                    "symb": symbol,
                    **_asset_fields(asset_meta.get(symbol) or {}),
                    "rank": index,
                    "trade_volume_rank": index,
                    "volume_1m": latest_volume,
                    "volume_10m": volume_10m,
                    "tvol": latest_volume,
                    "daily_volume": daily_volume,
                    "trade_count": _to_float(active.get("trade_count")),
                    "screener_source": active.get("screener_source"),
                    "toss_wts_rank": active.get("toss_wts_rank"),
                    "toss_wts_notional": active.get("toss_wts_notional"),
                    "mover_side": active.get("mover_side"),
                    "mover_rank": _to_float(active.get("mover_rank")),
                    "mover_change_pct": _to_float(active.get("mover_change_pct")),
                    "last": last_price,
                    "notional_1m": notional_1m,
                    "notional_10m": notional_10m,
                    "notional_velocity_10s": notional_velocity_1m,
                    "change_1m_pct": change_1m_pct,
                    "change_10m_pct": change_10m_pct,
                    "latest_bar_at": latest_bar_at,
                    "latest_trade_at": latest_trade_at,
                    "latest_quote_at": latest_quote_at,
                    "latest_bar_age_sec": _age_seconds(latest_bar_at),
                    "latest_activity_age_sec": _age_seconds(latest_activity_at),
                    "volume_source": volume_source,
                    "market_data_error": data_error
                    or (
                        f"Alpaca movers stale: last_updated={active.get('mover_last_updated')}"
                        if active.get("mover_stale")
                        else None
                    ),
                    "mover_stale": bool(active.get("mover_stale")),
                }
            )
        volume_passed_rows = [row for row in rows if _passes_mover_seed_volume_floor(row, self.settings)]
        if volume_passed_rows:
            rows = volume_passed_rows
        elif rows:
            bootstrap_source = "toss_wts_realtime_bootstrap" if using_toss_seed else "provider_movers_realtime_bootstrap"
            bootstrap_message = (
                "Toss WTS biggest_total_amount seed only: waiting for Alpaca realtime trade/quote ticks to confirm volume."
                if using_toss_seed
                else "Alpaca movers seed only: waiting for realtime trade/quote ticks to confirm volume."
            )
            rows = [
                {
                    **row,
                    "volume_source": bootstrap_source,
                    "market_data_error": row.get("market_data_error")
                    or bootstrap_message,
                    "realtime_bootstrap_candidate": True,
                }
                for row in rows
            ]
        ranked_rows = rows[:candidate_limit] if using_toss_seed else _rank_mover_seed_rows(rows)[:candidate_limit]
        for index, row in enumerate(ranked_rows, start=1):
            row["rank"] = index
        ranking_rows = [
            {
                **row,
                "rank": index,
                "trade_notional_rank": None,
                "trade_volume_rank": index,
                "screener_source": row.get("screener_source"),
                "toss_wts_rank": row.get("toss_wts_rank"),
                "toss_wts_notional": row.get("toss_wts_notional"),
                "volume_surge_rank": index,
                "realtime_liquidity_rank": None,
                "scanner_score": max(0.0, 101.0 - float(index)),
                "volume_score": max(0.0, 101.0 - float(index)),
                "liquidity_impulse_score": max(0.0, 101.0 - float(index)),
            }
            for index, row in enumerate(ranked_rows, start=1)
        ]
        return {
            "trade_volume": {"output2": ranking_rows},
            "volume_surge": {"output2": ranking_rows},
            "trade_strength": {"output2": []},
            "_meta": {"market_data_error": self._last_data_error, "feed": self.feed},
        }

    def _primary_seed_rows(self, *, limit: int) -> list[dict]:
        if self.settings.scanner_candidate_source == "toss_biggest_total_amount":
            try:
                rows = TossWtsRankingClient(self.settings).biggest_total_amount_rows(limit=limit)
            except TossWtsRankingError as exc:
                self._last_data_error = f"Toss WTS biggest_total_amount ranking unavailable: {exc}"
            except Exception as exc:
                self._last_data_error = f"Toss WTS biggest_total_amount ranking failed: {exc}"
            else:
                if rows:
                    return rows
                self._last_data_error = "Toss WTS biggest_total_amount ranking returned no symbols."
        return _rank_mover_seed_rows(self._mover_rows(limit=limit, allow_stale_bootstrap=True))

    async def start_realtime(
        self,
        *,
        symbols: list[str],
        exchange: str = "NAS",
        key_mode: str = "regular",
        subscribe_quotes: bool = True,
        subscribe_trades: bool = True,
    ) -> dict:
        del exchange, key_mode
        self._ensure_credentials()
        if self._task and not self._task.done():
            await self.stop_realtime()
        self._subscribe_quotes = subscribe_quotes
        self._subscribe_trades = subscribe_trades
        self._subscriptions = {symbol.upper() for symbol in symbols if symbol}
        now = datetime.now(timezone.utc)
        self._subscription_started_at = {symbol: now for symbol in self._subscriptions}
        self._latest_quotes.clear()
        self._latest_trades.clear()
        self._events.clear()
        self._status = "starting"
        self._last_error = None
        self._last_realtime_at = None
        self._last_trade_at = None
        self._last_quote_at = None
        self._started_at = _now_iso()
        self._task = asyncio.create_task(
            self._run(subscribe_quotes=subscribe_quotes, subscribe_trades=subscribe_trades)
        )
        await asyncio.sleep(0.2)
        return self.realtime_status()

    async def update_realtime(
        self,
        *,
        symbols: list[str],
        exchange: str = "NAS",
        key_mode: str = "regular",
        subscribe_quotes: bool = True,
        subscribe_trades: bool = True,
    ) -> dict:
        del exchange, key_mode
        self._ensure_credentials()
        desired = {symbol.upper() for symbol in symbols if symbol}
        if self._status not in ("starting", "connected") or not self._task or self._task.done():
            return await self.start_realtime(
                symbols=sorted(desired),
                subscribe_quotes=subscribe_quotes,
                subscribe_trades=subscribe_trades,
            )
        current = set(self._subscriptions)
        added = sorted(desired - current)
        removed = sorted(current - desired)
        self._subscribe_quotes = subscribe_quotes
        self._subscribe_trades = subscribe_trades
        if self._websocket is not None and self._status == "connected":
            if removed:
                await self._websocket.send(json.dumps(self._subscription_payload("unsubscribe", removed)))
            if added:
                await self._websocket.send(json.dumps(self._subscription_payload("subscribe", added)))
        self._subscriptions = desired
        now = datetime.now(timezone.utc)
        for symbol in added:
            self._subscription_started_at[symbol] = now
        for symbol in removed:
            self._latest_quotes.pop(symbol, None)
            self._latest_trades.pop(symbol, None)
            self._subscription_started_at.pop(symbol, None)
        return self.realtime_status()

    async def stop_realtime(self) -> dict:
        self._status = "stopping"
        if self._websocket is not None:
            await self._websocket.close()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        self._websocket = None
        self._status = "stopped"
        return self.realtime_status()

    def realtime_status(self) -> dict:
        return {
            "status": self._status,
            "environment": "external",
            "provider": self.provider_name,
            "feed": self.feed,
            "url": _redact_url(self.websocket_url),
            "subscription_count": len(self._subscriptions),
            "last_message_at": self._last_message_at,
            "last_realtime_at": self._last_realtime_at,
            "last_trade_at": self._last_trade_at,
            "last_quote_at": self._last_quote_at,
            "last_error": self._last_error,
            "started_at": self._started_at,
            "event_count": len(self._events),
            "latest_quote_symbols": sorted(self._latest_quotes.keys()),
            "latest_trade_symbols": sorted(self._latest_trades.keys()),
            "candidate_warmup_sec": self.settings.scanner_candidate_warmup_sec,
            "subscription_age_sec": {
                symbol: self._subscription_age_sec(symbol)
                for symbol in sorted(self._subscriptions)
            },
        }

    def realtime_snapshot(self) -> dict:
        return {
            "status": self.realtime_status(),
            "quotes": self._latest_quotes,
            "trades": self._latest_trades,
            "recent_events": self.recent_events(50),
        }

    def subscribed_symbols(self) -> set[str]:
        if self._status not in ("starting", "connected"):
            return set()
        return set(self._subscriptions)

    def order_flow_snapshot(self) -> dict[str, dict]:
        stats = {symbol: _empty_flow(symbol) for symbol in self.subscribed_symbols()}
        now = datetime.now(timezone.utc)
        previous_trade_price: dict[str, float] = {}
        # Snapshot: concurrent stream threads append to self._events; iterating
        # the live deque here would raise "deque mutated during iteration".
        for event in list(self._events):
            symbol = event.get("symbol")
            if not symbol or event.get("event_type") not in ("quote", "trade"):
                continue
            flow = stats.setdefault(symbol, _empty_flow(symbol))
            received = _parse_dt(event.get("received_at"))
            age_sec = (now - received).total_seconds() if received else None
            if age_sec is not None:
                flow["last_update_age_sec"] = age_sec if flow["last_update_age_sec"] is None else min(flow["last_update_age_sec"], age_sec)
            if event["event_type"] == "quote":
                flow["quote"] = event
                flow["spread_pct"] = event.get("spread_pct")
                flow["bid_ask_imbalance"] = event.get("bid_ask_imbalance")
                continue
            flow["trade"] = event
            flow["spread_pct"] = flow.get("spread_pct") or event.get("spread_pct")
            volume = _to_float(event.get("trade_volume")) or 0.0
            price = _to_float(event.get("last"))
            side = _trade_side(price=price, quote=flow.get("quote"), previous_price=previous_trade_price.get(symbol))
            if side == "buy":
                flow["aggressive_buy_volume"] += volume
            elif side == "sell":
                flow["aggressive_sell_volume"] += volume
            else:
                flow["unknown_trade_volume"] += volume
            if price is not None:
                previous_trade_price[symbol] = price
            if age_sec is None:
                continue
            if 0 <= age_sec <= 10:
                flow["volume_10s"] += volume
            elif 10 < age_sec <= 20:
                flow["volume_prev_10s"] += volume
            if 0 <= age_sec <= 30:
                flow["volume_30s"] += volume
            if 0 <= age_sec <= 60:
                flow["volume_60s"] += volume
        for flow in stats.values():
            prev = flow.pop("volume_prev_10s")
            flow["volume_velocity_10s"] = flow["volume_10s"] / prev if prev and prev > 0 else None
            directional_volume = flow["aggressive_buy_volume"] + flow["aggressive_sell_volume"]
            if directional_volume > 0:
                flow["trade_strength"] = flow["aggressive_buy_volume"] / directional_volume * 100
                flow["sell_pressure"] = flow["aggressive_sell_volume"] / directional_volume
        return stats

    def recent_events(self, limit: int = 100) -> list[dict]:
        return list(self._events)[-limit:]

    def price(self, symbol: str, exchange: str = "NAS") -> dict:
        del exchange
        snapshot = self._snapshots([symbol.upper()]).get(symbol.upper()) or {}
        trade = snapshot.get("latestTrade") or {}
        return {"output": {"last": trade.get("p"), "source": "alpaca_snapshot", "received_at": trade.get("t")}}

    def quote(self, symbol: str, exchange: str = "NAS") -> dict:
        del exchange
        snapshot = self._snapshots([symbol.upper()]).get(symbol.upper()) or {}
        quote = snapshot.get("latestQuote") or {}
        return {
            "output1": {},
            "output2": {
                "pbid1": quote.get("bp"),
                "pask1": quote.get("ap"),
                "vbid1": (_to_float(quote.get("bs")) or 0) * 100,
                "vask1": (_to_float(quote.get("as")) or 0) * 100,
                "source": "alpaca_snapshot",
                "received_at": quote.get("t"),
            },
        }

    def minute_bars(self, symbol: str, exchange: str = "NAS", interval: str = "1", limit: int = 120) -> dict:
        del exchange
        return {"output2": self._bars(symbol=symbol.upper(), timeframe=f"{interval}Min", limit=limit)}

    def minute_bars_history(
        self,
        symbol: str,
        exchange: str = "NAS",
        interval: str = "1",
        target_date: str | None = None,
        max_pages: int = 20,
    ) -> dict:
        del exchange, max_pages
        params = {}
        if target_date:
            start = datetime.strptime(target_date, "%Y%m%d").date()
            params["start"] = start.isoformat()
            params["end"] = (start + timedelta(days=1)).isoformat()
        return {"output2": self._bars(symbol=symbol.upper(), timeframe=f"{interval}Min", limit=10000, extra=params)}

    def daily_bars(
        self,
        symbol: str,
        exchange: str = "NAS",
        period: str = "0",
        bymd: str = "",
        adjusted: bool = True,
        max_pages: int = 5,
    ) -> dict:
        del exchange, period, bymd, adjusted, max_pages
        return {"output2": self._bars(symbol=symbol.upper(), timeframe="1Day", limit=365)}

    async def _run(self, *, subscribe_quotes: bool, subscribe_trades: bool) -> None:
        try:
            async with websockets.connect(
                self.websocket_url,
                ping_interval=None,
                open_timeout=ALPACA_WEBSOCKET_AUTH_TIMEOUT_SEC,
            ) as websocket:
                self._websocket = websocket
                welcome = await asyncio.wait_for(websocket.recv(), timeout=ALPACA_WEBSOCKET_AUTH_TIMEOUT_SEC)
                self._last_message_at = _now_iso()
                self._push_system(welcome)
                await websocket.send(
                    json.dumps({"action": "auth", "key": self.settings.alpaca_key, "secret": self.settings.alpaca_secret})
                )
                auth = await asyncio.wait_for(websocket.recv(), timeout=ALPACA_WEBSOCKET_AUTH_TIMEOUT_SEC)
                self._last_message_at = _now_iso()
                self._push_system(auth)
                if self._status == "error":
                    return
                self._status = "connected"
                self._subscribe_quotes = subscribe_quotes
                self._subscribe_trades = subscribe_trades
                await websocket.send(
                    json.dumps(self._subscription_payload("subscribe", sorted(self._subscriptions)))
                )
                async for message in websocket:
                    self._last_message_at = _now_iso()
                    self._handle_ws_message(str(message))
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._last_error = str(exc)
            self._status = "error"
            self._events.append({"event_type": "ws_error", "message": str(exc), "received_at": _now_iso()})
        finally:
            self._websocket = None
            if self._status not in ("error", "stopping", "stopped"):
                self._status = "stopped"

    def _handle_ws_message(self, message: str) -> None:
        try:
            payload = json.loads(message)
        except json.JSONDecodeError:
            self._events.append({"event_type": "raw", "raw": message, "received_at": _now_iso()})
            return
        rows = payload if isinstance(payload, list) else [payload]
        for row in rows:
            if not isinstance(row, dict):
                continue
            event = self._map_stream_event(row)
            self._events.append(event)
            if event.get("event_type") == "trade":
                self._latest_trades[event["symbol"]] = event
                self._last_realtime_at = event["received_at"]
                self._last_trade_at = event["received_at"]
                if not _has_active_paper_position(event.get("symbol")):
                    from app.services.candle_builder import candle_builder

                    candle = candle_builder.on_trade(event, source="provider_ws_tick")
                    if self._candidate_warmup_done(event.get("symbol")):
                        from app.services.strategy_runtime import strategy_runtime

                        strategy_runtime.on_trade(event, candle)
                self._publish_symbol_detail_event(event.get("symbol"), reason="trade")
            elif event.get("event_type") == "quote":
                self._latest_quotes[event["symbol"]] = event
                self._last_realtime_at = event["received_at"]
                self._last_quote_at = event["received_at"]
                self._publish_symbol_detail_event(event.get("symbol"), reason="quote")
            elif event.get("event_type") == "bar":
                from app.services.candle_builder import candle_builder

                candle_builder.seed(event["symbol"], [_bar_event_to_candle(event)], source="provider_minute")
                self._last_realtime_at = event["received_at"]
                self._publish_symbol_detail_event(event.get("symbol"), reason="bar")

    def _map_stream_event(self, row: dict) -> dict:
        msg_type = row.get("T")
        if msg_type == "t":
            return {
                "event_type": "trade",
                "symbol": row.get("S"),
                "last": _to_float(row.get("p")),
                "trade_volume": _to_float(row.get("s")),
                "received_at": row.get("t") or _now_iso(),
                "raw": row,
            }
        if msg_type == "q":
            bid = _to_float(row.get("bp"))
            ask = _to_float(row.get("ap"))
            bid_depth = (_to_float(row.get("bs")) or 0) * 100
            ask_depth = (_to_float(row.get("as")) or 0) * 100
            return {
                "event_type": "quote",
                "symbol": row.get("S"),
                "bid": bid,
                "ask": ask,
                "bid_depth": bid_depth,
                "ask_depth": ask_depth,
                "spread_pct": _spread_pct(bid, ask),
                "bid_ask_imbalance": _imbalance(bid_depth, ask_depth),
                "received_at": row.get("t") or _now_iso(),
                "raw": row,
            }
        if msg_type == "b":
            return {
                "event_type": "bar",
                "symbol": row.get("S"),
                "open": _to_float(row.get("o")),
                "high": _to_float(row.get("h")),
                "low": _to_float(row.get("l")),
                "close": _to_float(row.get("c")),
                "volume": _to_float(row.get("v")),
                "received_at": row.get("t") or _now_iso(),
                "raw": row,
            }
        return {"event_type": "system", "received_at": _now_iso(), "raw": row, "message": row.get("msg")}

    def _push_system(self, message: str) -> None:
        try:
            payload = json.loads(message)
        except json.JSONDecodeError:
            payload = message
        error_message = _system_error_message(payload)
        if error_message:
            self._last_error = error_message
            self._status = "error"
        self._events.append({"event_type": "system", "received_at": _now_iso(), "raw": payload})

    def _subscription_payload(self, action: str, symbols: list[str]) -> dict[str, object]:
        payload: dict[str, object] = {"action": action, "bars": sorted(symbols)}
        if self._subscribe_trades:
            payload["trades"] = sorted(symbols)
        if self._subscribe_quotes:
            payload["quotes"] = sorted(symbols)
        return payload

    def _subscription_age_sec(self, symbol: str | None) -> float | None:
        normalized = str(symbol or "").upper()
        started_at = self._subscription_started_at.get(normalized)
        if started_at is None:
            return None
        return max(0.0, (datetime.now(timezone.utc) - started_at).total_seconds())

    def _candidate_warmup_done(self, symbol: str | None) -> bool:
        if _has_active_paper_position(symbol):
            return True
        warmup_sec = max(0, int(self.settings.scanner_candidate_warmup_sec or 0))
        if warmup_sec <= 0:
            return True
        age_sec = self._subscription_age_sec(symbol)
        return age_sec is not None and age_sec >= warmup_sec

    def _publish_symbol_detail_event(self, symbol: str | None, *, reason: str) -> None:
        symbol = str(symbol or "").upper()
        if not symbol:
            return
        now = datetime.now(timezone.utc).timestamp()
        if now - self._last_symbol_detail_event_at.get(symbol, 0.0) < 0.8:
            return
        self._last_symbol_detail_event_at[symbol] = now
        from app.domain.enums import RealtimeEventType, StatusLevel
        from app.services.event_bus import event_bus

        event_bus.publish(
            RealtimeEventType.SYMBOL_DETAIL,
            {"event_type": f"market_data.{reason}", "symbol": symbol, "source": "alpaca_ws"},
            status_level=StatusLevel.NORMAL,
            symbol=symbol,
        )

    def _request(self, path: str, params: dict | None = None) -> dict:
        self._ensure_credentials()
        with httpx.Client(timeout=20) as client:
            response = client.get(
                f"{self.rest_base_url}{path}",
                headers=self._rest_headers(client),
                params=params or {},
            )
        if response.status_code >= 400:
            raise MarketDataUnavailableError(f"Alpaca market data error {response.status_code}: {response.text[:300]}")
        return response.json()

    def _rest_headers(self, client: httpx.Client) -> dict[str, str]:
        if self._resolved_auth_mode() == "broker":
            return {"Authorization": f"Bearer {self._broker_access_token(client)}"}
        return {
            "APCA-API-KEY-ID": self.settings.alpaca_key or "",
            "APCA-API-SECRET-KEY": self.settings.alpaca_secret or "",
        }

    def _broker_access_token(self, client: httpx.Client) -> str:
        now = datetime.now(timezone.utc)
        if self._access_token and self._access_token_expires_at and self._access_token_expires_at > now:
            return self._access_token
        response = client.post(
            self.settings.alpaca_oauth_token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": self.settings.alpaca_key or "",
                "client_secret": self.settings.alpaca_secret or "",
            },
        )
        if response.status_code >= 400:
            raise MarketDataUnavailableError(f"Alpaca broker auth error {response.status_code}: {response.text[:300]}")
        payload = response.json()
        token = payload.get("access_token")
        if not token:
            raise MarketDataUnavailableError("Alpaca broker auth response에 access_token이 없습니다.")
        expires_in = _to_float(payload.get("expires_in")) or 900
        self._access_token = str(token)
        self._access_token_expires_at = now + timedelta(seconds=max(60, expires_in - 60))
        return self._access_token

    def _resolved_auth_mode(self) -> str:
        if self.settings.alpaca_auth_mode in ("trading", "broker"):
            return self.settings.alpaca_auth_mode
        key = (self.settings.alpaca_key or "").strip()
        if key.startswith("C"):
            return "broker"
        return "trading"

    def _candidate_symbols(self, *, limit: int = 100) -> list[str]:
        return self._candidate_symbols_from_rows(
            _merge_active_rows(
                self._most_active_rows(limit=limit, by="volume"),
                self._most_active_rows(limit=limit, by="trades"),
            ),
            limit=limit,
        )

    def _candidate_symbols_from_rows(self, active_rows: list[dict], *, limit: int = 100) -> list[str]:
        active_symbols = [str(row.get("symb") or "").upper() for row in active_rows if row.get("symb")]
        has_mover_rows = any("movers_" in str(row.get("screener_source") or "") for row in active_rows)
        mover_symbols = [] if has_mover_rows else self._mover_symbols(limit=min(100, max(50, limit // 4)))
        active_reserve = max(0, limit - len(mover_symbols))
        symbols: list[str] = []
        for symbol in [*active_symbols[:active_reserve], *mover_symbols, *active_symbols[active_reserve:]]:
            if symbol and symbol not in symbols:
                symbols.append(symbol)
            if len(symbols) >= limit:
                break
        return symbols

    def _mover_symbols(self, *, limit: int = 100) -> list[str]:
        return [row["symb"] for row in self._mover_rows(limit=limit) if row.get("symb")]

    def _mover_rows(self, *, limit: int = 100, allow_stale_bootstrap: bool = False) -> list[dict]:
        rows: list[dict] = []
        seen: set[str] = set()
        top = min(50, max(1, int(limit)))
        try:
            movers = self._request("/v1beta1/screener/stocks/movers", {"top": top})
            stale_payload = not _screener_payload_fresh(movers, self.settings)
            if stale_payload:
                last_updated = movers.get("last_updated")
                self._last_data_error = f"Alpaca movers stale: last_updated={last_updated}"
                if not allow_stale_bootstrap:
                    return []
            for side in ("gainers", "losers"):
                for index, row in enumerate(movers.get(side, []) or [], start=1):
                    symbol = str(row.get("symbol") or "").upper()
                    if not symbol or symbol in seen:
                        continue
                    seen.add(symbol)
                    rows.append(
                        {
                            "symb": symbol,
                            "mover_side": side,
                            "mover_rank": index,
                            "mover_change": _to_float(row.get("change")),
                            "mover_change_pct": _to_float(
                                row.get("percent_change")
                                or row.get("change_percent")
                                or row.get("change_pct")
                            ),
                            "mover_last_updated": movers.get("last_updated"),
                            "mover_stale": stale_payload,
                            "screener_source": f"movers_{side}",
                        }
                    )
        except MarketDataUnavailableError:
            pass
        return rows[:limit]

    def _mover_symbols_legacy(self, *, limit: int = 100) -> list[str]:
        return self._mover_symbols(limit=limit)

    def _assets_for_symbols(self, symbols: list[str]) -> dict[str, dict]:
        if not symbols:
            return {}
        now = datetime.now(timezone.utc)
        if self._asset_cache and self._asset_cache_at and (now - self._asset_cache_at).total_seconds() < 300:
            return {symbol: self._asset_cache.get(symbol, {}) for symbol in symbols}
        endpoint = (self.settings.alpaca_endpoint or "").rstrip("/")
        if not endpoint.startswith("http") or "alpaca.markets" not in endpoint:
            return {}
        try:
            with httpx.Client(timeout=20) as client:
                response = client.get(
                    f"{endpoint}/assets",
                    headers=self._rest_headers(client),
                    params={"asset_class": "us_equity", "status": "active"},
                )
        except Exception:
            return {}
        if response.status_code >= 400:
            return {}
        payload = response.json()
        if not isinstance(payload, list):
            return {}
        self._asset_cache = {
            str(row.get("symbol") or "").upper(): row
            for row in payload
            if isinstance(row, dict) and row.get("symbol")
        }
        self._asset_cache_at = now
        return {symbol: self._asset_cache.get(symbol, {}) for symbol in symbols}

    def _most_active_rows(self, *, limit: int = 100, by: str = "volume") -> list[dict]:
        payload = None
        requested_top = min(max(1, int(limit)), ALPACA_SCREENER_MAX_TOP)
        for top in _dedupe_limits([requested_top, 50]):
            try:
                payload = self._request("/v1beta1/screener/stocks/most-actives", {"by": by, "top": top})
                break
            except MarketDataUnavailableError:
                continue
        if payload is None:
            return []
        rows = []
        for row in payload.get("most_actives") or []:
            symbol = str(row.get("symbol") or "").upper()
            if not symbol:
                continue
            rows.append(
                {
                    "symb": symbol,
                    "volume": _to_float(row.get("volume")),
                    "trade_count": _to_float(row.get("trade_count")),
                    "screener_source": f"most_actives_{by}",
                }
            )
        return rows

    def _latest_minute_bars(self, symbols: list[str]) -> dict[str, dict]:
        return {
            symbol: bars[0]
            for symbol, bars in self._recent_minute_bars(symbols, limit=1).items()
            if bars
        }

    def _recent_minute_bars(self, symbols: list[str], *, limit: int = 10) -> dict[str, list[dict]]:
        if not symbols:
            return {}
        latest: dict[str, list[dict]] = {}
        for start in range(0, len(symbols), 50):
            chunk = symbols[start : start + 50]
            params = {
                "symbols": ",".join(chunk),
                "timeframe": "1Min",
                "limit": max(100, len(chunk) * limit),
                "adjustment": "raw",
                "feed": self.feed,
                "sort": "desc",
            }
            next_page_token: str | None = None
            for _ in range(ALPACA_MULTI_SYMBOL_BAR_MAX_PAGES):
                page_params = dict(params)
                if next_page_token:
                    page_params["page_token"] = next_page_token
                try:
                    payload = self._request("/v2/stocks/bars", page_params)
                except MarketDataUnavailableError as exc:
                    self._last_data_error = _friendly_data_error(str(exc), feed=self.feed)
                    break
                for symbol, bars in (payload.get("bars") or {}).items():
                    if bars:
                        normalized = symbol.upper()
                        latest[normalized] = _sort_bars_desc([*(latest.get(normalized) or []), *bars])[:limit]
                if all(latest.get(symbol.upper()) for symbol in chunk):
                    break
                next_page_token = payload.get("next_page_token")
                if not next_page_token:
                    break
            missing_symbols = [
                symbol
                for symbol in chunk
                if not latest.get(symbol.upper())
            ]
            for symbol in missing_symbols[:ALPACA_MAX_INDIVIDUAL_BAR_FALLBACK_SYMBOLS]:
                try:
                    payload = self._request(
                        "/v2/stocks/bars",
                        {
                            "symbols": symbol.upper(),
                            "timeframe": "1Min",
                            "limit": max(10, limit),
                            "adjustment": "raw",
                            "feed": self.feed,
                            "sort": "desc",
                        },
                    )
                except MarketDataUnavailableError as exc:
                    self._last_data_error = _friendly_data_error(str(exc), feed=self.feed)
                    continue
                bars = (payload.get("bars") or {}).get(symbol.upper()) or []
                if bars:
                    latest[symbol.upper()] = _sort_bars_desc(bars)[:limit]
        return latest

    def _latest_minute_bar(self, symbol: str) -> dict | None:
        try:
            payload = self._request(
                "/v2/stocks/bars",
                {
                    "symbols": symbol.upper(),
                    "timeframe": "1Min",
                    "limit": 1,
                    "adjustment": "raw",
                    "feed": self.feed,
                    "sort": "desc",
                },
            )
        except MarketDataUnavailableError as exc:
            self._last_data_error = _friendly_data_error(str(exc), feed=self.feed)
            return None
        bars = (payload.get("bars") or {}).get(symbol.upper()) or []
        return bars[0] if bars else None

    def _snapshots(self, symbols: list[str]) -> dict:
        if not symbols:
            return {}
        snapshots: dict[str, dict] = {}
        for start in range(0, len(symbols), 50):
            chunk = symbols[start : start + 50]
            payload = self._request(
                "/v2/stocks/snapshots",
                {"symbols": ",".join(chunk), "feed": self.feed},
            )
            snapshots.update(payload.get("snapshots") or {})
        return snapshots

    def _bars(self, *, symbol: str, timeframe: str, limit: int, extra: dict | None = None) -> list[dict]:
        latest_intraday = timeframe.endswith("Min") and not extra
        params = {
            "symbols": symbol,
            "timeframe": timeframe,
            "limit": limit,
            "adjustment": "raw",
            "feed": self.feed,
            "sort": "desc" if latest_intraday else "asc",
        }
        if extra:
            params.update(extra)
        payload = self._request("/v2/stocks/bars", params)
        rows = (payload.get("bars") or {}).get(symbol, [])
        if latest_intraday:
            rows = list(reversed(rows))
        return [_bar_to_kis_shape(symbol, row) for row in rows]

    def _ensure_credentials(self) -> None:
        if not self.settings.alpaca_key or not self.settings.alpaca_secret:
            raise MarketDataUnavailableError("ALPACA_KEY/ALPACA_SECRET이 설정되어 있지 않습니다.")


def _bar_to_kis_shape(symbol: str, row: dict) -> dict:
    market_date, market_time, korea_date, korea_time = _split_timestamp(row.get("t"))
    return {
        "symb": symbol,
        "xymd": market_date,
        "xhms": market_time,
        "kymd": korea_date,
        "khms": korea_time,
        "open": row.get("o"),
        "high": row.get("h"),
        "low": row.get("l"),
        "last": row.get("c"),
        "evol": row.get("v"),
        "eamt": (_to_float(row.get("c")) or 0) * (_to_float(row.get("v")) or 0),
    }


def _bar_event_to_candle(event: dict) -> dict:
    market_date, market_time, korea_date, korea_time = _split_timestamp(event.get("received_at"))
    return {
        "symbol": event.get("symbol"),
        "market_date": market_date,
        "market_time": market_time,
        "korea_date": korea_date,
        "korea_time": korea_time,
        "open": event.get("open"),
        "high": event.get("high"),
        "low": event.get("low"),
        "close": event.get("close"),
        "volume": event.get("volume"),
        "source": "alpaca_bar",
    }


def _split_timestamp(value: str | None) -> tuple[str | None, str | None, str | None, str | None]:
    parsed = _parse_dt(value)
    if parsed is None:
        return None, None, None, None
    utc = parsed.astimezone(timezone.utc)
    kst = utc + timedelta(hours=9)
    return (
        utc.strftime("%Y%m%d"),
        utc.strftime("%H%M%S"),
        kst.strftime("%Y%m%d"),
        kst.strftime("%H%M%S"),
    )


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    if value.endswith("Z"):
        value = f"{value[:-1]}+00:00"
    if "." in value:
        head, tail = value.split(".", 1)
        fraction = tail
        zone = ""
        for marker in ("+", "-"):
            if marker in tail:
                fraction, zone = tail.split(marker, 1)
                zone = marker + zone
                break
        value = f"{head}.{fraction[:6]}{zone}"
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _age_seconds(value: str | None) -> float | None:
    parsed = _parse_dt(value)
    if parsed is None:
        return None
    return (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds()


def _sort_bars_desc(rows: list[dict]) -> list[dict]:
    return sorted(rows, key=lambda row: _parse_dt(row.get("t")) or datetime.min.replace(tzinfo=timezone.utc), reverse=True)


def _merge_active_rows(*row_groups: list[dict]) -> list[dict]:
    by_symbol: dict[str, dict] = {}
    order: list[str] = []
    for rows in row_groups:
        for row in rows:
            symbol = str(row.get("symb") or "").upper()
            if not symbol:
                continue
            if symbol not in by_symbol:
                by_symbol[symbol] = {"symb": symbol}
                order.append(symbol)
            item = by_symbol[symbol]
            for key in ("volume", "trade_count"):
                value = _to_float(row.get(key))
                if value is not None:
                    item[key] = max(_to_float(item.get(key)) or 0.0, value)
            for key in ("mover_side", "mover_rank", "mover_change", "mover_change_pct"):
                if item.get(key) is None and row.get(key) is not None:
                    item[key] = row.get(key)
            sources = set(str(item.get("screener_source") or "").split(",") if item.get("screener_source") else [])
            source = str(row.get("screener_source") or "").strip()
            if source:
                sources.add(source)
            item["screener_source"] = ",".join(sorted(sources))
    return [by_symbol[symbol] for symbol in order]


def _rank_mover_seed_rows(rows: list[dict]) -> list[dict]:
    ranked = sorted(
        rows,
        key=lambda row: (
            -abs(_to_float(row.get("mover_change_pct")) or 0.0),
            _mover_rank_value(row),
            row.get("symb") or "",
        ),
    )
    output = []
    for index, row in enumerate(ranked, start=1):
        item = dict(row)
        item["mover_abs_change_pct"] = abs(_to_float(row.get("mover_change_pct")) or 0.0)
        item["mover_abs_rank"] = index
        output.append(item)
    return output


def _passes_mover_seed_volume_floor(row: dict, settings: Settings) -> bool:
    volume_1m = _to_float(row.get("volume_1m"))
    volume_10m = _to_float(row.get("volume_10m"))
    min_1m = max(100.0, _to_float(settings.scanner_min_1m_volume) or 0.0)
    min_10m = max(1_000.0, _to_float(settings.scanner_min_10m_volume) or 0.0)
    return bool(
        (volume_1m is not None and volume_1m >= min_1m)
        or (volume_10m is not None and volume_10m >= min_10m)
    )


def _bar_notional(row: dict) -> float | None:
    close = _to_float(row.get("c"))
    volume = _to_float(row.get("v"))
    if close is None or volume is None:
        return None
    return close * volume


def _sum_bar_volume(rows: list[dict]) -> float | None:
    values = [_to_float(row.get("v")) for row in rows]
    values = [value for value in values if value is not None]
    return sum(values) if values else None


def _sum_bar_notional(rows: list[dict]) -> float | None:
    values = [_bar_notional(row) for row in rows]
    values = [value for value in values if value is not None]
    return sum(values) if values else None


def _notional_velocity_1m(rows_desc: list[dict]) -> float | None:
    if not rows_desc:
        return None
    latest = _bar_notional(rows_desc[0])
    previous_values = [_bar_notional(row) for row in rows_desc[1:]]
    previous_values = [value for value in previous_values if value is not None]
    if latest is None or not previous_values:
        return None
    previous_average = sum(previous_values) / len(previous_values)
    if previous_average <= 0:
        return None
    return latest / previous_average


def _bar_change_pct(row: dict) -> float | None:
    open_price = _to_float(row.get("o"))
    close = _to_float(row.get("c"))
    if open_price is None or close is None or open_price <= 0:
        return None
    return (close - open_price) / open_price * 100.0


def _bars_change_pct(rows_desc: list[dict]) -> float | None:
    if not rows_desc:
        return None
    latest_close = _to_float(rows_desc[0].get("c"))
    oldest = rows_desc[-1]
    base = _to_float(oldest.get("o")) or _to_float(oldest.get("c"))
    if latest_close is None or base is None or base <= 0:
        return None
    return (latest_close - base) / base * 100.0


def _rank_scanner_rows(rows: list[dict]) -> list[dict]:
    if not rows:
        return []
    notional_sorted = sorted(rows, key=lambda row: (-(row.get("notional_10m") or 0), row.get("symb") or ""))
    recent_notional_sorted = sorted(rows, key=lambda row: (-(row.get("notional_1m") or 0), row.get("symb") or ""))
    velocity_sorted = sorted(rows, key=lambda row: (-(row.get("notional_velocity_10s") or 0), row.get("symb") or ""))
    trade_count_sorted = sorted(rows, key=lambda row: (-(row.get("trade_count") or 0), row.get("symb") or ""))
    mover_sorted = sorted(rows, key=lambda row: (_mover_rank_value(row), row.get("symb") or ""))
    momentum_sorted = sorted(rows, key=lambda row: (-abs(row.get("change_10m_pct") or 0), row.get("symb") or ""))
    recent_momentum_sorted = sorted(rows, key=lambda row: (-abs(row.get("change_1m_pct") or 0), row.get("symb") or ""))
    notional_rank = {row["symb"]: index for index, row in enumerate(notional_sorted, start=1)}
    recent_notional_rank = {row["symb"]: index for index, row in enumerate(recent_notional_sorted, start=1)}
    velocity_rank = {row["symb"]: index for index, row in enumerate(velocity_sorted, start=1)}
    trade_count_rank = {row["symb"]: index for index, row in enumerate(trade_count_sorted, start=1)}
    mover_rank = {row["symb"]: index for index, row in enumerate(mover_sorted, start=1)}
    momentum_rank = {row["symb"]: index for index, row in enumerate(momentum_sorted, start=1)}
    recent_momentum_rank = {row["symb"]: index for index, row in enumerate(recent_momentum_sorted, start=1)}
    total = max(len(rows), 1)
    ranked = []
    for row in rows:
        symbol = row.get("symb")
        liquidity_impulse_score = (
            _rank_percent(velocity_rank.get(symbol), total) * 0.35
            + _rank_percent(recent_momentum_rank.get(symbol), total) * 0.30
            + _rank_percent(mover_rank.get(symbol), total) * 0.20
            + _rank_percent(trade_count_rank.get(symbol), total) * 0.10
            + _rank_percent(momentum_rank.get(symbol), total) * 0.05
        )
        score = liquidity_impulse_score
        item = dict(row)
        item["scanner_score"] = round(score, 4)
        item["volume_score"] = round(score, 4)
        item["liquidity_impulse_score"] = round(liquidity_impulse_score, 4)
        item["liquidity_rank"] = recent_notional_rank.get(symbol)
        item["trade_notional_rank"] = notional_rank.get(symbol)
        item["mover_rank"] = _to_float(row.get("mover_rank"))
        item["recent_liquidity_rank"] = None
        ranked.append(item)
    return sorted(ranked, key=lambda row: (-float(row.get("scanner_score") or 0), row.get("symb") or ""))


def _mover_rank_value(row: dict) -> float:
    rank = _to_float(row.get("mover_rank"))
    if rank is None:
        return 9999.0
    return rank


def _rank_percent(rank: int | None, total: int) -> float:
    if rank is None:
        return 0.0
    if total <= 1:
        return 100.0
    return max(0.0, (total - rank) / (total - 1) * 100.0)


def _dedupe_limits(values: list[int]) -> list[int]:
    output: list[int] = []
    for value in values:
        normalized = max(1, int(value))
        if normalized not in output:
            output.append(normalized)
    return output


def _screener_payload_fresh(payload: dict, settings: Settings) -> bool:
    last_updated = _parse_dt(str(payload.get("last_updated") or ""))
    if last_updated is None:
        return True
    max_age_sec = max(
        ALPACA_SCREENER_MAX_STALE_SEC,
        int(settings.scanner_max_latest_bar_age_sec or 0) * 2,
    )
    return (datetime.now(timezone.utc) - last_updated).total_seconds() <= max_age_sec


def _latest_timestamp(*values: str | None) -> str | None:
    parsed_values = [
        (parsed, value)
        for value in values
        if value and (parsed := _parse_dt(value)) is not None
    ]
    if not parsed_values:
        return None
    return max(parsed_values, key=lambda item: item[0])[1]


def _midpoint(bid: float | None, ask: float | None) -> float | None:
    if bid is None or ask is None:
        return None
    if bid <= 0 or ask <= 0:
        return None
    return (bid + ask) / 2


def _friendly_data_error(message: str, *, feed: str) -> str:
    normalized = message.lower()
    if "subscription does not permit" in normalized and "sip" in normalized:
        return f"Alpaca {feed.upper()} 최신 SIP 데이터 권한이 없어 snapshot/1분봉 조회가 차단됐습니다."
    if "403" in normalized:
        return f"Alpaca {feed.upper()} 데이터 권한 오류로 최신 snapshot/1분봉 조회가 차단됐습니다."
    return message[:220]


def _system_error_message(payload: Any) -> str | None:
    rows = payload if isinstance(payload, list) else [payload]
    for row in rows:
        if not isinstance(row, dict):
            continue
        if row.get("T") == "error":
            code = row.get("code")
            message = row.get("msg") or row.get("message") or "Alpaca WebSocket error"
            return f"Alpaca WebSocket error {code}: {message}" if code is not None else str(message)
    return None


def _empty_flow(symbol: str) -> dict:
    return {
        "symbol": symbol,
        "quote": None,
        "trade": None,
        "volume_10s": 0.0,
        "volume_prev_10s": 0.0,
        "volume_30s": 0.0,
        "volume_60s": 0.0,
        "aggressive_buy_volume": 0.0,
        "aggressive_sell_volume": 0.0,
        "unknown_trade_volume": 0.0,
        "volume_velocity_10s": None,
        "trade_strength": None,
        "sell_pressure": None,
        "spread_pct": None,
        "bid_ask_imbalance": None,
        "last_update_age_sec": None,
    }


FUND_LIKE_NAME_KEYWORDS = (
    " ETF",
    "ETFS",
    " ETN",
    " ETNS",
    "EXCHANGE TRADED",
    "FUND",
    "TRUST",
    "PROSHARES",
    "DIREXION",
    "ISHARES",
    "SPDR",
    "VANGUARD",
    "INVESCO QQQ",
    "ULTRAPRO",
    "ULTRA ",
    "2X",
    "3X",
    "INVERSE",
    "SHORT ",
    "TREASURY",
    "FUTURES",
    "COMMODITY",
    "VOLATILITY",
    " WARRANT",
    "WARRANTS",
    " RIGHT",
    "RIGHTS",
    " UNIT",
    "UNITS",
    "REDEEMABLE",
)


NON_COMMON_STOCK_DOT_SUFFIXES = (
    ".W",
    ".WS",
    ".WT",
    ".RT",
    ".R",
    ".U",
    ".UN",
)


def _asset_fields(asset: dict) -> dict:
    return {
        "company_name": asset.get("name"),
        "asset_class": asset.get("class") or asset.get("asset_class"),
        "asset_status": asset.get("status"),
        "asset_exchange": asset.get("exchange"),
        "asset_tradable": asset.get("tradable"),
    }


def _is_allowed_common_stock(symbol: str, asset: dict | None, settings: Settings) -> bool:
    normalized = str(symbol or "").strip().upper()
    excluded = {
        item.strip().upper()
        for item in settings.scanner_excluded_symbols.split(",")
        if item.strip()
    }
    if not normalized or normalized in excluded:
        return False
    if not settings.scanner_exclude_fund_like_symbols:
        return True
    if _looks_like_non_common_stock_symbol(normalized):
        return False
    if not asset:
        return True
    asset_class = str(asset.get("class") or asset.get("asset_class") or "").lower()
    if asset_class and asset_class != "us_equity":
        return False
    status = str(asset.get("status") or "").lower()
    if status and status != "active":
        return False
    if asset.get("tradable") is False:
        return False
    name = f" {str(asset.get('name') or '').upper()} "
    return not any(keyword in name for keyword in FUND_LIKE_NAME_KEYWORDS)


def _looks_like_non_common_stock_symbol(symbol: str) -> bool:
    if any(symbol.endswith(suffix) for suffix in NON_COMMON_STOCK_DOT_SUFFIXES):
        return True
    if len(symbol) >= 5 and symbol.endswith(("W", "WS", "WT", "WW")):
        return True
    return False


def _has_active_paper_position(symbol: str | None) -> bool:
    symbol = str(symbol or "").upper()
    if not symbol:
        return False
    try:
        from app.services.paper_broker import InternalPaperBroker

        positions = InternalPaperBroker().state().get("positions", [])
    except Exception:
        return False
    for position in positions:
        quantity = _to_float(position.get("quantity")) or 0.0
        if str(position.get("symbol") or "").upper() == symbol and quantity > 0:
            return True
    return False


def _to_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _spread_pct(bid: float | None, ask: float | None) -> float | None:
    if not bid or not ask:
        return None
    midpoint = (bid + ask) / 2
    return (ask - bid) / midpoint * 100 if midpoint > 0 else None


def _imbalance(bid_depth: float | None, ask_depth: float | None) -> float | None:
    if bid_depth is None or ask_depth is None:
        return None
    total = bid_depth + ask_depth
    return bid_depth / total if total > 0 else None


def _trade_side(*, price: float | None, quote: dict | None, previous_price: float | None) -> str:
    if price is None:
        return "unknown"
    bid = _to_float((quote or {}).get("bid"))
    ask = _to_float((quote or {}).get("ask"))
    if ask and price >= ask:
        return "buy"
    if bid and price <= bid:
        return "sell"
    if previous_price is not None:
        if price > previous_price:
            return "buy"
        if price < previous_price:
            return "sell"
    return "unknown"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _redact_url(value: str) -> str:
    return value.split("?")[0]
