from dataclasses import dataclass


@dataclass(frozen=True)
class RateLimitPolicy:
    endpoint_key: str
    capacity: int
    refill_per_sec: float
    source: str = "TODO_KIS_VERIFY: official KIS limit required"


DEFAULT_POLICIES: dict[str, RateLimitPolicy] = {}
