from functools import lru_cache

from app.adapters.market_data.alpaca import AlpacaMarketDataProvider
from app.adapters.market_data.external_stub import ExternalMarketDataStub
from app.adapters.market_data.kis_legacy import KisLegacyMarketDataProvider
from app.adapters.market_data.toss import TossMarketDataProvider
from app.core.config import get_settings


class MarketDataService:
    def __init__(self) -> None:
        settings = get_settings()
        self.settings = settings
        if settings.market_data_provider == "toss" or (
            settings.market_data_provider == "external_stub" and settings.toss_app_key and settings.toss_app_secret
        ):
            self.provider = TossMarketDataProvider(settings)
        elif settings.market_data_provider == "alpaca" or (
            settings.market_data_provider == "external_stub" and settings.alpaca_key and settings.alpaca_secret
        ):
            self.provider = AlpacaMarketDataProvider(settings)
        elif settings.market_data_provider == "kis_legacy":
            self.provider = KisLegacyMarketDataProvider()
        else:
            self.provider = ExternalMarketDataStub(settings)

    @property
    def provider_name(self) -> str:
        return self.provider.provider_name

    def status(self) -> dict:
        status = self.provider.status()
        status["role"] = "primary_market_data"
        status["kis_market_data_fallback_enabled"] = self.settings.kis_market_data_fallback_enabled
        return status


@lru_cache
def get_market_data_service() -> MarketDataService:
    return MarketDataService()
