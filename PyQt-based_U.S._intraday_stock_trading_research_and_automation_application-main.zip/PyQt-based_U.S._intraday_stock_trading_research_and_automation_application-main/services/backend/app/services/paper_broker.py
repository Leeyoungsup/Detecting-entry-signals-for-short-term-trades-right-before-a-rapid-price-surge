from datetime import datetime, timezone
from threading import RLock
from uuid import uuid4

from app.core.config import get_settings
from app.domain.enums import OrderState, StatusLevel
from app.domain.models import Fill, OrderEvent, OrderRequest, Position
from app.services.event_log import record_event
from app.services.fee_model import toss_fee_breakdown
from app.services import shared_state

_orders: dict[str, dict] = {}
_positions: dict[str, Position] = {}
_timeline: list[OrderEvent] = []
_fills: list[Fill] = []
_closed_trades: list[dict] = []
_state_lock = RLock()
PAPER_STATE_KEY = "trading_lab:paper:state"
LEGACY_PAPER_STATE_KEY = "kis:paper:state"
_shared_state_updated_at: str | None = None

OPEN_ORDER_STATES = {
    OrderState.CREATED,
    OrderState.RISK_CHECKED,
    OrderState.SUBMITTED,
    OrderState.ACKNOWLEDGED,
}


class InternalPaperBroker:
    def submit_order(self, request: OrderRequest, market_snapshot: dict | None = None) -> tuple[str, list[OrderEvent]]:
        _hydrate_state()
        if request.mode != "internal_paper":
            raise ValueError("Simulation broker only accepts internal_paper orders")
        order_id = str(uuid4())
        closed_trade_start = len(_closed_trades)
        events = [
            self._event(
                order_id=order_id,
                previous_state=None,
                new_state=OrderState.CREATED,
                source="internal_paper",
                message="Paper order created; no external order API was called.",
                payload=request.model_dump(),
            ),
        ]
        risk_reject = _paper_open_risk_reject_payload(request, market_snapshot or {})
        if risk_reject:
            final_state = OrderState.REJECTED
            fill = None
            events.append(
                self._event(
                    order_id=order_id,
                    previous_state=OrderState.CREATED,
                    new_state=OrderState.REJECTED,
                    source="risk_manager",
                    message="Paper risk hard cap blocked the order.",
                    payload=risk_reject,
                )
            )
        else:
            events.extend(
                [
                    self._event(
                        order_id=order_id,
                        previous_state=OrderState.CREATED,
                        new_state=OrderState.RISK_CHECKED,
                        source="risk_manager",
                        message="Paper-only risk check passed.",
                    ),
                    self._event(
                        order_id=order_id,
                        previous_state=OrderState.RISK_CHECKED,
                        new_state=OrderState.SUBMITTED,
                        source="paper_execution_gateway",
                        message="Order submitted to the simulation broker.",
                    ),
                    self._event(
                        order_id=order_id,
                        previous_state=OrderState.SUBMITTED,
                        new_state=OrderState.ACKNOWLEDGED,
                        source="paper_execution_gateway",
                        message="Simulation broker acknowledged order.",
                    ),
                ]
            )
            final_state, fill = self._simulate_fill(order_id, request, market_snapshot or {})
        if fill:
            _fills.append(fill)
            self._apply_fill(fill, request=request, market_snapshot=market_snapshot or {})
            events.append(
                self._event(
                    order_id=order_id,
                    previous_state=OrderState.ACKNOWLEDGED,
                    new_state=final_state,
                    source="paper_fill_model",
                    message="보수적 paper 체결 모델이 체결을 생성했습니다.",
                    payload=fill.model_dump(),
                )
            )
        elif not risk_reject:
            events.append(
                self._event(
                    order_id=order_id,
                    previous_state=OrderState.ACKNOWLEDGED,
                    new_state=final_state,
                    source="paper_fill_model",
                    message="지정가/호가 조건 미충족으로 시뮬레이션 주문을 만료 처리했습니다.",
                    payload={"market_snapshot": market_snapshot or {}},
                )
            )
        _orders[order_id] = {
            "order_id": order_id,
            "request": request.model_dump(),
            "state": final_state,
            "market_snapshot": market_snapshot or {},
            "filled_quantity": fill.quantity if fill else 0,
            "average_fill_price": fill.price if fill else None,
        }
        for event in events:
            _timeline.append(event)
            record_event(
                level="INFO",
                event_type="paper.order_event",
                message=event.message or str(event.new_state),
                severity=StatusLevel.NORMAL if event.new_state not in (OrderState.REJECTED, OrderState.ERROR) else StatusLevel.BLOCKED,
                symbol=request.symbol,
                order_id=order_id,
                payload=event.model_dump(mode="json"),
            )
        _persist_state()
        _persist_order_audit(
            order_id=order_id,
            request=request,
            events=events,
            fill=fill,
            market_snapshot=market_snapshot or {},
            closed_trades=_closed_trades[closed_trade_start:],
        )
        return order_id, events

    def state(self) -> dict:
        with _state_lock:
            _hydrate_state()
            return {
                "orders": [
                    {**order, "state": str(order["state"])}
                    for order in _orders.values()
                ],
                "positions": [position.model_dump() for position in _positions.values()],
                "timeline": [event.model_dump(mode="json") for event in _timeline[-200:]],
                "fills": [fill.model_dump() for fill in _fills[-200:]],
                "closed_trades": _closed_trades[-200:],
            }

    def reset(self) -> dict:
        _hydrate_state()
        cleared = {
            "orders": len(_orders),
            "positions": len(_positions),
            "timeline": len(_timeline),
            "fills": len(_fills),
            "closed_trades": len(_closed_trades),
        }
        _orders.clear()
        _positions.clear()
        _timeline.clear()
        _fills.clear()
        _closed_trades.clear()
        record_event(
            level="INFO",
            event_type="paper.reset",
            message="시뮬레이션 주문/포지션/타임라인을 초기화했습니다.",
            severity=StatusLevel.NORMAL,
            payload={"cleared": cleared},
        )
        _persist_state()
        return {"cleared": cleared}

    def has_exposure(self, symbol: str, parameter_set_id: str | None = None) -> bool:
        _hydrate_state()
        symbol = symbol.upper()
        position_key = _position_key(symbol, parameter_set_id) if parameter_set_id else None
        if position_key and position_key in _positions and _positions[position_key].quantity > 0:
            return True
        if not position_key and any(position.symbol.upper() == symbol and position.quantity > 0 for position in _positions.values()):
            return True
        return any(
            order["request"]["symbol"].upper() == symbol
            and (not parameter_set_id or _order_parameter_set_id(order) == parameter_set_id)
            and order["state"] in OPEN_ORDER_STATES
            for order in _orders.values()
        )

    def position(self, symbol: str, position_key: str | None = None, parameter_set_id: str | None = None) -> Position | None:
        _hydrate_state()
        if position_key:
            return _positions.get(position_key)
        if parameter_set_id:
            return _positions.get(_position_key(symbol, parameter_set_id))
        return next((position for position in _positions.values() if position.symbol.upper() == symbol.upper()), None)

    def positions_for_symbol(self, symbol: str) -> list[Position]:
        _hydrate_state()
        symbol = symbol.upper()
        return [position for position in _positions.values() if position.symbol.upper() == symbol and position.quantity > 0]

    def update_position(self, position: Position) -> None:
        _hydrate_state()
        key = position.position_key or _position_key(position.symbol, position.parameter_set_id)
        if position.quantity <= 0:
            _positions.pop(key, None)
            _persist_state()
            return
        position.position_key = key
        _positions[key] = position
        _persist_state()

    def _simulate_fill(
        self,
        order_id: str,
        request: OrderRequest,
        market_snapshot: dict,
    ) -> tuple[OrderState, Fill | None]:
        side = request.side.lower()
        if request.quantity <= 0:
            return OrderState.REJECTED, None
        if side not in ("buy", "sell"):
            return OrderState.REJECTED, None
        position_side = (request.position_side or "long").lower()
        # Close = the order that unwinds an existing position (long->sell, short->buy).
        # Open = the order that establishes/adds (long->buy, short->sell).
        is_close = (position_side == "long" and side == "sell") or (position_side == "short" and side == "buy")

        ask = _to_float(market_snapshot.get("ask"))
        bid = _to_float(market_snapshot.get("bid"))
        last = _to_float(market_snapshot.get("last"))
        spread_pct = _to_float(market_snapshot.get("spread_pct"))
        reference = (ask if side == "buy" else bid) or last or ask or bid or request.limit_price
        if reference is None:
            return OrderState.EXPIRED, None

        limit_price = request.limit_price or (reference * 1.001 if side == "buy" else reference * 0.999)
        if side == "buy" and ask is not None and limit_price < ask:
            return OrderState.EXPIRED, None
        if side == "sell" and bid is not None and limit_price > bid:
            return OrderState.EXPIRED, None
        if is_close:
            position = _positions.get(_market_position_key(request.symbol, market_snapshot))
            if not position or position.quantity <= 0:
                return OrderState.REJECTED, None

        slippage_bps = 5.0 if spread_pct is None or spread_pct <= 0.08 else 10.0
        if side == "buy":
            conservative_price = min(limit_price, reference * (1 + slippage_bps / 10000))
        else:
            conservative_price = max(limit_price, reference * (1 - slippage_bps / 10000))
        quantity = request.quantity
        if is_close:
            quantity = min(quantity, _positions[_market_position_key(request.symbol, market_snapshot)].quantity)
        final_state = OrderState.FILLED
        if (not is_close) and spread_pct is not None and spread_pct > 0.08 and quantity >= 2:
            quantity = max(1.0, quantity // 2)
            final_state = OrderState.PARTIALLY_FILLED
        return final_state, Fill(
            order_id=order_id,
            symbol=request.symbol,
            side=side,
            quantity=quantity,
            price=conservative_price,
            slippage_bps=slippage_bps,
            broker_fill_id=f"paper-{order_id[:8]}",
        )

    def _apply_fill(self, fill: Fill, *, request: OrderRequest, market_snapshot: dict) -> None:
        position_side = (request.position_side or "long").lower()
        is_close = (position_side == "long" and fill.side == "sell") or (position_side == "short" and fill.side == "buy")
        if is_close:
            position_key = _market_position_key(fill.symbol, market_snapshot)
            existing = _positions.get(position_key)
            if not existing:
                return
            direction = (existing.direction or "long").lower()
            remaining = existing.quantity - fill.quantity
            if direction == "short":
                # short profits when the cover price is below the entry
                realized_pnl = (existing.average_price - fill.price) * fill.quantity
            else:
                realized_pnl = (fill.price - existing.average_price) * fill.quantity
            close_ratio = min(1.0, fill.quantity / existing.quantity) if existing.quantity > 0 else 1.0
            allocated_entry_fees = existing.entry_fees_usd * close_ratio
            # close fee side follows the fill: long close = sell, short cover = buy
            exit_fee_breakdown = _fee_breakdown(side=fill.side, quantity=fill.quantity, price=fill.price)
            exit_fees = exit_fee_breakdown["total_fees_usd"]
            fees_usd = allocated_entry_fees + exit_fees
            net_pnl = realized_pnl - fees_usd
            _closed_trades.append(
                {
                    "symbol": fill.symbol,
                    "position_key": existing.position_key,
                    "direction": direction,
                    "strategy_name": existing.strategy_name or existing.entry_snapshot.get("strategy_name"),
                    "parameter_set_id": existing.parameter_set_id or existing.entry_snapshot.get("parameter_set_id"),
                    "entry_mode": existing.entry_mode or existing.entry_snapshot.get("entry_mode"),
                    "quantity": fill.quantity,
                    "entry_price": existing.average_price,
                    "exit_price": fill.price,
                    "gross_pnl_usd": realized_pnl,
                    "entry_fees_usd": allocated_entry_fees,
                    "exit_fees_usd": exit_fees,
                    "fees_usd": fees_usd,
                    "net_pnl_usd": net_pnl,
                    "fee_breakdown": {
                        "entry_allocated_usd": allocated_entry_fees,
                        "exit": exit_fee_breakdown,
                    },
                    "exit_reason": market_snapshot.get("exit_reason") or request.strategy_signal_id,
                    "entry_snapshot": existing.entry_snapshot,
                    "exit_snapshot": _compact_exit_snapshot(market_snapshot),
                    "closed_at": _utc_now().isoformat(),
                    "mode": existing.mode,
                }
            )
            if remaining <= 0:
                _positions.pop(position_key, None)
                return
            # Partial close: keep every field (direction, watermarks, exit plan)
            # and only reduce quantity and the still-allocated entry fees.
            _positions[position_key] = existing.model_copy(
                update={
                    "quantity": remaining,
                    "entry_fees_usd": max(0.0, existing.entry_fees_usd - allocated_entry_fees),
                }
            )
            return
        is_short = position_side == "short"
        exit_plan = market_snapshot.get("exit_plan") if isinstance(market_snapshot.get("exit_plan"), dict) else {}
        if is_short:
            # short: hard stop sits ABOVE entry; take-profit targets sit BELOW.
            stop_loss_price = _to_float(exit_plan.get("stop_loss_price")) or fill.price * 1.035
            take_profit_price = _to_float(exit_plan.get("take_profit_price")) or fill.price * 0.97
            partial_take_profit_price = _to_float(exit_plan.get("partial_take_profit_price")) or fill.price * 0.996
            trailing_activation_price = _to_float(exit_plan.get("trailing_activation_price")) or fill.price * 0.997
        else:
            stop_loss_price = _to_float(exit_plan.get("stop_loss_price")) or fill.price * 0.995
            take_profit_price = _to_float(exit_plan.get("take_profit_price")) or fill.price * 1.008
            partial_take_profit_price = _to_float(exit_plan.get("partial_take_profit_price")) or fill.price * 1.004
            trailing_activation_price = _to_float(exit_plan.get("trailing_activation_price")) or fill.price * 1.003
        dynamic_take_profit_price = _to_float(exit_plan.get("dynamic_take_profit_price")) or take_profit_price
        trailing_stop_price = _to_float(exit_plan.get("trailing_stop_price"))
        entry_snapshot = _compact_entry_snapshot(market_snapshot)
        parameter_set_id = entry_snapshot.get("parameter_set_id") or request.strategy_signal_id or "manual"
        position_key = _position_key(fill.symbol, str(parameter_set_id))
        existing = _positions.get(position_key)
        # open fee side follows the fill: long open = buy, short open = sell
        entry_fee_breakdown = _fee_breakdown(side=fill.side, quantity=fill.quantity, price=fill.price)
        entry_fees = entry_fee_breakdown["total_fees_usd"]
        if not existing:
            _positions[position_key] = Position(
                position_key=position_key,
                symbol=fill.symbol,
                strategy_name=entry_snapshot.get("strategy_name"),
                parameter_set_id=str(parameter_set_id),
                entry_mode=entry_snapshot.get("entry_mode"),
                direction=position_side,
                quantity=fill.quantity,
                average_price=fill.price,
                entry_fees_usd=entry_fees,
                mode="internal_paper",
                opened_at=_utc_now(),
                stop_loss_price=stop_loss_price,
                take_profit_price=take_profit_price,
                dynamic_take_profit_price=dynamic_take_profit_price,
                dynamic_take_profit_reason="entry_plan",
                dynamic_take_profit_updated_at=_utc_now(),
                partial_take_profit_price=partial_take_profit_price,
                trailing_stop_price=trailing_stop_price,
                trailing_activation_price=trailing_activation_price,
                high_watermark=None if is_short else fill.price,
                low_watermark=fill.price if is_short else None,
                exit_plan=exit_plan,
                entry_snapshot=entry_snapshot,
            )
            return
        total_quantity = existing.quantity + fill.quantity
        average_price = (
            (existing.average_price * existing.quantity) + (fill.price * fill.quantity)
        ) / total_quantity
        if is_short:
            merged_stop = max(existing.stop_loss_price or stop_loss_price, stop_loss_price)
            merged_take_profit = min(existing.take_profit_price or take_profit_price, take_profit_price)
            merged_dynamic_tp = min(existing.dynamic_take_profit_price or merged_take_profit, dynamic_take_profit_price)
        else:
            merged_stop = min(existing.stop_loss_price or stop_loss_price, stop_loss_price)
            merged_take_profit = max(existing.take_profit_price or take_profit_price, take_profit_price)
            merged_dynamic_tp = max(existing.dynamic_take_profit_price or merged_take_profit, dynamic_take_profit_price)
        _positions[position_key] = Position(
            position_key=position_key,
            symbol=fill.symbol,
            strategy_name=existing.strategy_name,
            parameter_set_id=existing.parameter_set_id,
            entry_mode=existing.entry_mode,
            direction=position_side,
            quantity=total_quantity,
            average_price=average_price,
            entry_fees_usd=existing.entry_fees_usd + entry_fees,
            mode="internal_paper",
            opened_at=existing.opened_at,
            stop_loss_price=merged_stop,
            take_profit_price=merged_take_profit,
            dynamic_take_profit_price=merged_dynamic_tp,
            dynamic_take_profit_reason=existing.dynamic_take_profit_reason or "entry_plan",
            dynamic_take_profit_updated_at=existing.dynamic_take_profit_updated_at,
            partial_take_profit_price=existing.partial_take_profit_price or partial_take_profit_price,
            partial_exit_done=existing.partial_exit_done,
            trailing_stop_price=existing.trailing_stop_price or trailing_stop_price,
            trailing_activation_price=existing.trailing_activation_price or trailing_activation_price,
            high_watermark=None if is_short else max(existing.high_watermark or average_price, fill.price),
            low_watermark=(min(existing.low_watermark or average_price, fill.price) if is_short else None),
            stop_loss_candidate_since=existing.stop_loss_candidate_since,
            stop_loss_hold_reason=existing.stop_loss_hold_reason,
            last_exit_check_at=existing.last_exit_check_at,
            exit_plan={**exit_plan, **existing.exit_plan},
            entry_snapshot=existing.entry_snapshot or entry_snapshot,
        )

    def _event(
        self,
        *,
        order_id: str,
        previous_state: OrderState | None,
        new_state: OrderState,
        source: str,
        message: str,
        payload: dict | None = None,
    ) -> OrderEvent:
        return OrderEvent(
            order_id=order_id,
            previous_state=previous_state,
            new_state=new_state,
            source=source,
            message=message,
            payload=payload or {},
        )


def _position_key(symbol: str, parameter_set_id: str | None) -> str:
    strategy_key = str(parameter_set_id or "manual").strip() or "manual"
    return f"{symbol.upper()}::{strategy_key}"


def _market_position_key(symbol: str, market_snapshot: dict) -> str:
    key = market_snapshot.get("position_key")
    if key:
        return str(key)
    parameter_set_id = market_snapshot.get("parameter_set_id")
    if parameter_set_id:
        return _position_key(symbol, str(parameter_set_id))
    entry_snapshot = market_snapshot.get("entry_snapshot")
    if isinstance(entry_snapshot, dict) and entry_snapshot.get("parameter_set_id"):
        return _position_key(symbol, str(entry_snapshot.get("parameter_set_id")))
    return _position_key(symbol, "manual")


def _order_parameter_set_id(order: dict) -> str | None:
    market_snapshot = order.get("market_snapshot") or {}
    if market_snapshot.get("parameter_set_id"):
        return str(market_snapshot.get("parameter_set_id"))
    entry_snapshot = market_snapshot.get("entry_snapshot")
    if isinstance(entry_snapshot, dict) and entry_snapshot.get("parameter_set_id"):
        return str(entry_snapshot.get("parameter_set_id"))
    request = order.get("request") or {}
    signal_id = request.get("strategy_signal_id")
    if isinstance(signal_id, str) and signal_id:
        return signal_id.split("-")[0]
    return None


def _paper_open_risk_reject_payload(request: OrderRequest, market_snapshot: dict) -> dict | None:
    # Risk hard caps apply to position OPENS only (long buy or short sell); a
    # close/cover never gets blocked by exposure caps.
    position_side = (request.position_side or "long").lower()
    side = request.side.lower()
    is_open = (position_side == "long" and side == "buy") or (position_side == "short" and side == "sell")
    if not is_open:
        return None
    settings = get_settings()
    if not settings.paper_risk_hard_caps_enabled:
        return None
    max_positions = max(1, int(settings.paper_max_open_positions or 1))
    max_exposure_usd = max(0.0, float(settings.paper_initial_equity_usd or 0.0) * float(settings.paper_max_total_exposure_pct or 0.0))
    open_positions = [position for position in _positions.values() if position.quantity > 0]
    position_key = _market_position_key(request.symbol, market_snapshot)
    creates_new_position = position_key not in _positions or _positions[position_key].quantity <= 0
    projected_position_count = len(open_positions) + (1 if creates_new_position else 0)
    if creates_new_position and projected_position_count > max_positions:
        return {
            "reason": "max_open_positions_exceeded",
            "max_open_positions": max_positions,
            "current_open_positions": len(open_positions),
            "projected_open_positions": projected_position_count,
        }

    current_exposure = _paper_total_exposure_usd(open_positions)
    order_notional = _paper_order_notional_usd(request, market_snapshot)
    projected_exposure = current_exposure + order_notional
    if max_exposure_usd > 0 and projected_exposure > max_exposure_usd:
        return {
            "reason": "max_total_exposure_exceeded",
            "max_total_exposure_pct": settings.paper_max_total_exposure_pct,
            "max_total_exposure_usd": round(max_exposure_usd, 4),
            "current_exposure_usd": round(current_exposure, 4),
            "order_notional_usd": round(order_notional, 4),
            "projected_exposure_usd": round(projected_exposure, 4),
        }
    return None


def _paper_total_exposure_usd(positions: list[Position]) -> float:
    return sum(
        max(0.0, float(position.quantity or 0.0)) * max(0.0, float(position.average_price or 0.0))
        for position in positions
    )


def _paper_order_notional_usd(request: OrderRequest, market_snapshot: dict) -> float:
    price = (
        _to_float(market_snapshot.get("ask"))
        or _to_float(market_snapshot.get("last"))
        or _to_float(market_snapshot.get("bid"))
        or _to_float(request.limit_price)
        or 0.0
    )
    return max(0.0, float(request.quantity or 0.0)) * max(0.0, price)


def _to_float(value: str | int | float | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _fee_breakdown(*, side: str, quantity: float, price: float) -> dict:
    return toss_fee_breakdown(side=side, quantity=quantity, price=price)


def _compact_entry_snapshot(market_snapshot: dict) -> dict:
    snapshot = market_snapshot.get("entry_snapshot")
    if isinstance(snapshot, dict):
        return snapshot
    return {
        "strategy_name": market_snapshot.get("strategy_name"),
        "parameter_set_id": market_snapshot.get("parameter_set_id"),
        "entry_mode": market_snapshot.get("entry_mode"),
        "price": market_snapshot.get("strategy_reference_price") or market_snapshot.get("last"),
        "execution_price_source": market_snapshot.get("execution_price_source") or market_snapshot.get("source"),
        "bid": market_snapshot.get("bid"),
        "ask": market_snapshot.get("ask"),
        "spread_pct": market_snapshot.get("spread_pct"),
        "risk_preview": market_snapshot.get("risk_preview"),
        "exit_plan": market_snapshot.get("exit_plan"),
    }


def _compact_exit_snapshot(market_snapshot: dict) -> dict:
    snapshot = market_snapshot.get("exit_snapshot")
    if isinstance(snapshot, dict):
        return snapshot
    return {
        "reason": market_snapshot.get("exit_reason"),
        "price": market_snapshot.get("strategy_reference_last") or market_snapshot.get("last"),
        "bid": market_snapshot.get("strategy_reference_bid") or market_snapshot.get("bid"),
        "ask": market_snapshot.get("strategy_reference_ask") or market_snapshot.get("ask"),
        "spread_pct": market_snapshot.get("strategy_reference_spread_pct") or market_snapshot.get("spread_pct"),
        "execution_price_source": market_snapshot.get("execution_price_source") or market_snapshot.get("source"),
        "indicators": market_snapshot.get("exit_indicators"),
    }


def _persist_state() -> None:
    global _shared_state_updated_at
    _shared_state_updated_at = datetime.now(timezone.utc).isoformat()
    shared_state.set_json(
        PAPER_STATE_KEY,
        {
            "updated_at": _shared_state_updated_at,
            "orders": [{**order, "state": str(order["state"])} for order in _orders.values()],
            "positions": [position.model_dump(mode="json") for position in _positions.values()],
            "timeline": [event.model_dump(mode="json") for event in _timeline[-500:]],
            "fills": [fill.model_dump(mode="json") for fill in _fills[-500:]],
            "closed_trades": _closed_trades[-500:],
        },
        ex=86400,
    )


def _persist_order_audit(
    *,
    order_id: str,
    request: OrderRequest,
    events: list[OrderEvent],
    fill: Fill | None,
    market_snapshot: dict,
    closed_trades: list[dict],
) -> None:
    if not get_settings().paper_order_audit_db_enabled:
        return
    try:
        from app.db.session import SessionLocal
        from app.db.repositories.orders import PaperOrderRepository

        db = SessionLocal()
        try:
            PaperOrderRepository(db).record_order_lifecycle(
                client_order_id=order_id,
                request=request,
                final_state=str(events[-1].new_state),
                events=events,
                fill=fill,
                market_snapshot=market_snapshot,
                closed_trades=closed_trades,
            )
        finally:
            db.close()
    except Exception as exc:
        record_event(
            level="WARNING",
            event_type="paper.persistence_failed",
            message="Paper order audit DB persistence failed; shared_state runtime state remains authoritative.",
            severity=StatusLevel.CAUTION,
            symbol=request.symbol,
            order_id=order_id,
            payload={"error": str(exc)[:300]},
        )


def _hydrate_state() -> None:
    global _shared_state_updated_at
    with _state_lock:
        payload = shared_state.get_json_any(PAPER_STATE_KEY, LEGACY_PAPER_STATE_KEY)
        if not isinstance(payload, dict):
            return
        updated_at = str(payload.get("updated_at") or "")
        if updated_at and updated_at == _shared_state_updated_at:
            return
        if not updated_at and (_orders or _positions or _timeline or _fills or _closed_trades):
            return
        _orders.clear()
        _positions.clear()
        _timeline.clear()
        _fills.clear()
        _closed_trades.clear()
        for row in payload.get("orders") or []:
            if not isinstance(row, dict) or not row.get("order_id"):
                continue
            state = row.get("state")
            try:
                row["state"] = OrderState(str(state))
            except Exception:
                row["state"] = state
            _orders[str(row["order_id"])] = row
        for row in payload.get("positions") or []:
            try:
                position = Position.model_validate(row)
            except Exception:
                continue
            key = position.position_key or _position_key(position.symbol, position.parameter_set_id)
            position.position_key = key
            _positions[key] = position
        for row in payload.get("timeline") or []:
            try:
                _timeline.append(OrderEvent.model_validate(row))
            except Exception:
                continue
        for row in payload.get("fills") or []:
            try:
                _fills.append(Fill.model_validate(row))
            except Exception:
                continue
        for row in payload.get("closed_trades") or []:
            if isinstance(row, dict):
                _closed_trades.append(row)
        _shared_state_updated_at = updated_at or _shared_state_updated_at
