@echo off
setlocal
cd /d "%~dp0"

if exist ".runtime\backend-log.txt" (
  set /p BACKEND_LOG=<".runtime\backend-log.txt"
) else (
  set BACKEND_LOG=logs\backend-8010.log
)

if exist ".runtime\web-log.txt" (
  set /p WEB_LOG=<".runtime\web-log.txt"
) else (
  set WEB_LOG=logs\web-3000.log
)

echo ===== Backend: %BACKEND_LOG% =====
if exist "%BACKEND_LOG%" (
  type "%BACKEND_LOG%"
) else (
  echo Backend log file does not exist yet.
)

echo.
echo ===== Web: %WEB_LOG% =====
if exist "%WEB_LOG%" (
  type "%WEB_LOG%"
) else (
  echo Web log file does not exist yet.
)
