import pytest

from app.core.config import get_settings
from app.domain.models import OrderRequest
from app.services import short_runtime as sr
from app.services.paper_broker import InternalPaperBroker
from app.services.short_runtime import ShortTrackRuntime


@pytest.fixture(autouse=True)
def short_enabled(monkeypatch):
    broker = InternalPaperBroker()
    broker.reset()
    settings = get_settings()
    monkeypatch.setattr(settings, "strategy_short_track_enabled", True)
    monkeypatch.setattr(settings, "trading_mode", "internal_paper")
    monkeypatch.setattr(settings, "strategy_short_max_notional_usd", 300.0)
    yield
    broker.reset()


def _bar(close, *, vol=1000.0, o=None, h=None, low=None):
    return {
        "open": close - 0.01 if o is None else o,
        "high": close + 0.02 if h is None else h,
        "low": close - 0.02 if low is None else low,
        "close": close,
        "volume": vol,
    }


def _blowoff_series():
    rows = [_bar(10.0) for _ in range(16)]
    for price in [10.3, 10.7, 11.2, 11.7, 12.2, 12.6, 13.0, 13.3, 13.6]:
        rows.append(_bar(price))
    # blow-off reversal: new high, close below open near the low, volume spike
    rows.append(_bar(13.7, vol=6000.0, o=14.0, h=14.2, low=13.6))
    return rows


def _mock_market(monkeypatch, *, bid=10.0, ask=10.05, last=10.02, spread_pct=0.5, symbol="SOBR"):
    monkeypatch.setattr(
        sr, "execution_market_snapshot",
        lambda s, side: {"bid": bid, "ask": ask, "last": last, "spread_pct": spread_pct},
    )

    class _Provider:
        def order_flow_snapshot(self):
            return {symbol: {"spread_pct": spread_pct}}

    class _Service:
        provider = _Provider()

    monkeypatch.setattr(sr, "get_market_data_service", lambda: _Service())


# ---------- feature helpers ----------
def test_feature_helpers() -> None:
    rows = [_bar(10.0 + i * 0.1) for i in range(12)]
    # lookback=10 -> change over the last 10 bars (window[0] == rows[-10]), matching replay
    assert sr._recent_10bar_change(rows) == pytest.approx((rows[-1]["close"] - rows[-10]["close"]) / rows[-10]["close"])
    assert sr._bar_close_position(_bar(10.0, o=9.9, h=10.1, low=9.9)) == pytest.approx(0.5)
    assert sr._climax_new_high(rows, 6) is True
    hot = [_bar(10.0, vol=1000) for _ in range(21)] + [_bar(10.0, vol=4000)]
    assert sr._volume_ratio(hot) >= 3.0


def test_blowoff_signal_fires_on_climax_reversal() -> None:
    assert sr._blowoff_signal(_blowoff_series()) is True


# ---------- entry ----------
def test_on_completed_candle_opens_short_position(monkeypatch) -> None:
    _mock_market(monkeypatch)
    ShortTrackRuntime().on_completed_candle("SOBR", "b1", _blowoff_series())

    positions = InternalPaperBroker().state()["positions"]
    assert len(positions) == 1
    assert positions[0]["direction"] == "short"
    assert positions[0]["stop_loss_price"] > positions[0]["average_price"]


def test_short_track_disabled_does_nothing(monkeypatch) -> None:
    monkeypatch.setattr(get_settings(), "strategy_short_track_enabled", False)
    _mock_market(monkeypatch)
    ShortTrackRuntime().on_completed_candle("SOBR", "b1", _blowoff_series())
    assert InternalPaperBroker().state()["positions"] == []


# ---------- exit ----------
def _open_short_directly(broker: InternalPaperBroker, *, stop=10.35):
    broker.submit_order(
        OrderRequest(
            symbol="SOBR", side="sell", position_side="short", quantity=30,
            mode="internal_paper", strategy_signal_id="parabolic_exhaustion_short",
        ),
        market_snapshot={
            "bid": 10.0, "ask": 10.05, "last": 10.02, "spread_pct": 0.02,
            "parameter_set_id": "parabolic_exhaustion_short",
            "entry_snapshot": {"parameter_set_id": "parabolic_exhaustion_short",
                               "strategy_name": "Parabolic Exhaustion Short", "entry_mode": "short"},
            "exit_plan": {"stop_loss_price": stop, "take_profit_price": 9.7},
        },
    )


def test_monitor_covers_short_on_hard_stop(monkeypatch) -> None:
    broker = InternalPaperBroker()
    _open_short_directly(broker)
    monkeypatch.setattr(sr.candle_builder, "latest_price", lambda symbol: 10.40)  # above stop
    monkeypatch.setattr(sr, "execution_market_snapshot",
                        lambda s, side: {"bid": 10.35, "ask": 10.40, "last": 10.38, "spread_pct": 0.02})

    result = ShortTrackRuntime().monitor_short_exits()
    state = InternalPaperBroker().state()
    assert result["covered"] == 1
    assert state["positions"] == []
    assert state["closed_trades"][0]["direction"] == "short"
    assert state["closed_trades"][0]["exit_reason"] == "hard_stop_loss"


def test_monitor_covers_short_on_trailing_after_profit(monkeypatch) -> None:
    broker = InternalPaperBroker()
    _open_short_directly(broker)
    runtime = ShortTrackRuntime()

    # price falls: activates trailing, ratchets the low watermark, no cover yet
    monkeypatch.setattr(sr.candle_builder, "latest_price", lambda symbol: 9.80)
    monkeypatch.setattr(sr, "execution_market_snapshot",
                        lambda s, side: {"bid": 9.78, "ask": 9.82, "last": 9.80, "spread_pct": 0.02})
    runtime.monitor_short_exits()
    assert InternalPaperBroker().state()["positions"], "should still be open after a fresh low"

    # price rallies back above the trailing stop -> cover
    monkeypatch.setattr(sr.candle_builder, "latest_price", lambda symbol: 9.90)
    runtime.monitor_short_exits()
    closed = InternalPaperBroker().state()["closed_trades"][0]
    assert InternalPaperBroker().state()["positions"] == []
    assert closed["exit_reason"] == "trailing_stop"
    assert closed["gross_pnl_usd"] > 0  # covered below entry
