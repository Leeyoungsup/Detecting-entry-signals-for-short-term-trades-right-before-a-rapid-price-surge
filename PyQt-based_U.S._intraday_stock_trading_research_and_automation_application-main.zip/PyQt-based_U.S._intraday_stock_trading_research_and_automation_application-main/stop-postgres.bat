@echo off
setlocal
cd /d "%~dp0"
call scripts\stop-postgres.cmd
echo.
echo PostgreSQL stop command complete.
pause
