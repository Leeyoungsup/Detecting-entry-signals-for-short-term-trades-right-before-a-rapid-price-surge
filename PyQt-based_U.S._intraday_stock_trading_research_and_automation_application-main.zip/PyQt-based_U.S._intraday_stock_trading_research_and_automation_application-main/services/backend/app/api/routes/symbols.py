import time
from datetime import datetime, timezone, timedelta
from typing import Any, Callable

from fastapi import APIRouter, HTTPException, Query

from app.adapters.market_data.base import MarketDataUnavailableError
from app.adapters.kis.errors import KisAdapterError, KisApiResponseError
from app.core.config import get_settings
from app.services.candle_builder import candle_builder
from app.services.execution_pricing import ExecutionPricingError, execution_quote_snapshot
from app.services.market_data import get_market_data_service
from app.services.paper_broker import InternalPaperBroker
from app.services.risk_manager import RiskManager
from app.services.strategy_engine import EntryPatternEngine, _indicator_snapshot, _normalize_candles
from app.services.strategy_runtime import _dynamic_stop_loss_price as _runtime_dynamic_stop_loss_price
from app.services.symbol_names import resolve_symbol_name

router = APIRouter()
_REST_CACHE: dict[tuple[str, str, str], tuple[float, dict]] = {}
_REST_CACHE_TTL_SEC = {
    "price": 5.0,
    "quote": 5.0,
    "minute": 10.0,
    "minute_history": 300.0,
    "daily": 300.0,
}
_EVAL_CACHE: dict[str, tuple[float, Any]] = {}
_EVAL_CACHE_TTL_SEC = 5.0


@router.get("/{symbol}")
def symbol_detail(
    symbol: str,
    timeframe: str = Query(default="1m"),
    chart_date: str | None = Query(default=None, alias="date"),
) -> dict:
    market_data = get_market_data_service()
    service = market_data.provider
    symbol = symbol.upper()
    timeframe = _normalize_timeframe(timeframe)
    chart_date = _normalize_chart_date(chart_date)
    held_position = _held_position(symbol)
    toss_position_market = None
    ws_snapshot = service.realtime_snapshot()
    ws_trade = ws_snapshot.get("trades", {}).get(symbol) or {}
    ws_quote = ws_snapshot.get("quotes", {}).get(symbol) or {}
    rest_source_used = False
    chart_warning = ""
    chart_source = _provider_source("minute", market_data.provider_name)
    live_merge_blocked = False
    if chart_date and not _is_daily_timeframe(timeframe):
        try:
            base_candles = _historical_intraday_candles(service, symbol, chart_date)
            rest_source_used = True
            chart_source = _provider_source("minute_history", market_data.provider_name)
        except MarketDataUnavailableError as exc:
            base_candles = []
            chart_warning = str(exc)
            chart_source = "external_market_data_unconfigured"
        except KisApiResponseError as exc:
            raise HTTPException(
                status_code=502,
                detail={
                    "message": str(exc),
                    "kis_status_code": exc.status_code,
                    "kis_error_code": exc.payload.get("msg_cd"),
                },
            ) from exc
        except KisAdapterError as exc:
            raise HTTPException(status_code=503, detail={"message": str(exc)}) from exc
    else:
        base_candles = []

    if not chart_date and not _is_daily_timeframe(timeframe):
        cached_sets = candle_builder.candle_sets(symbol, limit=300)
        live_tick_candles = cached_sets["live_tick"]
        official_candles = cached_sets["official"]
        settings = get_settings()
        if not settings.strategy_prefer_live_tick_candles and len(official_candles) >= 20:
            base_candles = official_candles
            chart_source = "provider_minute_scanner_seed"
        elif len(live_tick_candles) >= settings.strategy_live_tick_min_candles:
            base_candles = live_tick_candles
            chart_source = "provider_ws_tick_1m_window"
        elif len(official_candles) >= 20:
            base_candles = official_candles
            chart_source = "provider_minute_scanner_seed"
            chart_warning = (
                f"Toss polling tick-built 1분봉이 {len(live_tick_candles)}개라 "
                f"전략 기준 {settings.strategy_live_tick_min_candles}개를 채우는 중입니다. "
                "차트는 공식 1분봉 seed를 참고 표시합니다."
            )
        else:
            try:
                bars = _cached_rest(
                    "minute",
                    symbol,
                    "1m",
                    lambda: service.minute_bars(symbol=symbol, exchange="NAS", interval="1", limit=120),
                )
                base_candles = _bars_to_candles(symbol, bars.get("output2") or [])
                candle_builder.seed(symbol, base_candles, source=chart_source)
                rest_source_used = True
            except MarketDataUnavailableError as exc:
                if not candle_builder.has_symbol(symbol):
                    base_candles = []
                    chart_warning = str(exc)
                    chart_source = "external_market_data_unconfigured"
                else:
                    chart_warning = f"외부 공식 분봉 조회 실패, 임시 tick candle fallback 사용: {exc}"
                    chart_source = "provider_ws_tick_fallback"
            except KisApiResponseError as exc:
                if not candle_builder.has_symbol(symbol):
                    raise HTTPException(
                        status_code=502,
                        detail={
                            "message": str(exc),
                            "kis_status_code": exc.status_code,
                            "kis_error_code": exc.payload.get("msg_cd"),
                        },
                    ) from exc
                chart_warning = f"공식 분봉 조회 실패, 임시 tick candle fallback 사용: {exc}"
                chart_source = "provider_ws_tick_fallback"
            except KisAdapterError as exc:
                if not candle_builder.has_symbol(symbol):
                    raise HTTPException(status_code=503, detail={"message": str(exc)}) from exc
                chart_warning = f"공식 분봉 조회 실패, 임시 tick candle fallback 사용: {exc}"
                chart_source = "provider_ws_tick_fallback"
    price_output = _ws_price_output(ws_trade)
    quote_output1: dict = {}
    quote_output2 = _ws_quote_output(ws_quote)
    if not price_output and base_candles:
        chart_price = _latest_candle_close(base_candles)
        if chart_price is not None:
            price_output = {
                "last": chart_price,
                "source": f"{chart_source}_last_candle",
            }
    if toss_position_market:
        price_output = {
            "last": toss_position_market.get("last"),
            "source": toss_position_market.get("source"),
            "held_position": True,
        }
        quote_output1 = {"last": toss_position_market.get("last")}
        quote_output2 = {
            "pbid1": toss_position_market.get("bid"),
            "pask1": toss_position_market.get("ask"),
            "vbid1": None,
            "vask1": None,
            "spread_pct": toss_position_market.get("spread_pct"),
            "source": toss_position_market.get("source"),
            "held_position": True,
        }
    if not price_output or not quote_output2:
        try:
            if not price_output:
                price_output = (
                    _cached_rest(
                        "price",
                        symbol,
                        "current",
                        lambda: service.price(symbol=symbol, exchange="NAS"),
                    ).get("output")
                    or {}
                )
                rest_source_used = True
            if not quote_output2:
                quote = _cached_rest(
                    "quote",
                    symbol,
                    "current",
                    lambda: service.quote(symbol=symbol, exchange="NAS"),
                )
                quote_output1 = quote.get("output1") or {}
                quote_output2 = quote.get("output2") or {}
                rest_source_used = True
        except MarketDataUnavailableError:
            pass
        except KisApiResponseError as exc:
            if not candle_builder.has_symbol(symbol):
                raise HTTPException(
                    status_code=502,
                    detail={
                        "message": str(exc),
                        "kis_status_code": exc.status_code,
                        "kis_error_code": exc.payload.get("msg_cd"),
                    },
                ) from exc
        except KisAdapterError as exc:
            if not candle_builder.has_symbol(symbol):
                raise HTTPException(status_code=503, detail={"message": str(exc)}) from exc

    last_price = _to_float(price_output.get("last") or quote_output1.get("last")) or 100.0
    bid = _to_float(quote_output2.get("pbid1"))
    ask = _to_float(quote_output2.get("pask1"))
    bid_depth = _to_float(quote_output2.get("vbid1"))
    ask_depth = _to_float(quote_output2.get("vask1"))
    spread_pct = _spread_pct(bid, ask)
    bid_ask_imbalance = _imbalance(bid_depth, ask_depth)
    ws_flow = service.order_flow_snapshot().get(symbol, {})
    if not base_candles:
        cached_sets = candle_builder.candle_sets(symbol, limit=300)
        live_tick_candles = cached_sets["live_tick"]
        official_candles = cached_sets["official"]
        base_candles = live_tick_candles or official_candles or cached_sets["all"]
        if base_candles:
            chart_source = "provider_ws_tick_warming" if live_tick_candles else "provider_minute_scanner_seed"
    elif (
        not get_settings().strategy_prefer_live_tick_candles
        and not chart_date
        and not _is_daily_timeframe(timeframe)
        and chart_source not in {"provider_ws_tick_1m_window", "provider_ws_tick_warming"}
    ):
        live_candles = candle_builder.candles(symbol, limit=300, newest_first=False)
        if _has_live_candle(live_candles):
            merge_result = _merge_live_candles_if_continuous(base_candles, live_candles)
            if merge_result["merged"]:
                base_candles = merge_result["candles"]
                chart_source = "provider_minute_plus_ws_tick"
            else:
                live_merge_blocked = True
                chart_warning = merge_result["message"]
    try:
        candles = _display_candles(service, symbol, base_candles, timeframe, chart_date)
        if _is_daily_timeframe(timeframe):
            rest_source_used = True
            chart_source = _provider_source("daily", market_data.provider_name)
    except MarketDataUnavailableError as exc:
        candles = _apply_timeframe(base_candles, timeframe)
        chart_warning = str(exc)
        chart_source = "external_market_data_unconfigured"
    except KisAdapterError as exc:
        candles = _apply_timeframe(base_candles, timeframe)
        chart_warning = f"KIS 기간별시세 조회 실패: {exc}"
    strategy_candles, strategy_candle_mode = _symbol_strategy_candles(symbol)
    chart_indicators = _indicator_snapshot(_normalize_candles(candles))
    risk = RiskManager().preview_long_entry(
        account_equity_usd=2000.0,
        entry_price=last_price,
        stop_loss_price=_runtime_dynamic_stop_loss_price(last_price, strategy_candles),
    )
    evaluation = _cached_evaluation(symbol, strategy_candles, risk.model_dump())
    uses_toss_position_chart = chart_source == "toss_position_quote_1m_window"
    realtime_chart_flow = (
        None
        if uses_toss_position_chart
        else ws_flow if _chart_source_uses_realtime(chart_source) and not live_merge_blocked else None
    )
    freshness = _chart_freshness(candles, timeframe, realtime_chart_flow)
    realtime_freshness = freshness if uses_toss_position_chart else _realtime_freshness(ws_flow, timeframe)
    data_source = chart_source
    return {
        "symbol": symbol,
        "company_name": resolve_symbol_name(symbol),
        "data_source": data_source,
        "rest_source_used": rest_source_used,
        "price": price_output,
        "held_position": held_position,
        "toss_position_market": toss_position_market,
        "chart": {
            "interval": timeframe,
            "date": chart_date,
            "source": chart_source,
            "source_detail": _chart_source_detail(chart_source),
            "freshness": freshness,
            "realtime_freshness": realtime_freshness,
            "data_gap_blocked": live_merge_blocked,
            "strategy_candle_mode": strategy_candle_mode,
            "overlays": ["bollinger_upper", "bollinger_mid", "bollinger_lower", "vwap", "ema9", "ema20"],
            "candles": candles,
            "indicators": chart_indicators.__dict__,
            "markers": [],
            "message": chart_warning or _chart_message(timeframe, data_source, len(candles), chart_date),
        },
        "order_flow": {
            "volume_10s": ws_flow.get("volume_10s"),
            "volume_30s": ws_flow.get("volume_30s"),
            "volume_60s": ws_flow.get("volume_60s"),
            "volume_velocity_10s": ws_flow.get("volume_velocity_10s"),
            "aggressive_buy_ratio": _buy_ratio(ws_flow),
            "aggressive_sell_ratio": ws_flow.get("sell_pressure"),
            "trade_strength": ws_flow.get("trade_strength"),
            "tick_tape": [ws_flow.get("trade")] if ws_flow.get("trade") else [],
            "message": "실시간 tick 수신 전이면 값이 비어 있습니다.",
        },
        "order_book": {
            "bid": bid,
            "ask": ask,
            "spread_pct": spread_pct,
            "bid_depth": bid_depth,
            "ask_depth": ask_depth,
            "bid_ask_imbalance": bid_ask_imbalance,
            "raw": quote_output2,
            "source": quote_output2.get("source"),
            "held_position": bool(held_position),
        },
        "signal_explanation": {
            "strategy_name": evaluation.strategy_name,
            "passed_conditions": evaluation.passed_conditions,
            "failed_conditions": evaluation.failed_conditions,
            "reject_reason": evaluation.reject_reason,
            "entry_allowed": evaluation.entry_allowed,
            "entry_mode": evaluation.entry_mode,
            "strategy_candle_mode": strategy_candle_mode,
            "lower_band_status": evaluation.model_dump()["lower_band_status"],
            "pattern_status": evaluation.model_dump().get("pattern_status"),
        },
        "risk_preview": risk.model_dump(),
    }


def _bars_to_candles(symbol: str, rows: list[dict]) -> list[dict]:
    candles = [
        {
            "symbol": symbol,
            "market_date": row.get("xymd") or row.get("tymd"),
            "market_time": row.get("xhms"),
            "korea_date": row.get("kymd"),
            "korea_time": row.get("khms"),
            "open": _to_float(row.get("open")),
            "high": _to_float(row.get("high")),
            "low": _to_float(row.get("low")),
            "close": _to_float(row.get("last")),
            "volume": _to_float(row.get("evol")),
            "notional": _to_float(row.get("eamt")),
        }
        for row in rows
    ]
    return sorted(candles, key=lambda row: f"{row.get('market_date') or ''}{str(row.get('market_time') or '').zfill(6)}")


def _latest_candle_close(candles: list[dict]) -> float | None:
    for candle in reversed(candles):
        close = _to_float(candle.get("close"))
        if close is not None:
            return close
    return None


def _symbol_strategy_candles(symbol: str) -> tuple[list[dict], str]:
    settings = get_settings()
    sets = candle_builder.candle_sets(symbol, limit=120)
    official_candles = sets["official"]
    live_tick_candles = sets["live_tick"]
    if not settings.strategy_prefer_live_tick_candles:
        if len(official_candles) >= settings.strategy_official_min_candles:
            return official_candles, "official_latest"
        if official_candles:
            return official_candles, "official_warming"
        if len(live_tick_candles) >= settings.strategy_live_tick_min_candles:
            return live_tick_candles, "live_tick_fallback"
        return live_tick_candles, "live_tick_warming"
    if settings.strategy_prefer_live_tick_candles:
        return live_tick_candles, "live_tick" if len(live_tick_candles) >= settings.strategy_live_tick_min_candles else "live_tick_warming"
    return official_candles, "official_latest"


def _dynamic_stop_loss_price(entry_price: float, candles: list[dict]) -> float:
    settings = get_settings()
    if entry_price <= 0:
        return entry_price
    normalized = _normalize_candles(candles)
    indicators = _indicator_snapshot(normalized)
    stop_pct = max(settings.paper_stop_loss_pct, settings.paper_min_stop_loss_pct)
    if indicators.atr20:
        stop_pct = max(stop_pct, (indicators.atr20 * settings.paper_stop_atr_multiplier) / entry_price)
    recent_lows = [
        _to_float(row.get("low"))
        for row in normalized[-max(1, settings.paper_structure_stop_lookback_bars):]
        if _to_float(row.get("low")) is not None
    ]
    if recent_lows:
        structure_pct = max(0.0, (entry_price - min(recent_lows)) / entry_price)
        if structure_pct > 0:
            stop_pct = max(stop_pct, structure_pct)
    stop_pct = min(max(stop_pct, settings.paper_min_stop_loss_pct), settings.paper_max_stop_loss_pct)
    return entry_price * (1 - stop_pct)


def _daily_rows_to_candles(symbol: str, rows: list[dict], timeframe: str) -> list[dict]:
    candles = [
        {
            "symbol": symbol,
            "market_date": row.get("xymd"),
            "market_time": "000000",
            "korea_date": row.get("xymd"),
            "korea_time": "000000",
            "open": _to_float(row.get("open")),
            "high": _to_float(row.get("high")),
            "low": _to_float(row.get("low")),
            "close": _to_float(row.get("clos")),
            "volume": _to_float(row.get("tvol")),
            "notional": _to_float(row.get("tamt")),
            "source": f"provider_daily_{timeframe}",
        }
        for row in rows
        if row.get("xymd")
    ]
    return sorted(candles, key=lambda candle: str(candle.get("market_date") or ""))


def _historical_intraday_candles(service: Any, symbol: str, chart_date: str) -> list[dict]:
    response = _cached_rest(
        "minute_history",
        symbol,
        f"1m:{chart_date}",
        lambda: service.minute_bars_history(
            symbol=symbol,
            exchange="NAS",
            interval="1",
            target_date=chart_date,
            max_pages=20,
        ),
    )
    candles = _bars_to_candles(symbol, response.get("output2") or [])
    return [
        candle
        for candle in sorted(candles, key=lambda row: f"{row.get('market_date')}{row.get('market_time')}")
        if candle.get("market_date") == chart_date
    ]


def _display_candles(
    service: Any,
    symbol: str,
    base_candles: list[dict],
    timeframe: str,
    chart_date: str | None,
) -> list[dict]:
    if not _is_daily_timeframe(timeframe):
        return _apply_timeframe(base_candles, timeframe)

    desired_count = {"1d": 60, "7d": 7, "30d": 30, "365d": 365}[timeframe]
    response = _cached_rest(
        "daily",
        symbol,
        "dailyprice",
        lambda: service.daily_bars(symbol=symbol, exchange="NAS", period="0", bymd="", adjusted=True, max_pages=5),
    )
    daily_candles = _daily_rows_to_candles(symbol, response.get("output2") or [], timeframe)
    return daily_candles[-desired_count:]


def _cached_rest(kind: str, symbol: str, key: str, loader: Callable[[], dict]) -> dict:
    cache_key = (kind, symbol.upper(), key)
    now = time.monotonic()
    cached = _REST_CACHE.get(cache_key)
    ttl = _REST_CACHE_TTL_SEC.get(kind, 10.0)
    if cached and now - cached[0] <= ttl:
        return cached[1]
    value = loader()
    _REST_CACHE[cache_key] = (now, value)
    return value


def _cached_evaluation(symbol: str, candles: list[dict], risk_preview: dict) -> Any:
    """전략 평가 결과를 5초간 캐싱해서 HTTP 폴링마다 재평가하지 않도록 한다."""
    cache_key = symbol.upper()
    now = time.monotonic()
    cached = _EVAL_CACHE.get(cache_key)
    if cached and now - cached[0] <= _EVAL_CACHE_TTL_SEC:
        return cached[1]
    evaluation = EntryPatternEngine().evaluate(
        symbol=symbol,
        candles=candles,
        risk_preview=risk_preview,
    )
    _EVAL_CACHE[cache_key] = (now, evaluation)
    return evaluation


def _ws_price_output(trade: dict) -> dict:
    if not trade:
        return {}
    raw = trade.get("raw") if isinstance(trade.get("raw"), dict) else {}
    return {
        "rsym": trade.get("tr_key"),
        "last": trade.get("last"),
        "pvol": trade.get("trade_volume"),
        "tvol": trade.get("total_volume"),
        "tamt": trade.get("total_notional"),
        "open": raw.get("open"),
        "high": raw.get("high"),
        "low": raw.get("low"),
        "source": "provider_ws_tick",
        "received_at": trade.get("received_at"),
    }


def _ws_quote_output(quote: dict) -> dict:
    if not quote:
        return {}
    return {
        "pbid1": quote.get("bid"),
        "pask1": quote.get("ask"),
        "vbid1": quote.get("bid_depth"),
        "vask1": quote.get("ask_depth"),
        "source": "provider_ws_quote",
        "received_at": quote.get("received_at"),
    }


def _normalize_timeframe(value: str) -> str:
    normalized = value.lower().strip()
    aliases = {
        "1": "1m",
        "5": "5m",
        "10": "10m",
        "30": "30m",
        "60": "60m",
        "180": "180m",
        "3h": "180m",
        "1day": "1d",
        "7day": "7d",
        "30day": "30d",
        "365day": "365d",
    }
    normalized = aliases.get(normalized, normalized)
    allowed = {"1m", "5m", "10m", "30m", "60m", "180m", "1d", "7d", "30d", "365d"}
    return normalized if normalized in allowed else "1m"


def _normalize_chart_date(value: str | None) -> str | None:
    if not value:
        return None
    normalized = value.strip()
    for fmt in ("%Y-%m-%d", "%Y%m%d"):
        try:
            return datetime.strptime(normalized, fmt).strftime("%Y%m%d")
        except ValueError:
            continue
    return None


def _apply_timeframe(candles: list[dict], timeframe: str) -> list[dict]:
    if timeframe == "1m":
        return candles
    minute_groups = {"5m": 5, "10m": 10, "30m": 30, "60m": 60, "180m": 180}
    if timeframe in minute_groups:
        return _aggregate_by_minutes(candles, minute_groups[timeframe])
    if timeframe in {"1d", "7d", "30d", "365d"}:
        return _aggregate_by_day(candles)
    return candles


def _merge_live_candles_if_continuous(base_candles: list[dict], live_candles: list[dict]) -> dict:
    settings = get_settings()
    live_candles = [row for row in live_candles if not _is_future_live_candle(row)]
    live_rows = [row for row in live_candles if row.get("is_live")]
    if not live_rows:
        return {"merged": False, "candles": base_candles, "message": ""}

    base_latest = _latest_non_live_candle(live_candles) or (base_candles[-1] if base_candles else None)
    first_live = live_rows[0]
    if base_latest:
        base_dt = _candle_datetime_utc(base_latest)
        live_dt = _candle_datetime_utc(first_live)
        if base_dt and live_dt:
            gap_min = (live_dt - base_dt).total_seconds() / 60
            if gap_min > settings.chart_live_merge_max_gap_minutes:
                return {
                    "merged": False,
                    "candles": base_candles,
                    "message": (
                        f"공식 1분봉과 실시간 tick 사이에 {gap_min:.1f}분 공백이 있어 "
                        "BB/EMA/VWAP 왜곡 방지를 위해 live candle 병합을 보류합니다."
                    ),
                }

    merged_by_bucket = {
        _candle_bucket(row): row
        for row in base_candles
        if _candle_bucket(row)
    }
    for row in live_candles:
        bucket = _candle_bucket(row)
        if not bucket:
            continue
        if row.get("is_live") or bucket not in merged_by_bucket:
            merged_by_bucket[bucket] = row
    merged = sorted(merged_by_bucket.values(), key=lambda row: f"{row.get('market_date') or ''}{str(row.get('market_time') or '').zfill(6)}")
    return {"merged": True, "candles": merged[-300:], "message": ""}


def _latest_non_live_candle(candles: list[dict]) -> dict | None:
    return next((row for row in reversed(candles) if not row.get("is_live")), None)


def _is_future_live_candle(candle: dict) -> bool:
    if not (candle.get("is_live") or candle.get("is_tick_built")):
        return False
    candle_dt = _candle_datetime_utc(candle)
    if candle_dt is None:
        return False
    max_live_label = datetime.now(timezone.utc).replace(second=0, microsecond=0) + timedelta(minutes=1)
    return candle_dt > max_live_label


def _candle_bucket(candle: dict) -> str | None:
    market_date = candle.get("market_date")
    market_time = candle.get("market_time")
    if not market_date or not market_time:
        return None
    return f"{market_date}:{str(market_time).zfill(6)[:4]}00"


def _candle_datetime_utc(candle: dict) -> datetime | None:
    market_date = candle.get("market_date")
    market_time = str(candle.get("market_time") or "").zfill(6)
    if not market_date or len(str(market_date)) != 8 or len(market_time) < 6:
        return None
    try:
        return datetime.strptime(f"{market_date}{market_time[:6]}", "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _is_daily_timeframe(timeframe: str) -> bool:
    return timeframe in {"1d", "7d", "30d", "365d"}


def _aggregate_by_minutes(candles: list[dict], minutes: int) -> list[dict]:
    groups: dict[str, list[dict]] = {}
    for candle in candles:
        market_date = candle.get("market_date")
        market_time = str(candle.get("market_time") or "000000").zfill(6)
        if not market_date:
            continue
        hour = _to_int(market_time[:2]) or 0
        minute = _to_int(market_time[2:4]) or 0
        bucket_minute = (hour * 60 + minute) // minutes * minutes
        bucket = f"{market_date}:{bucket_minute:04d}"
        groups.setdefault(bucket, []).append(candle)
    return [_aggregate_group(rows, interval=f"{minutes}m") for _, rows in sorted(groups.items()) if rows]


def _aggregate_by_day(candles: list[dict]) -> list[dict]:
    groups: dict[str, list[dict]] = {}
    for candle in candles:
        market_date = candle.get("market_date")
        if market_date:
            groups.setdefault(str(market_date), []).append(candle)
    return [_aggregate_group(rows, interval="1d") for _, rows in sorted(groups.items()) if rows]


def _aggregate_group(rows: list[dict], *, interval: str) -> dict:
    ordered = sorted(rows, key=lambda row: str(row.get("market_time") or ""))
    first = ordered[0]
    last = ordered[-1]
    highs = [_to_float(row.get("high")) for row in ordered]
    lows = [_to_float(row.get("low")) for row in ordered]
    volumes = [_to_float(row.get("volume")) or 0.0 for row in ordered]
    notionals = [_to_float(row.get("notional")) or 0.0 for row in ordered]
    return {
        "symbol": first.get("symbol"),
        "market_date": first.get("market_date"),
        "market_time": first.get("market_time"),
        "korea_date": first.get("korea_date"),
        "korea_time": first.get("korea_time"),
        "open": _to_float(first.get("open")),
        "high": max((value for value in highs if value is not None), default=None),
        "low": min((value for value in lows if value is not None), default=None),
        "close": _to_float(last.get("close")),
        "volume": sum(volumes),
        "notional": sum(notionals),
        "source": f"aggregated_{interval}",
        "is_live": any(row.get("is_live") for row in ordered),
    }


def _held_position(symbol: str) -> dict | None:
    symbol = symbol.upper()
    for position in InternalPaperBroker().state().get("positions", []):
        quantity = _to_float(position.get("quantity")) or 0.0
        if str(position.get("symbol") or "").upper() == symbol and quantity > 0:
            return position
    return None


def _refresh_toss_position_chart(symbol: str) -> dict | None:
    settings = get_settings()
    try:
        market = execution_quote_snapshot(
            symbol,
            max_cache_age_sec=settings.toss_position_quote_cache_sec,
        )
    except ExecutionPricingError:
        return None
    price = _to_float(market.get("bid")) or _to_float(market.get("last")) or _to_float(market.get("ask"))
    if price is None:
        return None
    now = datetime.now(timezone.utc)
    event = {
        "event_type": "toss_position_quote",
        "symbol": symbol,
        "last": price,
        "trade_volume": 0,
        "bid": market.get("bid"),
        "ask": market.get("ask"),
        "spread_pct": market.get("spread_pct"),
        "received_at": now.isoformat(),
        "source": market.get("source"),
        "raw": {
            "bid": market.get("bid"),
            "ask": market.get("ask"),
            "spread_pct": market.get("spread_pct"),
            "source": market.get("source"),
        },
    }
    candle_builder.on_trade(event, source="toss_position_quote")
    return {
        **market,
        "last": price,
        "received_at": now.isoformat(),
        "chart_source": "toss_position_quote",
    }


def _latest_live_source(candles: list[dict]) -> str | None:
    for candle in reversed(candles):
        if candle.get("is_live") or candle.get("is_tick_built"):
            return str(candle.get("source") or "") or None
    return None


def _chart_message(timeframe: str, data_source: str, candle_count: int, chart_date: str | None) -> str:
    if chart_date and timeframe not in {"1d", "7d", "30d", "365d"}:
        source = "Toss OpenAPI" if data_source.startswith("toss_") else "Primary market data"
        return f"{source} 기반 {chart_date} {timeframe} 과거 분봉입니다. 표시 candle {candle_count}개."
    if timeframe in {"1d", "7d", "30d", "365d"}:
        source = "Toss OpenAPI" if data_source.startswith("toss_") else "Primary market data"
        return f"{source} 기반 일봉 차트입니다. 표시 candle {candle_count}개."
    if data_source == "provider_ws_tick_fallback":
        return f"공식 분봉 조회 실패로 임시 Toss polling tick candle을 표시합니다. 표시 candle {candle_count}개."
    if data_source == "provider_ws_tick_warming":
        return f"Toss polling tick-built 1분봉 window를 생성 중입니다. 현재 표시 candle {candle_count}개."
    if data_source == "provider_ws_tick_1m_window":
        return f"Toss polling tick으로 집계한 최신 1분봉 window 기준 {timeframe} 차트입니다. 표시 candle {candle_count}개."
    if data_source == "toss_position_quote_1m_window":
        return f"보유 종목은 Toss 호가 기준으로 최신 1분봉을 갱신합니다. 표시 candle {candle_count}개."
    if data_source == "external_market_data_unconfigured":
        return "외부 실시간 market data provider가 아직 설정되지 않아 차트를 표시할 수 없습니다."
    if data_source == "provider_minute_plus_ws_tick":
        return f"공식 1분봉 seed에 Toss polling 실시간 tick candle을 병합해 {timeframe} 차트를 표시합니다."
    source = "KIS legacy REST" if data_source.startswith("kis_") else "Toss OpenAPI" if data_source.startswith("toss_") else "Primary market data provider"
    return f"{source} 공식 1분봉을 기준으로 {timeframe} 차트를 표시합니다. 상세 화면은 이벤트 기반으로 갱신되며 Toss polling tick candle이 병합될 수 있습니다."


def _chart_source_detail(source: str) -> str:
    labels = {
        "kis_rest_minute": "KIS REST 공식 1분봉",
        "kis_rest_minute_history": "KIS REST 공식 과거 1분봉",
        "kis_rest_daily": "KIS REST 공식 일봉",
        "provider_minute": "Primary market data 공식 1분봉",
        "toss_minute": "Toss OpenAPI 공식 1분봉",
        "toss_minute_history": "Toss OpenAPI 공식 과거 1분봉",
        "toss_daily": "Toss OpenAPI 공식 일봉",
        "provider_minute_plus_ws_tick": "공식 1분봉 + Toss polling 실시간 tick",
        "provider_minute_scanner_seed": "스캐너 seed 공식 1분봉",
        "provider_minute_history": "Primary market data 공식 과거 1분봉",
        "provider_daily": "Primary market data 공식 일봉",
        "provider_ws_tick_1m_window": "Toss polling tick-built 최신 1분봉",
        "provider_ws_tick_warming": "Toss polling tick-built 1분봉 생성 중",
        "provider_ws_tick_fallback": "Toss polling tick 임시 fallback",
        "external_market_data_unconfigured": "외부 market data 미설정",
    }
    if source == "toss_position_quote_1m_window":
        return "보유 종목 Toss 호가 기준 1분봉"
    return labels.get(source, source)


def _chart_source_uses_realtime(source: str) -> bool:
    return source in {
        "provider_minute_plus_ws_tick",
        "provider_ws_tick_fallback",
        "provider_ws_tick_1m_window",
        "provider_ws_tick_warming",
        "toss_position_quote_1m_window",
    }


def _provider_source(kind: str, provider_name: str) -> str:
    if provider_name == "kis_legacy":
        return {
            "minute": "kis_rest_minute",
            "minute_history": "kis_rest_minute_history",
            "daily": "kis_rest_daily",
        }[kind]
    if provider_name == "toss":
        return {
            "minute": "toss_minute",
            "minute_history": "toss_minute_history",
            "daily": "toss_daily",
        }[kind]
    return {
        "minute": "provider_minute",
        "minute_history": "provider_minute_history",
        "daily": "provider_daily",
    }[kind]


def _chart_freshness(candles: list[dict], timeframe: str, realtime_flow: dict | None = None) -> dict:
    realtime_freshness = _realtime_freshness(realtime_flow or {}, timeframe)
    if realtime_freshness:
        return realtime_freshness
    if not candles:
        return {"latest_market_at": None, "latest_korea_at": None, "age_sec": None, "is_stale": True}
    latest = candles[-1]
    if latest.get("is_live"):
        live_updated = _parse_iso(str(latest.get("updated_at") or ""))
        if live_updated is not None:
            utc = live_updated.astimezone(timezone.utc)
            kst = utc + timedelta(hours=9)
            age_sec = max(0.0, (datetime.now(timezone.utc) - utc).total_seconds())
            return {
                "latest_market_at": utc.strftime("%Y-%m-%d %H:%M:%S"),
                "latest_korea_at": kst.strftime("%Y-%m-%d %H:%M:%S"),
                "age_sec": age_sec,
                "is_stale": age_sec > 30,
                "source": "websocket_live_candle",
            }
    latest_market_at = _format_compact_datetime(latest.get("market_date"), latest.get("market_time"))
    latest_korea_at = _format_compact_datetime(latest.get("korea_date"), latest.get("korea_time"))
    age_sec = None
    if latest_korea_at and not _is_daily_timeframe(timeframe):
        parsed = datetime.strptime(latest_korea_at, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone(timedelta(hours=9)))
        age_sec = max(0.0, (datetime.now(timezone(timedelta(hours=9))) - parsed).total_seconds())
    stale_threshold = 180.0 if timeframe in {"1m", "5m", "10m", "30m", "60m", "180m"} else None
    return {
        "latest_market_at": latest_market_at,
        "latest_korea_at": latest_korea_at,
        "age_sec": age_sec,
        "is_stale": bool(age_sec is None or (stale_threshold is not None and age_sec > stale_threshold)),
    }


def _realtime_freshness(realtime_flow: dict, timeframe: str) -> dict | None:
    if _is_daily_timeframe(timeframe):
        return None
    latest_event = None
    for key in ("trade", "quote"):
        event = realtime_flow.get(key) or {}
        received_at = event.get("received_at")
        parsed = _parse_iso(received_at)
        if parsed and (latest_event is None or parsed > latest_event):
            latest_event = parsed
    if latest_event is None:
        return None
    now = datetime.now(timezone.utc)
    age_sec = max(0.0, (now - latest_event.astimezone(timezone.utc)).total_seconds())
    utc = latest_event.astimezone(timezone.utc)
    kst = utc + timedelta(hours=9)
    return {
        "latest_market_at": utc.strftime("%Y-%m-%d %H:%M:%S"),
        "latest_korea_at": kst.strftime("%Y-%m-%d %H:%M:%S"),
        "age_sec": age_sec,
        "is_stale": age_sec > get_settings().strategy_tick_stale_block_sec,
        "is_caution": age_sec > get_settings().strategy_tick_stale_caution_sec,
        "source": "websocket_realtime",
    }


def _has_live_candle(candles: list[dict]) -> bool:
    return any(bool(candle.get("is_live")) for candle in candles[-3:])


def _parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def _format_compact_datetime(date_value: str | int | None, time_value: str | int | None) -> str | None:
    if not date_value or not time_value:
        return None
    date_digits = "".join(ch for ch in str(date_value) if ch.isdigit())
    time_digits = "".join(ch for ch in str(time_value).zfill(6) if ch.isdigit()).zfill(6)
    if len(date_digits) != 8 or len(time_digits) < 6:
        return None
    return f"{date_digits[:4]}-{date_digits[4:6]}-{date_digits[6:8]} {time_digits[:2]}:{time_digits[2:4]}:{time_digits[4:6]}"


def _to_int(value: str | int | None) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _to_float(value: str | int | float | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _spread_pct(bid: float | None, ask: float | None) -> float | None:
    if not bid or not ask:
        return None
    midpoint = (bid + ask) / 2
    if midpoint <= 0:
        return None
    return (ask - bid) / midpoint * 100


def _imbalance(bid_depth: float | None, ask_depth: float | None) -> float | None:
    if bid_depth is None or ask_depth is None:
        return None
    total = bid_depth + ask_depth
    if total <= 0:
        return None
    return bid_depth / total


def _buy_ratio(flow: dict) -> float | None:
    sell_pressure = flow.get("sell_pressure")
    if sell_pressure is None:
        return None
    return 1 - sell_pressure
