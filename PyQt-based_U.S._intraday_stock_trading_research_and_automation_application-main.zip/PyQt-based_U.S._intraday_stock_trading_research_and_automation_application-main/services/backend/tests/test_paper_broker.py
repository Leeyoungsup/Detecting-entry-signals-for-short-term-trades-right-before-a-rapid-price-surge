import pytest

from app.core.config import get_settings
from app.domain.enums import OrderState
from app.domain.models import OrderRequest
from app.services.paper_broker import InternalPaperBroker


@pytest.fixture(autouse=True)
def clean_paper_state() -> None:
    broker = InternalPaperBroker()
    broker.reset()
    yield
    broker.reset()


def test_paper_broker_rejects_non_internal_paper_orders() -> None:
    broker = InternalPaperBroker()
    request = OrderRequest(symbol="AAPL", side="buy", quantity=1, limit_price=101, mode="live")

    with pytest.raises(ValueError, match="internal_paper"):
        broker.submit_order(request, market_snapshot={"ask": 100, "bid": 99.95, "last": 100})


def test_paper_roundtrip_records_net_pnl_after_fees() -> None:
    broker = InternalPaperBroker()

    buy_request = OrderRequest(
        symbol="AAPL",
        side="buy",
        order_type="marketable_limit",
        quantity=10,
        limit_price=10.02,
        mode="internal_paper",
    )
    buy_id, buy_events = broker.submit_order(
        buy_request,
        market_snapshot={"ask": 10.00, "bid": 9.99, "last": 10.00, "spread_pct": 0.02},
    )

    buy_state = buy_events[-1].new_state
    state_after_buy = broker.state()
    position = state_after_buy["positions"][0]

    assert buy_id
    assert buy_state == OrderState.FILLED
    assert position["symbol"] == "AAPL"
    assert position["quantity"] == 10
    assert position["entry_fees_usd"] > 0

    sell_request = OrderRequest(
        symbol="AAPL",
        side="sell",
        order_type="marketable_limit",
        quantity=10,
        limit_price=10.48,
        mode="internal_paper",
    )
    _, sell_events = broker.submit_order(
        sell_request,
        market_snapshot={"ask": 10.51, "bid": 10.50, "last": 10.50, "spread_pct": 0.02},
    )
    final_state = sell_events[-1].new_state
    state_after_sell = broker.state()
    closed_trade = state_after_sell["closed_trades"][0]

    assert final_state == OrderState.FILLED
    assert state_after_sell["positions"] == []
    assert closed_trade["gross_pnl_usd"] > 0
    assert closed_trade["fees_usd"] > 0
    assert closed_trade["net_pnl_usd"] < closed_trade["gross_pnl_usd"]


def test_paper_broker_rejects_buy_above_max_open_positions(monkeypatch) -> None:
    settings = get_settings()
    monkeypatch.setattr(settings, "paper_risk_hard_caps_enabled", True)
    monkeypatch.setattr(settings, "paper_max_open_positions", 6)
    monkeypatch.setattr(settings, "paper_max_total_exposure_pct", 10.0)
    broker = InternalPaperBroker()

    for index in range(6):
        broker.submit_order(
            OrderRequest(symbol=f"P{index}", side="buy", quantity=1, limit_price=10, mode="internal_paper"),
            market_snapshot={"ask": 10.0, "bid": 9.99, "last": 10.0, "spread_pct": 0.01},
        )

    order_id, events = broker.submit_order(
        OrderRequest(symbol="P6", side="buy", quantity=1, limit_price=10, mode="internal_paper"),
        market_snapshot={"ask": 10.0, "bid": 9.99, "last": 10.0, "spread_pct": 0.01},
    )
    state = broker.state()

    assert events[-1].new_state == OrderState.REJECTED
    assert events[-1].payload["reason"] == "max_open_positions_exceeded"
    assert next(order for order in state["orders"] if order["order_id"] == order_id)["state"] == "REJECTED"
    assert len(state["positions"]) == 6


def test_paper_broker_rejects_buy_above_max_total_exposure(monkeypatch) -> None:
    settings = get_settings()
    monkeypatch.setattr(settings, "paper_risk_hard_caps_enabled", True)
    monkeypatch.setattr(settings, "paper_max_open_positions", 10)
    monkeypatch.setattr(settings, "paper_initial_equity_usd", 2_000.0)
    monkeypatch.setattr(settings, "paper_max_total_exposure_pct", 0.90)
    broker = InternalPaperBroker()

    for index in range(5):
        broker.submit_order(
            OrderRequest(symbol=f"E{index}", side="buy", quantity=30, limit_price=10, mode="internal_paper"),
            market_snapshot={"ask": 10.0, "bid": 9.99, "last": 10.0, "spread_pct": 0.01},
        )

    _, events = broker.submit_order(
        OrderRequest(symbol="E5", side="buy", quantity=31, limit_price=10, mode="internal_paper"),
        market_snapshot={"ask": 10.0, "bid": 9.99, "last": 10.0, "spread_pct": 0.01},
    )

    assert events[-1].new_state == OrderState.REJECTED
    assert events[-1].payload["reason"] == "max_total_exposure_exceeded"
    assert events[-1].payload["projected_exposure_usd"] > 1_800


def test_paper_broker_does_not_apply_risk_hard_caps_by_default(monkeypatch) -> None:
    settings = get_settings()
    monkeypatch.setattr(settings, "paper_risk_hard_caps_enabled", False)
    monkeypatch.setattr(settings, "paper_max_open_positions", 1)
    monkeypatch.setattr(settings, "paper_initial_equity_usd", 2_000.0)
    monkeypatch.setattr(settings, "paper_max_total_exposure_pct", 0.01)
    broker = InternalPaperBroker()

    broker.submit_order(
        OrderRequest(symbol="R0", side="buy", quantity=10, limit_price=10, mode="internal_paper"),
        market_snapshot={"ask": 10.0, "bid": 9.99, "last": 10.0, "spread_pct": 0.01},
    )
    _, events = broker.submit_order(
        OrderRequest(symbol="R1", side="buy", quantity=10, limit_price=10, mode="internal_paper"),
        market_snapshot={"ask": 10.0, "bid": 9.99, "last": 10.0, "spread_pct": 0.01},
    )

    assert events[-1].new_state == OrderState.FILLED
    assert len(broker.state()["positions"]) == 2
