from __future__ import annotations

import argparse
import csv
import json
import math
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path


KST = timezone(timedelta(hours=9), "KST")
UTC = timezone.utc


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def parse_kst(value: str) -> datetime:
    return datetime.strptime(value, "%Y-%m-%d %H:%M").replace(tzinfo=KST)


def iso_z(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def sma(values: list[float], period: int) -> float | None:
    if len(values) < period:
        return None
    return sum(values[-period:]) / period


def rolling_std(values: list[float], period: int) -> float | None:
    if len(values) < period:
        return None
    window = values[-period:]
    mean = sum(window) / period
    return math.sqrt(sum((value - mean) ** 2 for value in window) / period)


def ema_series(values: list[float], period: int) -> list[float | None]:
    alpha = 2 / (period + 1)
    output: list[float | None] = []
    ema: float | None = None
    for index, value in enumerate(values):
        if ema is None:
            if index + 1 < period:
                output.append(None)
                continue
            ema = sum(values[:period]) / period
        else:
            ema = value * alpha + ema * (1 - alpha)
        output.append(ema)
    return output


def fmt(value) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.8f}".rstrip("0").rstrip(".")
    return str(value)


def fetch_bars(*, symbol: str, start_utc: datetime, end_utc: datetime, env: dict[str, str]) -> list[dict]:
    key = env.get("ALPACA_KEY") or env.get("APCA_API_KEY_ID")
    secret = env.get("ALPACA_SECRET") or env.get("APCA_API_SECRET_KEY")
    base_url = (env.get("ALPACA_REST_BASE_URL") or "https://data.alpaca.markets").rstrip("/")
    if not key or not secret:
        raise SystemExit("ALPACA_KEY / ALPACA_SECRET missing in .env")

    headers = {
        "APCA-API-KEY-ID": key,
        "APCA-API-SECRET-KEY": secret,
        "Accept": "application/json",
    }
    all_bars: list[dict] = []
    page_token = None
    while True:
        params = {
            "symbols": symbol,
            "timeframe": "1Min",
            "start": iso_z(start_utc),
            "end": iso_z(end_utc),
            "adjustment": "raw",
            "feed": "sip",
            "sort": "asc",
            "limit": "10000",
        }
        if page_token:
            params["page_token"] = page_token
        url = f"{base_url}/v2/stocks/bars?{urllib.parse.urlencode(params)}"
        request = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="ignore")
            raise SystemExit(f"Alpaca HTTP {exc.code}: {body[:500]}")
        all_bars.extend(((payload.get("bars") or {}).get(symbol) or []))
        page_token = payload.get("next_page_token")
        if not page_token:
            break
    return all_bars


def export_csv(*, symbol: str, start_kst: datetime, end_kst: datetime, output: Path, env_path: Path) -> dict:
    start_utc = start_kst.astimezone(UTC)
    end_utc = end_kst.astimezone(UTC)
    env = read_env(env_path)
    raw_bars = fetch_bars(symbol=symbol, start_utc=start_utc, end_utc=end_utc, env=env)

    bars: list[dict] = []
    for bar in raw_bars:
        timestamp_utc = datetime.fromisoformat(str(bar["t"]).replace("Z", "+00:00")).astimezone(UTC)
        if start_utc <= timestamp_utc <= end_utc:
            row = dict(bar)
            row["timestamp_utc"] = timestamp_utc
            row["timestamp_kst"] = timestamp_utc.astimezone(KST)
            bars.append(row)
    if not bars:
        raise SystemExit(f"No bars returned for {symbol} {iso_z(start_utc)} ~ {iso_z(end_utc)}")

    close_seed = [float(row.get("c") or 0) for row in bars]
    ema9 = ema_series(close_seed, 9)
    ema20 = ema_series(close_seed, 20)
    ema12 = ema_series(close_seed, 12)
    ema26 = ema_series(close_seed, 26)
    macd_line = [None if fast is None or slow is None else fast - slow for fast, slow in zip(ema12, ema26)]
    macd_signal_seed = [0.0 if value is None else value for value in macd_line]
    macd_signal = ema_series(macd_signal_seed, 9)

    output.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "symbol",
        "timestamp_kst",
        "timestamp_utc",
        "open",
        "high",
        "low",
        "close",
        "volume",
        "trade_count",
        "alpaca_vwap",
        "notional_usd",
        "volume_ma20",
        "ma5",
        "ma20",
        "ma60",
        "ma120",
        "ema9",
        "ema20",
        "bb_mid20",
        "bb_upper20",
        "bb_lower20",
        "bb_position_0_1",
        "session_vwap",
        "macd_12_26",
        "macd_signal_9",
        "macd_histogram",
        "candle_color",
        "return_pct",
        "range_pct",
    ]
    closes: list[float] = []
    volumes: list[float] = []
    typical_x_volume_sum = 0.0
    volume_sum = 0.0
    previous_close: float | None = None
    with output.open("w", newline="", encoding="utf-8-sig") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=fields)
        writer.writeheader()
        for index, bar in enumerate(bars):
            open_ = float(bar.get("o") or 0)
            high = float(bar.get("h") or 0)
            low = float(bar.get("l") or 0)
            close = float(bar.get("c") or 0)
            volume = float(bar.get("v") or 0)
            closes.append(close)
            volumes.append(volume)
            typical = (high + low + close) / 3 if high or low or close else close
            typical_x_volume_sum += typical * volume
            volume_sum += volume
            bb_mid = sma(closes, 20)
            bb_std = rolling_std(closes, 20)
            bb_upper = bb_mid + 2 * bb_std if bb_mid is not None and bb_std is not None else None
            bb_lower = bb_mid - 2 * bb_std if bb_mid is not None and bb_std is not None else None
            bb_position = (
                (close - bb_lower) / (bb_upper - bb_lower)
                if bb_upper is not None and bb_lower is not None and bb_upper != bb_lower
                else None
            )
            signal = macd_signal[index] if macd_line[index] is not None else None
            histogram = macd_line[index] - signal if macd_line[index] is not None and signal is not None else None
            return_pct = ((close - previous_close) / previous_close * 100) if previous_close else None
            previous_close = close
            writer.writerow(
                {
                    "symbol": symbol,
                    "timestamp_kst": bar["timestamp_kst"].strftime("%Y-%m-%d %H:%M:%S"),
                    "timestamp_utc": bar["timestamp_utc"].strftime("%Y-%m-%d %H:%M:%S"),
                    "open": fmt(open_),
                    "high": fmt(high),
                    "low": fmt(low),
                    "close": fmt(close),
                    "volume": int(volume),
                    "trade_count": bar.get("n", ""),
                    "alpaca_vwap": fmt(bar.get("vw")),
                    "notional_usd": fmt(close * volume),
                    "volume_ma20": fmt(sma(volumes, 20)),
                    "ma5": fmt(sma(closes, 5)),
                    "ma20": fmt(bb_mid),
                    "ma60": fmt(sma(closes, 60)),
                    "ma120": fmt(sma(closes, 120)),
                    "ema9": fmt(ema9[index]),
                    "ema20": fmt(ema20[index]),
                    "bb_mid20": fmt(bb_mid),
                    "bb_upper20": fmt(bb_upper),
                    "bb_lower20": fmt(bb_lower),
                    "bb_position_0_1": fmt(bb_position),
                    "session_vwap": fmt(typical_x_volume_sum / volume_sum if volume_sum else None),
                    "macd_12_26": fmt(macd_line[index]),
                    "macd_signal_9": fmt(signal),
                    "macd_histogram": fmt(histogram),
                    "candle_color": "up" if close >= open_ else "down",
                    "return_pct": fmt(return_pct),
                    "range_pct": fmt((high - low) / close * 100 if close else None),
                }
            )
    return {
        "csv": str(output),
        "symbol": symbol,
        "rows": len(bars),
        "start_kst": start_kst.strftime("%Y-%m-%d %H:%M:%S"),
        "end_kst": end_kst.strftime("%Y-%m-%d %H:%M:%S"),
        "start_utc": iso_z(start_utc),
        "end_utc": iso_z(end_utc),
        "first_bar_kst": bars[0]["timestamp_kst"].strftime("%Y-%m-%d %H:%M:%S"),
        "last_bar_kst": bars[-1]["timestamp_kst"].strftime("%Y-%m-%d %H:%M:%S"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--start-kst", required=True, help="YYYY-MM-DD HH:MM")
    parser.add_argument("--end-kst", required=True, help="YYYY-MM-DD HH:MM")
    parser.add_argument("--out", required=True)
    parser.add_argument("--env", default=".env")
    args = parser.parse_args()
    summary = export_csv(
        symbol=args.symbol.upper(),
        start_kst=parse_kst(args.start_kst),
        end_kst=parse_kst(args.end_kst),
        output=Path(args.out),
        env_path=Path(args.env),
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
