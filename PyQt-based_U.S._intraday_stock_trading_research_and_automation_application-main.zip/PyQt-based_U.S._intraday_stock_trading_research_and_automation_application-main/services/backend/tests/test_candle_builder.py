from datetime import datetime, timedelta, timezone

from app.services.candle_builder import InMemoryCandleBuilder


def test_tick_candle_aggregates_ohlcv_within_same_minute() -> None:
    builder = InMemoryCandleBuilder()

    first = builder.on_trade(
        {
            "symbol": "AAPL",
            "last": 10.0,
            "trade_volume": 5,
            "market_date": "20260702",
            "local_time": "143015",
            "received_at": "2026-07-02T14:30:15+00:00",
        }
    )
    second = builder.on_trade(
        {
            "symbol": "AAPL",
            "last": 10.5,
            "trade_volume": 7,
            "market_date": "20260702",
            "local_time": "143045",
            "received_at": "2026-07-02T14:30:45+00:00",
        }
    )

    assert first is not None
    assert second is not None
    assert second["open"] == 10.0
    assert second["high"] == 10.5
    assert second["low"] == 10.0
    assert second["close"] == 10.5
    assert second["volume"] == 12
    assert second["notional"] == 10.0 * 5 + 10.5 * 7


def test_polling_tick_does_not_create_future_minute_from_raw_timestamp() -> None:
    builder = InMemoryCandleBuilder()

    candle = builder.on_trade(
        {
            "symbol": "AAPL",
            "last": 10.0,
            "trade_volume": 5,
            "received_at": "2026-07-02T14:30:15+00:00",
            "raw": {
                "xymd": "20260702",
                "xhms": "143100",
            },
        },
        source="toss_polling_tick",
    )

    assert candle is not None
    assert candle["market_date"] == "20260702"
    assert candle["market_time"] == "143000"
    assert candle["korea_date"] == "20260702"
    assert candle["korea_time"] == "233000"


def test_live_tick_updates_latest_official_candle_bucket_when_adjacent() -> None:
    builder = InMemoryCandleBuilder()
    builder.seed(
        "AAPL",
        [
            {
                "market_date": "20260702",
                "market_time": "143100",
                "korea_date": "20260702",
                "korea_time": "233100",
                "open": 10.0,
                "high": 10.4,
                "low": 9.9,
                "close": 10.2,
                "volume": 100,
                "notional": 1_020,
            }
        ],
        source="provider_minute_scanner_seed",
    )

    candle = builder.on_trade(
        {
            "symbol": "AAPL",
            "last": 10.6,
            "trade_volume": 5,
            "received_at": "2026-07-02T14:30:15+00:00",
        },
        source="toss_polling_tick",
    )

    assert candle is not None
    assert candle["market_time"] == "143100"
    assert candle["korea_time"] == "233100"
    assert candle["open"] == 10.0
    assert candle["high"] == 10.6
    assert candle["low"] == 9.9
    assert candle["close"] == 10.6
    assert candle["volume"] == 105
    assert candle["live_merged_from_official"] is True


def test_new_minute_completes_previous_live_candle() -> None:
    builder = InMemoryCandleBuilder()
    builder.on_trade(
        {
            "symbol": "AAPL",
            "last": 10.0,
            "trade_volume": 1,
            "market_date": "20260702",
            "local_time": "143015",
        }
    )
    builder.on_trade(
        {
            "symbol": "AAPL",
            "last": 11.0,
            "trade_volume": 1,
            "market_date": "20260702",
            "local_time": "143100",
        }
    )

    candles = builder.live_tick_candles("AAPL")

    assert len(candles) == 2
    assert candles[0]["is_live"] is False
    assert candles[0]["is_complete"] is True
    assert candles[1]["is_live"] is True


def test_official_seed_replaces_same_source_window() -> None:
    builder = InMemoryCandleBuilder()
    builder.seed(
        "AAPL",
        [
            {
                "market_date": "20260702",
                "market_time": "143100",
                "open": 10.0,
                "high": 10.0,
                "low": 10.0,
                "close": 10.0,
            }
        ],
        source="provider_minute_scanner_seed",
    )

    builder.seed(
        "AAPL",
        [
            {
                "market_date": "20260702",
                "market_time": "143000",
                "open": 11.0,
                "high": 11.0,
                "low": 11.0,
                "close": 11.0,
            }
        ],
        source="provider_minute_scanner_seed",
    )

    candles = builder.candles("AAPL")

    assert len(candles) == 1
    assert candles[0]["market_time"] == "143000"
    assert candles[0]["close"] == 11.0


def test_official_future_candle_is_hidden_from_current_window() -> None:
    builder = InMemoryCandleBuilder()
    future = datetime.now(timezone.utc).replace(second=0, microsecond=0) + timedelta(minutes=5)

    builder.seed(
        "AAPL",
        [
            {
                "market_date": future.strftime("%Y%m%d"),
                "market_time": future.strftime("%H%M%S"),
                "open": 10.0,
                "high": 10.0,
                "low": 10.0,
                "close": 10.0,
            }
        ],
        source="provider_minute_scanner_seed",
    )

    assert builder.candles("AAPL") == []
