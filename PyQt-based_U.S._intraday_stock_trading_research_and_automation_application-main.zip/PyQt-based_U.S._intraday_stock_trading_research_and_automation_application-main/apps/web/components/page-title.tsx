import type { ReactNode } from "react";

export function PageTitle({
  title,
  description,
  action,
  icon,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="z-10 flex flex-col gap-4 border-b border-line/70 bg-white/75 px-6 py-5 backdrop-blur-xl md:flex-row md:items-center md:justify-between lg:sticky lg:top-0">
      <div className="flex min-w-0 items-start gap-3.5">
        {icon ? (
          <div className="mt-0.5 grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-indigo-100 to-blue-50 text-indigo-600 shadow-sm ring-1 ring-indigo-100">
            {icon}
          </div>
        ) : null}
        <div className="min-w-0">
          <h1 className="text-2xl font-bold tracking-tight text-ink">{title}</h1>
          {description ? <p className="mt-1 max-w-3xl text-sm leading-6 text-zinc-500">{description}</p> : null}
        </div>
      </div>
      {action}
    </div>
  );
}
