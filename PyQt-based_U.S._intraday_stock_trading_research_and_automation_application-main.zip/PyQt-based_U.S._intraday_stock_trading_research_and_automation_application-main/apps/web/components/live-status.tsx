"use client";

export function LiveStatus({
  connected,
  eventAt,
  updatedAt,
  label = "부분 업데이트 연결",
}: {
  connected: boolean;
  eventAt?: Date | null;
  updatedAt: Date | null;
  label?: string;
}) {
  return (
    <div className="inline-flex items-center gap-2 rounded border border-line bg-white px-3 py-2 text-xs font-semibold text-zinc-600">
      <span className={connected ? "h-2 w-2 rounded-full bg-ok" : "h-2 w-2 rounded-full bg-warn"} />
      <span>{connected ? label : "이벤트 대기"}</span>
      <span className="text-zinc-400">이벤트 {formatTime(eventAt)}</span>
      <span className="text-zinc-400">데이터 {formatTime(updatedAt)}</span>
    </div>
  );
}

function formatTime(value?: Date | null) {
  return value ? value.toLocaleTimeString("ko-KR", { hour12: false }) : "-";
}
