from datetime import datetime, timedelta, timezone

import pytest

from app.adapters.toss.client import TossApiError, TossExecutionClient, _TOKEN_CACHE
from app.core.config import Settings


class _Response:
    def __init__(self, status_code: int, payload: dict | None = None, text: str = "") -> None:
        self.status_code = status_code
        self._payload = payload or {}
        self.text = text

    def json(self) -> dict:
        return self._payload


def _seed_cached_token(settings: Settings, token: str) -> tuple[str, str]:
    cache_key = (settings.toss_token_url, settings.toss_app_key or "")
    _TOKEN_CACHE[cache_key] = (token, datetime.now(timezone.utc) + timedelta(hours=1))
    return cache_key


def test_toss_client_refreshes_token_and_retries_once_on_401(monkeypatch) -> None:
    settings = Settings(
        toss_app_key="app-key",
        toss_app_secret="app-secret",
        toss_base_url="https://example.test",
        toss_token_url="https://example.test/oauth2/token",
    )
    client = TossExecutionClient(settings)
    _seed_cached_token(settings, "stale-token")
    tokens_used: list[str] = []

    def fake_send(method, path, *, params, json_body, account_seq, token):
        tokens_used.append(token)
        if len(tokens_used) == 1:
            return _Response(401, {"error": "expired"}, "expired")
        return _Response(200, {"result": {"ok": True}})

    monkeypatch.setattr(client, "_send_authorized_request", fake_send)
    monkeypatch.setattr(client, "_refresh_access_token", lambda *, stale_token: "fresh-token")

    result = client._request("GET", "/api/v1/orderbook", params={"symbol": "AAPL"})

    assert result == {"result": {"ok": True}}
    # First attempt uses the cached token, the retry uses the coalesced refreshed token.
    assert tokens_used == ["stale-token", "fresh-token"]


def test_toss_client_reports_invalid_token_after_refresh(monkeypatch) -> None:
    settings = Settings(
        toss_app_key="app-key",
        toss_app_secret="app-secret",
        toss_base_url="https://example.test",
        toss_token_url="https://example.test/oauth2/token",
    )
    client = TossExecutionClient(settings)
    _seed_cached_token(settings, "stale-token")
    tokens_used: list[str] = []

    def fake_send(method, path, *, params, json_body, account_seq, token):
        tokens_used.append(token)
        return _Response(
            401,
            {"error": {"code": "invalid-token", "message": "invalid"}},
            '{"error":{"code":"invalid-token","message":"invalid"}}',
        )

    monkeypatch.setattr(client, "_send_authorized_request", fake_send)
    monkeypatch.setattr(client, "_refresh_access_token", lambda *, stale_token: "fresh-token")

    with pytest.raises(TossApiError) as exc_info:
        client._request("GET", "/api/v1/orderbook", params={"symbol": "AAPL"})

    assert tokens_used == ["stale-token", "fresh-token"]
    assert exc_info.value.status_code == 401
    assert "Toss token rejected after refresh" in str(exc_info.value)


def test_toss_refresh_coalesces_when_another_thread_already_refreshed() -> None:
    settings = Settings(
        toss_app_key="app-key",
        toss_app_secret="app-secret",
        toss_base_url="https://example.test",
        toss_token_url="https://example.test/oauth2/token",
    )
    client = TossExecutionClient(settings)
    # Another thread already stored a newer, still-valid token in the shared cache.
    _seed_cached_token(settings, "fresh-token")

    # Refreshing after failing with the old token must adopt the cached one, not re-fetch.
    token = client._refresh_access_token(stale_token="stale-token")

    assert token == "fresh-token"


def test_toss_create_order_requires_live_gate() -> None:
    settings = Settings(
        toss_app_key="app-key",
        toss_app_secret="app-secret",
        trading_mode="internal_paper",
        toss_environment="live",
        live_enabled=True,
        toss_live_order_enabled=False,
    )
    client = TossExecutionClient(settings)

    with pytest.raises(TossApiError) as exc_info:
        client.create_order(symbol="AAPL", side="BUY", order_type="MARKET", quantity=1)

    assert "Toss live order is disabled" in str(exc_info.value)


def test_toss_create_order_posts_quantity_market_order(monkeypatch) -> None:
    settings = Settings(
        toss_app_key="app-key",
        toss_app_secret="app-secret",
        toss_base_url="https://example.test",
        toss_token_url="https://example.test/oauth2/token",
        trading_mode="live",
        live_enabled=True,
        toss_environment="live",
        toss_live_order_enabled=True,
    )
    client = TossExecutionClient(settings)
    sent: list[dict] = []

    def fake_request(method, path, *, params=None, json_body=None, account_seq=None):
        sent.append(
            {
                "method": method,
                "path": path,
                "params": params,
                "json_body": json_body,
                "account_seq": account_seq,
            }
        )
        return {"result": {"orderId": "order-1", "clientOrderId": json_body["clientOrderId"]}}

    monkeypatch.setattr(client, "_request", fake_request)

    result = client.create_order(
        symbol="aapl",
        side="buy",
        order_type="market",
        quantity=1,
        client_order_id="tl-test",
        account_seq=7,
    )

    assert result == {"orderId": "order-1", "clientOrderId": "tl-test"}
    assert sent == [
        {
            "method": "POST",
            "path": "/api/v1/orders",
            "params": None,
            "json_body": {
                "symbol": "AAPL",
                "side": "BUY",
                "orderType": "MARKET",
                "timeInForce": "DAY",
                "confirmHighValueOrder": False,
                "clientOrderId": "tl-test",
                "quantity": "1",
            },
            "account_seq": 7,
        }
    ]


def test_toss_order_detail_lists_and_cancels_orders(monkeypatch) -> None:
    settings = Settings(
        toss_app_key="app-key",
        toss_app_secret="app-secret",
        toss_base_url="https://example.test",
        toss_token_url="https://example.test/oauth2/token",
        toss_account_id="9",
    )
    client = TossExecutionClient(settings)
    sent: list[dict] = []

    def fake_request(method, path, *, params=None, json_body=None, account_seq=None):
        sent.append(
            {
                "method": method,
                "path": path,
                "params": params,
                "json_body": json_body,
                "account_seq": account_seq,
            }
        )
        if path == "/api/v1/orders/order-1":
            return {"result": {"orderId": "order-1", "status": "FILLED"}}
        if path == "/api/v1/orders":
            return {"result": {"orders": []}}
        return {"result": {"orderId": "order-1"}}

    monkeypatch.setattr(client, "_request", fake_request)

    assert client.order_detail(order_id="order-1") == {"orderId": "order-1", "status": "FILLED"}
    assert client.list_orders(status="open", symbol="path", from_date="2026-07-01", to_date="2026-07-11", limit=250) == {"orders": []}
    assert client.cancel_order(order_id="order-1") == {"orderId": "order-1"}
    assert sent == [
        {
            "method": "GET",
            "path": "/api/v1/orders/order-1",
            "params": None,
            "json_body": None,
            "account_seq": 9,
        },
        {
            "method": "GET",
            "path": "/api/v1/orders",
            "params": {"status": "OPEN", "symbol": "PATH", "from": "2026-07-01", "to": "2026-07-11", "limit": 100},
            "json_body": None,
            "account_seq": 9,
        },
        {
            "method": "POST",
            "path": "/api/v1/orders/order-1/cancel",
            "params": None,
            "json_body": {},
            "account_seq": 9,
        },
    ]
