from app.adapters.kis.websocket_client import KisWebSocketClient

kis_ws_client = KisWebSocketClient()
