"use client";

import { CalendarDays, RefreshCw, X } from "lucide-react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

const timeframes = [
  { value: "1m", label: "1분" },
  { value: "5m", label: "5분" },
  { value: "10m", label: "10분" },
  { value: "30m", label: "30분" },
  { value: "60m", label: "60분" },
  { value: "180m", label: "3시간" },
  { value: "1d", label: "1일" },
  { value: "7d", label: "7일" },
  { value: "30d", label: "30일" },
  { value: "365d", label: "365일" },
];

export function SymbolRefreshControls({ activeTimeframe, activeDate }: { activeTimeframe: string; activeDate?: string }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const selectedDate = normalizeInputDate(activeDate);
  const historicalMode = Boolean(selectedDate);

  function selectTimeframe(value: string) {
    const params = new URLSearchParams(searchParams.toString());
    params.set("timeframe", value);
    router.push(`${pathname}?${params.toString()}`);
  }

  function selectDate(value: string) {
    const params = new URLSearchParams(searchParams.toString());
    if (value) {
      params.set("date", value);
    } else {
      params.delete("date");
    }
    router.push(`${pathname}?${params.toString()}`);
  }

  return (
    <div className="rounded border border-line bg-white p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {timeframes.map((timeframe) => {
            const active = timeframe.value === activeTimeframe;
            return (
              <button
                key={timeframe.value}
                onClick={() => selectTimeframe(timeframe.value)}
                className={[
                  "h-9 rounded border px-3 text-sm font-semibold",
                  active ? "border-ink bg-ink text-white" : "border-line bg-white text-ink hover:bg-zinc-50",
                ].join(" ")}
              >
                {timeframe.label}
              </button>
            );
          })}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex h-9 items-center gap-2 rounded border border-line bg-white px-3">
            <CalendarDays className="h-4 w-4 text-zinc-500" aria-hidden />
            <input
              type="date"
              value={selectedDate}
              onChange={(event) => selectDate(event.target.value)}
              className="w-36 bg-transparent text-sm font-semibold text-ink outline-none"
              aria-label="과거 차트 날짜"
            />
          </div>
          <button
            type="button"
            onClick={() => selectDate(formatDateInput(new Date()))}
            className="h-9 rounded border border-line px-3 text-sm font-semibold text-ink hover:bg-zinc-50"
          >
            오늘
          </button>
          <button
            type="button"
            onClick={() => selectDate(formatDateInput(addDays(new Date(), -1)))}
            className="h-9 rounded border border-line px-3 text-sm font-semibold text-ink hover:bg-zinc-50"
          >
            어제
          </button>
          {selectedDate ? (
            <button
              type="button"
              onClick={() => selectDate("")}
              className="grid h-9 w-9 place-items-center rounded border border-line text-ink hover:bg-zinc-50"
              title="날짜 해제"
              aria-label="날짜 해제"
            >
              <X className="h-4 w-4" aria-hidden />
            </button>
          ) : null}
        </div>
        <div className="inline-flex items-center gap-2 text-xs font-semibold text-zinc-500">
          <RefreshCw className="h-4 w-4" aria-hidden />
          {historicalMode ? "과거 차트 고정" : "자동 새로고침 꺼짐"}
        </div>
      </div>
    </div>
  );
}

function normalizeInputDate(value?: string) {
  if (!value) {
    return "";
  }
  if (/^\d{8}$/.test(value)) {
    return `${value.slice(0, 4)}-${value.slice(4, 6)}-${value.slice(6, 8)}`;
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return value;
  }
  return "";
}

function addDays(date: Date, days: number) {
  const output = new Date(date);
  output.setDate(output.getDate() + days);
  return output;
}

function formatDateInput(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
