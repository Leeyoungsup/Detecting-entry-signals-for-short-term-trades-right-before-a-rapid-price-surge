from datetime import datetime, timezone
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Query

from app.adapters.market_data.base import MarketDataUnavailableError
from app.adapters.toss.client import TossApiError, TossExecutionClient
from app.core.config import get_settings
from app.domain.models import OrderRequest
from app.services.candle_builder import candle_builder
from app.services.execution_pricing import ExecutionPricingError, execution_market_snapshot
from app.services.live_broker import LiveBroker
from app.services.market_data import get_market_data_service
from app.services.paper_broker import InternalPaperBroker
from app.services.risk_manager import RiskManager
from app.services.scanner import ScannerService
from app.services.strategy_engine import EntryPatternEngine
from app.services.strategy_runtime import _dynamic_stop_loss_price, _entry_exit_plan, strategy_runtime

router = APIRouter()


def _ensure_internal_paper_mode() -> None:
    settings = get_settings()
    if settings.trading_mode != "internal_paper":
        raise HTTPException(
            status_code=410,
            detail={
                "message": "Internal paper order routes are disabled while live mode is active.",
                "trading_mode": settings.trading_mode,
                "live_enabled": settings.live_enabled,
            },
        )


@router.get("")
def orders() -> dict:
    settings = get_settings()
    if settings.trading_mode == "live":
        return LiveBroker(settings=settings).state()
    return InternalPaperBroker().state()


@router.post("/live/reconcile")
def reconcile_live_orders() -> dict:
    settings = get_settings()
    if settings.trading_mode != "live":
        raise HTTPException(status_code=410, detail={"message": "Live reconcile is only available in TRADING_MODE=live."})
    return LiveBroker(settings=settings).reconcile_open_orders()


@router.post("/live/emergency-stop")
def live_emergency_stop(
    reason: str = Query(default="manual_api"),
    liquidate: bool = Query(default=False),
) -> dict:
    settings = get_settings()
    if settings.trading_mode != "live":
        raise HTTPException(status_code=410, detail={"message": "Live emergency stop is only available in TRADING_MODE=live."})
    return LiveBroker(settings=settings).activate_emergency_stop(reason=reason, liquidate=liquidate)


@router.post("/live/emergency-stop/clear")
def clear_live_emergency_stop() -> dict:
    settings = get_settings()
    if settings.trading_mode != "live":
        raise HTTPException(status_code=410, detail={"message": "Live emergency stop is only available in TRADING_MODE=live."})
    return LiveBroker(settings=settings).clear_emergency_stop()


@router.post("/paper/reset")
def reset_paper_state() -> dict:
    _ensure_internal_paper_mode()
    return {
        "paper": InternalPaperBroker().reset(),
        "strategy_runtime": strategy_runtime.reset_order_memory(),
    }


@router.post("/paper")
def submit_paper_order(request: OrderRequest) -> dict:
    _ensure_internal_paper_mode()
    order_id, events = InternalPaperBroker().submit_order(request)
    return {"order_id": order_id, "events": [event.model_dump(mode="json") for event in events]}


@router.post("/paper/dev-simulate")
def submit_dev_simulated_paper_order(
    symbol: str = Query(default="AAPL"),
    side: str = Query(default="buy", pattern="^(buy|sell)$"),
    price: float | None = Query(default=None, gt=0),
    quantity: float | None = Query(default=None, gt=0),
) -> dict:
    _ensure_internal_paper_mode()
    """Create a simulated order for timeline/UI testing only.

    This endpoint never calls Toss/KIS order APIs. It uses live market-data when
    available and falls back to a local fixture price so the order state machine
    can be tested even while execution provider access is blocked.
    """
    symbol = symbol.upper()
    broker = InternalPaperBroker()
    state = broker.state()
    existing_position = next((row for row in state.get("positions", []) if row.get("symbol") == symbol), None)

    if side == "sell" and not existing_position:
        raise HTTPException(status_code=409, detail={"message": "청산할 paper 포지션이 없습니다.", "symbol": symbol})

    provider = get_market_data_service().provider
    market = _market_snapshot(provider, symbol)
    reference = price or market.get("ask") or market.get("bid") or market.get("last") or 100.0
    bid = market.get("bid") or reference * 0.999
    ask = market.get("ask") or reference * 1.001
    if side == "sell":
        default_quantity = float(existing_position["quantity"])
        quantity = quantity or default_quantity
    else:
        if get_settings().scanner_min_price_usd > 0 and ask < get_settings().scanner_min_price_usd:
            raise HTTPException(
                status_code=409,
                detail={
                    "message": "초저가 종목은 스프레드/호가 왜곡 위험이 커서 paper 매수 주문을 생성하지 않았습니다.",
                    "min_price_usd": get_settings().scanner_min_price_usd,
                    "entry_price": ask,
                },
            )
        quantity = quantity or max(1.0, min(3.0, int(300.0 / reference)))
    market_snapshot = {
        **market,
        "last": market.get("last") or reference,
        "bid": bid,
        "ask": ask,
        "spread_pct": market.get("spread_pct") if market.get("spread_pct") is not None else _spread_pct(bid, ask),
        "source": market.get("source") or "internal_dev_simulation",
        "dev_simulation": True,
        "live_order_called": False,
    }
    if side == "buy":
        market_snapshot["exit_plan"] = _entry_exit_plan(ask, quantity=quantity, market_snapshot=market_snapshot)
    elif existing_position:
        market_snapshot["position_key"] = existing_position.get("position_key")
        market_snapshot["strategy_name"] = existing_position.get("strategy_name")
        market_snapshot["parameter_set_id"] = existing_position.get("parameter_set_id")
        market_snapshot["entry_mode"] = existing_position.get("entry_mode")
    limit_price = ask * 1.001 if side == "buy" else bid * 0.999
    request = OrderRequest(
        symbol=symbol,
        side=side,
        order_type="marketable_limit",
        quantity=float(quantity),
        limit_price=limit_price,
        mode="internal_paper",
    )
    order_id, events = broker.submit_order(request, market_snapshot=market_snapshot)
    return {
        "order_id": order_id,
        "mode": "internal_paper",
        "dev_simulation": True,
        "live_order_called": False,
        "market_snapshot": market_snapshot,
        "events": [event.model_dump(mode="json") for event in events],
    }


@router.post("/paper/dev-tick")
def push_dev_paper_tick(
    symbol: str = Query(default="AAPL"),
    price: float = Query(..., gt=0),
    volume: float = Query(default=1, gt=0),
) -> dict:
    _ensure_internal_paper_mode()
    """Push a synthetic market-data tick through the candle/strategy runtime."""
    symbol = symbol.upper()
    now = datetime.now(timezone.utc)
    event = {
        "event_type": "trade",
        "symbol": symbol,
        "last": price,
        "trade_volume": volume,
        "received_at": now.isoformat(),
        "local_time": now.strftime("%H%M%S"),
        "market_date": now.strftime("%Y%m%d"),
        "raw": {
            "xymd": now.strftime("%Y%m%d"),
            "xhms": now.strftime("%H%M%S"),
        },
        "dev_simulation": True,
    }
    candle = candle_builder.on_trade(event, source="internal_dev_tick")
    strategy_runtime.on_trade(event, candle)
    return {
        "symbol": symbol,
        "price": price,
        "volume": volume,
        "candle": candle,
        "orders": InternalPaperBroker().state(),
    }


@router.get("/toss/preview")
def toss_execution_preview(symbol: str = Query(...), side: str = Query(default="buy")) -> dict:
    try:
        return TossExecutionClient(get_settings()).execution_preview(symbol=symbol.upper(), side=side, currency="USD")
    except TossApiError as exc:
        raise HTTPException(
            status_code=502,
            detail={"message": str(exc), "status_code": exc.status_code, "payload": exc.payload},
        ) from exc


@router.get("/toss/accounts")
def toss_accounts(include_holdings: bool = Query(default=True), symbol: str | None = Query(default=None)) -> dict:
    settings = get_settings()
    client = TossExecutionClient(settings)
    try:
        accounts = client.accounts()
        account_seq = client.account_seq()
        buying_power_usd = client.buying_power(currency="USD", account_seq=account_seq)
        holdings = client.holdings(symbol=symbol.upper(), account_seq=account_seq) if include_holdings and symbol else None
        all_holdings = client.holdings(account_seq=account_seq) if include_holdings and not symbol else None
    except TossApiError as exc:
        raise HTTPException(
            status_code=502,
            detail={"message": str(exc), "status_code": exc.status_code, "payload": exc.payload},
        ) from exc

    return {
        "provider": "toss",
        "environment": settings.toss_environment,
        "trading_mode": settings.trading_mode,
        "live_enabled": settings.live_enabled,
        "live_order_enabled": client.live_order_enabled(),
        "selected_account_seq": account_seq,
        "accounts": [_safe_account(row) for row in accounts],
        "buying_power_usd": buying_power_usd,
        "holdings": holdings if symbol else all_holdings,
    }


@router.post("/toss/live-test-order")
def toss_live_test_order(
    symbol: str = Query(..., min_length=1, max_length=12, pattern=r"^[A-Za-z0-9.\-]+$"),
    side: str = Query(..., pattern="^(buy|sell)$"),
    quantity: float = Query(default=1.0, gt=0),
    dry_run: bool = Query(default=True),
    confirm: str = Query(default=""),
    arm_token: str | None = Query(default=None),
) -> dict:
    settings = get_settings()
    client = TossExecutionClient(settings)
    symbol = symbol.upper()
    side = side.lower()
    quantity = float(quantity)

    if quantity > settings.toss_live_max_quantity:
        raise HTTPException(
            status_code=409,
            detail={
                "message": "수동 live 테스트 주문 수량 한도를 초과했습니다.",
                "quantity": quantity,
                "max_quantity": settings.toss_live_max_quantity,
            },
        )

    try:
        account_seq = client.account_seq()
        preview = client.execution_preview(symbol=symbol, side=side, currency="USD")
        reference_price = _to_float(preview.get("best_ask")) if side == "buy" else _to_float(preview.get("best_bid"))
        if reference_price is None:
            raise HTTPException(status_code=422, detail={"message": "Toss 호가 기준 가격이 없어 live 테스트 주문을 준비할 수 없습니다."})

        notional_usd = reference_price * quantity
        if notional_usd > settings.toss_live_max_order_notional_usd:
            raise HTTPException(
                status_code=409,
                detail={
                    "message": "수동 live 테스트 주문 금액 한도를 초과했습니다.",
                    "estimated_notional_usd": round(notional_usd, 4),
                    "max_notional_usd": settings.toss_live_max_order_notional_usd,
                },
            )

        sellable = None
        if side == "sell":
            sellable = client.sellable_quantity(symbol=symbol, account_seq=account_seq)
            sellable_quantity = _to_float(sellable.get("sellableQuantity")) or 0.0
            if sellable_quantity < quantity:
                raise HTTPException(
                    status_code=409,
                    detail={
                        "message": "매도 가능 수량이 live 테스트 주문 수량보다 적습니다.",
                        "sellable_quantity": sellable_quantity,
                        "quantity": quantity,
                    },
                )
        else:
            cash_buying_power = _to_float(preview.get("cash_buying_power")) or 0.0
            if cash_buying_power < notional_usd:
                raise HTTPException(
                    status_code=409,
                    detail={
                        "message": "매수 가능 금액이 live 테스트 주문 예상 금액보다 적습니다.",
                        "cash_buying_power_usd": cash_buying_power,
                        "estimated_notional_usd": round(notional_usd, 4),
                    },
                )
    except HTTPException:
        raise
    except TossApiError as exc:
        raise HTTPException(
            status_code=502,
            detail={"message": str(exc), "status_code": exc.status_code, "payload": exc.payload},
        ) from exc

    client_order_id = _live_test_client_order_id(symbol, side)
    required_confirm = f"LIVE {side.upper()} {symbol} {_quantity_label(quantity)}"
    request_body = {
        "clientOrderId": client_order_id,
        "symbol": symbol,
        "side": side.upper(),
        "orderType": "MARKET",
        "quantity": _quantity_label(quantity),
        "timeInForce": "DAY",
        "confirmHighValueOrder": False,
    }
    base_response = {
        "provider": "toss",
        "environment": settings.toss_environment,
        "trading_mode": settings.trading_mode,
        "live_enabled": settings.live_enabled,
        "live_order_enabled": client.live_order_enabled(),
        "live_order_called": False,
        "dry_run": dry_run,
        "symbol": symbol,
        "side": side,
        "quantity": quantity,
        "estimated_notional_usd": round(reference_price * quantity, 4),
        "reference_price": reference_price,
        "required_confirm": required_confirm,
        "request_body": request_body,
        "account_seq": account_seq,
        "preview": preview,
        "sellable": sellable,
    }
    if dry_run:
        return {
            **base_response,
            "message": "dry_run=true 이므로 실제 Toss 주문은 호출하지 않았습니다.",
        }

    _require_live_test_gate(settings, client, arm_token=arm_token, confirm=confirm, required_confirm=required_confirm)
    try:
        result = client.create_order(
            symbol=symbol,
            side=side.upper(),
            order_type="MARKET",
            quantity=quantity,
            client_order_id=client_order_id,
            account_seq=account_seq,
            require_live_enabled=True,
        )
    except TossApiError as exc:
        raise HTTPException(
            status_code=502,
            detail={"message": str(exc), "status_code": exc.status_code, "payload": exc.payload, "request_body": request_body},
        ) from exc

    return {
        **base_response,
        "dry_run": False,
        "live_order_called": True,
        "message": "Toss live 테스트 주문을 제출했습니다. 주문 상세/체결 상태를 반드시 확인하세요.",
        "result": result,
    }


@router.post("/paper/test-from-scanner")
async def submit_test_from_scanner(
    max_orders: int = Query(default=1, ge=1, le=5),
    relaxed: bool = Query(default=True),
) -> dict:
    _ensure_internal_paper_mode()
    settings = get_settings()
    if not settings.paper_test_orders_enabled:
        raise HTTPException(status_code=403, detail={"message": "PAPER_TEST_ORDERS_ENABLED=false"})

    scanner = ScannerService()
    await scanner.ensure_realtime()
    snapshot = scanner.funnel_snapshot()
    provider = get_market_data_service().provider
    broker = InternalPaperBroker()
    orders = []
    skipped = []
    max_count = min(max_orders, settings.paper_test_max_orders_per_call)

    for candidate in snapshot.get("candidates", []):
        symbol = str(candidate.get("symbol") or "").upper()
        if not symbol:
            continue
        if broker.has_exposure(symbol):
            skipped.append({"symbol": symbol, "reason": "이미 paper 포지션 또는 열린 주문이 있습니다."})
            continue
        if not _paper_test_candidate_allowed(candidate, relaxed=relaxed):
            skipped.append({"symbol": symbol, "reason": candidate.get("reject_reason") or "테스트 후보 기준 미달"})
            continue

        try:
            market = _execution_market_snapshot(provider, symbol, side="buy")
        except TossApiError as exc:
            raise HTTPException(
                status_code=502,
                detail={
                    "message": "Toss 호가/매수가능금액 조회 실패로 시뮬레이션 테스트 주문을 생성하지 않았습니다.",
                    "toss_error": str(exc),
                    "status_code": exc.status_code,
                    "payload": exc.payload,
                },
            ) from exc
        entry_price = market.get("ask") or market.get("last")
        if entry_price is None:
            skipped.append({"symbol": symbol, "reason": "실시간 가격/호가가 없어 시뮬레이션 주문 생성 불가"})
            continue
        cash_buying_power = _to_float(market.get("cash_buying_power"))
        strategy_candles = candle_builder.live_tick_candles(symbol, limit=120, include_current=True, newest_first=False)
        if settings.scanner_min_price_usd > 0 and entry_price < settings.scanner_min_price_usd:
            skipped.append(
                {
                    "symbol": symbol,
                    "reason": "low_price_blocked",
                    "entry_price": entry_price,
                    "min_price_usd": settings.scanner_min_price_usd,
                }
            )
            continue
        risk = RiskManager().preview_long_entry(
            account_equity_usd=settings.paper_initial_equity_usd,
            entry_price=entry_price,
            stop_loss_price=_dynamic_stop_loss_price(entry_price, strategy_candles, market_snapshot=market),
        )
        if cash_buying_power is not None:
            capped_quantity = int(min(risk.quantity or 0, cash_buying_power / entry_price))
            risk.quantity = float(capped_quantity)
            risk.max_notional_usd = min(risk.max_notional_usd, cash_buying_power)
        if not risk.allowed or not risk.quantity or risk.quantity <= 0:
            skipped.append({"symbol": symbol, "reason": risk.reason or "리스크 수량 계산 실패"})
            continue

        toss_order_amount = min((risk.quantity or 0) * entry_price, cash_buying_power or float("inf"))
        request = OrderRequest(
            symbol=symbol,
            side="buy",
            order_type="marketable_limit",
            quantity=risk.quantity,
            limit_price=entry_price * 1.001,
            mode="internal_paper",
        )
        market["exit_plan"] = _entry_exit_plan(entry_price, strategy_candles, quantity=risk.quantity, market_snapshot=market)
        order_id, events = broker.submit_order(request, market_snapshot=market)
        orders.append(
            {
                "symbol": symbol,
                "order_id": order_id,
                "mode": "internal_paper",
                "test_relaxed": relaxed,
                "candidate": candidate,
                "market_snapshot": market,
                "toss_order_amount_usd": round(toss_order_amount, 2),
                "toss_live_order_note": "실제 Toss 주문은 호출하지 않음. 정규장 US MARKET 매수는 orderAmount 방식 가능.",
                "risk_preview": risk.model_dump(),
                "events": [event.model_dump(mode="json") for event in events],
            }
        )
        if len(orders) >= max_count:
            break

    if not orders:
        raise HTTPException(
            status_code=409,
            detail={
                "message": "시뮬레이션 테스트 주문 후보가 없습니다.",
                "skipped": skipped[:20],
            },
        )
    return {"orders": orders, "skipped": skipped[:20]}


@router.post("/paper/close")
def close_paper_position(symbol: str = Query(...), position_key: str | None = Query(default=None)) -> dict:
    _ensure_internal_paper_mode()
    symbol = symbol.upper()
    broker = InternalPaperBroker()
    state = broker.state()
    position = next(
        (
            row
            for row in state.get("positions", [])
            if row.get("symbol") == symbol and (position_key is None or row.get("position_key") == position_key)
        ),
        None,
    )
    if not position:
        raise HTTPException(status_code=404, detail={"message": "paper 포지션이 없습니다.", "symbol": symbol})
    provider = get_market_data_service().provider
    try:
        market = _execution_market_snapshot(provider, symbol, side="sell")
    except TossApiError as exc:
        raise HTTPException(
            status_code=502,
            detail={
                "message": "Toss 호가 조회 실패로 시뮬레이션 청산을 생성하지 않았습니다.",
                "toss_error": str(exc),
                "status_code": exc.status_code,
                "payload": exc.payload,
            },
        ) from exc
    exit_price = market.get("bid") or market.get("last")
    if exit_price is None:
        raise HTTPException(status_code=422, detail={"message": "실시간 가격/호가가 없어 시뮬레이션 청산 불가"})
    request = OrderRequest(
        symbol=symbol,
        side="sell",
        order_type="marketable_limit",
        quantity=float(position["quantity"]),
        limit_price=exit_price * 0.999,
        mode="internal_paper",
    )
    market["position_key"] = position.get("position_key")
    market["strategy_name"] = position.get("strategy_name")
    market["parameter_set_id"] = position.get("parameter_set_id")
    market["entry_mode"] = position.get("entry_mode")
    order_id, events = broker.submit_order(request, market_snapshot=market)
    return {
        "symbol": symbol,
        "order_id": order_id,
        "mode": "internal_paper",
        "market_snapshot": market,
        "events": [event.model_dump(mode="json") for event in events],
    }


@router.post("/paper/from-signal")
def submit_from_signal(symbol: str = Query(...), exchange: str = Query(default="NAS")) -> dict:
    _ensure_internal_paper_mode()
    symbol = symbol.upper()
    service = get_market_data_service().provider
    try:
        bars = service.minute_bars(symbol=symbol, exchange=exchange, interval="1", limit=120)
    except MarketDataUnavailableError as exc:
        raise HTTPException(status_code=503, detail={"message": str(exc)}) from exc
    candles = _bars_to_candles(symbol, bars.get("output2") or [])
    candle_builder.seed(symbol, candles, source="provider_minute")

    try:
        market_snapshot = execution_market_snapshot(symbol, side="buy")
    except ExecutionPricingError as exc:
        raise HTTPException(
            status_code=502,
            detail={"message": "Toss 기준 최종 매수 호가 조회 실패로 시뮬레이션 주문을 생성하지 않았습니다.", "payload": exc.payload},
        ) from exc
    entry_price = market_snapshot.get("ask") or market_snapshot.get("last")
    if entry_price is None:
        raise HTTPException(status_code=422, detail={"message": "Toss ask/last 가격이 없어 시뮬레이션 주문을 생성할 수 없습니다."})
    if get_settings().scanner_min_price_usd > 0 and entry_price < get_settings().scanner_min_price_usd:
        raise HTTPException(
            status_code=409,
            detail={
                "message": "초저가 종목은 스프레드/호가 왜곡 위험이 커서 시뮬레이션 주문을 생성하지 않았습니다.",
                "min_price_usd": get_settings().scanner_min_price_usd,
                "entry_price": entry_price,
            },
        )
    strategy_candles = candle_builder.live_tick_candles(symbol, limit=120, include_current=True, newest_first=False)
    base_risk = RiskManager().preview_long_entry(
        account_equity_usd=2000.0,
        entry_price=entry_price,
        stop_loss_price=_dynamic_stop_loss_price(entry_price, strategy_candles, market_snapshot=market_snapshot),
    )
    base_payload = base_risk.model_dump()
    base_payload["exit_plan"] = _entry_exit_plan(entry_price, strategy_candles, quantity=base_risk.quantity, market_snapshot=market_snapshot)
    preliminary = EntryPatternEngine().evaluate(
        symbol=symbol,
        candles=strategy_candles,
        risk_preview=base_payload,
    )
    risk = RiskManager().preview_long_entry(
        account_equity_usd=2000.0,
        entry_price=entry_price,
        stop_loss_price=_dynamic_stop_loss_price(
            entry_price,
            strategy_candles,
            market_snapshot=market_snapshot,
            evaluation=preliminary.model_dump(),
        ),
    )
    risk_payload = risk.model_dump()
    risk_payload["exit_plan"] = _entry_exit_plan(
        entry_price,
        strategy_candles,
        quantity=risk.quantity,
        market_snapshot=market_snapshot,
        evaluation=preliminary.model_dump(),
    )
    evaluation = EntryPatternEngine().evaluate(
        symbol=symbol,
        candles=strategy_candles,
        risk_preview=risk_payload,
    )
    if not evaluation.entry_allowed:
        raise HTTPException(
            status_code=409,
            detail={
                "message": "전략 진입 조건이 통과되지 않아 시뮬레이션 주문을 생성하지 않았습니다.",
                "evaluation": evaluation.model_dump(),
            },
        )
    request = OrderRequest(
        symbol=symbol,
        side="buy",
        order_type="marketable_limit",
        quantity=risk.quantity or 0,
        limit_price=entry_price * 1.001,
        mode="internal_paper",
        strategy_signal_id=f"{evaluation.parameter_set_id}-{symbol}",
    )
    market_snapshot["exit_plan"] = risk_payload["exit_plan"]
    market_snapshot["strategy_name"] = evaluation.strategy_name
    market_snapshot["parameter_set_id"] = evaluation.parameter_set_id
    market_snapshot["entry_mode"] = evaluation.entry_mode
    market_snapshot["entry_snapshot"] = {
        "strategy_name": evaluation.strategy_name,
        "strategy_version": evaluation.strategy_version,
        "parameter_set_id": evaluation.parameter_set_id,
        "entry_mode": evaluation.entry_mode,
        "final_score": evaluation.final_score,
        "price": entry_price,
        "risk_preview": risk_payload,
        "exit_plan": risk_payload["exit_plan"],
    }
    order_id, events = InternalPaperBroker().submit_order(
        request,
        market_snapshot=market_snapshot,
    )
    return {
        "order_id": order_id,
        "evaluation": evaluation.model_dump(),
        "events": [event.model_dump(mode="json") for event in events],
    }


def _safe_account(row: dict) -> dict:
    account = dict(row or {})
    account_no = account.pop("accountNo", None)
    account["accountNoMasked"] = _mask_account_no(account_no)
    return account


def _mask_account_no(value: object) -> str | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    visible = raw[-4:]
    return f"{'*' * max(0, len(raw) - len(visible))}{visible}"


def _live_test_client_order_id(symbol: str, side: str) -> str:
    safe_symbol = "".join(ch if ch.isalnum() else "_" for ch in symbol.upper())[:8] or "SYMBOL"
    return f"tl-{side[:1].lower()}-{safe_symbol}-{uuid4().hex[:20]}"


def _quantity_label(quantity: float) -> str:
    return f"{float(quantity):.6f}".rstrip("0").rstrip(".")


def _require_live_test_gate(settings, client: TossExecutionClient, *, arm_token: str | None, confirm: str, required_confirm: str) -> None:
    if not client.live_order_enabled():
        raise HTTPException(
            status_code=403,
            detail={
                "message": "Toss live 주문 게이트가 닫혀 있습니다.",
                "required": {
                    "TRADING_MODE": "live",
                    "LIVE_ENABLED": True,
                    "TOSS_ENVIRONMENT": "live",
                    "TOSS_LIVE_ORDER_ENABLED": True,
                },
                "current": {
                    "trading_mode": settings.trading_mode,
                    "live_enabled": settings.live_enabled,
                    "toss_environment": settings.toss_environment,
                    "toss_live_order_enabled": settings.toss_live_order_enabled,
                },
            },
        )
    if not settings.toss_live_order_arm_token:
        raise HTTPException(status_code=403, detail={"message": "TOSS_LIVE_ORDER_ARM_TOKEN이 설정되어 있지 않습니다."})
    if arm_token != settings.toss_live_order_arm_token:
        raise HTTPException(status_code=403, detail={"message": "live 주문 arm token이 일치하지 않습니다."})
    if confirm != required_confirm:
        raise HTTPException(
            status_code=409,
            detail={"message": "live 주문 confirm 문구가 일치하지 않습니다.", "required_confirm": required_confirm},
        )


def _bars_to_candles(symbol: str, rows: list[dict]) -> list[dict]:
    candles = [
        {
            "symbol": symbol,
            "market_date": row.get("xymd") or row.get("tymd"),
            "market_time": row.get("xhms"),
            "korea_date": row.get("kymd"),
            "korea_time": row.get("khms"),
            "open": _to_float(row.get("open")),
            "high": _to_float(row.get("high")),
            "low": _to_float(row.get("low")),
            "close": _to_float(row.get("last")),
            "volume": _to_float(row.get("evol")),
        }
        for row in rows
    ]
    return sorted(candles, key=lambda row: f"{row.get('market_date') or ''}{str(row.get('market_time') or '').zfill(6)}")


def _to_float(value: str | int | float | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _spread_pct(bid: float | None, ask: float | None) -> float | None:
    if not bid or not ask:
        return None
    midpoint = (bid + ask) / 2
    if midpoint <= 0:
        return None
    return (ask - bid) / midpoint * 100


def _paper_test_candidate_allowed(candidate: dict, *, relaxed: bool) -> bool:
    if candidate.get("selected_for_strategy"):
        return True
    if not relaxed or not get_settings().paper_test_relaxed_order_flow_only:
        return False
    return (
        bool(candidate.get("selected_for_ws"))
        and candidate.get("volume_source") == "provider_ws_tick_60s"
        and (_to_float(candidate.get("volume_1m")) or 0.0) >= get_settings().paper_test_min_realtime_volume_60s
    )


def _market_snapshot(provider, symbol: str) -> dict:
    realtime = provider.realtime_snapshot()
    trade = realtime.get("trades", {}).get(symbol) or {}
    quote = realtime.get("quotes", {}).get(symbol) or {}
    last = _to_float(trade.get("last"))
    bid = _to_float(quote.get("bid"))
    ask = _to_float(quote.get("ask"))
    if last is None:
        try:
            last = _to_float((provider.price(symbol=symbol, exchange="NAS").get("output") or {}).get("last"))
        except MarketDataUnavailableError:
            pass
    if bid is None or ask is None:
        try:
            quote_output2 = provider.quote(symbol=symbol, exchange="NAS").get("output2") or {}
            bid = bid if bid is not None else _to_float(quote_output2.get("pbid1"))
            ask = ask if ask is not None else _to_float(quote_output2.get("pask1"))
        except MarketDataUnavailableError:
            pass
    return {
        "last": last,
        "bid": bid,
        "ask": ask,
        "spread_pct": _spread_pct(bid, ask),
        "source": "market_data_provider_snapshot",
    }


def _execution_market_snapshot(provider, symbol: str, *, side: str) -> dict:
    settings = get_settings()
    if settings.execution_provider == "toss" or settings.toss_app_key or settings.toss_app_secret:
        preview = TossExecutionClient(settings).execution_preview(symbol=symbol, side=side, currency="USD")
        best_ask = _to_float(preview.get("best_ask"))
        best_bid = _to_float(preview.get("best_bid"))
        return {
            "last": best_ask or best_bid,
            "bid": best_bid,
            "ask": best_ask,
            "spread_pct": preview.get("spread_pct"),
            "cash_buying_power": preview.get("cash_buying_power"),
            "account_seq": preview.get("account_seq"),
            "currency": preview.get("currency"),
            "source": "toss_orderbook_buying_power",
            "toss_preview": preview,
        }
    return _market_snapshot(provider, symbol)
