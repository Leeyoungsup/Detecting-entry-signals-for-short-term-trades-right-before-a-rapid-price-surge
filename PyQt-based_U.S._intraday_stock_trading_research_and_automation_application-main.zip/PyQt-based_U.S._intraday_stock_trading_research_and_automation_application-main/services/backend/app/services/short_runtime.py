"""Live short-track runtime (extreme-fade shorts).

Evaluates the walk-forward-validated short setups -- Parabolic Exhaustion and
Volume Blow-off -- on completed live candles and manages short paper positions.
Mirrors scripts/replay_extreme_shorts.py, but computes indicators from the live
candle series (the enriched-CSV columns used in replay are not present live).

Safety: runs ONLY when strategy_short_track_enabled AND trading_mode ==
internal_paper. Live short order submission is never done here; every order goes
through the internal paper broker with position_side="short". The whole path is
wrapped so a failure never breaks the runtime loop.
"""
from __future__ import annotations

import statistics
from datetime import datetime, timezone

from app.core.config import get_settings
from app.domain.enums import StatusLevel
from app.domain.models import OrderRequest
from app.services.candle_builder import candle_builder
from app.services.event_log import record_event
from app.services.execution_pricing import ExecutionPricingError, execution_market_snapshot
from app.services.market_data import get_market_data_service
from app.services.paper_broker import InternalPaperBroker

# Parabolic Exhaustion Short (config D)
PARABOLIC_MIN_10BAR_RUN = 0.08
PARABOLIC_MIN_BB_POSITION = 1.05
PARABOLIC_MIN_VOLUME_RATIO = 1.30
PARABOLIC_MAX_BAR_CLOSE_POSITION = 0.45
PARABOLIC_CLIMAX_LOOKBACK = 6
# Volume Blow-off Short (config C)
BLOWOFF_MIN_VOLUME_RATIO = 3.00
BLOWOFF_MIN_10BAR_RUN = 0.06
BLOWOFF_MAX_BAR_CLOSE_POSITION = 0.40
# common short filter
MIN_NOTIONAL_1M_USD = 30_000.0
MIN_EXPECTED_EDGE_PCT = 0.002
# execution / risk (validated: bounded stop above, tight trailing)
FINAL_STOP_PCT = 0.035
TRAILING_ACTIVATE_PCT = 0.006
TRAILING_WIDTH_PCT = 0.006


def _f(value: object) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _completed(candles: list[dict]) -> list[dict]:
    return [row for row in candles if not row.get("is_live")]


def _recent_10bar_change(candles: list[dict], lookback: int = 10) -> float | None:
    # Matches replay recent_10bar_change_fraction: change over the last `lookback`
    # bars (window = candles[-lookback:]), NOT candles[-lookback-1].
    window = candles[-lookback:]
    if len(window) < 2:
        return None
    first, last = _f(window[0].get("close")), _f(window[-1].get("close"))
    if not first or first <= 0 or last is None:
        return None
    return (last - first) / first


def _volume_ratio(candles: list[dict]) -> float:
    # Matches the enriched volume_ma20 column: a 20-bar SMA INCLUDING the current
    # bar (empirically verified: col_ma20 == mean(volume[i-19:i+1])).
    window = [(_f(row.get("volume")) or 0.0) for row in candles[-20:]]
    baseline = (sum(window) / len(window)) if window else 0.0
    return (_f(candles[-1].get("volume")) or 0.0) / max(baseline, 1.0)


def _bb_position(candles: list[dict]) -> float | None:
    closes = [_f(row.get("close")) for row in candles[-20:]]
    closes = [c for c in closes if c is not None]
    if len(closes) < 20:
        return None
    mid = statistics.fmean(closes)
    std = statistics.pstdev(closes)
    upper, lower = mid + 2 * std, mid - 2 * std
    if upper <= lower:
        return None
    close = _f(candles[-1].get("close"))
    return None if close is None else (close - lower) / (upper - lower)


def _bar_close_position(row: dict) -> float:
    high, low, close = _f(row.get("high")), _f(row.get("low")), _f(row.get("close"))
    if high is None or low is None or close is None or high <= low:
        return 0.5
    return (close - low) / (high - low)


def _climax_new_high(candles: list[dict], lookback: int) -> bool:
    prior = candles[-(lookback + 1):-1]
    if not prior:
        return False
    prior_high = max((_f(row.get("high")) or 0.0) for row in prior)
    return (_f(candles[-1].get("high")) or 0.0) >= prior_high * 0.999


def _parabolic_signal(candles: list[dict]) -> bool:
    row = candles[-1]
    run = _recent_10bar_change(candles) or 0.0
    bb = _bb_position(candles)
    reversal = (_f(row.get("close")) or 0.0) < (_f(row.get("open")) or 0.0) and _bar_close_position(row) <= PARABOLIC_MAX_BAR_CLOSE_POSITION
    return (
        run >= PARABOLIC_MIN_10BAR_RUN
        and (bb is None or bb >= PARABOLIC_MIN_BB_POSITION)
        and _climax_new_high(candles, PARABOLIC_CLIMAX_LOOKBACK)
        and reversal
        and _volume_ratio(candles) >= PARABOLIC_MIN_VOLUME_RATIO
    )


def _blowoff_signal(candles: list[dict]) -> bool:
    row = candles[-1]
    run = _recent_10bar_change(candles) or 0.0
    reversal = (_f(row.get("close")) or 0.0) < (_f(row.get("open")) or 0.0) and _bar_close_position(row) <= BLOWOFF_MAX_BAR_CLOSE_POSITION
    return _volume_ratio(candles) >= BLOWOFF_MIN_VOLUME_RATIO and run >= BLOWOFF_MIN_10BAR_RUN and reversal


SHORT_SETUPS = [
    ("Parabolic Exhaustion Short", "parabolic_exhaustion_short", _parabolic_signal),
    ("Volume Blow-off Short", "volume_blowoff_short", _blowoff_signal),
]


def _common_short_ok(candles: list[dict], flow: dict) -> bool:
    row = candles[-1]
    close = _f(row.get("close")) or 0.0
    volume = _f(row.get("volume")) or 0.0
    if close * volume < MIN_NOTIONAL_1M_USD:
        return False
    spread_pct = _f(flow.get("spread_pct"))
    spread_fraction = max(0.0, (spread_pct or 0.0) / 100.0)
    if spread_fraction > (0.0125 if close < 2.0 else 0.0085):
        return False
    recent_move = abs(_recent_10bar_change(candles) or 0.0)
    reachable = recent_move * 0.4
    roundtrip_cost = spread_fraction + 0.0033  # slippage + commission + SEC (matches replay)
    return reachable >= roundtrip_cost + MIN_EXPECTED_EDGE_PCT


class ShortTrackRuntime:
    def __init__(self) -> None:
        self._last_ordered_bucket: dict[str, str] = {}

    def on_completed_candle(self, symbol: str, bucket: str, candles: list[dict]) -> None:
        try:
            settings = get_settings()
            if not settings.strategy_short_track_enabled or settings.trading_mode != "internal_paper":
                return
            completed = _completed(candles)
            if len(completed) < 25:
                return
            flow = get_market_data_service().provider.order_flow_snapshot().get(symbol.upper(), {})
            for strategy_name, parameter_set_id, signal in SHORT_SETUPS:
                if signal(completed) and _common_short_ok(completed, flow):
                    self._submit_short_entry(symbol, bucket, strategy_name, parameter_set_id)
                    return
        except Exception as exc:  # never break the runtime loop
            record_event(
                level="WARNING", event_type="short.error", severity=StatusLevel.WARNING,
                symbol=symbol, message="Short-track entry evaluation failed.", payload={"error": str(exc)},
            )

    def _submit_short_entry(self, symbol: str, bucket: str, strategy_name: str, parameter_set_id: str) -> None:
        settings = get_settings()
        order_key = f"{symbol}::{parameter_set_id}"
        if self._last_ordered_bucket.get(order_key) == bucket:
            return
        broker = InternalPaperBroker()
        if broker.has_exposure(symbol, parameter_set_id=parameter_set_id):
            return
        try:
            snapshot = execution_market_snapshot(symbol, side="sell")
        except ExecutionPricingError as exc:
            record_event(
                level="WARNING", event_type="short.order_blocked", severity=StatusLevel.BLOCKED, symbol=symbol,
                message="숏 진입 호가 조회 실패로 주문을 차단했습니다.", payload={"error": str(exc)},
            )
            return
        bid = _f(snapshot.get("bid")) or _f(snapshot.get("last"))
        if not bid or bid <= 0:
            return
        quantity = int(settings.strategy_short_max_notional_usd / bid)
        if quantity < 1:
            return
        exit_plan = {
            "stop_loss_price": round(bid * (1 + FINAL_STOP_PCT), 6),   # stop ABOVE entry
            "take_profit_price": round(bid * (1 - 0.03), 6),           # target BELOW entry
        }
        market_snapshot = {
            **snapshot,
            "parameter_set_id": parameter_set_id,
            "strategy_name": strategy_name,
            "exit_plan": exit_plan,
            "entry_snapshot": {
                "parameter_set_id": parameter_set_id,
                "strategy_name": strategy_name,
                "entry_mode": "short",
            },
        }
        broker.submit_order(
            OrderRequest(
                symbol=symbol, side="sell", position_side="short",
                quantity=quantity, mode="internal_paper", strategy_signal_id=parameter_set_id,
            ),
            market_snapshot=market_snapshot,
        )
        self._last_ordered_bucket[order_key] = bucket
        record_event(
            level="INFO", event_type="short.entry", severity=StatusLevel.NORMAL, symbol=symbol,
            message=f"숏 진입 시뮬레이션 주문 생성: {strategy_name}",
            payload={"strategy_name": strategy_name, "parameter_set_id": parameter_set_id, "quantity": quantity, "bucket": bucket},
        )

    def monitor_short_exits(self) -> dict:
        settings = get_settings()
        if not settings.strategy_short_track_enabled or settings.trading_mode != "internal_paper":
            return {"checked": 0, "skipped": "disabled"}
        broker = InternalPaperBroker()
        shorts = [
            row for row in broker.state().get("positions", [])
            if (row.get("direction") == "short") and (row.get("quantity") or 0) > 0
        ]
        covered = 0
        for row in shorts:
            try:
                covered += 1 if self._maybe_cover(broker, row) else 0
            except Exception as exc:
                record_event(
                    level="WARNING", event_type="short.error", severity=StatusLevel.WARNING,
                    symbol=row.get("symbol"), message="Short-track exit monitoring failed.", payload={"error": str(exc)},
                )
        return {"checked": len(shorts), "covered": covered}

    def _maybe_cover(self, broker: InternalPaperBroker, row: dict) -> bool:
        symbol = str(row.get("symbol"))
        parameter_set_id = row.get("parameter_set_id")
        entry = _f(row.get("average_price"))
        stop = _f(row.get("stop_loss_price"))
        price = _f(candle_builder.latest_price(symbol))
        if entry is None or entry <= 0 or price is None:
            return False
        low_watermark = min(_f(row.get("low_watermark")) or entry, price)
        profit_pct = (entry - price) / entry
        reason = None
        if stop is not None and price >= stop:
            reason = "hard_stop_loss"
        else:
            trailing_stop = low_watermark * (1 + TRAILING_WIDTH_PCT) if profit_pct >= TRAILING_ACTIVATE_PCT else None
            if trailing_stop is not None and price >= trailing_stop:
                reason = "trailing_stop"
            # persist the ratcheting low watermark / trailing level
            position = broker.position(symbol, parameter_set_id=parameter_set_id)
            if position is not None:
                position.low_watermark = low_watermark
                if trailing_stop is not None:
                    position.trailing_stop_price = trailing_stop
                position.last_exit_check_at = datetime.now(timezone.utc)
                broker.update_position(position)
        if reason is None:
            return False
        try:
            snapshot = execution_market_snapshot(symbol, side="buy")
        except ExecutionPricingError:
            return False
        market_snapshot = {**snapshot, "parameter_set_id": parameter_set_id, "exit_reason": reason}
        broker.submit_order(
            OrderRequest(
                symbol=symbol, side="buy", position_side="short",
                quantity=float(row.get("quantity") or 0), mode="internal_paper", strategy_signal_id=str(parameter_set_id or ""),
            ),
            market_snapshot=market_snapshot,
        )
        record_event(
            level="INFO", event_type="short.exit", severity=StatusLevel.NORMAL, symbol=symbol,
            message=f"숏 청산 시뮬레이션 주문 생성: {reason}",
            payload={"reason": reason, "parameter_set_id": parameter_set_id, "entry_price": entry, "cover_ref_price": price},
        )
        return True


short_track_runtime = ShortTrackRuntime()
