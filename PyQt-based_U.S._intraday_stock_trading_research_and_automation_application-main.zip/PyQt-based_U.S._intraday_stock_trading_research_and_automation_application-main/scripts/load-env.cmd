@echo off
pushd "%~dp0.."

if not exist ".env" (
  if exist ".env.conda.example" copy ".env.conda.example" ".env" > nul
)

if exist ".env" (
  for /f "usebackq eol=# tokens=1,* delims==" %%A in (".env") do call :set_env "%%A" "%%B"
)

popd
exit /b 0

:set_env
set "env_key=%~1"
set "env_value=%~2"
call :trim_var env_key
call :trim_var env_value
if not "%env_key%"=="" set "%env_key%=%env_value%"
exit /b 0

:trim_var
setlocal EnableDelayedExpansion
set "trimmed=!%~1!"
for /f "tokens=* delims= " %%T in ("!trimmed!") do set "trimmed=%%T"
:trim_right
if defined trimmed if "!trimmed:~-1!"==" " (
  set "trimmed=!trimmed:~0,-1!"
  goto trim_right
)
endlocal & set "%~1=%trimmed%"
exit /b 0
