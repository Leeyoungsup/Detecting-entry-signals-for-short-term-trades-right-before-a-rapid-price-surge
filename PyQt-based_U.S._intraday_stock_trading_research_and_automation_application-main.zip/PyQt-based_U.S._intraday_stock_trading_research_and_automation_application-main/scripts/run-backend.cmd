@echo off
setlocal

cd /d "%~dp0.."

set REQUESTED_BACKEND_PROCESS_ROLE=%BACKEND_PROCESS_ROLE%
call scripts\load-env.cmd
if not "%REQUESTED_BACKEND_PROCESS_ROLE%"=="" set BACKEND_PROCESS_ROLE=%REQUESTED_BACKEND_PROCESS_ROLE%
if "%BACKEND_PROCESS_ROLE%"=="" set BACKEND_PROCESS_ROLE=combined
set APP_PROCESS_ROLE=%BACKEND_PROCESS_ROLE%

set CONDA_ENV_DIR=%USERPROFILE%\.conda\envs\kis-trading-research
if not exist "%CONDA_ENV_DIR%\python.exe" set CONDA_ENV_DIR=C:\ProgramData\anaconda3\envs\kis-trading-research
set PATH=%CONDA_ENV_DIR%;%CONDA_ENV_DIR%\Library\bin;%CONDA_ENV_DIR%\Scripts;%PATH%

if not exist ".env" (
  copy ".env.conda.example" ".env" > nul
)

if "%API_PORT%"=="" (
  if not "%NEXT_PUBLIC_API_BASE_URL%"=="" (
    for /f "tokens=3 delims=:" %%A in ("%NEXT_PUBLIC_API_BASE_URL%") do (
      for /f "tokens=1 delims=/" %%B in ("%%A") do set API_PORT=%%B
    )
  )
)
if "%API_PORT%"=="" set API_PORT=18001
netstat -ano | findstr /R /C:":%API_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%API_PORT%"=="18001" set API_PORT=18002
)

if not exist ".runtime" mkdir ".runtime"
echo %API_PORT%> ".runtime\api-port.txt"

if "%DATABASE_URL%"=="" set DATABASE_URL=postgresql+psycopg://kis_app:change_me@127.0.0.1:5432/kis_trading_research
if "%REDIS_URL%"=="" set REDIS_URL=redis://127.0.0.1:6379/0
if /I "%REDIS_URL%"=="redis://redis:6379/0" set REDIS_URL=redis://127.0.0.1:6379/0
set NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:%API_PORT%
set NEXT_PUBLIC_REALTIME_URL=ws://127.0.0.1:%API_PORT%/api/realtime/ws

echo Starting FastAPI backend on http://127.0.0.1:%API_PORT%
echo Process role: %APP_PROCESS_ROLE%
echo API docs: http://127.0.0.1:%API_PORT%/docs
cd services\backend
if "%BACKEND_RELOAD%"=="true" (
  uvicorn app.main:app --reload --host 127.0.0.1 --port %API_PORT%
) else (
  uvicorn app.main:app --host 127.0.0.1 --port %API_PORT%
)
