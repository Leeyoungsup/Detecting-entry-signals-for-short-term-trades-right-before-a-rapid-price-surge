@echo off
setlocal
cd /d "%~dp0"
call scripts\migrate-db.cmd
if errorlevel 1 (
  echo.
  echo Database migration failed.
  pause
  exit /b %errorlevel%
)
echo.
echo Database migration complete.
pause
