from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from app.services import shared_state

DESIRED_SUBSCRIPTIONS_KEY = "trading_lab:realtime:desired_subscriptions"
REALTIME_STATUS_KEY = "trading_lab:realtime:status"
REALTIME_ORDER_FLOW_KEY = "trading_lab:realtime:order_flow"
REALTIME_PRICES_KEY = "trading_lab:realtime:prices"
LEGACY_REALTIME_STATUS_KEY = "kis:realtime:status"
LEGACY_REALTIME_ORDER_FLOW_KEY = "kis:realtime:order_flow"

DESIRED_SUBSCRIPTIONS_TTL_SEC = 180
REALTIME_STATE_TTL_SEC = 30


def publish_desired_subscriptions(
    symbols: list[str],
    *,
    exchange: str,
    key_mode: str,
    reason: str,
) -> dict:
    payload = {
        "symbols": _normalize_symbols(symbols),
        "exchange": exchange,
        "key_mode": key_mode,
        "reason": reason,
        "updated_at": _now_iso(),
    }
    shared_state.set_json(DESIRED_SUBSCRIPTIONS_KEY, payload, ex=DESIRED_SUBSCRIPTIONS_TTL_SEC)
    return payload


def desired_subscriptions() -> dict:
    payload = shared_state.get_json(DESIRED_SUBSCRIPTIONS_KEY)
    if not isinstance(payload, dict):
        return {"symbols": [], "exchange": "NAS", "key_mode": "regular", "updated_at": None}
    payload["symbols"] = _normalize_symbols(payload.get("symbols") or [])
    payload["exchange"] = str(payload.get("exchange") or "NAS")
    payload["key_mode"] = str(payload.get("key_mode") or "regular")
    return payload


def publish_realtime_runtime(
    status: dict,
    order_flow: dict[str, dict],
    prices: dict[str, dict] | None = None,
) -> dict:
    payload = {
        **status,
        "source": "realtime_worker",
        "updated_at": _now_iso(),
    }
    shared_state.set_json(REALTIME_STATUS_KEY, payload, ex=REALTIME_STATE_TTL_SEC)
    shared_state.set_json(REALTIME_ORDER_FLOW_KEY, order_flow, ex=REALTIME_STATE_TTL_SEC)
    if prices is not None:
        shared_state.set_json(REALTIME_PRICES_KEY, prices, ex=REALTIME_STATE_TTL_SEC)
    return payload


def realtime_status() -> dict | None:
    payload = shared_state.get_json_any(REALTIME_STATUS_KEY, LEGACY_REALTIME_STATUS_KEY)
    return payload if isinstance(payload, dict) else None


def realtime_order_flow() -> dict[str, dict]:
    payload = shared_state.get_json_any(REALTIME_ORDER_FLOW_KEY, LEGACY_REALTIME_ORDER_FLOW_KEY)
    return payload if isinstance(payload, dict) else {}


def realtime_prices() -> dict[str, dict]:
    payload = shared_state.get_json(REALTIME_PRICES_KEY)
    return payload if isinstance(payload, dict) else {}


def subscribed_symbols(status: dict | None = None) -> set[str]:
    payload = status or realtime_status() or {}
    age_by_symbol = payload.get("subscription_age_sec") if isinstance(payload, dict) else None
    if isinstance(age_by_symbol, dict):
        return {str(symbol).upper() for symbol in age_by_symbol}
    return set()


def waiting_status(*, local_status: dict | None = None) -> dict:
    base: dict[str, Any] = dict(local_status or {})
    base.update(
        {
            "status": "waiting_for_realtime_worker",
            "source": "shared_realtime_pending",
            "subscription_count": len(subscribed_symbols(base)),
            "updated_at": _now_iso(),
        }
    )
    return base


def _normalize_symbols(symbols: object) -> list[str]:
    if not isinstance(symbols, list):
        return []
    normalized = []
    for symbol in symbols:
        value = str(symbol or "").upper().strip()
        if value and value not in normalized:
            normalized.append(value)
    return normalized


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
