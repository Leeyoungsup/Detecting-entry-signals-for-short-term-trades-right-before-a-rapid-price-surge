from app.api.routes.strategies import _active_strategies_payload
from app.core.config import get_settings


def test_active_strategies_payload_includes_liquidity_pullback_reclaim(monkeypatch) -> None:
    settings = get_settings()
    monkeypatch.setattr(settings, "strategy_liquidity_pullback_reclaim_enabled", True)

    rows = _active_strategies_payload(settings)
    by_name = {row["strategy_name"]: row for row in rows}

    assert by_name["Liquidity Pullback Reclaim"] == {
        "strategy_name": "Liquidity Pullback Reclaim",
        "parameter_set_id": "liquidity_pullback_reclaim",
        "role": "Takes high-liquidity momentum pullbacks after support reclaim with cost and overheat filters.",
        "enabled": True,
    }
