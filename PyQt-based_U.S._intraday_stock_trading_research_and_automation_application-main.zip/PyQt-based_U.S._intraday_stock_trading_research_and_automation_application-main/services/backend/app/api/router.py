from fastapi import APIRouter

from app.api.routes import (
    alerts,
    backtests,
    command_center,
    health,
    kis,
    logs,
    orders,
    paper,
    realtime,
    scanner,
    settings,
    strategies,
    symbols,
)

api_router = APIRouter()
api_router.include_router(health.router, tags=["health"])
api_router.include_router(kis.router, prefix="/kis", tags=["legacy-kis"], deprecated=True)
api_router.include_router(command_center.router, prefix="/command-center", tags=["command-center"])
api_router.include_router(scanner.router, prefix="/scanner", tags=["scanner"])
api_router.include_router(settings.router, prefix="/settings", tags=["settings"])
api_router.include_router(symbols.router, prefix="/symbols", tags=["symbols"])
api_router.include_router(strategies.router, prefix="/strategies", tags=["strategies"])
api_router.include_router(backtests.router, prefix="/backtests", tags=["backtests"])
api_router.include_router(paper.router, prefix="/paper", tags=["paper"])
api_router.include_router(orders.router, prefix="/orders", tags=["orders"])
api_router.include_router(logs.router, prefix="/logs", tags=["logs"])
api_router.include_router(alerts.router, prefix="/alerts", tags=["alerts"])
api_router.include_router(realtime.router, prefix="/realtime", tags=["realtime"])
