# AGENTS.md

## 0. Purpose

This file defines how Codex should work in this repository.

This project is a private, single-user web platform for researching and validating U.S. intraday stock trading strategies. The old PyQt desktop direction is abandoned. The current direction is:

```text
1. Browser-based private dashboard
2. FastAPI backend + Next.js frontend
3. Toss Invest OpenAPI as the primary market-data, quote, account-preview, and future execution gateway
4. Alpaca is not the primary market-data source; keep any Alpaca adapter optional and inactive unless explicitly requested
5. Internal paper trading first
6. Live trading disabled until explicitly implemented and verified
7. Strategy research focused on 1-minute U.S. intraday momentum, pullback, order flow, and liquidity behavior
8. Detailed logs, replay artifacts, and visual explanation screens
```

The platform is not a profit-guaranteeing bot. Treat every result as research until costs, spread, slippage, stale data, partial fills, missed fills, and false signals have been tested.

The old broker-specific direction is no longer part of the product. Do not design new work around removed broker integrations. Any remaining legacy broker code is deletion-candidate code unless the user explicitly asks to inspect or remove it.

---

## 1. Codex Role

In this repository, Codex acts as:

> A backend/frontend engineer, trading-research platform designer, strategy reviewer, and observability builder for a private U.S. intraday trading lab.

Priority order:

```text
1. Prevent accidental live orders
2. Keep internal paper trading and live execution clearly separated
3. Keep order/fill/position state understandable
4. Make strategy decisions visible on screen
5. Preserve replayability and logs
6. Model spread, slippage, fees, and conservative fills
7. Keep the app easy to run locally
8. Improve strategy quality through backtests, paper trading, and replay comparison
9. Maintain clean code and focused tests
10. Optimize returns only after the above are working
```

Do not weaken order safety, logging, or replayability to chase a better-looking strategy result.

---

## 2. Product Definition

### 2.1 Product Shape

The product is a private personal SaaS-style web app, usually run locally or on a locked-down private machine.

```text
Frontend:
- Next.js dashboard
- Command Center
- Scanner
- Symbol Detail
- Strategy Monitor
- Orders and Positions
- Backtests and Replay
- Logs
- Alerts
- Settings

Backend:
- FastAPI API
- Runtime supervisor / worker
- Market data service
- Scanner service
- Candle builder
- Strategy runtime
- Risk manager
- Internal paper broker
- Execution/account preview gateway
- Realtime WebSocket event gateway
```

This is a single-user private tool. Do not add authentication, multi-user account management, JWT/session flows, 2FA, CSRF systems, or admin-user scaffolding unless the user explicitly asks for it.

Even though app-level auth is not required, secrets must still stay server-side and out of the browser bundle.

### 2.2 Runtime Modes

Supported modes:

```yaml
trading_mode: "internal_paper"   # research, backtest, internal_paper, toss_mock, live
live_enabled: false
strategy_validated: false
require_validation_for_live: true
validation_gate_enabled: true
```

Mode meaning:

```text
research:
  Develop screens, data structures, and strategy logic without live market/order dependencies.

backtest:
  Run historical strategy checks. Use conservative fill assumptions.

internal_paper:
  Receive realtime or replay data, then simulate orders/fills internally.
  This is the default mode.

toss_mock:
  Reserved for future Toss mock/sandbox workflows if the official API supports them.

live:
  Real-money trading. Not implemented by default.
  Any live implementation must be explicit, narrow, logged, and separately reviewed.
```

The default app behavior must be `internal_paper`.

---

## 3. Current Stack

### 3.1 Frontend

```text
- Next.js
- React
- TypeScript
- Tailwind CSS
- lucide-react icons
- Realtime updates through backend WebSocket plus fallback polling
```

Frontend rules:

```text
- The browser never calls Toss or any external market-data/broker API directly.
- The browser never receives app secrets, access tokens, account ids, or broker credentials.
- Strategy calculation, risk calculation, order state, and fill simulation belong in the backend.
- Screens should show why a symbol passed or failed, not only the final result.
```

### 3.2 Backend

```text
- Python 3.11+
- FastAPI
- Pydantic
- SQLAlchemy / Alembic
- PostgreSQL
- Redis for shared runtime state and realtime event fanout where available
- In-memory fallback where useful for local development
```

Backend structure should prefer existing project boundaries:

```text
services/backend/app/adapters/market_data/
services/backend/app/adapters/toss/
services/backend/app/api/routes/
services/backend/app/core/
services/backend/app/domain/
services/backend/app/services/
services/backend/app/db/
```

Do not introduce a new framework or major architectural direction without a clear reason.

---

## 4. External Integrations

### 4.1 Toss Market Data

Toss OpenAPI is the primary market-data source for this project.

Use cases:

```text
- Real-time trades
- Real-time quotes
- 1-minute bars
- Recent and current-session candles
- Current orderbook quotes for paper fill realism
- Scanner candidate ranking where implemented
```

Required behavior:

```text
- Use server-side credentials only.
- Clearly surface stale, delayed, unauthorized, or degraded market data.
- Do not treat snapshot/daily ranking data as equivalent to realtime trade ticks.
- Prefer realtime tick aggregation for active symbols.
- Use REST candles for initial loading, recovery, and replay where Toss supports the requested window.
- If Toss historical depth is insufficient for a replay, mark the data gap explicitly instead of silently switching providers.
```

Config names:

```text
MARKET_DATA_PROVIDER=toss
TOSS_APP_KEY
TOSS_APP_SECRET
TOSS_BASE_URL
TOSS_TOKEN_URL
```

### 4.2 Toss Execution And Account Gateway

Toss is also the execution/account-preview gateway.

Current intended use:

```text
- Account/buying-power preview
- Orderbook quote lookup
- Position quote monitoring
- Future execution gateway after official endpoint and field verification
```

Real Toss order submission is blocked unless the user explicitly asks to implement it and the implementation includes clear safety gates.

Required behavior:

```text
- Never hardcode Toss credentials.
- Never expose Toss credentials to the frontend.
- Treat order endpoint/field uncertainty as TODO_TOSS_VERIFY.
- Paper trading may use Toss quote/account-preview data for more realistic internal fills.
- Actual live order endpoints must remain disabled by default.
```

Config names:

```text
EXECUTION_PROVIDER=toss
TOSS_ENVIRONMENT=mock|live
TOSS_APP_KEY
TOSS_APP_SECRET
TOSS_ACCOUNT_ID
TOSS_BASE_URL
TOSS_TOKEN_URL
```

---

## 5. Secrets And Local Privacy

This is a private single-user tool, so app login is not required by default.

Still required:

```text
- Do not commit real .env files.
- Do not hardcode Toss or other external API keys.
- Do not log full tokens, app secrets, account ids, or authorization headers.
- Keep secrets server-side.
- Use .env or local secret files ignored by git.
```

Allowed:

```text
- Local unauthenticated dashboard
- Local runtime settings screen
- Local dev-only paper order buttons
```

Recommended but not mandatory:

```text
- Bind backend to 127.0.0.1 for local-only use
- Use a firewall/VPN if deployed away from the local machine
- Avoid exposing the dashboard to the public internet
```

---

## 6. Strategy Direction

The current strategy lab is not only a lower-band mean-reversion bot. It is a multi-strategy intraday research platform for high-liquidity, high-momentum U.S. names.

Active strategy family:

```text
- Surge Pullback Reclaim
- Order Flow Imbalance Proxy
- Liquidity Absorption Breakout
- Runner Continuation / EMA9 Ride
```

Archived or secondary strategy family:

```text
- Pullback Reclaim
- Lower Band Snapback
- VWAP Reclaim
- Liquidity Imbalance Proxy
- Opening Liquidity Imbalance
```

Strategy principles:

```text
- Do not buy merely because price touched a Bollinger band.
- Do not buy upper-band breakouts blindly.
- Prefer liquidity, order flow, spread quality, and actual trade activity before chart-only signals.
- A strategy must explain why it entered, rejected, or exited.
- Shadow replay may let multiple strategies hold independent simulated positions in the same symbol.
- Shadow portfolios are for comparison, not a recommendation to multiply live exposure.
```

---

## 7. Scanner Design

The scanner should prioritize symbols where money and real activity are present.

Priority order:

```text
1. Recent notional turnover
2. Realtime trade activity
3. Trade strength / aggressive buy-sell proxy
4. Sell pressure behavior
5. Spread
6. Bid/ask imbalance
7. Volatility suitability
8. Chart structure
9. Market context
```

Core metrics:

```python
notional_1m = close * volume_1m
notional_5m = sum(close_i * volume_i for i in last_5_bars)
notional_velocity_10s = notional_last_10s / max(notional_prev_10s, epsilon)
spread_pct = (ask - bid) / max((ask + bid) / 2, epsilon)
bid_ask_imbalance = bid_depth / max(bid_depth + ask_depth, epsilon)
trade_strength = aggressive_buy_volume / max(total_trade_volume, epsilon)
sell_pressure = aggressive_sell_volume / max(total_trade_volume, epsilon)
```

Trade direction estimation:

```text
- If trade price is near ask, treat it as aggressive buy.
- If trade price is near bid, treat it as aggressive sell.
- If quote data is unavailable, use tick-rule fallback.
- Unknown direction should stay unknown or receive low weight.
```

Scanner funnel:

```text
Universe
  -> coarse candidate ranking
  -> websocket subscription target
  -> order-flow candidate
  -> strategy candidate
  -> risk-approved paper order candidate
```

The UI should show counts, rejects, top reject reasons, data freshness, and whether data is realtime, delayed, or fallback.

---

## 8. Paper Broker And Execution Model

Internal paper broker is the default execution model.

Paper broker requirements:

```text
- No real order API call
- Marketable-limit style simulation by default
- Quote/spread-aware fill assumptions
- Slippage and fee model applied
- Partial fills allowed when spread/liquidity conditions are poor
- Position state tied to strategy_name and parameter_set_id where useful
- Closed trades retain entry/exit snapshots
```

Order states:

```text
CREATED
RISK_CHECKED
SUBMITTED
ACKNOWLEDGED
PARTIALLY_FILLED
FILLED
CANCEL_REQUESTED
CANCELLED
REPLACE_REQUESTED
REPLACED
REJECTED
EXPIRED
ERROR
UNKNOWN_RECONCILE_REQUIRED
```

Live order submission is out of scope unless the user explicitly asks for it.

---

## 9. Risk Management

Default research capital:

```yaml
account:
  base_currency: "USD"
  initial_equity_usd: 2000.00
  paper_initial_equity_usd: 2000.00
  backtest_initial_equity_usd: 2000.00
```

Sizing model:

```python
risk_amount_usd = account_equity_usd * risk_per_trade_pct
position_notional_usd = risk_amount_usd / max(stop_loss_pct, epsilon)
position_notional_usd = min(position_notional_usd, max_notional_per_trade_usd)
```

Initial risk defaults:

```yaml
risk:
  risk_per_trade_pct: 0.002
  max_risk_per_trade_pct: 0.0025
  max_notional_per_trade_pct: 0.15
  max_total_exposure_pct: 0.30
  max_open_positions: 2
```

All paper and replay results should show gross and net PnL. Net PnL must include configured spread/slippage/fee assumptions.

---

## 10. Replay And Backtesting

Backtests and replays must be conservative.

For OHLCV-only backtests:

```text
If the same candle touches take-profit and stop-loss, assume stop-loss first.
```

For enriched replay:

```text
- Entry after signal candle should use next bar first_ask where available.
- Exit after exit signal should use next bar first_bid where available.
- Stop-loss touch should use conservative bid/min-bid assumptions.
- Spread, slippage, SEC fee, TAF, and commissions must be configurable.
```

Replay outputs should be treated as research artifacts, not validation proof, especially when the sample is one symbol or one session.

---

## 11. Observability And Screens

Visibility is a core product feature. The user should be able to see:

```text
- What the system is watching
- Why a symbol is a candidate
- Why a signal passed or failed
- Why a paper order was or was not created
- What fill model was used
- What exit plan exists
- What happened in closed trades
```

Required screens:

```text
/
/scanner
/symbols
/symbols/[symbol]
/strategies
/backtests
/orders
/logs
/alerts
/settings
```

Command Center should show:

```text
- Current mode
- Live enabled flag
- Market data provider and status
- Execution provider and status
- Data freshness
- Active session
- Equity and PnL
- Exposure
- Open positions
- Open orders
- Recent warnings
- Runtime supervisor status
```

Scanner should show:

```text
- Funnel stages
- Candidate table
- Ranking score
- Notional and volume metrics
- Order flow metrics
- Spread
- Reject reason
- Data age
```

Symbol detail should show:

```text
- 1-minute chart
- VWAP/EMA/Bollinger context where available
- Tick/order-flow panel
- Quote/spread panel
- Strategy explanation
- Risk preview
- Position and exit plan if held
```

Orders screen should show the state machine and timeline, not only final fills.

---

## 12. Logging And Storage

Structured logs are required.

Important log types:

```text
platform.boot
market_data.status
scanner.snapshot
strategy.signal_evaluation
risk.decision
paper.order_event
paper.fill
paper.reset
strategy.settings_updated
settings.runtime_updated
runtime.supervisor_started
runtime.supervisor_tick_failed
alert.created
```

Do not log raw secrets.

PostgreSQL schemas may exist ahead of full persistence. When adding persistence, prefer repository/service boundaries and avoid scattering SQL in route handlers.

Redis may be used for:

```text
- Runtime shared state
- Realtime event history
- Structured log history
- Paper state sharing between API and worker
```

---

## 13. Development And Scripts

Prefer the existing Windows/cmd workflow:

```cmd
setup.bat
start-all.bat
stop-dev.bat
stop-all-dev.bat
check.bat
logs.bat
follow-logs.bat
```

Internal scripts:

```cmd
scripts\setup-conda.cmd
scripts\start-postgres.cmd
scripts\migrate-db.cmd
scripts\run-backend.cmd
scripts\run-worker.cmd
scripts\run-web.cmd
scripts\start-dev-vscode.cmd
scripts\stop-dev.cmd
scripts\stop-all-dev.cmd
```

When changing scripts, preserve local Windows usability. Prefer cmd-compatible changes for project scripts unless the user asks otherwise.

---

## 14. Testing Expectations

Important tests to add or maintain:

```text
- Risk sizing
- Paper broker order states
- Paper fill model
- Fee/slippage model
- Conservative same-bar backtest exit
- Candle builder aggregation
- Strategy signal explanation
- Scanner reject reasons
- Realtime event serialization
- Settings mutation bounds
- Secret redaction
```

Before finalizing backend changes, run what is reasonable:

```cmd
scripts\check-conda.cmd
cd services\backend
python -m pytest
python -m ruff check app
```

Before finalizing frontend changes, run:

```cmd
npm --workspace apps/web run build
```

If a command cannot run in the current shell, say exactly what was blocked and what was verified instead.

---

## 15. Strategy Update Rules

When changing strategy logic:

```text
1. Keep the change scoped.
2. Keep old and new parameter meanings clear.
3. Log why signals pass or fail.
4. Keep replay results separated by strategy_name and parameter_set_id.
5. Do not judge a strategy from one symbol/session.
6. Record gross and net performance.
7. Include costs before treating results as useful.
8. Prefer comparison across multiple hot-name sessions.
```

Strategy changes should improve observability, not just the final score.

---

## 16. Forbidden Defaults

Codex must not:

```text
- Reintroduce PyQt as the main app direction
- Reintroduce removed broker integrations as required product dependencies
- Put broker/market-data secrets in frontend code
- Hardcode real API keys, app secrets, tokens, or account ids
- Enable live trading by default
- Add real Toss order submission casually
- Hide live-order behavior behind a paper endpoint
- Treat a single replay result as validation
- Remove logs or explanations to make code shorter
- Implement chart-only entries without liquidity/order-flow checks
- Ignore spread/slippage/fees in replay or paper results
- Add multi-user/auth complexity unless the user asks for it
```

---

## 17. Current Product Summary

The current product is:

```text
Private local web dashboard
FastAPI + Next.js
Toss market data
Toss execution/account preview gateway
Internal paper trading first
Shadow replay for strategy comparison
Live order submission disabled
No app auth required by default
Detailed logs and visual strategy explanation required
```

Keep the repository aligned with this direction.
