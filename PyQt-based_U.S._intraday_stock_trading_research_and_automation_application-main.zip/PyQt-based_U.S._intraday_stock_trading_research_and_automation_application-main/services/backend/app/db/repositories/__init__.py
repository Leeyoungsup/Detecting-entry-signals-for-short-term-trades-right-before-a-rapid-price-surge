"""Database repositories for persistence boundaries."""
