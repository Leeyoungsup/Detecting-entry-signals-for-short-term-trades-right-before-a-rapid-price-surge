from app.adapters.market_data import toss as toss_module
from app.adapters.market_data.toss import TossMarketDataProvider
from app.adapters.toss.client import TossApiError
from app.core.config import Settings


class _FakeTossClient:
    def stocks(self, *, symbols: list[str]) -> list[dict]:
        rows = []
        for symbol in symbols:
            if symbol == "SOXL":
                rows.append(
                    {
                        "symbol": symbol,
                        "name": "디렉시온 세미컨덕터 3X 롱",
                        "securityType": "ETF",
                        "isCommonShare": True,
                        "status": "ACTIVE",
                        "currency": "USD",
                        "leverageFactor": "3",
                    }
                )
                continue
            rows.append(
                {
                    "symbol": symbol,
                    "name": f"{symbol} 코리아명",
                    "englishName": f"{symbol} Inc.",
                    "securityType": "STOCK",
                    "isCommonShare": True,
                    "status": "ACTIVE",
                    "currency": "USD",
                    "leverageFactor": None,
                }
            )
        return rows

    def rankings(self, *, ranking_type: str, market_country: str = "US", duration: str = "realtime", exclude_investment_caution: bool = False, count: int = 100) -> dict:
        del ranking_type, market_country, exclude_investment_caution, count
        if duration != "realtime":
            return {"rankedAt": "2026-07-07T20:38:00.000+09:00", "rankings": []}
        return {
            "rankedAt": "2026-07-07T20:38:00.000+09:00",
            "rankings": [
                {
                    "rank": 1,
                    "symbol": "SOXL",
                    "currency": "USD",
                    "price": {"lastPrice": "152.37", "basePrice": "150.0", "changeRate": "0.0158"},
                    "tradingVolume": "500000",
                    "tradingAmount": "76185000",
                },
                {
                    "rank": 2,
                    "symbol": "NVDA",
                    "currency": "USD",
                    "price": {"lastPrice": "190.74", "basePrice": "188.0", "changeRate": "0.0146"},
                    "tradingVolume": "342100",
                    "tradingAmount": "65280234",
                },
                {
                    "rank": 3,
                    "symbol": "SUGP",
                    "currency": "USD",
                    "price": {"lastPrice": "10.0", "basePrice": "9.8", "changeRate": "0.0204"},
                    "tradingVolume": "12000",
                    "tradingAmount": "120000",
                },
            ],
        }

    def exchange_rate(self, *, base_currency: str = "USD", quote_currency: str = "KRW") -> float | None:
        del base_currency, quote_currency
        return 1380.0

    def candles(self, *, symbol: str, interval: str = "1m", count: int = 120, before=None, adjusted: bool = True) -> list[dict]:
        del before, adjusted
        assert interval == "1m"
        return [
            {
                "timestamp": "2026-07-07T20:38:00.000+09:00",
                "openPrice": "190.75",
                "highPrice": "190.80",
                "lowPrice": "190.70",
                "closePrice": "190.73",
                "volume": "929",
                "currency": "USD",
            }
        ][:count]

    def orderbook_quote(self, *, symbol: str, max_cache_age_sec: float = 0.0) -> dict:
        return {
            "symbol": symbol,
            "bid": 190.78,
            "ask": 190.84,
            "bid_depth": 44,
            "ask_depth": 266,
            "received_at": "2026-07-07T20:38:48.000+09:00",
        }

    def prices(self, *, symbols: list[str]) -> list[dict]:
        return [
            {
                "symbol": symbol,
                "timestamp": "2026-07-07T20:38:48.000+09:00",
                "lastPrice": "190.74",
                "currency": "USD",
            }
            for symbol in symbols
        ]

    def trades(self, *, symbol: str, count: int = 5) -> list[dict]:
        return [
            {
                "price": "190.8395",
                "volume": "8",
                "timestamp": "2026-07-07T20:38:48.000+09:00",
                "currency": "USD",
            }
        ][:count]


class _StockNotFoundTossClient(_FakeTossClient):
    def prices(self, *, symbols: list[str]) -> list[dict]:
        if "BAD" in symbols:
            raise TossApiError(
                'Toss API error 404: {"error":{"code":"stock-not-found","message":"종목을 찾을 수 없습니다."}}',
                status_code=404,
                payload={"error": {"code": "stock-not-found", "message": "종목을 찾을 수 없습니다."}},
            )
        return super().prices(symbols=symbols)


def test_toss_market_data_provider_uses_rankings_api_and_excludes_leveraged_etf() -> None:
    provider = TossMarketDataProvider(
        Settings(toss_app_key="key", toss_app_secret="secret", scanner_max_websocket_symbols=2)
    )
    provider.client = _FakeTossClient()  # type: ignore[assignment]

    rows = provider.scanner_rankings()["trade_volume"]["output2"]

    # SOXL ranks #1 in the fake rankings payload but is a 3x-leveraged ETF and must be
    # dropped; NVDA/SUGP (plain STOCK, isCommonShare) fill the limit=2 slots instead.
    assert [row["symb"] for row in rows] == ["NVDA", "SUGP"]
    assert rows[0]["volume_source"] == "toss_rankings_api"
    assert rows[0]["screener_source"] == "toss_rankings_api"
    assert rows[0]["latest_bar_at"] is None
    assert rows[0]["notional_1m"] is None
    # company_name/asset_name prefer the official Korean `name` from /api/v1/stocks.
    assert rows[0]["company_name"] == "NVDA 코리아명"
    assert rows[0]["asset_name"] == "NVDA 코리아명"
    assert rows[0]["is_common_stock"] is True
    assert rows[0]["toss_wts_notional"] == 65280234.0
    assert rows[0]["toss_trade_amount_krw"] == 65280234.0 * 1380.0


def test_toss_market_data_provider_poll_symbol_updates_quote_and_trade(monkeypatch) -> None:
    provider = TossMarketDataProvider(Settings(toss_app_key="key", toss_app_secret="secret"))
    provider.client = _FakeTossClient()  # type: ignore[assignment]
    provider._subscriptions = {"NVDA"}
    monkeypatch.setattr(toss_module, "_has_active_paper_position", lambda symbol: True)

    provider._poll_symbol("NVDA")
    provider._poll_symbol("NVDA")

    snapshot = provider.realtime_snapshot()
    assert snapshot["quotes"]["NVDA"]["bid"] == 190.78
    assert snapshot["trades"]["NVDA"]["last"] == 190.8395
    assert len([event for event in provider.recent_events(20) if event["event_type"] == "trade"]) == 1


def test_toss_trade_event_separates_receive_time_from_provider_trade_time(monkeypatch) -> None:
    monkeypatch.setattr(toss_module, "_now_iso", lambda: "2026-07-07T11:38:49+00:00")

    event = toss_module._trade_event(
        "NVDA",
        {
            "price": "190.8395",
            "volume": "8",
            "timestamp": "2026-07-07T20:38:48.000+09:00",
        },
    )

    assert event is not None
    assert event["received_at"] == "2026-07-07T11:38:49+00:00"
    assert event["event_at"] == "2026-07-07T11:38:48+00:00"
    assert event["raw"]["event_at"] == "2026-07-07T11:38:48+00:00"


def test_toss_1m_candle_timestamp_keeps_provider_bar_time() -> None:
    row = {
        "timestamp": "2026-07-07T20:38:00.000+09:00",
        "openPrice": "190.75",
        "highPrice": "190.80",
        "lowPrice": "190.70",
        "closePrice": "190.73",
        "volume": "929",
    }

    candle = toss_module._toss_candle_to_provider_bar("NVDA", row, interval="1m")

    assert candle["xhms"] == "113800"
    assert candle["khms"] == "203800"
    assert candle["provider_timestamp"] == "2026-07-07T20:38:00.000+09:00"
    assert candle["timestamp_role"] == "bar_time"


def test_toss_daily_candle_timestamp_is_not_shifted() -> None:
    row = {
        "timestamp": "2026-07-07T00:00:00.000+09:00",
        "openPrice": "190.75",
        "highPrice": "190.80",
        "lowPrice": "190.70",
        "closePrice": "190.73",
        "volume": "929",
    }

    candle = toss_module._toss_candle_to_provider_bar("NVDA", row, interval="1d")

    assert candle["xhms"] == "150000"
    assert candle["khms"] == "000000"
    assert candle["timestamp_role"] == "bar_time"


def test_priority_symbols_restricts_microstructure_polling_to_top_n_and_open_positions(monkeypatch) -> None:
    provider = TossMarketDataProvider(
        Settings(toss_app_key="key", toss_app_secret="secret", toss_realtime_microstructure_top_n=2)
    )
    provider._subscriptions = {"AAA", "BBB", "CCC", "DDD"}
    provider._subscription_rank = {"AAA": 0, "BBB": 1, "CCC": 2, "DDD": 3}
    monkeypatch.setattr(toss_module, "_has_active_paper_position", lambda symbol: symbol == "DDD")

    priority = provider._priority_symbols(sorted(provider._subscriptions))

    # Top-2 by rank (AAA, BBB) are always included; CCC is rank-3 with no position so it's
    # excluded from orderbook/trade polling; DDD is rank-4 but has an open position so it's
    # pulled in anyway.
    assert priority == ["AAA", "BBB", "DDD"]


def test_poll_prices_batch_fills_latest_prices_for_full_universe() -> None:
    provider = TossMarketDataProvider(Settings(toss_app_key="key", toss_app_secret="secret"))
    provider.client = _FakeTossClient()  # type: ignore[assignment]

    provider._poll_prices_batch(["NVDA", "AAPL"])

    assert provider._latest_prices["NVDA"]["last"] == 190.74
    assert provider._latest_prices["AAPL"]["last"] == 190.74
    assert provider.realtime_snapshot()["prices"]["NVDA"]["source"] == "toss_prices_polling"


def test_poll_prices_batch_drops_stock_not_found_symbol_without_losing_batch() -> None:
    provider = TossMarketDataProvider(Settings(toss_app_key="key", toss_app_secret="secret"))
    provider.client = _StockNotFoundTossClient()  # type: ignore[assignment]
    provider._subscriptions = {"NVDA", "BAD", "AAPL"}

    provider._poll_prices_batch(["NVDA", "BAD", "AAPL"])

    assert provider._latest_prices["NVDA"]["last"] == 190.74
    assert provider._latest_prices["AAPL"]["last"] == 190.74
    assert "BAD" not in provider._subscriptions
    assert "BAD" in provider.realtime_status()["invalid_symbols"]
    assert any(event["event_type"] == "invalid_symbol" and event["symbol"] == "BAD" for event in provider.recent_events(20))
