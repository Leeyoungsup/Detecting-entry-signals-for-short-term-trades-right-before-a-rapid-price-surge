import asyncio
import signal

from app.core.logging import configure_logging
from app.services.runtime_supervisor import runtime_supervisor


async def main() -> None:
    configure_logging()
    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except NotImplementedError:
            pass
    runtime_supervisor.start()
    try:
        await stop_event.wait()
    finally:
        await runtime_supervisor.stop()


if __name__ == "__main__":
    asyncio.run(main())
