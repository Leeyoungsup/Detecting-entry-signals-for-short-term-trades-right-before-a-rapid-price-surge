from typing import Any

from fastapi import APIRouter

from app.core.config import get_settings
from app.services.candle_builder import candle_builder
from app.services.event_log import list_events
from app.services.market_data import get_market_data_service
from app.services.paper_broker import InternalPaperBroker
from app.services.strategy_runtime import strategy_runtime

router = APIRouter()

@router.get("")
def strategies() -> dict:
    settings = get_settings()
    active_strategies = _active_strategies_payload(settings)
    active_strategy_names = {row["strategy_name"] for row in active_strategies}
    signal_events = [
        event for event in list_events(limit=500, event_type="strategy.signal_evaluation")
    ]
    signal_events = [
        event for event in signal_events if _event_strategy_name(event.payload or {}) in active_strategy_names
    ]
    latest = signal_events[-1].payload if signal_events else {}
    lower_band_status = latest.get("lower_band_status") or {
        "lower_band_breached": False,
        "lower_band_reclaimed": False,
        "bars_since_breach": None,
        "reclaim_holding": False,
        "macd_histogram_delta": None,
        "vwap_distance_atr": None,
        "atr_distance": None,
        "order_flow_turning": False,
        "entry_allowed": False,
    }
    paper_state = InternalPaperBroker().state()
    candle_status = candle_builder.status()
    runtime_status = strategy_runtime.status()
    market_data = get_market_data_service().provider
    # The candle cache also holds stale/dev-injected symbols (persisted with a TTL), so
    # the runtime "Candle Window" only shows symbols currently subscribed for watching.
    subscribed_symbols = set(market_data.subscribed_symbols())
    active_candle_counts = {
        symbol: count for symbol, count in candle_status["counts"].items() if symbol in subscribed_symbols
    }
    closed_trades = [
        row for row in paper_state.get("closed_trades", [])
        if _trade_strategy_name(row) in active_strategy_names
    ]
    wins = [row for row in closed_trades if _pnl(row) > 0]
    losses = [row for row in closed_trades if _pnl(row) < 0]
    return {
        "strategies": [
            {
                "strategy_name": "Strategy Router",
                "strategy_version": "1.0.0",
                "parameter_set_id": settings.strategy_primary_name,
                "enabled": any(row["enabled"] for row in active_strategies),
                "watching_symbols": len(subscribed_symbols),
                "ws_candle_symbols": len(active_candle_counts),
                "ws_candle_counts": active_candle_counts,
                "last_runtime_evaluation": runtime_status["last_evaluated_bucket"],
                "signals_today": sum(1 for event in signal_events if (event.payload or {}).get("passed")),
                "rejects_today": sum(1 for event in signal_events if not (event.payload or {}).get("passed")),
                "orders_submitted": len(paper_state["orders"]),
                "fills": len(paper_state["fills"]),
                "win_loss": f"{len(wins)}/{len(losses)}",
                "net_pnl_usd": round(sum(_pnl(row) for row in closed_trades), 2),
                "expectancy": None,
                "latest_symbol": latest.get("symbol"),
                "latest_reject_reason": latest.get("reject_reason"),
                # Runtime enters on a boolean AND of every condition (replay-style), so the
                # weighted score is no longer a gate. Expose the per-condition pass/fail map
                # instead of score components. `strategy_conditions` gives one entry per
                # enabled strategy (data-driven, scales as strategies are added/retired);
                # `latest_conditions` is kept for the header's most-recent summary.
                "latest_conditions": latest.get("gate_status") or {},
                "strategy_conditions": _latest_conditions_by_strategy(signal_events, active_strategies),
                "pattern_status": latest.get("pattern_status") or {},
                "lower_band_status": lower_band_status,
                "strategy_breakdown": _strategy_breakdown(signal_events, closed_trades, list(active_strategy_names)),
                "active_strategies": active_strategies,
                "auxiliary_strategies": active_strategies,
            }
        ]
    }


def _active_strategies_payload(settings) -> list[dict[str, Any]]:
    # Only the generalizing strategies are surfaced. Retired and hidden from the UI:
    # Surge Pullback Reclaim, Liquidity Sweep Reclaim (both long off), Liquidity
    # Pullback Reclaim (anti-generalizer), and VWAP Soft Reclaim (retired 2026-07-16
    # after walk-forward showed in-sample 100% win flipping to 0% win / -$45 out of
    # sample with no separable entry edge). Their engine flags still exist in config
    # for re-enabling; add an entry back here to resurface one.
    payload = [
        {
            "strategy_name": "First Pullback After Volume Shock",
            "parameter_set_id": "volume_shock_first_pullback",
            "role": "Captures the first controlled pullback after a volume/notional shock.",
            "enabled": settings.strategy_volume_shock_pullback_enabled,
        },
        {
            "strategy_name": "Micro Breakout With Absorption",
            "parameter_set_id": "micro_breakout_absorption",
            "role": "Requires prior absorption/compression before a short-range high break.",
            "enabled": settings.strategy_micro_absorption_breakout_enabled,
        },
    ]
    return [row for row in payload if row["enabled"]]


def _latest_conditions_by_strategy(signal_events: list, active_strategies: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Most recent per-condition pass/fail map for each enabled strategy.

    Data-driven so the UI renders one panel per active strategy without hardcoding
    the strategy set — new strategies appear automatically, retired ones drop off.
    """
    latest_by_name: dict[str, dict] = {}
    for event in reversed(signal_events):
        payload = event.payload or {}
        name = _event_strategy_name(payload)
        if not name or name in latest_by_name:
            continue
        latest_by_name[name] = payload
    output: list[dict[str, Any]] = []
    for row in active_strategies:
        if not row.get("enabled"):
            continue
        payload = latest_by_name.get(row["strategy_name"]) or {}
        output.append(
            {
                "strategy_name": row["strategy_name"],
                "symbol": payload.get("symbol"),
                "entry_allowed": bool(payload.get("entry_allowed", False)),
                "reject_reason": payload.get("reject_reason"),
                "conditions": payload.get("gate_status") or {},
            }
        )
    return output


def _event_strategy_name(payload: dict[str, Any]) -> str:
    # No default strategy: nameless events fall through _strategy_breakdown's
    # "name not in rows" guard and are skipped (the retired Surge default was stale).
    return str(payload.get("strategy_name") or "")


def _trade_strategy_name(row: dict[str, Any]) -> str:
    return str(row.get("strategy_name") or "")


def _strategy_breakdown(signal_events: list, closed_trades: list[dict], names: list[str]) -> list[dict]:
    rows = {name: _empty_strategy_row(name) for name in names}
    for event in signal_events:
        payload = event.payload or {}
        name = _event_strategy_name(payload)
        if name not in rows:
            continue
        row = rows[name]
        if payload.get("passed"):
            row["signals"] += 1
        else:
            row["rejects"] += 1
        score = payload.get("final_score")
        if isinstance(score, (int, float)):
            row["_score_sum"] += float(score)
            row["_score_count"] += 1
    for trade in closed_trades:
        name = _trade_strategy_name(trade)
        if name not in rows:
            continue
        row = rows[name]
        pnl = _pnl(trade)
        notional = float(trade.get("entry_price") or 0.0) * float(trade.get("quantity") or 0.0)
        row["trades"] += 1
        row["net_pnl_usd"] += pnl
        row["notional_usd"] += notional
        if pnl > 0:
            row["wins"] += 1
            row["gross_profit_usd"] += pnl
        elif pnl < 0:
            row["losses"] += 1
            row["gross_loss_usd"] += abs(pnl)
    output = []
    for row in rows.values():
        trades = row["trades"]
        row["net_pnl_usd"] = round(row["net_pnl_usd"], 2)
        row["notional_usd"] = round(row["notional_usd"], 2)
        row["win_rate_pct"] = round(row["wins"] / trades * 100, 2) if trades else None
        row["return_pct"] = round(row["net_pnl_usd"] / row["notional_usd"] * 100, 3) if row["notional_usd"] else None
        row["profit_factor"] = (
            round(row["gross_profit_usd"] / row["gross_loss_usd"], 3)
            if row["gross_loss_usd"] > 0
            else None
        )
        row["avg_score"] = round(row["_score_sum"] / row["_score_count"], 2) if row["_score_count"] else None
        row["expectancy_usd"] = round(row["net_pnl_usd"] / trades, 3) if trades else None
        row.pop("_score_sum", None)
        row.pop("_score_count", None)
        row["gross_profit_usd"] = round(row["gross_profit_usd"], 2)
        row["gross_loss_usd"] = round(row["gross_loss_usd"], 2)
        output.append(row)
    return sorted(output, key=lambda row: (row["trades"] == 0, row["strategy_name"]))


def _empty_strategy_row(name: str) -> dict:
    return {
        "strategy_name": name,
        "signals": 0,
        "rejects": 0,
        "trades": 0,
        "wins": 0,
        "losses": 0,
        "net_pnl_usd": 0.0,
        "gross_profit_usd": 0.0,
        "gross_loss_usd": 0.0,
        "notional_usd": 0.0,
        "_score_sum": 0.0,
        "_score_count": 0,
    }


def _pnl(row: dict) -> float:
    if row.get("net_pnl_usd") is not None:
        return float(row.get("net_pnl_usd") or 0.0)
    return float(row.get("gross_pnl_usd") or 0.0)
