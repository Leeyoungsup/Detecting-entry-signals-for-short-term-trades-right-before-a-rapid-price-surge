import pytest

from app.services.strategy_decision import (
    DynamicTakeProfitConfig,
    EntryFillGateConfig,
    ExitDecisionConfig,
    ExitDecisionIndicators,
    ExitDecisionPosition,
    advance_trailing_stop,
    bounded_stop_exit_price,
    compute_structure_stop_price,
    evaluate_exit_decision,
    evaluate_entry_fill_gate,
    ohlcv_spread_proxy_fraction,
    update_dynamic_take_profit_target,
)


def test_entry_fill_gate_blocks_wide_spread_and_price_chase() -> None:
    config = EntryFillGateConfig(entry_slippage_pct=0.0005, max_chase_pct=0.012)

    wide = evaluate_entry_fill_gate(
        bid=1.00,
        ask=1.03,
        last=None,
        spread_pct=None,
        max_spread_pct=1.25,
        signal_close=1.01,
        strategy_name="Micro Breakout With Absorption",
        config=config,
    )
    assert wide.allowed is False
    assert wide.reason == "spread_too_wide"

    chase = evaluate_entry_fill_gate(
        bid=10.0,
        ask=10.30,
        last=None,
        spread_pct=0.2,
        max_spread_pct=0.85,
        signal_close=10.0,
        strategy_name="Micro Breakout With Absorption",
        config=config,
    )
    assert chase.allowed is False
    assert chase.reason == "price_chase_too_far"


def test_common_stop_and_trailing_helpers_match_replay_runtime_shape() -> None:
    stop = compute_structure_stop_price(
        [9.95, 9.96, 9.70],
        10.0,
        final_stop_pct=0.035,
        structure_stop_buffer=0.004,
    )
    assert stop == pytest.approx(9.70 * 0.996)

    trailing = advance_trailing_stop(
        entry_price=10.0,
        current_price=10.08,
        high_watermark=10.0,
        trailing_stop_price=None,
        activation_price=None,
        activation_pct=0.0035,
        trailing_pct=0.004,
    )
    assert trailing.trailing_active is True
    assert trailing.trailing_stop_price == pytest.approx(10.08 * 0.996)

    capped = bounded_stop_exit_price(
        9.0,
        trigger_price=10.0,
        reason="structure_or_final_stop",
        stop_slippage_cap_pct=0.005,
    )
    assert capped == pytest.approx(9.95)


def test_ohlcv_spread_proxy_tightens_for_liquid_bars() -> None:
    thin = ohlcv_spread_proxy_fraction(range_pct=10.0, close=1.0, volume=20_000, trade_count=10)
    liquid = ohlcv_spread_proxy_fraction(range_pct=10.0, close=1.0, volume=1_500_000, trade_count=400)

    assert thin > liquid
    assert 0.002 <= liquid <= 0.02


def test_dynamic_take_profit_update_matches_runtime_target_adjustments() -> None:
    config = DynamicTakeProfitConfig(
        enabled=True,
        default_take_profit_pct=0.006,
        dynamic_trailing_normal_pct=0.004,
        dynamic_trailing_wide_pct=0.012,
        max_exit_spread_pct=0.8,
    )
    weak_state = {"weak": True, "execution_spread_pct": 0.35}

    lowered = update_dynamic_take_profit_target(
        average_price=10.0,
        quantity=10,
        current_price=10.20,
        high_watermark=10.50,
        take_profit_price=10.80,
        previous_dynamic_take_profit_price=10.80,
        profit_floor=10.05,
        momentum_state=weak_state,
        trailing_pct=0.004,
        config=config,
    )

    assert lowered is not None
    assert lowered["price"] == pytest.approx(10.20)
    assert lowered["reason"] == "sell_dominance_lower_target"
    assert weak_state["dynamic_take_profit_action"] == "lower_or_exit_candidate"
    assert weak_state["spread_exit_priority"] is False

    runner_state = {"runner": True}
    raised = update_dynamic_take_profit_target(
        average_price=10.0,
        quantity=10,
        current_price=10.40,
        high_watermark=10.60,
        take_profit_price=10.20,
        previous_dynamic_take_profit_price=10.20,
        profit_floor=10.03,
        momentum_state=runner_state,
        trailing_pct=0.004,
        config=config,
    )

    assert raised is not None
    assert raised["price"] == pytest.approx(10.60 * (1 + 0.012 * 0.5))
    assert raised["reason"] == "runner_buy_dominance_raise_target"
    assert runner_state["dynamic_take_profit_action"] == "raise"


def test_common_exit_decision_requires_weakness_for_trailing_and_confirms_stop() -> None:
    config = ExitDecisionConfig(
        partial_exit_fraction=0.0,
        dynamic_take_profit_enabled=True,
        partial_exit_requires_weakness=True,
        high_failure_exit_enabled=True,
        break_even_activation_pct=0.003,
        trailing_activation_pct=0.0035,
        take_profit_requires_weakness=True,
        exit_on_vwap_ema_break=False,
        vwap_ema_break_min_hold_seconds=30,
        vwap_ema_break_min_loss_pct=0.01,
        time_exit_enabled=False,
        time_exit_seconds=300,
        stop_loss_hold_enabled=False,
        stop_loss_hold_max_seconds=5,
        max_stop_loss_pct=0.015,
        stop_loss_deep_break_pct=0.002,
        stop_loss_rapid_drop_pct=0.012,
        strategy_min_trade_strength_for_entry=45.0,
        strategy_max_sell_pressure_for_entry=0.55,
    )
    position = ExitDecisionPosition(
        quantity=10,
        average_price=10.0,
        opened_elapsed_seconds=120,
        stop_loss_price=9.5,
        trailing_activation_price=10.035,
    )
    indicators = ExitDecisionIndicators(ema9=10.0, ema20=9.9, vwap=9.95, bb_mid=10.2)

    held = evaluate_exit_decision(
        current_price=10.05,
        position=position,
        indicators=indicators,
        high_watermark=10.20,
        trailing_stop_price=10.10,
        momentum_state={"weak": False, "strong": True},
        high_failure_count=0,
        full_profit_floor=10.01,
        partial_profit_floor=float("inf"),
        config=config,
    )
    assert held.reason is None

    trailed = evaluate_exit_decision(
        current_price=10.05,
        position=position,
        indicators=indicators,
        high_watermark=10.20,
        trailing_stop_price=10.10,
        momentum_state={"weak": True},
        high_failure_count=0,
        full_profit_floor=10.01,
        partial_profit_floor=float("inf"),
        config=config,
    )
    assert trailed.reason == "trailing_stop"

    stop_position = ExitDecisionPosition(
        quantity=10,
        average_price=10.0,
        opened_elapsed_seconds=120,
        stop_loss_price=9.95,
    )
    stopped = evaluate_exit_decision(
        current_price=9.94,
        position=stop_position,
        indicators=indicators,
        high_watermark=10.20,
        trailing_stop_price=10.10,
        momentum_state={"chart_breakdown": False},
        high_failure_count=0,
        full_profit_floor=10.01,
        partial_profit_floor=float("inf"),
        config=config,
    )
    assert stopped.reason == "stop_loss_confirmed"
