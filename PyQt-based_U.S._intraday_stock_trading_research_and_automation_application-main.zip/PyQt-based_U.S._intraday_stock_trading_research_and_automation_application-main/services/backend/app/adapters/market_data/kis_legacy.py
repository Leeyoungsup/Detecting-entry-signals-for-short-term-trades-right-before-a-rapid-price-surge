from app.services.kis_connection import KisConnectionService
from app.services.kis_ws_manager import kis_ws_client


class KisLegacyMarketDataProvider:
    provider_name = "kis_legacy"

    def __init__(self) -> None:
        self.kis = KisConnectionService()

    def status(self) -> dict:
        status = self.kis.status(ping=False)
        status["provider"] = self.provider_name
        status["message"] = "임시 KIS market-data fallback입니다. 실시간 차트/tick의 주 소스로 쓰지 않습니다."
        return status

    def scanner_rankings(self, exchange: str = "NAS") -> dict:
        return self.kis.scanner_rankings(exchange=exchange)

    async def start_realtime(
        self,
        *,
        symbols: list[str],
        exchange: str = "NAS",
        key_mode: str = "regular",
        subscribe_quotes: bool = True,
        subscribe_trades: bool = True,
    ) -> dict:
        return await kis_ws_client.start(
            symbols=symbols,
            exchange=exchange,
            key_mode=key_mode,  # type: ignore[arg-type]
            subscribe_quotes=subscribe_quotes,
            subscribe_trades=subscribe_trades,
        )

    async def stop_realtime(self) -> dict:
        return await kis_ws_client.stop()

    def realtime_status(self) -> dict:
        return kis_ws_client.status()

    def realtime_snapshot(self) -> dict:
        return kis_ws_client.snapshot()

    def subscribed_symbols(self) -> set[str]:
        return kis_ws_client.subscribed_symbols()

    def order_flow_snapshot(self) -> dict[str, dict]:
        return kis_ws_client.order_flow_snapshot()

    def recent_events(self, limit: int = 100) -> list[dict]:
        return kis_ws_client.recent_events(limit)

    def price(self, symbol: str, exchange: str = "NAS") -> dict:
        return self.kis.price(symbol=symbol, exchange=exchange)

    def quote(self, symbol: str, exchange: str = "NAS") -> dict:
        return self.kis.quote(symbol=symbol, exchange=exchange)

    def minute_bars(self, symbol: str, exchange: str = "NAS", interval: str = "1", limit: int = 120) -> dict:
        return self.kis.minute_bars(symbol=symbol, exchange=exchange, interval=interval, limit=limit)

    def minute_bars_history(
        self,
        symbol: str,
        exchange: str = "NAS",
        interval: str = "1",
        target_date: str | None = None,
        max_pages: int = 20,
    ) -> dict:
        return self.kis.minute_bars_history(
            symbol=symbol,
            exchange=exchange,
            interval=interval,
            target_date=target_date,
            max_pages=max_pages,
        )

    def daily_bars(
        self,
        symbol: str,
        exchange: str = "NAS",
        period: str = "0",
        bymd: str = "",
        adjusted: bool = True,
        max_pages: int = 5,
    ) -> dict:
        return self.kis.daily_bars(
            symbol=symbol,
            exchange=exchange,
            period=period,
            bymd=bymd,
            adjusted=adjusted,
            max_pages=max_pages,
        )
