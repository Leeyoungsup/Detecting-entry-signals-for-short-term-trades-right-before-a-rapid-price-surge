from collections import deque
from datetime import datetime, timedelta, timezone

from app.services import shared_state

CANDLE_SYMBOLS_KEY = "trading_lab:candles:symbols"
CANDLE_KEY_PREFIX = "trading_lab:candles:"
LEGACY_CANDLE_SYMBOLS_KEY = "kis:candles:symbols"
LEGACY_CANDLE_KEY_PREFIX = "kis:candles:"


class InMemoryCandleBuilder:
    def __init__(self, max_candles: int = 300) -> None:
        self.max_candles = max_candles
        self._candles: dict[str, deque[dict]] = {}
        self._last_tick_at: dict[str, str] = {}

    def seed(self, symbol: str, candles: list[dict], *, source: str = "kis_rest") -> None:
        symbol = symbol.upper()
        # list() snapshots the deque atomically; concurrent on_trade appends must
        # not mutate it mid-iteration ("deque mutated during iteration").
        existing = {
            self._storage_key(row): row
            for row in list(self._candles.get(symbol, deque()))
            if row.get("is_tick_built") or row.get("source") != source
        }
        for candle in candles:
            bucket = self._bucket_key(candle)
            if not bucket:
                continue
            storage_key = f"official:{bucket}"
            normalized = {
                **candle,
                "symbol": symbol,
                "source": source,
                "is_live": False,
                "is_complete": True,
                "is_tick_built": False,
                "updated_at": _now_iso(),
            }
            if storage_key in existing and not _is_authoritative_source(source):
                continue
            existing[storage_key] = normalized
        ordered = sorted(
            existing.values(),
            key=lambda row: (str(row.get("market_date") or ""), str(row.get("market_time") or ""), str(row.get("source") or "")),
        )
        self._candles[symbol] = deque(ordered[-self.max_candles :], maxlen=self.max_candles)
        self._persist_symbol(symbol)

    def on_trade(self, event: dict, *, source: str = "provider_ws_tick") -> dict | None:
        symbol = str(event.get("symbol") or "").upper()
        price = _to_float(event.get("last"))
        volume = _to_float(event.get("trade_volume")) or 0.0
        if not symbol or price is None:
            return None

        raw = event.get("raw") if isinstance(event.get("raw"), dict) else {}
        received_utc = _event_received_utc(event)
        (
            fallback_market_date,
            fallback_market_time,
            fallback_korea_date,
            fallback_korea_time,
        ) = _received_bucket_parts(received_utc)
        # The live-tick forming candle uses the received CLOSE-time bucket (see
        # _received_bucket_parts). Received time tracks the trade within ~1s and
        # close-time is what aligns the tick with Toss's official (close-time) 1m
        # candles; the raw open-time trade stamp put the tick one bar behind.
        market_date = fallback_market_date
        market_time = fallback_market_time
        korea_date = fallback_korea_date
        korea_time = fallback_korea_time

        candles = self._candles.setdefault(symbol, deque(maxlen=self.max_candles))
        # Snapshot for reads; another thread's on_trade may append concurrently.
        candles_snapshot = list(candles)
        official_base = _target_official_candle(candles_snapshot, market_date, market_time, received_utc)
        if official_base:
            market_date = _date_digits(official_base.get("market_date")) or market_date
            market_time = _minute_time(official_base.get("market_time")) or market_time
            korea_date = _date_digits(official_base.get("korea_date")) or korea_date
            korea_time = _minute_time(official_base.get("korea_time")) or korea_time
        bucket = f"{market_date}:{market_time}"
        current = next(
            (
                row
                for row in reversed(candles_snapshot)
                if self._bucket_key(row) == bucket and (row.get("is_tick_built") or row.get("source") == source)
            ),
            None,
        )
        if current is None:
            for row in reversed(candles_snapshot):
                if row.get("source") == source and row.get("is_live"):
                    row["is_live"] = False
                    row["is_complete"] = True
                    row["completed_at"] = _now_iso()
                    break
            current = _live_seed_from_official(official_base) if official_base else {
                "symbol": symbol,
                "market_date": market_date,
                "market_time": market_time,
                "korea_date": korea_date,
                "korea_time": korea_time,
                "open": price,
                "high": price,
                "low": price,
                "close": price,
                "volume": 0.0,
                "notional": 0.0,
                "source": source,
                "is_live": True,
                "is_complete": False,
                "is_tick_built": True,
                "updated_at": _now_iso(),
            }
            current["source"] = source
            current["is_live"] = True
            current["is_complete"] = False
            current["is_tick_built"] = True
            current["updated_at"] = _now_iso()
            candles.append(current)

        current["high"] = max(_to_float(current.get("high")) or price, price)
        current["low"] = min(_to_float(current.get("low")) or price, price)
        current["close"] = price
        current["volume"] = (_to_float(current.get("volume")) or 0.0) + volume
        current["notional"] = (_to_float(current.get("notional")) or 0.0) + price * volume
        current["source"] = source
        current["is_live"] = True
        current["updated_at"] = _now_iso()
        self._last_tick_at[symbol] = str(event.get("received_at") or current["updated_at"])
        self._persist_symbol(symbol)
        return dict(current)

    def candles(self, symbol: str, *, limit: int = 120, newest_first: bool = False) -> list[dict]:
        self._hydrate_symbol(symbol)
        rows = [row for row in list(self._candles.get(symbol.upper(), deque())) if not _is_future_candle(row)][-limit:]
        if newest_first:
            return list(reversed(rows))
        return rows

    def live_tick_candles(
        self,
        symbol: str,
        *,
        limit: int = 120,
        include_current: bool = True,
        newest_first: bool = False,
    ) -> list[dict]:
        self._hydrate_symbol(symbol)
        rows = [
            row
            for row in list(self._candles.get(symbol.upper(), deque()))
            if (row.get("is_tick_built") or row.get("source") == "provider_ws_tick")
            and not _is_future_candle(row)
        ]
        if not include_current:
            rows = [row for row in rows if not row.get("is_live")]
        rows = rows[-limit:]
        if newest_first:
            return list(reversed(rows))
        return list(rows)

    def candle_sets(self, symbol: str, *, limit: int = 120) -> dict:
        self._hydrate_symbol(symbol)
        rows = self.candles(symbol, limit=limit, newest_first=False)
        live_rows = self.live_tick_candles(symbol, limit=limit, include_current=True, newest_first=False)
        official_rows = [row for row in rows if not row.get("is_tick_built") and row.get("source") != "provider_ws_tick"]
        return {
            "all": rows,
            "official": official_rows,
            "live_tick": live_rows,
            "live_tick_completed": [row for row in live_rows if not row.get("is_live")],
        }

    def latest_candle(self, symbol: str) -> dict | None:
        rows = self.candles(symbol, limit=1, newest_first=False)
        return dict(rows[-1]) if rows else None

    def latest_price(self, symbol: str) -> float | None:
        candle = self.latest_candle(symbol)
        return _to_float(candle.get("close")) if candle else None

    def status(self) -> dict:
        self._hydrate_known_symbols()
        # Snapshot dict items and each deque: on_trade may add symbols / append
        # candles from other threads mid-iteration (dict/deque size change).
        items = [(symbol, list(candles)) for symbol, candles in list(self._candles.items())]
        return {
            "symbols": sorted(symbol for symbol, _ in items),
            "counts": {symbol: len(candles) for symbol, candles in items if candles},
            "last_tick_at": dict(self._last_tick_at),
            "official_latest": {
                symbol: _latest_key([row for row in candles if not row.get("is_tick_built") and row.get("source") != "provider_ws_tick"])
                for symbol, candles in items
                if candles
            },
            "tick_latest": {
                symbol: _latest_key([row for row in candles if row.get("is_tick_built") or row.get("source") == "provider_ws_tick"])
                for symbol, candles in items
                if candles
            },
        }

    def has_symbol(self, symbol: str) -> bool:
        self._hydrate_symbol(symbol)
        return bool(self._candles.get(symbol.upper()))

    def _bucket_key(self, candle: dict) -> str | None:
        market_date = candle.get("market_date")
        market_time = candle.get("market_time")
        if not market_date or not market_time:
            return None
        return f"{market_date}:{_minute_time(market_time)}"

    def _storage_key(self, candle: dict) -> str | None:
        bucket = self._bucket_key(candle)
        if not bucket:
            return None
        source_prefix = "tick" if candle.get("is_tick_built") or candle.get("source") == "provider_ws_tick" else "official"
        return f"{source_prefix}:{bucket}"

    def _persist_symbol(self, symbol: str) -> None:
        symbol = symbol.upper()
        payload = {
            "candles": list(self._candles.get(symbol, deque())),
            "last_tick_at": self._last_tick_at.get(symbol),
        }
        shared_state.set_json(f"{CANDLE_KEY_PREFIX}{symbol}", payload, ex=3600)
        known = shared_state.get_json(CANDLE_SYMBOLS_KEY)
        symbols = set(known if isinstance(known, list) else [])
        symbols.add(symbol)
        shared_state.set_json(CANDLE_SYMBOLS_KEY, sorted(symbols), ex=3600)

    def _hydrate_symbol(self, symbol: str) -> None:
        symbol = symbol.upper()
        if self._candles.get(symbol):
            return
        payload = shared_state.get_json_any(f"{CANDLE_KEY_PREFIX}{symbol}", f"{LEGACY_CANDLE_KEY_PREFIX}{symbol}")
        if not isinstance(payload, dict):
            return
        candles = payload.get("candles")
        if isinstance(candles, list):
            self._candles[symbol] = deque(candles[-self.max_candles :], maxlen=self.max_candles)
        if payload.get("last_tick_at"):
            self._last_tick_at[symbol] = str(payload.get("last_tick_at"))

    def _hydrate_known_symbols(self) -> None:
        symbols = shared_state.get_json_any(CANDLE_SYMBOLS_KEY, LEGACY_CANDLE_SYMBOLS_KEY)
        if not isinstance(symbols, list):
            return
        for symbol in symbols:
            if isinstance(symbol, str):
                self._hydrate_symbol(symbol)


def _minute_time(value: str | int | None) -> str | None:
    if value in (None, ""):
        return None
    digits = "".join(ch for ch in str(value) if ch.isdigit())
    if len(digits) < 4:
        return None
    return f"{digits[:4]}00"


def _date_digits(value: str | int | None) -> str | None:
    if value in (None, ""):
        return None
    digits = "".join(ch for ch in str(value) if ch.isdigit())
    return digits[:8] if len(digits) >= 8 else None


def _event_received_utc(event: dict) -> datetime:
    received = _parse_iso(event.get("received_at"))
    if received is None:
        return datetime.now(timezone.utc)
    return received.astimezone(timezone.utc)


def _received_bucket_parts(received_utc: datetime) -> tuple[str, str, str, str]:
    # Toss labels 1m candles by CLOSE time (a trade at 10:59:xx belongs to the
    # candle labeled 11:00, which closes at 11:00:00). So the forming live-tick
    # candle for a trade received at minute M is bucketed to M+1. Using open-time
    # (floor) here put the tick on the previous minute, one bar behind the official
    # forming candle. +1 (with datetime rollover) aligns tick and official.
    close_utc = received_utc.astimezone(timezone.utc).replace(second=0, microsecond=0) + timedelta(minutes=1)
    close_kst = close_utc + timedelta(hours=9)
    return (
        close_utc.strftime("%Y%m%d"),
        close_utc.strftime("%H%M00"),
        close_kst.strftime("%Y%m%d"),
        close_kst.strftime("%H%M00"),
    )


def _bucket_is_after_received(market_date: str, market_time: str, received_utc: datetime) -> bool:
    bucket_dt = _bucket_datetime_utc(market_date, market_time)
    if bucket_dt is None:
        return False
    received_floor = received_utc.astimezone(timezone.utc).replace(second=0, microsecond=0)
    return bucket_dt > received_floor


def _bucket_datetime_utc(market_date: str | int | None, market_time: str | int | None) -> datetime | None:
    date_digits = _date_digits(market_date)
    time_digits = "".join(ch for ch in str(market_time or "").zfill(6) if ch.isdigit()).zfill(6)
    if not date_digits or len(time_digits) < 6:
        return None
    try:
        return datetime.strptime(f"{date_digits}{time_digits[:6]}", "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _target_official_candle(candles: list[dict], market_date: str, market_time: str, received_utc: datetime) -> dict | None:
    candidate_dt = _bucket_datetime_utc(market_date, market_time)
    if candidate_dt is None:
        return None
    received_floor = received_utc.astimezone(timezone.utc).replace(second=0, microsecond=0)
    latest_official = next((row for row in reversed(candles) if not _is_tick_candle(row)), None)
    if not latest_official:
        return None
    official_dt = _bucket_datetime_utc(latest_official.get("market_date"), latest_official.get("market_time"))
    if official_dt is None:
        return None
    # Both the tick bucket (candidate_dt) and the official candles are now CLOSE-time
    # labelled, so only merge the tick into the official candle for the SAME forming
    # minute. Merging into an earlier (completed) official bucket is exactly the
    # off-by-one that put the live tick one bar behind.
    del received_floor  # no longer used for alignment
    if official_dt == candidate_dt:
        return latest_official
    return None


def _live_seed_from_official(official: dict | None) -> dict:
    return {
        **(official or {}),
        "is_live": True,
        "is_complete": False,
        "is_tick_built": True,
        "updated_at": _now_iso(),
        "live_merged_from_official": True,
        "official_source": (official or {}).get("source"),
    }


def _is_tick_candle(candle: dict) -> bool:
    return bool(candle.get("is_tick_built") or candle.get("source") == "provider_ws_tick")


def _is_future_candle(candle: dict) -> bool:
    bucket_dt = _bucket_datetime_utc(candle.get("market_date"), candle.get("market_time"))
    if bucket_dt is None:
        return False
    max_live_label = datetime.now(timezone.utc).replace(second=0, microsecond=0) + timedelta(minutes=1)
    if bucket_dt > max_live_label:
        return True
    if not _is_tick_candle(candle):
        return False
    updated = _parse_iso(candle.get("updated_at"))
    if updated is None:
        return False
    # Tick candles are CLOSE-time labelled: a candle updated during minute M carries
    # the label M+1 (it closes at M+1). So the legitimate forming label is
    # updated_floor + 1; only beyond that is a genuinely stale/future tick.
    updated_floor = updated.astimezone(timezone.utc).replace(second=0, microsecond=0)
    return bucket_dt > updated_floor + timedelta(minutes=1)


def _parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _to_float(value: str | int | float | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _is_authoritative_source(source: str) -> bool:
    return source.startswith("kis_rest") or source.startswith("provider_")


def _latest_key(rows) -> str | None:
    if not rows:
        return None
    latest = sorted(rows, key=lambda row: (str(row.get("market_date") or ""), str(row.get("market_time") or "")))[-1]
    return f"{latest.get('market_date') or ''} {str(latest.get('market_time') or '').zfill(6)}".strip()


candle_builder = InMemoryCandleBuilder()
