import asyncio
import json
from collections import deque
from datetime import datetime, timezone
from typing import Any, Literal

import websockets

from app.adapters.kis.auth import KisAuthClient
from app.adapters.kis.errors import KisAdapterError, KisConfigurationError
from app.core.config import Settings, get_settings

KIS_WS_TR_QUOTE_US = "HDFSASP0"
KIS_WS_TR_TRADE = "HDFSCNT0"

QUOTE_COLUMNS = [
    "rsym",
    "symb",
    "zdiv",
    "xymd",
    "xhms",
    "kymd",
    "khms",
    "bvol",
    "avol",
    "bdvl",
    "advl",
    "pbid1",
    "pask1",
    "vbid1",
    "vask1",
    "dbid1",
    "dask1",
]

TRADE_COLUMNS = [
    "rsym",
    "symb",
    "zdiv",
    "tymd",
    "xymd",
    "xhms",
    "kymd",
    "khms",
    "open",
    "high",
    "low",
    "last",
    "sign",
    "diff",
    "rate",
    "pbid",
    "pask",
    "vbid",
    "vask",
    "evol",
    "tvol",
    "tamt",
    "bivl",
    "asvl",
    "strn",
    "mtyp",
]

REGULAR_EXCHANGE_PREFIX = {
    "NAS": "DNAS",
    "NYS": "DNYS",
    "AMS": "DAMS",
}

DAYTIME_EXCHANGE_PREFIX = {
    "NAS": "RBAQ",
    "NYS": "RBAY",
    "AMS": "RBAA",
}


class KisWebSocketClient:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.auth_client = KisAuthClient(self.settings)
        self._task: asyncio.Task | None = None
        self._websocket: Any | None = None
        self._events: deque[dict] = deque(maxlen=1000)
        self._latest_quotes: dict[str, dict] = {}
        self._latest_trades: dict[str, dict] = {}
        self._subscriptions: list[dict] = []
        self._status = "stopped"
        self._last_error: str | None = None
        self._last_message_at: str | None = None
        self._last_realtime_at: str | None = None
        self._started_at: str | None = None

    @property
    def ws_url(self) -> str:
        base = (
            self.settings.kis_websocket_url_live
            if self.settings.kis_environment == "live"
            else self.settings.kis_websocket_url_mock
        )
        return base if base.endswith("/tryitout") else f"{base.rstrip('/')}/tryitout"

    async def start(
        self,
        *,
        symbols: list[str],
        exchange: str = "NAS",
        key_mode: Literal["regular", "daytime"] = "regular",
        subscribe_quotes: bool = True,
        subscribe_trades: bool = True,
    ) -> dict:
        if self._task and not self._task.done():
            return self.status()
        if not symbols:
            raise KisConfigurationError("WebSocket 구독 종목이 비어 있습니다.")
        subscriptions = []
        for symbol in symbols:
            tr_key = build_us_tr_key(symbol=symbol, exchange=exchange, key_mode=key_mode)
            if subscribe_quotes:
                subscriptions.append({"tr_id": KIS_WS_TR_QUOTE_US, "tr_key": tr_key, "kind": "quote"})
            if subscribe_trades:
                subscriptions.append({"tr_id": KIS_WS_TR_TRADE, "tr_key": tr_key, "kind": "trade"})
        self._subscriptions = subscriptions
        self._status = "starting"
        self._last_error = None
        self._started_at = _now_iso()
        self._task = asyncio.create_task(self._run())
        return self.status()

    async def stop(self) -> dict:
        self._status = "stopping"
        task = self._task
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._task = None
        self._websocket = None
        self._subscriptions = []
        self._status = "stopped"
        return self.status()

    async def connect(self) -> None:
        await self.start(symbols=["AAPL"])

    async def subscribe_trades(self, symbols: list[str]) -> None:
        await self.start(symbols=symbols, subscribe_quotes=False, subscribe_trades=True)

    async def subscribe_orderbook(self, symbols: list[str]) -> None:
        await self.start(symbols=symbols, subscribe_quotes=True, subscribe_trades=False)

    def status(self) -> dict:
        task_done = self._task.done() if self._task else True
        if self._task and task_done and self._status not in ("stopped", "error"):
            self._status = "stopped"
        return {
            "status": self._status,
            "environment": self.settings.kis_environment,
            "url": self.ws_url,
            "subscriptions": self._subscriptions,
            "subscription_count": len(self._subscriptions),
            "last_message_at": self._last_message_at,
            "last_realtime_at": self._last_realtime_at,
            "last_error": self._last_error,
            "started_at": self._started_at,
            "event_count": len(self._events),
            "latest_quote_symbols": sorted(self._latest_quotes.keys()),
            "latest_trade_symbols": sorted(self._latest_trades.keys()),
        }

    def recent_events(self, limit: int = 100) -> list[dict]:
        return list(self._events)[-limit:]

    def snapshot(self) -> dict:
        return {
            "status": self.status(),
            "quotes": self._latest_quotes,
            "trades": self._latest_trades,
            "recent_events": self.recent_events(50),
        }

    def subscribed_symbols(self) -> set[str]:
        if self._status not in ("starting", "connected"):
            return set()
        return {
            _symbol_from_tr_key(subscription.get("tr_key")) or subscription.get("tr_key")
            for subscription in self._subscriptions
            if subscription.get("tr_key")
        }

    def order_flow_snapshot(self, *, now: datetime | None = None) -> dict[str, dict]:
        now = now or datetime.now(timezone.utc)
        stats: dict[str, dict] = {}
        for symbol in self.subscribed_symbols():
            if symbol:
                stats.setdefault(symbol, _empty_flow(symbol))

        # Snapshot: the websocket thread appends to self._events; iterating the
        # live deque here would raise "deque mutated during iteration".
        for event in list(self._events):
            symbol = event.get("symbol")
            if not symbol or event.get("event_type") not in ("quote", "trade"):
                continue
            received_at = _parse_iso(event.get("received_at"))
            age_sec = (now - received_at).total_seconds() if received_at else None
            flow = stats.setdefault(symbol, _empty_flow(symbol))
            if age_sec is not None:
                flow["last_update_age_sec"] = (
                    age_sec
                    if flow["last_update_age_sec"] is None
                    else min(flow["last_update_age_sec"], age_sec)
                )
            if event["event_type"] == "quote":
                flow["quote"] = event
                flow["spread_pct"] = event.get("spread_pct")
                flow["bid_ask_imbalance"] = event.get("bid_ask_imbalance")
                continue

            flow["trade"] = event
            flow["trade_strength"] = event.get("trade_strength")
            flow["sell_pressure"] = _sell_pressure(event)
            flow["spread_pct"] = flow.get("spread_pct") if flow.get("quote") else event.get("spread_pct")
            flow["bid_ask_imbalance"] = (
                flow.get("bid_ask_imbalance") if flow.get("quote") else event.get("bid_ask_imbalance")
            )
            notional = _event_notional(event)
            volume = _event_volume(event)
            if age_sec is None:
                continue
            if 0 <= age_sec <= 10:
                flow["notional_10s"] += notional
                flow["volume_10s"] += volume
            elif 10 < age_sec <= 20:
                flow["notional_prev_10s"] += notional
                flow["volume_prev_10s"] += volume
            if 0 <= age_sec <= 30:
                flow["notional_30s"] += notional
                flow["volume_30s"] += volume
            if 0 <= age_sec <= 60:
                flow["notional_60s"] += notional
                flow["volume_60s"] += volume

        for flow in stats.values():
            prev = flow.pop("notional_prev_10s")
            flow["notional_velocity_10s"] = (
                flow["notional_10s"] / prev if prev and prev > 0 else None
            )
            prev_volume = flow.pop("volume_prev_10s")
            flow["volume_velocity_10s"] = (
                flow["volume_10s"] / prev_volume if prev_volume and prev_volume > 0 else None
            )
        return stats

    async def _run(self) -> None:
        try:
            approval_key = self.auth_client.issue_ws_approval_key_sync()
            async with websockets.connect(self.ws_url, ping_interval=None) as websocket:
                self._websocket = websocket
                self._status = "connected"
                for subscription in self._subscriptions:
                    await websocket.send(_subscribe_message(approval_key=approval_key, **subscription))
                    await asyncio.sleep(0.1)
                async for message in websocket:
                    await self._handle_message(str(message), websocket)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._last_error = str(exc)
            self._status = "error"
            self._push_event({"event_type": "ws_error", "message": str(exc)})
        finally:
            self._websocket = None
            if self._status not in ("error", "stopping", "stopped"):
                self._status = "stopped"

    async def _handle_message(self, message: str, websocket: Any) -> None:
        self._last_message_at = _now_iso()
        if not message:
            return
        if message[0] in ("0", "1"):
            events = parse_realtime_messages(message)
            for event in events:
                self._push_event(event)
                if event["event_type"] == "quote":
                    self._last_realtime_at = event["received_at"]
                    self._latest_quotes[event["symbol"]] = event
                elif event["event_type"] == "trade":
                    self._last_realtime_at = event["received_at"]
                    self._latest_trades[event["symbol"]] = event
                    self._handle_trade_pipeline(event)
            return

        payload = json.loads(message)
        header = payload.get("header", {})
        tr_id = header.get("tr_id")
        if tr_id == "PINGPONG":
            await websocket.pong(message.encode("utf-8"))
            self._push_event({"event_type": "pingpong", "raw": payload})
            return
        body = payload.get("body", {})
        rt_cd = body.get("rt_cd")
        event = {
            "event_type": "system",
            "tr_id": tr_id,
            "tr_key": header.get("tr_key"),
            "rt_cd": rt_cd,
            "message": body.get("msg1"),
            "raw": _redact_ws_payload(payload),
        }
        self._push_event(event)
        if rt_cd not in (None, "0") and body.get("msg1") != "ALREADY IN SUBSCRIBE":
            raise KisAdapterError(body.get("msg1") or f"KIS WebSocket system error: {payload}")

    def _push_event(self, event: dict) -> None:
        event.setdefault("received_at", _now_iso())
        self._events.append(event)

    def _handle_trade_pipeline(self, event: dict) -> None:
        from app.services.candle_builder import candle_builder
        from app.services.strategy_runtime import strategy_runtime

        candle = candle_builder.on_trade(event)
        strategy_runtime.on_trade(event, candle)


def build_us_tr_key(
    *,
    symbol: str,
    exchange: str = "NAS",
    key_mode: Literal["regular", "daytime"] = "regular",
) -> str:
    normalized = symbol.upper().strip()
    if normalized.startswith(("DNAS", "DNYS", "DAMS", "RBAQ", "RBAY", "RBAA")):
        return normalized
    exchange = exchange.upper().strip()
    prefixes = DAYTIME_EXCHANGE_PREFIX if key_mode == "daytime" else REGULAR_EXCHANGE_PREFIX
    if exchange not in prefixes:
        raise KisConfigurationError(
            f"KIS WebSocket 해외주식 tr_key prefix는 NAS/NYS/AMS만 확인되었습니다: {exchange}"
        )
    return f"{prefixes[exchange]}{normalized}"


def parse_realtime_message(message: str) -> dict | None:
    events = parse_realtime_messages(message)
    return events[-1] if events else None


def parse_realtime_messages(message: str) -> list[dict]:
    parts = message.split("|", 3)
    if len(parts) < 4:
        return []
    tr_id = parts[1]
    count = _to_int(parts[2]) or 1
    values = parts[3].split("^")
    if tr_id == KIS_WS_TR_QUOTE_US:
        return _rows_to_events("quote", tr_id, values, QUOTE_COLUMNS, count)
    if tr_id == KIS_WS_TR_TRADE:
        return _rows_to_events("trade", tr_id, values, TRADE_COLUMNS, count)
    return [
        {
            "event_type": "raw_realtime",
            "tr_id": tr_id,
            "count": count,
            "values": values,
        }
    ]


def _rows_to_events(event_type: str, tr_id: str, values: list[str], columns: list[str], count: int) -> list[dict]:
    events = []
    width = len(columns)
    for index in range(count):
        row_values = values[index * width : (index + 1) * width]
        if len(row_values) < width:
            continue
        row = dict(zip(columns, row_values, strict=False))
        symbol = row.get("symb") or _symbol_from_tr_key(row.get("rsym"))
        event = {
            "event_type": event_type,
            "tr_id": tr_id,
            "tr_key": row.get("rsym"),
            "symbol": symbol,
            "raw": row,
        }
        if event_type == "quote":
            event.update(
                {
                    "bid": _to_float(row.get("pbid1")),
                    "ask": _to_float(row.get("pask1")),
                    "bid_depth": _to_float(row.get("vbid1")),
                    "ask_depth": _to_float(row.get("vask1")),
                    "spread_pct": _spread_pct(_to_float(row.get("pbid1")), _to_float(row.get("pask1"))),
                    "bid_ask_imbalance": _imbalance(_to_float(row.get("vbid1")), _to_float(row.get("vask1"))),
                    "local_time": row.get("xhms"),
                    "korea_time": row.get("khms"),
                }
            )
        else:
            bid = _to_float(row.get("pbid"))
            ask = _to_float(row.get("pask"))
            bid_depth = _to_float(row.get("vbid"))
            ask_depth = _to_float(row.get("vask"))
            event.update(
                {
                    "last": _to_float(row.get("last")),
                    "bid": bid,
                    "ask": ask,
                    "bid_depth": bid_depth,
                    "ask_depth": ask_depth,
                    "spread_pct": _spread_pct(bid, ask),
                    "bid_ask_imbalance": _imbalance(bid_depth, ask_depth),
                    "trade_volume": _to_float(row.get("evol")),
                    "total_volume": _to_float(row.get("tvol")),
                    "total_notional": _to_float(row.get("tamt")),
                    "sell_volume": _to_float(row.get("bivl")),
                    "buy_volume": _to_float(row.get("asvl")),
                    "trade_strength": _to_float(row.get("strn")),
                    "market_type": row.get("mtyp"),
                    "local_time": row.get("xhms"),
                    "korea_time": row.get("khms"),
                }
            )
        events.append(event)
    return events


def _subscribe_message(approval_key: str, tr_id: str, tr_key: str, kind: str, tr_type: str = "1") -> str:
    del kind
    return json.dumps(
        {
            "header": {
                "approval_key": approval_key,
                "custtype": "P",
                "tr_type": tr_type,
                "content-type": "utf-8",
            },
            "body": {"input": {"tr_id": tr_id, "tr_key": tr_key}},
        },
        ensure_ascii=False,
    )


def _redact_ws_payload(payload: dict) -> dict:
    copied = json.loads(json.dumps(payload, ensure_ascii=False))
    output = copied.get("body", {}).get("output")
    if isinstance(output, dict):
        if "key" in output:
            output["key"] = "***"
        if "iv" in output:
            output["iv"] = "***"
    return copied


def _symbol_from_tr_key(tr_key: str | None) -> str | None:
    if not tr_key:
        return None
    for prefix in ("DNAS", "DNYS", "DAMS", "RBAQ", "RBAY", "RBAA"):
        if tr_key.startswith(prefix):
            return tr_key[len(prefix) :]
    return tr_key


def _to_float(value: str | int | float | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _to_int(value: str | int | None) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _spread_pct(bid: float | None, ask: float | None) -> float | None:
    if not bid or not ask:
        return None
    midpoint = (bid + ask) / 2
    if midpoint <= 0:
        return None
    return (ask - bid) / midpoint * 100


def _imbalance(bid_depth: float | None, ask_depth: float | None) -> float | None:
    if bid_depth is None or ask_depth is None:
        return None
    total = bid_depth + ask_depth
    if total <= 0:
        return None
    return bid_depth / total


def _empty_flow(symbol: str) -> dict:
    return {
        "symbol": symbol,
        "quote": None,
        "trade": None,
        "notional_10s": 0.0,
        "notional_prev_10s": 0.0,
        "notional_30s": 0.0,
        "notional_60s": 0.0,
        "notional_velocity_10s": None,
        "volume_10s": 0.0,
        "volume_prev_10s": 0.0,
        "volume_30s": 0.0,
        "volume_60s": 0.0,
        "volume_velocity_10s": None,
        "trade_strength": None,
        "sell_pressure": None,
        "spread_pct": None,
        "bid_ask_imbalance": None,
        "last_update_age_sec": None,
    }


def _event_notional(event: dict) -> float:
    last = event.get("last")
    volume = event.get("trade_volume")
    if last is not None and volume is not None:
        return float(last) * float(volume)
    return 0.0


def _event_volume(event: dict) -> float:
    volume = event.get("trade_volume")
    if volume is not None:
        return float(volume)
    return 0.0


def _sell_pressure(event: dict) -> float | None:
    sell_volume = event.get("sell_volume")
    buy_volume = event.get("buy_volume")
    if sell_volume is None or buy_volume is None:
        return None
    total = float(sell_volume) + float(buy_volume)
    if total <= 0:
        return None
    return float(sell_volume) / total


def _parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
