"""Replay-only experiment for chart-liquidity reversal strategies.

This is for chart-structure liquidity, not quote/orderbook liquidity:
lower-band flushes, prior-low sweeps, MACD histogram hooks, and reclaim bars.
It imports the conservative replay engine and writes isolated experiment
artifacts without changing the active runtime/replay strategy set.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ENGINE_PATH = PROJECT_ROOT / "scripts" / "replay_tc_shadow_strategies.py"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "exports" / "strategy_replay" / "chart_liquidity_experiment"

FILENAME_RE = re.compile(
    r"^(?P<symbol>[a-z0-9]+)_(?P<date>\d{4}-\d{2}-\d{2})_(?P<timerange>\d{4}-\d{4})_kst_(?P<hash>[0-9a-f]+)_enriched\.csv$"
)


def load_engine():
    spec = importlib.util.spec_from_file_location("tc_replay_engine_chart_liquidity", ENGINE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


engine = load_engine()
ORIGINAL_SHOULD_EXIT = engine.should_exit


def _volume_ratio(row: dict) -> float:
    return (row.get("volume") or 0.0) / max(row.get("volume_ma20") or 0.0, 1.0)


def _green_reclaim(row: dict, previous: dict) -> bool:
    return row["close"] >= row["open"] and row["close"] >= previous["close"]


def _close_location(row: dict) -> float:
    high = row.get("high")
    low = row.get("low")
    close = row.get("close")
    if high is None or low is None or close is None or high <= low:
        return 0.0
    return (close - low) / (high - low)


def _macd_values(rows: list[dict], start: int, end: int) -> list[float]:
    values = [rows[i].get("macd_histogram") for i in range(max(0, start), min(len(rows), end))]
    return [value for value in values if value is not None]


def _macd_line_hook_from_sweep(rows: list[dict], sweep_index: int, index: int) -> bool:
    sweep_macd = rows[sweep_index].get("macd_12_26")
    current_macd = rows[index].get("macd_12_26")
    current_signal = rows[index].get("macd_signal_9")
    previous_macd = rows[index - 1].get("macd_12_26") if index > 0 else None
    previous_signal = rows[index - 1].get("macd_signal_9") if index > 0 else None
    if None in (sweep_macd, current_macd, current_signal, previous_macd):
        return False
    if not (sweep_macd < 0 and current_macd < 0 and current_signal < 0):
        return False

    line_improved_from_sweep = current_macd > sweep_macd
    line_rising_now = current_macd > previous_macd
    current_gap = current_macd - current_signal
    previous_gap = current_gap if previous_macd is None or previous_signal is None else previous_macd - previous_signal
    gap_improving = current_gap >= previous_gap
    return line_improved_from_sweep and (line_rising_now or gap_improving)


def _macd_line_divergence(rows: list[dict], sweep_index: int, prior_start: int, prior_end: int) -> bool:
    sweep_macd = rows[sweep_index].get("macd_12_26")
    prior = [rows[i].get("macd_12_26") for i in range(max(0, prior_start), min(len(rows), prior_end))]
    prior = [value for value in prior if value is not None]
    if sweep_macd is None or not prior:
        return False
    prior_low = min(prior)
    if prior_low >= 0:
        return sweep_macd >= prior_low
    return sweep_macd > prior_low and sweep_macd >= prior_low * 0.85


def _recent_lower_band_sweep(rows: list[dict], index: int, lookback: int = 3) -> int | None:
    for sweep_index in range(index, max(0, index - lookback) - 1, -1):
        row = rows[sweep_index]
        lower = row.get("bb_lower20")
        if lower and (row["low"] <= lower * 0.997 or row["close"] <= lower * 1.002):
            return sweep_index
    return None


def _recent_lower_band_flush(rows: list[dict], index: int, lookback: int = 4) -> int | None:
    for sweep_index in range(index, max(0, index - lookback) - 1, -1):
        row = rows[sweep_index]
        lower = row.get("bb_lower20")
        bb_position = row.get("bb_position_0_1")
        if lower and (row["low"] <= lower * 1.01 or (bb_position is not None and bb_position <= 0.16)):
            return sweep_index
    return None


def _recent_prior_low_sweep(rows: list[dict], index: int, lookback: int = 4, base_lookback: int = 14) -> tuple[int, float] | None:
    for sweep_index in range(index, max(0, index - lookback) - 1, -1):
        base_start = max(0, sweep_index - base_lookback)
        prior = rows[base_start:sweep_index]
        if len(prior) < 5:
            continue
        prior_low = min(item["low"] for item in prior)
        if rows[sweep_index]["low"] <= prior_low * 0.997:
            return sweep_index, prior_low
    return None


def _post_flush_not_chasing(rows: list[dict], index: int, sweep_index: int) -> bool:
    row = rows[index]
    bb_position = row.get("bb_position_0_1")
    if bb_position is not None and bb_position > 0.85:
        return False
    if engine.ema9_extension_fraction(row) > 0.045:
        return False
    sweep_low = rows[sweep_index]["low"]
    if sweep_low > 0 and (row["close"] - sweep_low) / sweep_low > 0.11:
        return False
    return True


def _chart_entry_ok(rows: list[dict], index: int, strategy: str) -> bool:
    return (
        engine.common_entry_ok(rows, index, strategy)
        and not engine.spread_widening(rows, index)
        and engine.failed_follow_through_ok(rows, index)
    )


def _chart_liquidity_should_exit(rows: list[dict], index: int, position: object) -> tuple[bool, str]:
    strategy = getattr(position, "strategy", "")
    if not strategy.startswith("Chart Liquidity"):
        return ORIGINAL_SHOULD_EXIT(rows, index, position)

    row = rows[index]
    close = row["close"]
    entry_price = position.entry_price
    profit_pct = (close - entry_price) / entry_price if entry_price > 0 else 0.0
    bars_held = index - position.entry_index
    bb_mid = row.get("bb_mid20")
    macd = row.get("macd_12_26")
    signal = row.get("macd_signal_9")
    previous_macd = rows[index - 1].get("macd_12_26") if index > 0 else None
    lower = row.get("bb_lower20")

    if bb_mid is not None and close >= bb_mid * 0.995 and profit_pct >= 0:
        return True, "bb_mid_reversion_target"
    if profit_pct >= 0.002 and None not in (macd, signal, previous_macd) and macd < signal and macd < previous_macd:
        return True, "macd_line_hook_faded"
    if bars_held >= 1 and lower is not None and close < lower and None not in (macd, previous_macd) and macd < previous_macd:
        return True, "bb_lower_reclaim_failed_macd_down"
    if bars_held >= 6 and profit_pct <= 0:
        return True, "reversion_time_failed"
    return ORIGINAL_SHOULD_EXIT(rows, index, position)


engine.should_exit = _chart_liquidity_should_exit


def _is_chart_strategy(strategy: str) -> bool:
    return strategy.startswith("Chart Liquidity")


def _chart_mid_target(row: dict, position: object) -> float | None:
    macd = row.get("macd_12_26")
    signal = row.get("macd_signal_9")
    if macd is not None and signal is not None and macd < 0 and signal < 0:
        return None
    bb_mid = row.get("bb_mid20")
    if bb_mid is None or bb_mid <= position.entry_price * 1.002:
        return None
    if row["high"] >= bb_mid:
        return bb_mid
    return None


def replay_chart(rows: list[dict], *, entry_start_time: str | None = None, entry_end_time: str | None = None) -> dict[str, object]:
    portfolios = {name: engine.Portfolio(strategy=name) for name in engine.STRATEGIES}
    for index, row in enumerate(rows):
        for portfolio in portfolios.values():
            if portfolio.pending_exit and portfolio.position:
                engine.close_position(portfolio, rows, index, portfolio.pending_exit)
                portfolio.pending_exit = None
            if portfolio.pending_entry and portfolio.position is None:
                engine.open_position(portfolio, rows, index, portfolio.pending_entry)
                portfolio.pending_entry = None

        for portfolio in portfolios.values():
            if portfolio.position and row["low"] <= portfolio.position.stop_price:
                engine.close_position(portfolio, rows, index, "structure_or_final_stop", stop_fill=True)
                portfolio.pending_exit = None
            if not portfolio.position:
                continue

            position = portfolio.position
            if _is_chart_strategy(position.strategy):
                target = _chart_mid_target(row, position)
                if target is not None:
                    engine.close_position(
                        portfolio,
                        rows,
                        index,
                        "intrabar_bb_mid_target_trailing",
                        stop_fill=True,
                        stop_price_override=target,
                    )
                    portfolio.pending_exit = None
                if not portfolio.position:
                    continue

            profit_high_pct = (row["high"] - position.entry_price) / position.entry_price if position.entry_price > 0 else 0.0
            if profit_high_pct >= engine.TRAILING_ACTIVATION_PCT:
                position.trailing_active = True
                position.high_watermark = max(position.high_watermark, row["high"])
                runner_mode = engine.is_runner_strategy(position.strategy) and profit_high_pct >= engine.RUNNER_CANDIDATE_PROFIT_PCT
                trailing_pct = engine.TRAILING_WIDE_PCT if runner_mode else engine.TRAILING_NORMAL_PCT
                trailing_stop = position.high_watermark * (1 - trailing_pct)
                position.trailing_stop_price = trailing_stop
                if row["low"] <= trailing_stop:
                    engine.close_position(
                        portfolio,
                        rows,
                        index,
                        "intrabar_trailing_stop_after_profit",
                        stop_fill=True,
                        stop_price_override=trailing_stop,
                    )
                    portfolio.pending_exit = None

        if index >= len(rows) - 1:
            continue
        allow_new_entry = engine._can_signal_entry(row, rows[index + 1], entry_start_time, entry_end_time)

        for name, detector in engine.STRATEGIES.items():
            portfolio = portfolios[name]
            if portfolio.position:
                should, reason = engine.should_exit(rows, index, portfolio.position)
                if should:
                    portfolio.pending_exit = reason
            elif (
                allow_new_entry
                and not portfolio.pending_entry
                and engine.strategy_reentry_allowed(portfolio, index, name)
                and engine.symbol_reentry_allowed(portfolios, index)
            ):
                ok, reason = detector(rows, index)
                if ok:
                    portfolio.pending_entry = {
                        "reason": reason,
                        "strategy": name,
                        "signal_close": row.get("close"),
                        "reference_high": engine.recent_high(rows, index, lookback=18, include_current=False),
                        "indicators": engine.indicator_snapshot(rows, index, name),
                    }

    last_index = len(rows) - 1
    for portfolio in portfolios.values():
        if portfolio.position:
            engine.close_position(portfolio, rows, last_index, "end_of_replay_flatten")
    return portfolios


def signal_bb_lower_sweep_macd_line_hook(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 30:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    lower = row.get("bb_lower20")
    if not lower:
        return False, ""
    sweep_index = _recent_lower_band_sweep(rows, index, lookback=3)
    if sweep_index is None:
        return False, ""
    reclaimed_band = row["close"] >= lower * 1.002 and (row.get("bb_position_0_1") is None or row["bb_position_0_1"] >= 0.04)
    wick_or_strong_close = engine.lower_wick_support(rows[sweep_index]) or _close_location(row) >= 0.62
    bb_position = row.get("bb_position_0_1")
    ema9 = row.get("ema9")
    recent_change = engine.recent_10bar_change_fraction(rows, index) or 0.0
    cost = engine.estimated_roundtrip_cost_fraction(row)
    not_midline_chase = bb_position is None or bb_position <= 0.58
    ema9_almost_reclaimed = ema9 is None or row["close"] >= ema9 * 0.995
    not_falling_knife = recent_change >= -0.06
    cost_ok = cost <= 0.010
    if (
        _chart_entry_ok(rows, index, "Chart Liquidity BB Lower Sweep MACD Line Hook")
        and reclaimed_band
        and _macd_line_hook_from_sweep(rows, sweep_index, index)
        and _green_reclaim(row, previous)
        and wick_or_strong_close
        and _volume_ratio(row) >= 0.85
        and not_midline_chase
        and ema9_almost_reclaimed
        and not_falling_knife
        and cost_ok
        and _post_flush_not_chasing(rows, index, sweep_index)
    ):
        sweep_macd = rows[sweep_index].get("macd_12_26") or 0.0
        current_macd = row.get("macd_12_26") or 0.0
        return True, f"bb_lower_sweep_macd_line_hook_{sweep_macd:.4f}_to_{current_macd:.4f}"
    return False, ""


def signal_bb_lower_soft_macd_line_hook(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 30:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    lower = row.get("bb_lower20")
    if not lower:
        return False, ""
    sweep_index = _recent_lower_band_flush(rows, index, lookback=4)
    if sweep_index is None:
        return False, ""
    bb_position = row.get("bb_position_0_1")
    ema9 = row.get("ema9")
    recent_change = engine.recent_10bar_change_fraction(rows, index) or 0.0
    cost = engine.estimated_roundtrip_cost_fraction(row)
    reclaimed_band = row["close"] >= lower * 1.006 and (bb_position is None or bb_position >= 0.08)
    not_midline_chase = bb_position is None or bb_position <= 0.66
    ema9_almost_reclaimed = ema9 is None or row["close"] >= ema9 * 0.992
    if (
        _chart_entry_ok(rows, index, "Chart Liquidity BB Lower Soft MACD Line Hook")
        and reclaimed_band
        and _macd_line_hook_from_sweep(rows, sweep_index, index)
        and _green_reclaim(row, previous)
        and (_close_location(row) >= 0.55 or engine.lower_wick_support(row))
        and _volume_ratio(row) >= 0.75
        and not_midline_chase
        and ema9_almost_reclaimed
        and recent_change >= -0.075
        and cost <= 0.012
        and _post_flush_not_chasing(rows, index, sweep_index)
    ):
        return True, "bb_lower_soft_flush_macd_line_hook"
    return False, ""


def signal_prior_low_sweep_macd_line_divergence(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 35:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    sweep = _recent_prior_low_sweep(rows, index, lookback=4, base_lookback=16)
    if sweep is None:
        return False, ""
    sweep_index, prior_low = sweep
    reclaimed_prior_low = row["close"] >= prior_low * 1.003
    reclaim_quality = _green_reclaim(row, previous) and (_close_location(row) >= 0.58 or engine.lower_wick_support(row))
    if (
        _chart_entry_ok(rows, index, "Chart Liquidity Prior Low Sweep MACD Line Divergence")
        and reclaimed_prior_low
        and _macd_line_divergence(rows, sweep_index, max(0, sweep_index - 16), sweep_index)
        and _macd_line_hook_from_sweep(rows, sweep_index, index)
        and reclaim_quality
        and _volume_ratio(row) >= 0.9
        and _post_flush_not_chasing(rows, index, sweep_index)
    ):
        return True, f"prior_low_sweep_reclaim_{(row['close'] - prior_low) / prior_low:.1%}_macd_line_divergence"
    return False, ""


CHART_LIQUIDITY_STRATEGIES = {
    "Chart Liquidity BB Lower Sweep MACD Line Hook": signal_bb_lower_sweep_macd_line_hook,
    "Chart Liquidity BB Lower Soft MACD Line Hook": signal_bb_lower_soft_macd_line_hook,
    "Chart Liquidity Prior Low Sweep MACD Line Divergence": signal_prior_low_sweep_macd_line_divergence,
}

CHART_LIQUIDITY_ALIASES = {
    "bb": "Chart Liquidity BB Lower Sweep MACD Line Hook",
    "soft": "Chart Liquidity BB Lower Soft MACD Line Hook",
    "prior": "Chart Liquidity Prior Low Sweep MACD Line Divergence",
}


def parse_window_key(path_file: Path) -> tuple[str, str, str] | None:
    match = FILENAME_RE.match(path_file.name)
    if not match:
        return None
    return (match.group("symbol").upper(), match.group("date"), match.group("timerange"))


def dedup_windows(paths: list[Path]) -> dict[tuple[str, str, str], Path]:
    best: dict[tuple[str, str, str], Path] = {}
    for path_file in paths:
        key = parse_window_key(path_file)
        if key is None:
            continue
        current = best.get(key)
        if current is None or path_file.stat().st_mtime > current.stat().st_mtime:
            best[key] = path_file
    return best


def aggregate(summaries: list[dict]) -> dict:
    trades = sum(item["trades"] for item in summaries)
    wins = sum(item["wins"] for item in summaries)
    losses = sum(item["losses"] for item in summaries)
    net = round(sum(item["net_pnl_usd"] for item in summaries), 4)
    return {
        "trades": trades,
        "wins": wins,
        "losses": losses,
        "net_pnl": net,
        "return_pct": round(net / 2000.0 * 100, 4),
        "win_rate_pct": round(wins / trades * 100, 2) if trades else 0.0,
    }


def replay_window(path_file: Path) -> tuple[list[dict], list[dict]]:
    rows = engine.load_rows(path_file)
    portfolios = replay_chart(rows)
    summaries = [engine.summary_row(portfolio) for portfolio in portfolios.values()]
    trades = [
        {"source_file": path_file.name, **trade}
        for portfolio in portfolios.values()
        for trade in portfolio.trades
    ]
    return summaries, trades


def build_report(windows: dict[tuple[str, str, str], Path]) -> tuple[dict, list[dict]]:
    window_reports: list[dict] = []
    all_trades: list[dict] = []
    total_summaries: list[dict] = []
    by_strategy_summaries: dict[str, list[dict]] = defaultdict(list)
    by_symbol_summaries: dict[str, list[dict]] = defaultdict(list)

    for key in sorted(windows):
        symbol, date, timerange = key
        path_file = windows[key]
        summaries, trades = replay_window(path_file)
        all_trades.extend(trades)
        total_summaries.extend(summaries)
        for summary in summaries:
            by_strategy_summaries[summary["strategy"]].append(summary)
            by_symbol_summaries[symbol].append(summary)
        total = aggregate(summaries)
        window_reports.append(
            {
                "key": [symbol, date, timerange],
                "file": path_file.name,
                **total,
                "by_strategy": {item["strategy"]: item for item in summaries},
            }
        )

    by_strategy = {}
    for name, items in by_strategy_summaries.items():
        stat = aggregate(items)
        stat.pop("return_pct", None)
        by_strategy[name] = stat

    report = {
        "engine": str(ENGINE_PATH.relative_to(PROJECT_ROOT)),
        "strategy_names_active": list(engine.STRATEGIES.keys()),
        "dedup_windows": len(windows),
        "total": aggregate(total_summaries),
        "by_strategy": by_strategy,
        "by_symbol": {
            symbol: {
                "windows": sum(1 for item in window_reports if item["key"][0] == symbol),
                **aggregate(items),
            }
            for symbol, items in sorted(by_symbol_summaries.items())
        },
        "windows": window_reports,
    }
    return report, all_trades


def write_outputs(report: dict, trades: list[dict], output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / "chart_liquidity_strategies_replay_summary.json"
    trades_path = output_dir / "chart_liquidity_strategies_replay_trades.csv"
    summary_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if trades:
        fields = list(trades[0].keys())
        with trades_path.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader()
            writer.writerows(trades)
    return summary_path, trades_path


def print_console(report: dict) -> None:
    total = report["total"]
    print("=" * 92)
    print(f"Chart-liquidity experiment strategies: {', '.join(report['strategy_names_active'])}")
    print(f"Windows replayed                    : {report['dedup_windows']}")
    print(
        f"TOTAL                               : {total['trades']} trades | win {total['win_rate_pct']}% | "
        f"net ${total['net_pnl']} | return {total['return_pct']}% (on $2000/strategy)"
    )
    print("-" * 92)
    print(f"{'BY STRATEGY':<52}{'trades':>7}{'win%':>8}{'net$':>12}")
    for name, stat in sorted(report["by_strategy"].items(), key=lambda item: item[1]["net_pnl"], reverse=True):
        print(f"{name:<52}{stat['trades']:>7}{stat['win_rate_pct']:>8}{stat['net_pnl']:>12}")
    print("-" * 92)
    print(f"{'TOP SYMBOLS':<10}{'win':>5}{'trades':>8}{'win%':>8}{'net$':>12}{'ret%':>9}")
    for symbol, stat in sorted(report["by_symbol"].items(), key=lambda item: item[1]["net_pnl"], reverse=True)[:12]:
        print(f"{symbol:<10}{stat['windows']:>5}{stat['trades']:>8}{stat['win_rate_pct']:>8}{stat['net_pnl']:>12}{stat['return_pct']:>9}")
    print("=" * 92)


def main() -> None:
    parser = argparse.ArgumentParser(description="Replay experimental chart-liquidity strategies over enriched replay windows.")
    parser.add_argument(
        "--dir",
        action="append",
        required=True,
        help="Folder containing *_enriched.csv windows. Pass multiple times to combine sessions.",
    )
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument(
        "--only",
        action="append",
        choices=sorted(CHART_LIQUIDITY_STRATEGIES.keys()),
        help="Run only the named chart-liquidity strategy. Can be passed multiple times.",
    )
    parser.add_argument(
        "--only-key",
        action="append",
        choices=sorted(CHART_LIQUIDITY_ALIASES.keys()),
        help="Run only a strategy alias: bb, prior, or mid. Can be passed multiple times.",
    )
    args = parser.parse_args()

    selected = CHART_LIQUIDITY_STRATEGIES
    selected_names: list[str] = []
    if args.only:
        selected_names.extend(args.only)
    if args.only_key:
        selected_names.extend(CHART_LIQUIDITY_ALIASES[key] for key in args.only_key)
    if selected_names:
        selected = {name: CHART_LIQUIDITY_STRATEGIES[name] for name in dict.fromkeys(selected_names)}
    engine.STRATEGIES = selected
    paths: list[Path] = []
    for raw_dir in args.dir:
        paths.extend(sorted(Path(raw_dir).resolve().glob("*_enriched.csv")))
    windows = dedup_windows(paths)
    report, trades = build_report(windows)
    summary_path, trades_path = write_outputs(report, trades, Path(args.output_dir).resolve())
    print_console(report)
    print(f"raw files: {len(paths)}  ->  dedup windows: {len(windows)}")
    print(f"summary : {summary_path.relative_to(PROJECT_ROOT)}")
    print(f"trades  : {trades_path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
