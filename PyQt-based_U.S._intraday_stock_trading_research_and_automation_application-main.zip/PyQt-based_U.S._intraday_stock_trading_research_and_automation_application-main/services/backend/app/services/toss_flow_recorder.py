"""Per-symbol, per-minute recorder of Toss order-flow.

Why this exists
---------------
The replay/backtest enriched CSVs carry per-bar flow computed from Alpaca's full
consolidated trade feed, but the live runtime acts on Toss flow polled over REST. The two
scales differ substantially (measured Alpaca trade_strength 80-88 vs Toss 35-50 on the same
premarket names), so flow thresholds tuned on Alpaca (e.g. Micro ts>=80) rarely trigger on
Toss. To re-tune thresholds to the Toss scale we first need a dataset of Toss's own flow --
which Toss cannot supply historically -- so we record it live here.

What it records
---------------
One row per symbol per completed ET minute, using the LAST flow seen during that minute
(~= the candle close), matching how the Alpaca enriched CSVs carry per-bar close flow. The
minute is labelled close-time (floor + 1 min) to match the candle_builder convention. Rows
where Toss saw no trades at all (trade_strength is None) are dropped to keep the file
signal-dense. Appended to exports/toss_flow/toss_flow_<ET-date>.csv.

Safety
------
Every public entry point is wrapped so a recorder failure can never break the realtime
worker loop it is called from.
"""

from __future__ import annotations

import csv
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock
from zoneinfo import ZoneInfo

_ET = ZoneInfo("America/New_York")
_EXPORT_DIR = Path(__file__).resolve().parents[4] / "exports" / "toss_flow"

# Order matters: this is the CSV header written for new files.
_FIELDS = [
    "recorded_at_et",
    "minute_close_et",
    "symbol",
    "last_price",
    "trade_strength",
    "sell_pressure",
    "bid_ask_imbalance",
    "spread_pct",
    "volume_60s",
    "aggressive_buy_volume",
    "aggressive_sell_volume",
    "unknown_trade_volume",
    "last_update_age_sec",
]


def _to_price(value: object) -> float | None:
    if isinstance(value, dict):
        for key in ("last", "price", "close", "trade_price"):
            got = value.get(key)
            if got is not None:
                value = got
                break
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None


class _TossFlowRecorder:
    def __init__(self) -> None:
        self._lock = Lock()
        # symbol -> (minute_floor_dt, row dict of the last flow seen that minute)
        self._pending: dict[str, tuple[datetime, dict]] = {}

    def record(self, flow_snapshot: dict, latest_prices: dict | None = None) -> None:
        try:
            self._record(flow_snapshot, latest_prices)
        except Exception:
            # Never propagate into the realtime worker tick.
            pass

    def _record(self, flow_snapshot: dict, latest_prices: dict | None) -> None:
        if not isinstance(flow_snapshot, dict) or not flow_snapshot:
            return
        now_et = datetime.now(_ET)
        minute_floor = now_et.replace(second=0, microsecond=0)
        prices = latest_prices if isinstance(latest_prices, dict) else {}
        recorded_at = now_et.strftime("%Y-%m-%d %H:%M:%S")
        close_label = (minute_floor + timedelta(minutes=1)).strftime("%Y-%m-%d %H:%M:%S")

        to_flush: list[dict] = []
        with self._lock:
            for symbol, flow in flow_snapshot.items():
                if not isinstance(flow, dict):
                    continue
                prev = self._pending.get(symbol)
                # Minute rolled over for this symbol -> finalize the prior minute's last row.
                if prev is not None and prev[0] != minute_floor:
                    to_flush.append(prev[1])
                    prev = None
                row = {
                    "recorded_at_et": recorded_at,
                    "minute_close_et": close_label,
                    "symbol": symbol,
                    "last_price": _to_price(prices.get(symbol)),
                    "trade_strength": flow.get("trade_strength"),
                    "sell_pressure": flow.get("sell_pressure"),
                    "bid_ask_imbalance": flow.get("bid_ask_imbalance"),
                    "spread_pct": flow.get("spread_pct"),
                    "volume_60s": flow.get("volume_60s"),
                    "aggressive_buy_volume": flow.get("aggressive_buy_volume"),
                    "aggressive_sell_volume": flow.get("aggressive_sell_volume"),
                    "unknown_trade_volume": flow.get("unknown_trade_volume"),
                    "last_update_age_sec": flow.get("last_update_age_sec"),
                }
                # Last write within the minute wins -> approximates the minute close.
                self._pending[symbol] = (minute_floor, row)

        for row in to_flush:
            self._write(row)

    def _write(self, row: dict) -> None:
        # Drop minutes where Toss saw no trades at all -- no measurement to tune against.
        if row.get("trade_strength") is None:
            return
        date_key = str(row.get("minute_close_et") or "")[:10] or datetime.now(_ET).strftime("%Y-%m-%d")
        path = _EXPORT_DIR / f"toss_flow_{date_key}.csv"
        try:
            _EXPORT_DIR.mkdir(parents=True, exist_ok=True)
            is_new = not path.exists()
            with path.open("a", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=_FIELDS)
                if is_new:
                    writer.writeheader()
                writer.writerow({key: row.get(key) for key in _FIELDS})
        except Exception:
            pass


_recorder = _TossFlowRecorder()


def record_flow(flow_snapshot: dict, latest_prices: dict | None = None) -> None:
    """Record one per-symbol row for any minute that just completed. Safe to call every tick."""
    _recorder.record(flow_snapshot, latest_prices)
