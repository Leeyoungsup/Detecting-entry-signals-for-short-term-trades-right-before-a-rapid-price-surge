from app.services import realtime_state


def test_desired_subscriptions_are_normalized(monkeypatch) -> None:
    stored = {}

    def fake_set_json(key, value, *, ex=None):
        stored[key] = {"value": value, "ex": ex}
        return True

    monkeypatch.setattr(realtime_state.shared_state, "set_json", fake_set_json)

    payload = realtime_state.publish_desired_subscriptions(
        ["nvda", "NVDA", " aapl "],
        exchange="NAS",
        key_mode="regular",
        reason="test",
    )

    assert payload["symbols"] == ["NVDA", "AAPL"]
    assert stored[realtime_state.DESIRED_SUBSCRIPTIONS_KEY]["value"]["symbols"] == ["NVDA", "AAPL"]
    assert stored[realtime_state.DESIRED_SUBSCRIPTIONS_KEY]["ex"] == realtime_state.DESIRED_SUBSCRIPTIONS_TTL_SEC


def test_subscribed_symbols_uses_subscription_age_keys() -> None:
    status = {"subscription_age_sec": {"nvda": 1.0, "AAPL": 2.0}}

    assert realtime_state.subscribed_symbols(status) == {"NVDA", "AAPL"}
