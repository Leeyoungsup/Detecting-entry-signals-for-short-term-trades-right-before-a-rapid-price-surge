"use client";

import {
  AlertTriangle,
  Bell,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleDot,
  Filter,
  RadioTower,
  Search,
  Settings2,
  Wifi,
  WifiOff,
  XCircle,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { API_BASE_URL } from "@/lib/api";

type LogRow = {
  id?: string;
  level?: string;
  event_type?: string;
  message?: string;
  severity?: string;
  correlation_id?: string | null;
  mode?: string;
  symbol?: string | null;
  order_id?: string | null;
  occurred_at?: string;
  payload?: Record<string, unknown>;
};

type RealtimeEnvelope = {
  event_id: string;
  event_type: string;
  occurred_at: string;
  status_level: string;
  symbol: string | null;
  payload: Record<string, unknown>;
};

const noisyEvents = new Set([
  "strategy.waiting_for_candles",
  "scanner.session_paused",
  "runtime.supervisor_started",
  "runtime.supervisor_stopped",
  "scanner.snapshot",
]);

function realtimeUrl() {
  const base = API_BASE_URL.replace(/^http/, "ws").replace(/\/$/, "");
  return `${base}/api/realtime/ws`;
}

function envelopeToLog(event: RealtimeEnvelope): LogRow {
  const payload = event.payload ?? {};
  return {
    id: event.event_id,
    occurred_at: event.occurred_at,
    level: String(payload.level ?? "INFO"),
    event_type: String(payload.event_type ?? event.event_type),
    severity: String(payload.severity ?? event.status_level),
    message: String(payload.message ?? event.event_type),
    symbol: (payload.symbol as string | null) ?? event.symbol ?? null,
    order_id: (payload.order_id as string | null) ?? null,
    correlation_id: (payload.correlation_id as string | null) ?? null,
    mode: String(payload.mode ?? ""),
    payload: (payload.payload as Record<string, unknown>) ?? payload,
  };
}

function isNoisy(row: LogRow) {
  return noisyEvents.has(String(row.event_type ?? ""));
}

function isImportant(row: LogRow) {
  const eventType = String(row.event_type ?? "");
  const severity = String(row.severity ?? "");
  if (["CAUTION", "BLOCKED", "EMERGENCY"].includes(severity)) return true;
  return (
    eventType.startsWith("live.") ||
    eventType.startsWith("paper.") ||
    eventType === "strategy.signal_evaluation" ||
    eventType.startsWith("scanner.realtime") ||
    eventType === "scanner.minute_seed" ||
    eventType === "platform.boot"
  );
}

export function LogsRealtimeTable({ initialLogs }: { initialLogs: LogRow[] }) {
  const [logs, setLogs] = useState<LogRow[]>(initialLogs.filter((row) => !isNoisy(row)));
  const [connected, setConnected] = useState(false);
  const [query, setQuery] = useState("");
  const [severity, setSeverity] = useState("ALL");
  const [includeNoise, setIncludeNoise] = useState(false);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [lastEventAt, setLastEventAt] = useState<Date | null>(null);
  const lastEventMsRef = useRef(0);
  const watchdogRef = useRef<number | null>(null);

  useEffect(() => {
    let closed = false;
    let socket: WebSocket | null = null;

    function connect() {
      if (closed) return;
      socket = new WebSocket(realtimeUrl());
      socket.onopen = () => {
        const now = Date.now();
        lastEventMsRef.current = now;
        setLastEventAt(new Date(now));
        setConnected(true);
      };
      socket.onclose = () => {
        setConnected(false);
        if (!closed) window.setTimeout(connect, 3000);
      };
      socket.onerror = () => setConnected(false);
      socket.onmessage = (message) => {
        try {
          const now = Date.now();
          lastEventMsRef.current = now;
          setLastEventAt(new Date(now));
          const event = JSON.parse(message.data) as RealtimeEnvelope;
          if (!event.payload) return;
          setLogs((current) => {
            const row = envelopeToLog(event);
            if (isNoisy(row) && !includeNoise) return current;
            if (!isImportant(row) && !includeNoise) return current;
            const rowId = String(row.id ?? "");
            if (rowId && current.some((item) => item.id === rowId)) return current;
            return [row, ...current].slice(0, 200);
          });
        } catch {
          setConnected(false);
        }
      };
    }

    function watchdog() {
      if (closed) return;
      const idleMs = Date.now() - lastEventMsRef.current;
      if (lastEventMsRef.current > 0 && idleMs > 15000) {
        setConnected(false);
        socket?.close();
      }
      watchdogRef.current = window.setTimeout(watchdog, 5000);
    }

    connect();
    watchdog();
    return () => {
      closed = true;
      socket?.close();
      if (watchdogRef.current !== null) {
        window.clearTimeout(watchdogRef.current);
      }
    };
  }, [includeNoise]);

  const filtered = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return logs.filter((row) => {
      if (!includeNoise && isNoisy(row)) return false;
      if (severity !== "ALL" && row.severity !== severity) return false;
      if (!normalizedQuery) return true;
      return [
        row.event_type,
        row.message,
        row.symbol,
        row.order_id,
        row.correlation_id,
        JSON.stringify(row.payload ?? {}),
      ]
        .join(" ")
        .toLowerCase()
        .includes(normalizedQuery);
    });
  }, [includeNoise, logs, query, severity]);

  const counts = useMemo(() => {
    return logs.reduce(
      (acc, row) => {
        const key = String(row.severity ?? "NORMAL");
        acc[key] = (acc[key] ?? 0) + 1;
        return acc;
      },
      {} as Record<string, number>,
    );
  }, [logs]);

  return (
    <section className="space-y-4">
      <div className="grid gap-3 md:grid-cols-4">
        <LogMetric label="중요 이벤트" value={logs.filter((row) => isImportant(row)).length} />
        <LogMetric label="주의" value={counts.CAUTION ?? 0} tone="warn" />
        <LogMetric label="차단/긴급" value={(counts.BLOCKED ?? 0) + (counts.EMERGENCY ?? 0)} tone="block" />
        <LogMetric label="실시간 연결" value={connected ? `연결됨 ${formatTime(lastEventAt)}` : "대기"} tone={connected ? "ok" : "warn"} />
      </div>

      <div className="rounded border border-line bg-white">
        <div className="flex flex-col gap-3 border-b border-line p-4 xl:flex-row xl:items-center xl:justify-between">
          <div className="inline-flex items-center gap-2 text-sm font-semibold text-ink">
            <RadioTower className="h-4 w-4 text-info" aria-hidden />
            이벤트 스트림
            <span className="rounded bg-zinc-100 px-2 py-1 text-xs font-medium text-zinc-500">{filtered.length}개 표시</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                className="h-9 w-72 rounded border border-line pl-9 pr-3 text-sm outline-none focus:border-ink"
                placeholder="종목, 주문ID, 메시지 검색"
              />
            </div>
            <select
              value={severity}
              onChange={(event) => setSeverity(event.target.value)}
              className="h-9 rounded border border-line px-3 text-sm outline-none focus:border-ink"
            >
              <option value="ALL">전체 심각도</option>
              <option value="NORMAL">정상</option>
              <option value="CAUTION">주의</option>
              <option value="BLOCKED">차단</option>
              <option value="EMERGENCY">긴급</option>
            </select>
            <label className="inline-flex h-9 items-center gap-2 rounded border border-line px-3 text-sm text-zinc-600">
              <input type="checkbox" checked={includeNoise} onChange={(event) => setIncludeNoise(event.target.checked)} className="accent-zinc-900" />
              반복 로그 포함
            </label>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-zinc-500">
              {connected ? <Wifi className="h-4 w-4 text-ok" aria-hidden /> : <WifiOff className="h-4 w-4 text-block" aria-hidden />}
              {connected ? "실시간 연결됨" : "실시간 대기"}
            </div>
          </div>
        </div>

        <div className="divide-y divide-line">
          {filtered.map((log, index) => {
            const id = String(log.id ?? `${log.event_type}-${index}`);
            const isOpen = Boolean(expanded[id]);
            return (
              <article key={id} className="px-5 py-4">
                <button
                  type="button"
                  onClick={() => setExpanded((current) => ({ ...current, [id]: !current[id] }))}
                  className="flex w-full items-start gap-3 text-left"
                >
                  <span className={`mt-1 grid h-8 w-8 shrink-0 place-items-center rounded ${severityBg(log.severity)}`}>
                    {eventIcon(log)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-2">
                      <SeverityPill severity={String(log.severity ?? "NORMAL")} />
                      <span className="font-semibold text-ink">{eventLabel(String(log.event_type ?? "-"))}</span>
                      {log.symbol ? <span className="rounded bg-blue-50 px-2 py-1 text-xs font-bold text-info">{log.symbol}</span> : null}
                      {log.order_id ? <span className="font-mono text-xs text-zinc-500">{shortId(String(log.order_id))}</span> : null}
                    </span>
                    <span className="mt-1 block text-sm leading-6 text-zinc-700">{String(log.message ?? "-")}</span>
                    <span className="mt-2 flex flex-wrap gap-2 text-xs text-zinc-500">
                      <span>{formatDateTimeKst(log.occurred_at)}</span>
                      <span>{String(log.level ?? "INFO")}</span>
                      <span>{String(log.mode || "-")}</span>
                    </span>
                  </span>
                  <span className="mt-1 text-zinc-400">{isOpen ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}</span>
                </button>
                {isOpen ? (
                  <div className="mt-4 grid gap-3 pl-11 xl:grid-cols-[360px_1fr]">
                    <PayloadSummary payload={log.payload ?? {}} />
                    <pre className="max-h-96 overflow-auto rounded bg-zinc-950 p-4 text-xs leading-5 text-zinc-100">
                      {JSON.stringify(log.payload ?? {}, null, 2)}
                    </pre>
                  </div>
                ) : null}
              </article>
            );
          })}
          {filtered.length === 0 ? (
            <div className="flex min-h-64 flex-col items-center justify-center px-6 py-10 text-center">
              <Filter className="h-8 w-8 text-zinc-400" aria-hidden />
              <div className="mt-3 text-base font-semibold text-ink">표시할 로그가 없습니다</div>
              <div className="mt-2 text-sm text-zinc-500">반복 로그 포함을 켜거나 검색 조건을 줄여보세요.</div>
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
}

function formatTime(value?: Date | null) {
  return value ? value.toLocaleTimeString("ko-KR", { hour12: false }) : "-";
}

function LogMetric({ label, value, tone = "info" }: { label: string; value: string | number; tone?: "ok" | "warn" | "block" | "info" }) {
  return (
    <div className="rounded border border-line bg-white p-4">
      <div className="text-xs font-medium text-zinc-500">{label}</div>
      <div className={`mt-2 text-2xl font-bold ${toneText(tone)}`}>{value}</div>
    </div>
  );
}

function PayloadSummary({ payload }: { payload: Record<string, unknown> }) {
  const rows = summarizePayload(payload);
  return (
    <div className="rounded border border-line bg-zinc-50 p-4">
      <div className="mb-3 text-xs font-semibold text-zinc-500">요약</div>
      <div className="space-y-2">
        {rows.length ? rows.map(([label, value]) => (
          <div key={label} className="flex justify-between gap-3 text-sm">
            <span className="text-zinc-500">{label}</span>
            <span className="max-w-[210px] truncate text-right font-semibold text-ink">{value}</span>
          </div>
        )) : <div className="text-sm text-zinc-500">요약 가능한 payload가 없습니다.</div>}
      </div>
    </div>
  );
}

function summarizePayload(payload: Record<string, unknown>): [string, string][] {
  const rows: [string, string][] = [];
  for (const key of ["symbol", "reason", "reject_reason", "current_price", "quantity", "order_id", "candle_mode", "candle_count", "required"]) {
    const value = payload[key];
    if (value != null) rows.push([summaryLabel(key), String(value)]);
  }
  const changed = payload.changed;
  if (changed && typeof changed === "object") rows.push(["변경 설정", Object.keys(changed as Record<string, unknown>).join(", ")]);
  return rows.slice(0, 8);
}

function summaryLabel(key: string) {
  const labels: Record<string, string> = {
    symbol: "종목",
    reason: "사유",
    reject_reason: "거절 사유",
    current_price: "현재가",
    quantity: "수량",
    order_id: "주문 ID",
    candle_mode: "캔들 기준",
    candle_count: "캔들 수",
    required: "필요 수",
  };
  return labels[key] ?? key;
}

function SeverityPill({ severity }: { severity: string }) {
  return <span className={`rounded px-2 py-1 text-xs font-bold ring-1 ${pillClass(severity)}`}>{severityLabel(severity)}</span>;
}

function eventIcon(log: LogRow) {
  const eventType = String(log.event_type ?? "");
  const severity = String(log.severity ?? "");
  if (["BLOCKED", "EMERGENCY"].includes(severity)) return <XCircle className="h-4 w-4 text-block" />;
  if (severity === "CAUTION") return <AlertTriangle className="h-4 w-4 text-warn" />;
  if (eventType.startsWith("live.") || eventType.startsWith("paper.")) return <Bell className="h-4 w-4 text-info" />;
  if (eventType.startsWith("strategy.")) return <Settings2 className="h-4 w-4 text-info" />;
  if (eventType.startsWith("scanner.")) return <RadioTower className="h-4 w-4 text-info" />;
  if (severity === "NORMAL") return <CheckCircle2 className="h-4 w-4 text-ok" />;
  return <CircleDot className="h-4 w-4 text-info" />;
}

function eventLabel(value: string) {
  const labels: Record<string, string> = {
    "platform.boot": "로그 저장소 초기화",
    "runtime.supervisor_started": "감시 루프 시작",
    "runtime.supervisor_stopped": "감시 루프 중지",
    "runtime.supervisor_tick_failed": "감시 루프 실패",
    "scanner.session_paused": "세션 일시중지",
    "scanner.minute_seed": "공식 1분봉 갱신",
    "scanner.realtime_start": "실시간 구독 시작",
    "scanner.realtime_paused": "실시간 구독 보류",
    "strategy.signal_evaluation": "전략 평가",
    "paper.order_event": "시뮬레이션 주문 이벤트",
    "paper.exit_signal": "시뮬레이션 청산 신호",
    "paper.order_blocked": "시뮬레이션 주문 차단",
  };
  return labels[value] ?? value;
}

function severityLabel(value: string) {
  const labels: Record<string, string> = {
    NORMAL: "정상",
    CAUTION: "주의",
    BLOCKED: "차단",
    EMERGENCY: "긴급",
  };
  return labels[value] ?? value;
}

function pillClass(severity: string) {
  if (severity === "NORMAL") return "bg-emerald-50 text-ok ring-emerald-100";
  if (severity === "CAUTION") return "bg-amber-50 text-warn ring-amber-100";
  return "bg-red-50 text-block ring-red-100";
}

function severityBg(severity?: string) {
  if (severity === "NORMAL") return "bg-emerald-50";
  if (severity === "CAUTION") return "bg-amber-50";
  if (severity === "BLOCKED" || severity === "EMERGENCY") return "bg-red-50";
  return "bg-blue-50";
}

function toneText(tone: "ok" | "warn" | "block" | "info") {
  return {
    ok: "text-ok",
    warn: "text-warn",
    block: "text-block",
    info: "text-info",
  }[tone];
}

function formatDateTimeKst(value?: string | null) {
  if (!value) return "-";
  const date = /[zZ]$|[+-]\d{2}:?\d{2}$/.test(value) ? new Date(value) : new Date(`${value}Z`);
  return date.toLocaleString("ko-KR", {
    timeZone: "Asia/Seoul",
    year: "2-digit",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function shortId(value: string) {
  return value.length > 8 ? value.slice(0, 8) : value;
}
