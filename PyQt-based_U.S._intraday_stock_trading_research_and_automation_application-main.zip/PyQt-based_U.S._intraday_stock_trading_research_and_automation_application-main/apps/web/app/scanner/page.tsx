"use client";

import { useState, type ReactNode } from "react";
import Link from "next/link";
import {
  Activity,
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  Clock3,
  Filter,
  Pin,
  Plus,
  RadioTower,
  Search,
  Signal,
  Trash2,
} from "lucide-react";
import { LiveStatus } from "@/components/live-status";
import { PageTitle } from "@/components/page-title";
import { StatusPill } from "@/components/status-pill";
import { API_BASE_URL } from "@/lib/api";
import { useLiveResource, type RealtimeEnvelope } from "@/lib/use-live-resource";

type Stage = { name: string; passed: number; rejected: number; waiting?: number; top_reject_reasons: string[] };
type Candidate = Record<string, string | number | boolean | string[] | null | undefined>;
type ManualCandidate = { symbol: string; pinned: boolean; added_at?: string; updated_at?: string };

type ScannerData = {
  updated_at?: string;
  paused?: boolean;
  pause_reason?: string;
  session?: {
    state?: string;
    label?: string;
    now_market?: string;
    now_local?: string;
  };
  websocket?: {
    status: string;
    subscription_count: number;
    last_message_at: string | null;
    last_realtime_at: string | null;
    latest_quote_symbols?: string[];
    latest_trade_symbols?: string[];
  };
  realtime?: {
    subscribed_symbols: string[];
    symbols_with_quote: string[];
    symbols_with_trade: string[];
    last_realtime_at: string | null;
  };
  stages: Stage[];
  candidates: Candidate[];
  manual_candidates?: ManualCandidate[];
};

const fallback: ScannerData = { stages: [], candidates: [] };

const funnelOrder = [
  "Universe",
  "External market-data coarse scanner",
  "Realtime polling watchlist",
  "Order flow",
  "Strategy signal watch",
  "Strategy signal",
  "Risk check",
  "Order candidate",
];

const stageMeta: Record<string, { label: string; desc: string; icon: ReactNode }> = {
  Universe: {
    label: "전체 후보군",
    desc: "Toss 거래대금 랭킹과 OpenAPI 시세 기반 universe",
    icon: <Search className="h-4 w-4" />,
  },
  "External market-data coarse scanner": {
    label: "1차 유동성 스캐너",
    desc: "10분 거래대금과 가격충격으로 후보 추림",
    icon: <BarChart3 className="h-4 w-4" />,
  },
  "Realtime polling watchlist": {
    label: "Toss 감시",
    desc: "상위 후보 quote/trade polling",
    icon: <RadioTower className="h-4 w-4" />,
  },
  "Order flow": {
    label: "오더플로우",
    desc: "최근 tick, 거래대금, 스프레드 확인",
    icon: <Activity className="h-4 w-4" />,
  },
  "Strategy signal watch": {
    label: "전략 신호 감시",
    desc: "공식 1분봉 + 실시간 봉으로 전략 진입 조건 평가 대기",
    icon: <Filter className="h-4 w-4" />,
  },
  "Strategy signal": {
    label: "전략 신호",
    desc: "개별 전략별 진입 평가",
    icon: <Signal className="h-4 w-4" />,
  },
  "Risk check": {
    label: "리스크 체크",
    desc: "수량, 주문금액, 노출 한도 확인",
    icon: <CheckCircle2 className="h-4 w-4" />,
  },
  "Order candidate": {
    label: "주문 후보",
    desc: "live/시뮬레이션 주문 가능 후보",
    icon: <CheckCircle2 className="h-4 w-4" />,
  },
};

export default function ScannerPage() {
  const { data, connected, eventAt, updatedAt, reload } = useLiveResource<ScannerData>({
    path: "/scanner/funnel",
    fallback,
    shouldReload: scannerShouldReload,
    minIntervalMs: 2500,
  });
  const stageByName = new Map(data.stages.map((stage) => [stage.name, stage]));
  const orderedStages = funnelOrder.map((name) => stageByName.get(name)).filter(Boolean) as Stage[];
  const visibleStages = orderedStages.length ? orderedStages : data.stages;
  const subscribedSymbols = data.realtime?.subscribed_symbols ?? [];
  const quoteSymbols = data.realtime?.symbols_with_quote ?? data.websocket?.latest_quote_symbols ?? [];
  const tradeSymbols = data.realtime?.symbols_with_trade ?? data.websocket?.latest_trade_symbols ?? [];
  const readyCandidates = data.candidates.filter((candidate) => candidate.selected_for_strategy).length;

  return (
    <>
      <PageTitle
        title="스캐너 퍼널"
        description="거래량이 아니라 거래대금과 유동성, 가격충격, 스프레드를 기준으로 단타 후보를 줄여갑니다."
        icon={<Filter className="h-5 w-5" aria-hidden />}
        action={<LiveStatus connected={connected} eventAt={eventAt} updatedAt={updatedAt} />}
      />

      <section className="space-y-5 p-6">
        <div className={data.paused ? "rounded border border-amber-200 bg-amber-50 p-5" : "rounded border border-emerald-200 bg-emerald-50 p-5"}>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <StatusPill status={data.paused ? "CAUTION" : "NORMAL"} />
                <span className="text-sm font-semibold text-ink">{data.session?.label ?? "세션 확인 중"}</span>
                <span className="text-xs text-zinc-600">{data.session?.now_market ?? "-"}</span>
              </div>
              <h2 className="text-2xl font-bold text-ink">
                {data.paused ? "장마감 상태라 실시간 스캐너를 쉬게 둡니다" : "실시간 유동성 후보 감시 중"}
              </h2>
              <p className="max-w-3xl text-sm leading-6 text-zinc-700">
                {data.paused
                  ? data.pause_reason ?? "장마감에는 Toss realtime polling 감시와 scanner 갱신을 중지합니다. 프리마켓부터 자동으로 다시 시작합니다."
                  : "후보 표시는 최종 필터를 통과한 종목이고, 관찰 구독은 그보다 앞단의 coarse 랭킹 상위 종목입니다. 그래서 구독 수가 후보 수보다 클 수 있습니다."}
              </p>
            </div>
            <div className="grid gap-2 sm:grid-cols-3 lg:min-w-[520px]">
              <StatusBox label="Toss polling" value={data.websocket?.status ?? "-"} tone={data.paused ? "warn" : statusTone(data.websocket?.status)} />
              <StatusBox label="감시 종목" value={`${subscribedSymbols.length}개`} tone={subscribedSymbols.length > 0 ? "ok" : data.paused ? "warn" : "block"} />
              <StatusBox label="마지막 tick" value={formatKstDateTime(data.realtime?.last_realtime_at)} tone={data.realtime?.last_realtime_at ? "ok" : data.paused ? "warn" : "block"} />
            </div>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-4">
          <MetricPanel icon={<Filter className="h-5 w-5" />} label="후보 종목" value={data.candidates.length} detail="최종 후보 테이블 표시 수" />
          <MetricPanel icon={<Activity className="h-5 w-5" />} label="체결 tick 수신" value={tradeSymbols.length} detail={formatSymbolList(tradeSymbols)} />
          <MetricPanel icon={<Signal className="h-5 w-5" />} label="호가 quote 수신" value={quoteSymbols.length} detail={formatSymbolList(quoteSymbols)} />
          <MetricPanel icon={<CheckCircle2 className="h-5 w-5" />} label="전략 감시 후보" value={readyCandidates} detail={`${data.candidates.length}개 후보 중`} />
        </div>

        <section className="rounded border border-line bg-white">
          <div className="flex flex-col gap-2 border-b border-line px-5 py-4 md:flex-row md:items-end md:justify-between">
            <div>
              <h2 className="text-base font-semibold text-ink">후보가 줄어드는 순서</h2>
              <p className="mt-1 text-xs text-zinc-500">왼쪽에서 오른쪽으로 갈수록 실제 주문에 가까운 후보입니다.</p>
            </div>
            <div className="text-xs text-zinc-500">최근 갱신: {formatKstDateTime(data.updated_at)}</div>
          </div>
          <div className="grid gap-px bg-line md:grid-cols-2 xl:grid-cols-4">
            {visibleStages.map((stage, index) => (
              <StageCard key={`${stage.name}-${index}`} stage={stage} index={index + 1} />
            ))}
          </div>
        </section>

        {data.paused ? (
          <section className="rounded border border-line bg-white p-8 text-center">
            <Clock3 className="mx-auto h-8 w-8 text-warn" aria-hidden />
            <h2 className="mt-3 text-lg font-semibold text-ink">장마감 대기 중</h2>
            <p className="mx-auto mt-2 max-w-2xl text-sm leading-6 text-zinc-600">
              지금은 후보 테이블을 비워둡니다. 다음 프리마켓부터 Toss polling 감시, 실시간 유동성 순위, 오더플로우 평가가 자동으로 다시 시작됩니다.
            </p>
          </section>
        ) : (
          <TossCandidateTable candidates={data.candidates} />
        )}

        <ManualCandidatePanel candidates={data.manual_candidates ?? []} onChanged={reload} />
      </section>
    </>
  );
}

function ManualCandidatePanel({ candidates, onChanged }: { candidates: ManualCandidate[]; onChanged: () => Promise<void> }) {
  const [symbol, setSymbol] = useState("");
  const [pinned, setPinned] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit() {
    const normalized = symbol.trim().toUpperCase();
    if (!normalized) return;
    setBusy(true);
    setError("");
    try {
      const response = await fetch(`${API_BASE_URL}/api/scanner/manual-candidates`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol: normalized, pinned }),
        cache: "no-store",
      });
      if (!response.ok) throw new Error(await response.text());
      setSymbol("");
      await onChanged();
    } catch (exc) {
      setError(exc instanceof Error ? exc.message : "후보 추가 실패");
    } finally {
      setBusy(false);
    }
  }

  async function toggle(candidate: ManualCandidate) {
    setBusy(true);
    setError("");
    try {
      const response = await fetch(`${API_BASE_URL}/api/scanner/manual-candidates/${candidate.symbol}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pinned: !candidate.pinned }),
        cache: "no-store",
      });
      if (!response.ok) throw new Error(await response.text());
      await onChanged();
    } catch (exc) {
      setError(exc instanceof Error ? exc.message : "고정 변경 실패");
    } finally {
      setBusy(false);
    }
  }

  async function remove(candidate: ManualCandidate) {
    setBusy(true);
    setError("");
    try {
      const response = await fetch(`${API_BASE_URL}/api/scanner/manual-candidates/${candidate.symbol}`, {
        method: "DELETE",
        cache: "no-store",
      });
      if (!response.ok) throw new Error(await response.text());
      await onChanged();
    } catch (exc) {
      setError(exc instanceof Error ? exc.message : "후보 삭제 실패");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="rounded border border-line bg-white">
      <div className="flex flex-col gap-3 border-b border-line px-5 py-4 xl:flex-row xl:items-end xl:justify-between">
        <div>
          <h2 className="text-base font-semibold text-ink">수동 후보 / 고정 구독</h2>
          <p className="mt-1 text-xs text-zinc-500">Ticker를 직접 넣으면 후보 테이블과 실시간 구독 우선순위에 포함됩니다. 고정은 자동 후보 갱신 때도 앞순위로 유지됩니다.</p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <input
            value={symbol}
            onChange={(event) => setSymbol(event.target.value.toUpperCase())}
            onKeyDown={(event) => {
              if (event.key === "Enter") void submit();
            }}
            placeholder="예: TC"
            className="h-10 w-full rounded border border-line px-3 text-sm font-semibold uppercase outline-none focus:border-info sm:w-40"
          />
          <label className="flex h-10 items-center gap-2 rounded border border-line px-3 text-sm text-zinc-700">
            <input type="checkbox" checked={pinned} onChange={(event) => setPinned(event.target.checked)} />
            고정
          </label>
          <button
            type="button"
            onClick={() => void submit()}
            disabled={busy || !symbol.trim()}
            className="inline-flex h-10 items-center justify-center gap-2 rounded bg-ink px-4 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Plus className="h-4 w-4" />
            추가
          </button>
        </div>
      </div>
      <div className="px-5 py-4">
        {error ? <div className="mb-3 rounded bg-red-50 px-3 py-2 text-xs text-block">{error}</div> : null}
        {candidates.length === 0 ? (
          <div className="text-sm text-zinc-500">수동 후보가 없습니다.</div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {candidates.map((candidate) => (
              <div key={candidate.symbol} className="inline-flex items-center overflow-hidden rounded border border-line bg-zinc-50">
                <Link href={`/symbols/${candidate.symbol}`} prefetch={false} className="px-3 py-2 text-sm font-bold text-ink hover:text-info">
                  {candidate.symbol}
                </Link>
                <button
                  type="button"
                  onClick={() => void toggle(candidate)}
                  disabled={busy}
                  className={candidate.pinned ? "inline-flex h-9 items-center gap-1 border-l border-line px-2 text-xs font-semibold text-info" : "inline-flex h-9 items-center gap-1 border-l border-line px-2 text-xs font-semibold text-zinc-500"}
                  title={candidate.pinned ? "고정 해제" : "고정"}
                >
                  <Pin className="h-3.5 w-3.5" />
                  {candidate.pinned ? "고정" : "일반"}
                </button>
                <button
                  type="button"
                  onClick={() => void remove(candidate)}
                  disabled={busy}
                  className="inline-flex h-9 items-center border-l border-line px-2 text-zinc-500 hover:text-block"
                  title="삭제"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function scannerShouldReload(event: RealtimeEnvelope) {
  if (event.event_type !== "log.event") return false;
  return [
    "scanner.snapshot",
    "scanner.realtime_start",
    "scanner.realtime_paused",
    "scanner.minute_seed",
    "strategy.signal_evaluation",
    "risk.decision",
    "paper.order_event",
  ].includes(String(event.payload?.event_type ?? ""));
}

function StageCard({ stage, index }: { stage: Stage; index: number }) {
  const meta = stageMeta[stage.name] ?? { label: stage.name, desc: "", icon: <Filter className="h-4 w-4" /> };
  const isEmpty = stage.passed === 0;
  const hasReject = stage.rejected > 0 || stage.top_reject_reasons.length > 0;
  const waiting = Number(stage.waiting ?? 0);

  return (
    <div className="bg-white p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 gap-3">
          <div className={isEmpty ? "flex h-8 w-8 shrink-0 items-center justify-center rounded bg-zinc-100 text-zinc-500" : "flex h-8 w-8 shrink-0 items-center justify-center rounded bg-blue-50 text-info"}>
            {meta.icon}
          </div>
          <div className="min-w-0">
            <div className="text-xs font-medium text-zinc-500">STEP {index}</div>
            <h3 className="mt-1 truncate text-sm font-semibold text-ink">{meta.label}</h3>
            <p className="mt-1 text-xs leading-5 text-zinc-500">{meta.desc}</p>
          </div>
        </div>
        {hasReject ? <AlertTriangle className="h-4 w-4 shrink-0 text-warn" /> : <CheckCircle2 className="h-4 w-4 shrink-0 text-ok" />}
      </div>
      <div className="mt-4 flex items-end justify-between">
        <div>
          <div className="text-2xl font-bold text-ink">{stage.passed}</div>
          <div className="mt-1 text-xs text-zinc-500">통과</div>
        </div>
        <div className="text-right">
          <div className={stage.rejected > 0 ? "text-lg font-bold text-warn" : "text-lg font-bold text-zinc-400"}>{stage.rejected}</div>
          <div className="mt-1 text-xs text-zinc-500">탈락</div>
        </div>
      </div>
      {waiting > 0 ? (
        <div className="mt-3 rounded bg-blue-50 px-3 py-2 text-xs font-medium text-info">
          구독 슬롯 대기 {waiting}개
        </div>
      ) : null}
      {stage.top_reject_reasons.length ? (
        <div className="mt-4 space-y-2">
          {stage.top_reject_reasons.slice(0, 2).map((reason) => (
            <div key={reason} className="rounded bg-amber-50 px-3 py-2 text-xs leading-5 text-warn">
              {reason}
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function TossCandidateTable({ candidates }: { candidates: Candidate[] }) {
  const visible = candidates.slice(0, 30);
  return (
    <section className="overflow-hidden rounded border border-line bg-white">
      <div className="flex flex-col gap-2 border-b border-line px-5 py-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h2 className="text-base font-semibold text-ink">후보 종목</h2>
          <p className="mt-1 text-xs text-zinc-500">Toss 거래대금 랭킹 30개를 기준으로 보고, 현재가는 Toss trade/호가 polling 값으로 갱신합니다.</p>
        </div>
        <div className="text-xs text-zinc-500">표시 {visible.length}개 / 전체 {candidates.length}개</div>
      </div>
      {visible.length === 0 ? (
        <div className="p-8 text-center text-sm text-zinc-500">현재 표시할 후보가 없습니다.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-zinc-50 text-xs text-zinc-500">
              <tr>
                <Header label="종목" />
                <Header label="현재가" align="right" />
                <Header label="등락률" align="right" />
                <Header label="스프레드" align="right" />
                <Header label="구독" />
                <Header label="전략" />
              </tr>
            </thead>
            <tbody>
              {visible.map((candidate, index) => {
                const dayChange = candidateDayChangePct(candidate);
                return (
                  <tr key={`${candidate.symbol}-${index}`} className="border-t border-line">
                    <td className="whitespace-nowrap px-4 py-3">
                      <Link href={`/symbols/${candidate.symbol}`} prefetch={false} className="font-bold text-ink hover:text-info">
                        {String(candidate.symbol ?? "-")}
                      </Link>
                      <div className="mt-1 max-w-[240px] truncate text-xs text-zinc-500">{String(candidate.company_name ?? "-")}</div>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-right font-semibold text-zinc-700">{formatPrice(candidate.last_price)}</td>
                    <td className={`whitespace-nowrap px-4 py-3 text-right font-semibold ${percentTone(dayChange)}`}>{formatSignedPercent(dayChange)}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-right text-zinc-700">{formatPercent(candidate.spread_pct)}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <BoolPill value={Boolean(candidate.selected_for_ws)} trueLabel="구독" falseLabel="대기" />
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <BoolPill value={Boolean(candidate.selected_for_strategy)} trueLabel="감시" falseLabel="보류" />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

function Header({ label, align = "left" }: { label: string; align?: "left" | "right" }) {
  return <th className={`whitespace-nowrap px-4 py-3 font-semibold ${align === "right" ? "text-right" : ""}`}>{label}</th>;
}

function BoolPill({ value, trueLabel, falseLabel }: { value: boolean; trueLabel: string; falseLabel: string }) {
  return (
    <span className={value ? "inline-flex rounded bg-emerald-50 px-2 py-1 text-xs font-semibold text-ok ring-1 ring-emerald-100" : "inline-flex rounded bg-zinc-50 px-2 py-1 text-xs font-semibold text-zinc-500 ring-1 ring-zinc-200"}>
      {value ? trueLabel : falseLabel}
    </span>
  );
}

function MetricPanel({ icon, label, value, detail }: { icon: ReactNode; label: string; value: number; detail: string }) {
  return (
    <div className="rounded border border-line bg-white p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="text-xs font-medium text-zinc-500">{label}</div>
        <div className="text-info">{icon}</div>
      </div>
      <div className="mt-3 text-2xl font-bold text-ink">{value}</div>
      <div className="mt-2 truncate text-xs text-zinc-500">{detail || "-"}</div>
    </div>
  );
}

function StatusBox({ label, value, tone }: { label: string; value: string; tone: "ok" | "warn" | "block" | "info" }) {
  return (
    <div className="rounded border border-line bg-white px-3 py-2">
      <div className="text-xs font-medium text-zinc-500">{label}</div>
      <div className="mt-1 flex items-center gap-2">
        <span className={dotClass(tone)} />
        <span className="truncate text-sm font-semibold text-ink">{value}</span>
      </div>
    </div>
  );
}

function statusTone(status?: string): "ok" | "warn" | "block" | "info" {
  const normalized = (status ?? "").toLowerCase();
  if (["connected", "starting"].includes(normalized)) return "ok";
  if (["stopped", "stopping"].includes(normalized)) return "warn";
  if (normalized === "configured") return "info";
  return "block";
}

function dotClass(tone: "ok" | "warn" | "block" | "info") {
  return {
    ok: "h-2 w-2 rounded-full bg-ok",
    warn: "h-2 w-2 rounded-full bg-warn",
    block: "h-2 w-2 rounded-full bg-block",
    info: "h-2 w-2 rounded-full bg-info",
  }[tone];
}

function formatSymbolList(symbols: string[]) {
  if (!symbols.length) return "-";
  return symbols.slice(0, 5).join(", ") + (symbols.length > 5 ? ` 외 ${symbols.length - 5}` : "");
}

function formatKstDateTime(value?: string | null) {
  if (!value) return "-";
  const date = parseRealtimeDate(value);
  if (!date) return "-";
  return date.toLocaleString("ko-KR", {
    timeZone: "Asia/Seoul",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function parseRealtimeDate(value: string) {
  let normalized = value;
  if (normalized.endsWith("Z")) normalized = `${normalized.slice(0, -1)}+00:00`;
  normalized = normalized.replace(/\.(\d{3,6})\d+([+-]\d{2}:?\d{2})$/, ".$1$2");
  normalized = normalized.replace(/\.(\d{3,6})\d+$/, ".$1");
  const date = /[+-]\d{2}:?\d{2}$/.test(normalized) ? new Date(normalized) : new Date(`${normalized}Z`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function formatPrice(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "-";
  return `$${number.toLocaleString("en-US", { minimumFractionDigits: number < 10 ? 4 : 2, maximumFractionDigits: number < 10 ? 4 : 2 })}`;
}

function formatPercent(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "-";
  return `${number.toFixed(3)}%`;
}

function formatSignedPercent(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "-";
  const sign = number > 0 ? "+" : "";
  return `${sign}${number.toFixed(2)}%`;
}

function percentTone(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "text-zinc-500";
  if (number > 0) return "text-red-600";
  if (number < 0) return "text-blue-600";
  return "text-zinc-500";
}

// Day change % from the live polling price against the prior-day close when both are
// available (keeps the value fresh intraday), otherwise falls back to the ranking snapshot's
// change rate.
function candidateDayChangePct(candidate: Candidate): number | null {
  const last = toNumber(candidate.last_price);
  const prevClose = toNumber(candidate.prev_close_price);
  if (last != null && prevClose != null && prevClose !== 0) {
    return ((last - prevClose) / prevClose) * 100;
  }
  return toNumber(candidate.day_change_pct);
}

function toNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value.replace(/,/g, ""));
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
