from datetime import datetime, timezone

from fastapi import APIRouter

from app.adapters.toss.client import TossApiError, TossExecutionClient
from app.core.config import get_settings
from app.services.execution_gateway import ExecutionGatewayService
from app.services.live_broker import LiveBroker
from app.services.market_data import get_market_data_service
from app.services.market_session import active_trading_session, realtime_session_allowed
from app.services.paper_broker import InternalPaperBroker
from app.services import shared_state
from app.services import realtime_state
from app.services.runtime_supervisor import RUNTIME_STATUS_TTL_SEC, runtime_supervisor

router = APIRouter()


@router.get("")
async def command_center() -> dict:
    settings = get_settings()
    market_data = get_market_data_service()
    market_status = market_data.status()
    local_ws_status = market_data.provider.realtime_status()
    execution_status = ExecutionGatewayService().status()
    if settings.trading_mode == "live":
        account_payload, counts_payload = _live_account_and_counts(settings)
        paper_state = {"positions": [], "orders": [], "closed_trades": []}
    else:
        paper_state = InternalPaperBroker().state()
        account = _paper_account_summary(settings.paper_initial_equity_usd, paper_state)
        account_payload = {
            "base_currency": "USD",
            "source": "internal_paper",
            "initial_equity_usd": settings.paper_initial_equity_usd,
            "equity_usd": account["equity_usd"],
            "realized_pnl_usd": account["realized_pnl_usd"],
            "unrealized_pnl_usd": account["unrealized_pnl_usd"],
            "daily_loss_limit_used_pct": account["daily_loss_limit_used_pct"],
            "daily_loss_limit_enabled": False,
            "total_exposure_pct": account["total_exposure_pct"],
            "risk_hard_caps_enabled": settings.paper_risk_hard_caps_enabled,
        }
        counts_payload = {
            "open_positions": len(paper_state.get("positions", [])),
            "open_orders": _open_order_count(paper_state.get("orders", [])),
            "trades_today": len(paper_state.get("closed_trades", [])),
        }
    runtime_status = runtime_supervisor.status()
    active_session = active_trading_session(settings)
    session = active_session["session"]
    realtime_allowed = realtime_session_allowed(settings, session)
    automation_enabled = bool(active_session.get("automation_enabled"))
    shared_system_status = shared_state.get_json_any(
        "trading_lab:runtime:system_status",
        "kis:runtime:system_status",
    )
    # 파일 기반 shared_state는 TTL을 지원하지 않으므로 직접 나이를 검사한다.
    # 60초(2×TTL) 초과된 공유 상태는 stale로 간주하고 로컬 상태를 사용한다.
    _shared_system_age_ok = False
    if isinstance(shared_system_status, dict):
        _gen_at = str(shared_system_status.get("generated_at") or "")
        if _gen_at:
            try:
                from datetime import datetime as _dt, timezone as _tz
                _gen_dt = _dt.fromisoformat(_gen_at.replace("Z", "+00:00"))
                if _gen_dt.tzinfo is None:
                    _gen_dt = _gen_dt.replace(tzinfo=_tz.utc)
                _shared_system_age_ok = (_dt.now(_tz.utc) - _gen_dt).total_seconds() <= RUNTIME_STATUS_TTL_SEC
            except (ValueError, TypeError, AttributeError):
                _shared_system_age_ok = False
    shared_runtime_status = (shared_system_status or {}).get("runtime_supervisor") if isinstance(shared_system_status, dict) else None
    if _shared_system_age_ok and isinstance(shared_runtime_status, dict) and shared_runtime_status.get("running"):
        runtime_status = shared_runtime_status
    shared_ws_status = (shared_system_status or {}).get("websocket") if (_shared_system_age_ok and isinstance(shared_system_status, dict)) else None
    if not isinstance(shared_ws_status, dict):
        shared_ws_status = realtime_state.realtime_status()
    ws_status = _effective_ws_status(local_ws_status, shared_ws_status)
    shared_freshness = (shared_system_status or {}).get("data_freshness") if (_shared_system_age_ok and isinstance(shared_system_status, dict)) else None
    if not isinstance(shared_freshness, dict):
        shared_freshness = {}

    return {
        "status_level": "NORMAL" if automation_enabled else "CAUTION",
        "trading_mode": settings.trading_mode,
        "live_enabled": settings.live_enabled,
        "active_market": active_session,
        "market_data_provider": market_status.get("provider"),
        "market_data_status": market_status.get("status"),
        "market_data_message": market_status.get("message"),
        "execution_provider": execution_status.get("provider"),
        "execution_status": execution_status.get("status"),
        "execution_gateway_status": execution_status.get("status"),
        "execution_gateway_role": execution_status.get("role"),
        "execution_live_order_enabled": execution_status.get("live_order_enabled"),
        "kis_rest_status": execution_status.get("status"),
        "kis_websocket_status": "execution_only",
        "legacy_kis_rest_status": "legacy_debug_only",
        "legacy_kis_websocket_status": "legacy_debug_only",
        "runtime_supervisor": runtime_status,
        "data_freshness": {
            "last_ws_message_at": shared_freshness.get("last_ws_message_at") or ws_status["last_message_at"],
            "last_realtime_at": shared_freshness.get("last_realtime_at") or ws_status["last_realtime_at"],
            "last_trade_at": shared_freshness.get("last_trade_at") or ws_status.get("last_trade_at"),
            "last_quote_at": shared_freshness.get("last_quote_at") or ws_status.get("last_quote_at"),
            "state": shared_freshness.get("state") or (_data_freshness_state(ws_status) if realtime_allowed else "PAUSED"),
            "trade_state": shared_freshness.get("trade_state") or _tick_freshness_state(ws_status.get("last_trade_at"), ws_status),
            "quote_state": shared_freshness.get("quote_state") or _tick_freshness_state(ws_status.get("last_quote_at"), ws_status),
            "paused": not automation_enabled,
            "pause_reason": None if realtime_allowed else f"{session.get('label')} 세션이라 실시간 구독을 일시 중지합니다.",
        },
        "session": session,
        "account": account_payload,
        "counts": counts_payload,
        "performance": account_payload.get("performance"),
        "recent_warnings": _compact_warnings(
            [
                None if realtime_allowed else f"{session.get('label')} 세션이라 Toss polling 구독과 scanner 자동 갱신을 멈춥니다.",
                market_status.get("message", "market data 상태를 확인하세요."),
                execution_status.get("message", "실행/계좌 gateway 상태를 확인하세요."),
                _ws_warning(ws_status, market_status),
                _runtime_warning(runtime_status),
                _live_automation_note(settings, execution_status),
            ]
        ),
    }


def _live_automation_note(settings, execution_status: dict) -> str | None:
    if settings.trading_mode != "live" or not settings.live_enabled:
        return None
    if execution_status.get("live_auto_trade_enabled"):
        return "실전 자동 주문 활성화: 전략 신호가 통과하면 Toss live 주문을 제출합니다."
    if execution_status.get("live_order_enabled"):
        return "Toss live 주문 API는 활성화되어 있지만 자동 전략 주문은 차단되어 있습니다."
    return "실전 모드이지만 Toss live 주문 게이트가 차단되어 있습니다."


def _paper_account_summary(initial_equity: float, paper_state: dict) -> dict:
    positions = paper_state.get("positions", [])
    closed_trades = paper_state.get("closed_trades", [])
    realized = sum(_closed_trade_pnl(row) for row in closed_trades)
    exposure = sum(float(row.get("quantity") or 0.0) * float(row.get("average_price") or 0.0) for row in positions)
    wins = [row for row in closed_trades if _closed_trade_pnl(row) > 0]
    losses = [row for row in closed_trades if _closed_trade_pnl(row) < 0]
    gross_profit = sum(_closed_trade_pnl(row) for row in wins)
    gross_loss = abs(sum(_closed_trade_pnl(row) for row in losses))
    daily_loss_limit = initial_equity * 0.02
    loss_used = max(0.0, -realized) / daily_loss_limit * 100 if daily_loss_limit > 0 else 0.0
    return {
        "equity_usd": initial_equity + realized,
        "realized_pnl_usd": realized,
        "unrealized_pnl_usd": 0.0,
        "daily_loss_limit_used_pct": loss_used,
        "total_exposure_pct": exposure / initial_equity * 100 if initial_equity > 0 else 0.0,
        "performance": {
            "win_rate_today": (len(wins) / len(closed_trades) * 100) if closed_trades else None,
            "profit_factor_today": (gross_profit / gross_loss) if gross_loss > 0 else (None if gross_profit == 0 else 999.0),
        },
    }


def _live_account_and_counts(settings) -> tuple[dict, dict]:
    base_account = {
        "base_currency": "USD",
        "source": "toss_live",
        "initial_equity_usd": 0.0,
        "equity_usd": 0.0,
        "cash_buying_power_usd": 0.0,
        "realized_pnl_usd": 0.0,
        "unrealized_pnl_usd": 0.0,
        "daily_loss_limit_used_pct": 0.0,
        "daily_loss_limit_enabled": False,
        "total_exposure_pct": 0.0,
        "risk_hard_caps_enabled": False,
        "performance": {
            "win_rate_today": None,
            "profit_factor_today": None,
        },
    }
    live_state = LiveBroker(settings=settings).state()
    counts = {
        "open_positions": len(live_state.get("positions", [])),
        "open_orders": _open_order_count(live_state.get("orders", [])),
        "trades_today": len(live_state.get("closed_trades", [])),
    }
    client = TossExecutionClient(settings)
    try:
        account_seq = client.account_seq()
        buying_power = client.buying_power(currency="USD", account_seq=account_seq)
        holdings = client.holdings(account_seq=account_seq)
    except TossApiError as exc:
        return (
            {
                **base_account,
                "status": "live_account_unavailable",
                "message": str(exc),
                "status_code": exc.status_code,
            },
            counts,
        )
    cash_buying_power = _to_float(buying_power.get("cashBuyingPower"))
    holding_rows = _holding_rows(holdings)
    open_positions = [row for row in holding_rows if _holding_quantity(row) > 0]
    exposure = sum(_holding_quantity(row) * _holding_price(row) for row in open_positions)
    cash_value = cash_buying_power or 0.0
    equity = cash_value + exposure
    return (
        {
            **base_account,
            "status": "configured",
            "initial_equity_usd": equity,
            "equity_usd": equity,
            "cash_buying_power_usd": cash_value,
            "live_order_enabled": client.live_order_enabled(),
            "holdings_count": len(open_positions),
            "total_exposure_usd": exposure,
            "total_exposure_pct": (exposure / equity * 100) if equity and equity > 0 else 0.0,
        },
        {
            "open_positions": max(len(open_positions), counts["open_positions"]),
            "open_orders": counts["open_orders"],
            "trades_today": counts["trades_today"],
        },
    )


def _holding_rows(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("holdings", "positions", "stocks", "items", "assets"):
        rows = payload.get(key)
        if isinstance(rows, list):
            return [row for row in rows if isinstance(row, dict)]
    if payload.get("symbol") or payload.get("ticker") or payload.get("stockCode"):
        return [payload]
    return []


def _holding_quantity(row: dict) -> float:
    return _to_float(
        row.get("quantity")
        or row.get("qty")
        or row.get("holdingQuantity")
        or row.get("sellableQuantity")
        or row.get("ownedQuantity")
    ) or 0.0


def _holding_price(row: dict) -> float:
    return _to_float(
        row.get("currentPrice")
        or row.get("lastPrice")
        or row.get("marketPrice")
        or row.get("price")
        or row.get("averagePrice")
    ) or 0.0


def _to_float(value: object) -> float | None:
    try:
        return float(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return None


def _open_order_count(orders: list[dict]) -> int:
    open_states = {
        "CREATED",
        "RISK_CHECKED",
        "SUBMITTED",
        "ACKNOWLEDGED",
        "PARTIALLY_FILLED",
        "CANCEL_REQUESTED",
        "REPLACE_REQUESTED",
        "UNKNOWN_RECONCILE_REQUIRED",
    }
    return sum(1 for order in orders if str(order.get("state")) in open_states)


def _closed_trade_pnl(row: dict) -> float:
    if row.get("net_pnl_usd") is not None:
        return float(row.get("net_pnl_usd") or 0.0)
    return float(row.get("gross_pnl_usd") or 0.0)


def _data_freshness_state(ws_status: dict) -> str:
    if ws_status.get("status") == "error":
        return "BLOCKED"
    return _tick_freshness_state(ws_status.get("last_realtime_at"), ws_status)


def _tick_freshness_state(value: object, ws_status: dict) -> str:
    if not value:
        return "CAUTION" if ws_status.get("status") in ("starting", "connected") else "BLOCKED"
    parsed = _parse_ws_time(value)
    if parsed is None:
        return "CAUTION"
    max_age = max(15, int(get_settings().scanner_realtime_stale_restart_sec or 90))
    age_sec = (datetime.now(timezone.utc) - parsed).total_seconds()
    if age_sec <= max_age:
        return "NORMAL"
    return "CAUTION" if ws_status.get("status") in ("starting", "connected") else "BLOCKED"


def _effective_ws_status(local_ws_status: dict, shared_ws_status: object) -> dict:
    if not isinstance(shared_ws_status, dict):
        return local_ws_status
    if local_ws_status.get("status") in ("starting", "connected") and not shared_ws_status.get("last_realtime_at"):
        return local_ws_status
    if shared_ws_status.get("status") in ("starting", "connected") and local_ws_status.get("status") not in ("starting", "connected"):
        return shared_ws_status
    local_seen = _latest_ws_seen_at(local_ws_status)
    shared_seen = _latest_ws_seen_at(shared_ws_status)
    if shared_seen and (not local_seen or shared_seen >= local_seen):
        return shared_ws_status
    return local_ws_status


def _latest_ws_seen_at(ws_status: dict) -> datetime | None:
    for key in ("last_realtime_at", "last_message_at", "started_at"):
        value = ws_status.get(key)
        if not value:
            continue
        parsed = _parse_ws_time(value)
        if parsed is None:
            continue
        return parsed
    return None


def _parse_ws_time(value: object) -> datetime | None:
    raw = str(value or "")
    if not raw:
        return None
    if raw.endswith("Z"):
        raw = f"{raw[:-1]}+00:00"
    if "." in raw:
        head, tail = raw.split(".", 1)
        fraction = tail
        zone = ""
        for marker in ("+", "-"):
            if marker in tail:
                fraction, zone = tail.split(marker, 1)
                zone = marker + zone
                break
        raw = f"{head}.{fraction[:6]}{zone}"
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _compact_warnings(values: list[str | None]) -> list[str]:
    return [value for value in values if value]


def _ws_warning(ws_status: dict, market_status: dict) -> str:
    if ws_status.get("last_error"):
        return ws_status["last_error"]
    if ws_status.get("last_realtime_at"):
        return "market data 실시간 quote/trade 수신 중입니다."
    if ws_status.get("status") == "connected":
        return "market data 구독 ACK는 성공했지만 아직 quote/trade tick이 수신되지 않았습니다."
    if market_status.get("status") == "configured":
        return "market data provider는 설정되어 있고 실시간 연결을 대기 중입니다."
    return "market data provider를 설정하면 scanner 실시간 구독을 시작합니다."


def _runtime_warning(runtime_status: dict) -> str:
    if runtime_status.get("running"):
        return "백그라운드 scanner/strategy 감시 루프가 실행 중입니다."
    return "백그라운드 scanner/strategy 감시 루프가 중지되어 있습니다."
