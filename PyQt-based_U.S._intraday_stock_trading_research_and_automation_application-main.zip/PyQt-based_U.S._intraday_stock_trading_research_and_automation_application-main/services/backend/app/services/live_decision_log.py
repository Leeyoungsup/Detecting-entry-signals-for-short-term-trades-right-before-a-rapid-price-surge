"""Append-only per-session log of live entry/exit decisions, each with the full
1-minute candle window the strategy saw at that moment.

Purpose: every morning, compare what actually happened live (buy/sell timeline +
the exact 120-candle view at each decision) against the replay. Written to a
separate daily JSONL file (not the hot live shared-state) so it never bloats or
slows the order path. Failures are swallowed: logging must never break trading.

File: exports/live_snapshots/live_<ET-session-date>.jsonl  (one JSON object/line)
The ET date matches the replay session_<ET-date> folders for easy alignment.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

KST = ZoneInfo("Asia/Seoul")
ET = ZoneInfo("America/New_York")
LOG_DIR = Path(__file__).resolve().parents[4] / "exports" / "live_snapshots"


def record(payload: dict) -> None:
    """Append one decision snapshot as a JSON line. Never raises."""
    try:
        now_utc = datetime.now(timezone.utc)
        now_et = now_utc.astimezone(ET)
        now_kst = now_utc.astimezone(KST)
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        path = LOG_DIR / f"live_{now_et.strftime('%Y-%m-%d')}.jsonl"
        row = {
            "logged_at_kst": now_kst.isoformat(timespec="seconds"),
            "logged_at_et": now_et.isoformat(timespec="seconds"),
            **payload,
        }
        with path.open("a", encoding="utf-8") as file:
            file.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    except Exception:
        # Logging must never interfere with order submission.
        pass
