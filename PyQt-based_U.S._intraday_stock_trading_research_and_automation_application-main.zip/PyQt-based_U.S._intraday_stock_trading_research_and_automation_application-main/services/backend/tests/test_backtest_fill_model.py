from app.services.backtest import ConservativeFillModel


def test_same_candle_stop_and_target_assumes_stop_first() -> None:
    decision = ConservativeFillModel().decide_exit(
        candle_high=105,
        candle_low=95,
        stop_loss=98,
        take_profit=104,
    )

    assert decision is not None
    assert decision.exit_reason == "stop_loss"
    assert decision.exit_price == 98
    assert "stop is assumed first" in (decision.conservative_note or "")
