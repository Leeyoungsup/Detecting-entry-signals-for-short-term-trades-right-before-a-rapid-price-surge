@echo off
setlocal

cd /d "%~dp0.."

if "%API_PORT%"=="" set API_PORT=18001
netstat -ano | findstr /R /C:":%API_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%API_PORT%"=="18001" set API_PORT=18002
)

if "%WEB_PORT%"=="" set WEB_PORT=18000
netstat -ano | findstr /R /C:":%WEB_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%WEB_PORT%"=="18000" set WEB_PORT=18004
)

echo Opening backend and web in separate cmd windows.
echo Backend: http://127.0.0.1:%API_PORT%
echo Web:     http://127.0.0.1:%WEB_PORT%
start "Trading Lab Backend" cmd /k "set API_PORT=%API_PORT%&& call ""%~dp0run-backend.cmd"""
timeout /t 3 /nobreak > nul
start "Trading Lab Web" cmd /k "set API_PORT=%API_PORT%&& set WEB_PORT=%WEB_PORT%&& call ""%~dp0run-web.cmd"""
