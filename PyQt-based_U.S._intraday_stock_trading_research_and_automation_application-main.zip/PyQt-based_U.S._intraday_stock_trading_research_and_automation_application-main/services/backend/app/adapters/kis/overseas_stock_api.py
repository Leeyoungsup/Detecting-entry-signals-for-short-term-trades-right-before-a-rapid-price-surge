import time
from datetime import datetime, timedelta

from app.adapters.kis.errors import KisApiResponseError, KisEndpointNotVerifiedError
from app.adapters.kis.rest_client import KisRestClient
from app.domain.models import OrderRequest


class KisOverseasStockApi:
    def __init__(self, rest_client: KisRestClient | None = None) -> None:
        self.rest_client = rest_client or KisRestClient()

    def get_price_sync(self, symbol: str, exchange: str = "NAS") -> dict:
        return self.rest_client.request_sync(
            path="/uapi/overseas-price/v1/quotations/price",
            tr_id="HHDFS00000300",
            payload={"AUTH": "", "EXCD": exchange, "SYMB": symbol.upper()},
        )

    def get_quote_sync(self, symbol: str, exchange: str = "NAS") -> dict:
        return self.rest_client.request_sync(
            path="/uapi/overseas-price/v1/quotations/inquire-asking-price",
            tr_id="HHDFS76200100",
            payload={"AUTH": "", "EXCD": exchange, "SYMB": symbol.upper()},
        )

    def get_minute_bars_sync(
        self,
        symbol: str,
        exchange: str = "NAS",
        interval: str = "1",
        limit: int = 120,
        pinc: str = "1",
        next_flag: str = "",
        keyb: str = "",
        include_headers: bool = False,
    ) -> dict:
        return self.rest_client.request_sync(
            path="/uapi/overseas-price/v1/quotations/inquire-time-itemchartprice",
            tr_id="HHDFS76950200",
            payload={
                "AUTH": "",
                "EXCD": exchange,
                "SYMB": symbol.upper(),
                "NMIN": interval,
                "PINC": pinc,
                "NEXT": next_flag,
                "NREC": str(min(limit, 120)),
                "FILL": "",
                "KEYB": keyb,
            },
            tr_cont="N" if next_flag else "",
            include_headers=include_headers,
        )

    def get_minute_bars_history_sync(
        self,
        symbol: str,
        exchange: str = "NAS",
        interval: str = "1",
        target_date: str | None = None,
        max_pages: int = 20,
    ) -> dict:
        merged: dict = {}
        seen_keys: set[str] = set()
        keyb = ""
        next_flag = ""
        interval_minutes = max(_to_int(interval) or 1, 1)

        for page in range(max_pages):
            response = self._get_minute_bars_with_backoff(
                symbol=symbol,
                exchange=exchange,
                interval=interval,
                next_flag=next_flag,
                keyb=keyb,
            )
            rows = response.get("output2") or []
            if not merged:
                merged = {key: value for key, value in response.items() if key != "_response_headers"}
                merged["output2"] = []
            new_rows = []
            for row in rows:
                row_key = f"{row.get('xymd') or row.get('tymd')}:{row.get('xhms')}"
                if row_key not in seen_keys:
                    seen_keys.add(row_key)
                    new_rows.append(row)
            merged["output2"].extend(new_rows)

            if not new_rows:
                break
            if target_date and _oldest_market_date(new_rows) and _oldest_market_date(new_rows) < target_date:
                break
            oldest_key = _oldest_datetime_key(new_rows)
            if not oldest_key:
                break
            keyb = _previous_keyb(oldest_key, interval_minutes)
            next_flag = "1"
            if page < max_pages - 1:
                time.sleep(0.75)
        return merged

    def _get_minute_bars_with_backoff(
        self,
        *,
        symbol: str,
        exchange: str,
        interval: str,
        next_flag: str,
        keyb: str,
    ) -> dict:
        last_error: KisApiResponseError | None = None
        for attempt in range(4):
            try:
                return self.get_minute_bars_sync(
                    symbol=symbol,
                    exchange=exchange,
                    interval=interval,
                    limit=120,
                    pinc="1",
                    next_flag=next_flag,
                    keyb=keyb,
                    include_headers=True,
                )
            except KisApiResponseError as exc:
                last_error = exc
                if exc.payload.get("msg_cd") != "EGW00201":
                    raise
                time.sleep(1.2 + attempt * 0.5)
        if last_error:
            raise last_error
        raise RuntimeError("KIS minute bars request failed without an error.")

    def get_daily_bars_sync(
        self,
        symbol: str,
        exchange: str = "NAS",
        period: str = "0",
        bymd: str = "",
        adjusted: bool = True,
        max_pages: int = 5,
    ) -> dict:
        merged: dict = {}
        tr_cont = ""
        for page in range(max_pages):
            try:
                response = self.rest_client.request_sync(
                    path="/uapi/overseas-price/v1/quotations/dailyprice",
                    tr_id="HHDFS76240000",
                    payload={
                        "AUTH": "",
                        "EXCD": exchange,
                        "SYMB": symbol.upper(),
                        "GUBN": period,
                        "BYMD": bymd,
                        "MODP": "1" if adjusted else "0",
                    },
                    tr_cont=tr_cont,
                    include_headers=True,
                )
            except KisApiResponseError:
                if merged.get("output2"):
                    break
                raise
            if not merged:
                merged = {key: value for key, value in response.items() if key != "_response_headers"}
            else:
                merged_output2 = merged.setdefault("output2", [])
                current_output2 = response.get("output2") or []
                if isinstance(current_output2, list):
                    merged_output2.extend(current_output2)
            next_cont = (response.get("_response_headers") or {}).get("tr_cont", "")
            if next_cont not in {"M", "F"}:
                break
            tr_cont = "N"
            if page < max_pages - 1:
                time.sleep(0.25)
        return merged

    def get_trade_notional_ranking_sync(self, exchange: str = "NAS") -> dict:
        return self.rest_client.request_sync(
            path="/uapi/overseas-stock/v1/ranking/trade-pbmn",
            tr_id="HHDFS76320010",
            payload={
                "EXCD": exchange,
                "NDAY": "0",
                "VOL_RANG": "0",
                "AUTH": "",
                "KEYB": "",
                "PRC1": "",
                "PRC2": "",
            },
        )

    def get_trade_strength_ranking_sync(self, exchange: str = "NAS") -> dict:
        return self.rest_client.request_sync(
            path="/uapi/overseas-stock/v1/ranking/volume-power",
            tr_id="HHDFS76280000",
            payload={"EXCD": exchange, "NDAY": "0", "VOL_RANG": "0", "AUTH": "", "KEYB": ""},
        )

    def get_trade_volume_ranking_sync(self, exchange: str = "NAS") -> dict:
        return self.rest_client.request_sync(
            path="/uapi/overseas-stock/v1/ranking/trade-vol",
            tr_id="HHDFS76310010",
            payload={
                "EXCD": exchange,
                "NDAY": "0",
                "VOL_RANG": "0",
                "KEYB": "",
                "AUTH": "",
                "PRC1": "",
                "PRC2": "",
            },
        )

    def get_volume_surge_ranking_sync(self, exchange: str = "NAS") -> dict:
        return self.rest_client.request_sync(
            path="/uapi/overseas-stock/v1/ranking/volume-surge",
            tr_id="HHDFS76270000",
            payload={
                "EXCD": exchange,
                "MINX": "0",
                "VOL_RANG": "0",
                "KEYB": "",
                "AUTH": "",
            },
        )

    async def get_minute_bars(self, symbol: str, interval: str = "1m", limit: int = 100):
        nmin = interval.removesuffix("m")
        return self.get_minute_bars_sync(symbol=symbol, interval=nmin, limit=limit)

    async def get_daily_bars(self, symbol: str, period: str = "0"):
        return self.get_daily_bars_sync(symbol=symbol, period=period)

    async def get_quote(self, symbol: str):
        return self.get_quote_sync(symbol=symbol)

    async def get_scanner_rankings(self):
        return [
            self.get_trade_volume_ranking_sync(),
            self.get_volume_surge_ranking_sync(),
            self.get_trade_strength_ranking_sync(),
        ]

    async def submit_order(self, request: OrderRequest) -> dict:
        raise KisEndpointNotVerifiedError(
            "KIS 주문 API는 legacy adapter이며 현재 자동 주문 경로에서 차단됩니다."
        )

    async def get_open_orders(self) -> list[dict]:
        raise KisEndpointNotVerifiedError("TODO_KIS_VERIFY: overseas open orders endpoint/TR ID.")

    async def get_fills(self) -> list[dict]:
        raise KisEndpointNotVerifiedError("TODO_KIS_VERIFY: overseas fills/order history endpoint/TR ID.")


def _to_int(value: str | int | None) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _oldest_market_date(rows: list[dict]) -> str | None:
    dates = [str(row.get("xymd") or row.get("tymd") or "") for row in rows if row.get("xymd") or row.get("tymd")]
    return min(dates) if dates else None


def _oldest_datetime_key(rows: list[dict]) -> str | None:
    keys = [
        f"{row.get('xymd') or row.get('tymd')}{str(row.get('xhms') or '000000').zfill(6)}"
        for row in rows
        if row.get("xymd") or row.get("tymd")
    ]
    return min(keys) if keys else None


def _previous_keyb(value: str, minutes: int) -> str:
    parsed = datetime.strptime(value, "%Y%m%d%H%M%S")
    return (parsed - timedelta(minutes=minutes)).strftime("%Y%m%d%H%M%S")
