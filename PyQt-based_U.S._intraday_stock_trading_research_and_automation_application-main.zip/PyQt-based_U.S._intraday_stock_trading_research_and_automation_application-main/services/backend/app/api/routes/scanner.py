import asyncio
from typing import Literal

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from app.core.config import get_settings
from app.services.scanner import (
    ScannerService,
    add_manual_candidate,
    list_manual_candidates,
    remove_manual_candidate,
    update_manual_candidate,
)
from app.services.market_data import get_market_data_service
from app.services import shared_state
from app.services import realtime_state

router = APIRouter()
_ensure_realtime_task: asyncio.Task | None = None


class ManualCandidateRequest(BaseModel):
    symbol: str
    pinned: bool = True


class ManualCandidateUpdateRequest(BaseModel):
    pinned: bool


@router.get("/funnel")
async def scanner_funnel() -> dict:
    service = ScannerService()
    if get_settings().app_process_role != "api":
        _schedule_ensure_realtime(service)
    return await service.cached_funnel_snapshot()


def _schedule_ensure_realtime(service: ScannerService) -> None:
    global _ensure_realtime_task
    if _ensure_realtime_task and not _ensure_realtime_task.done():
        return
    _ensure_realtime_task = asyncio.create_task(_ensure_realtime_background(service))


async def _ensure_realtime_background(service: ScannerService) -> None:
    try:
        await service.ensure_realtime()
    except Exception:
        # KIS/token/rate-limit hiccups should degrade the dashboard, not break it.
        pass


@router.post("/realtime/start")
async def scanner_realtime_start(
    top_n: int = Query(default=30, ge=1, le=100),
    exchange: str = Query(default="NAS"),
    key_mode: Literal["regular", "daytime"] = Query(default="regular"),
    restart: bool = Query(default=True),
) -> dict:
    return await ScannerService().start_realtime(
        top_n=top_n,
        exchange=exchange,
        key_mode=key_mode,
        restart=restart,
    )


@router.post("/realtime/stop")
async def scanner_realtime_stop() -> dict:
    realtime_state.publish_desired_subscriptions(
        [],
        exchange=get_settings().scanner_websocket_exchange,
        key_mode=get_settings().scanner_websocket_key_mode,
        reason="scanner.realtime_stop",
    )
    if get_settings().app_process_role == "combined":
        return await get_market_data_service().provider.stop_realtime()
    return realtime_state.realtime_status() or realtime_state.waiting_status()


@router.get("/realtime/status")
def scanner_realtime_status() -> dict:
    local_status = get_market_data_service().provider.realtime_status()
    direct_realtime_status = realtime_state.realtime_status()
    if isinstance(direct_realtime_status, dict):
        return {**direct_realtime_status, "source": direct_realtime_status.get("source") or "shared_realtime"}
    shared_system_status = shared_state.get_json_any(
        "trading_lab:runtime:system_status",
        "kis:runtime:system_status",
    )
    shared_status = (shared_system_status or {}).get("websocket") if isinstance(shared_system_status, dict) else None
    if (
        isinstance(shared_status, dict)
        and shared_status.get("status") in ("starting", "connected")
        and local_status.get("status") not in ("starting", "connected")
    ):
        return {**shared_status, "source": "shared_worker"}
    return {**local_status, "source": "local_api"}


@router.get("/manual-candidates")
def scanner_manual_candidates() -> dict:
    return {"manual_candidates": list_manual_candidates()}


@router.post("/manual-candidates")
def scanner_manual_candidate_add(payload: ManualCandidateRequest) -> dict:
    try:
        result = add_manual_candidate(payload.symbol, pinned=payload.pinned)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return result


@router.patch("/manual-candidates/{symbol}")
def scanner_manual_candidate_update(symbol: str, payload: ManualCandidateUpdateRequest) -> dict:
    try:
        result = update_manual_candidate(symbol, pinned=payload.pinned)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return result


@router.delete("/manual-candidates/{symbol}")
def scanner_manual_candidate_delete(symbol: str) -> dict:
    try:
        result = remove_manual_candidate(symbol)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return result
