from app.services import strategy_runtime as strategy_runtime_module


def _apply_exit_settings(monkeypatch, *, commission_pct: float = 0.0005, min_net_pct: float = 0.0015) -> None:
    settings = strategy_runtime_module.get_settings()
    monkeypatch.setattr(settings, "paper_fee_model_enabled", True)
    monkeypatch.setattr(settings, "paper_commission_pct", commission_pct)
    monkeypatch.setattr(settings, "paper_commission_per_share", 0.0)
    monkeypatch.setattr(settings, "paper_min_commission_usd", 0.0)
    monkeypatch.setattr(settings, "paper_sec_fee_pct", 0.0)
    monkeypatch.setattr(settings, "paper_taf_fee_per_share", 0.0)
    monkeypatch.setattr(settings, "paper_stop_loss_pct", 0.004)
    monkeypatch.setattr(settings, "paper_min_stop_loss_pct", 0.0025)
    monkeypatch.setattr(settings, "paper_max_stop_loss_pct", 0.015)
    monkeypatch.setattr(settings, "paper_adaptive_max_stop_loss_pct", 0.035)
    monkeypatch.setattr(settings, "paper_stop_atr_multiplier", 1.0)
    monkeypatch.setattr(settings, "paper_take_profit_pct", 0.0035)
    monkeypatch.setattr(settings, "paper_partial_take_profit_pct", 0.0025)
    monkeypatch.setattr(settings, "paper_min_net_take_profit_pct", min_net_pct)
    monkeypatch.setattr(settings, "paper_take_profit_lookback_bars", 20)
    monkeypatch.setattr(settings, "paper_take_profit_atr_multiplier", 1.8)
    monkeypatch.setattr(settings, "paper_partial_take_profit_atr_multiplier", 0.8)
    monkeypatch.setattr(settings, "paper_trailing_activation_pct", 0.0035)
    monkeypatch.setattr(settings, "paper_trailing_stop_pct", 0.004)
    monkeypatch.setattr(settings, "paper_dynamic_trailing_tight_pct", 0.002)
    monkeypatch.setattr(settings, "paper_dynamic_trailing_normal_pct", 0.004)
    monkeypatch.setattr(settings, "paper_dynamic_trailing_wide_pct", 0.012)


def _flat_candles(*, high: float, low: float, close: float = 10.0, count: int = 25) -> list[dict]:
    rows = []
    for index in range(count):
        rows.append(
            {
                "market_date": "2026-01-02",
                "market_time": f"09:{30 + index:02d}:00",
                "open": close,
                "high": high,
                "low": low,
                "close": close,
                "volume": 10_000,
            }
        )
    return rows


def _trend_candles(*, start: float, end: float, count: int = 25, wick: float = 0.01) -> list[dict]:
    rows = []
    previous = start
    for index in range(count):
        progress = index / max(count - 1, 1)
        close = start + ((end - start) * progress)
        rows.append(
            {
                "market_date": "2026-01-02",
                "market_time": f"09:{30 + index:02d}:00",
                "open": previous,
                "high": close + wick,
                "low": close - wick,
                "close": close,
                "volume": 20_000,
            }
        )
        previous = close
    return rows


def test_exit_plan_uses_cost_floor_instead_of_old_wide_static_targets(monkeypatch) -> None:
    _apply_exit_settings(monkeypatch)

    plan = strategy_runtime_module._entry_exit_plan(
        10.0,
        _flat_candles(high=10.06, low=9.99),
        quantity=100,
        market_snapshot={"spread_pct": 0.02},
        evaluation={"final_score": 60},
    )

    profile = plan["dynamic_exit_profile"]
    assert profile["take_profit_pct"] < 0.01
    assert 0.002 <= plan["required_profit_pct"] <= 0.004
    assert plan["take_profit_price"] >= 10.0 * (1 + plan["required_profit_pct"])


def test_exit_plan_blocks_entry_when_expected_upside_cannot_clear_fees(monkeypatch) -> None:
    _apply_exit_settings(monkeypatch, commission_pct=0.001)

    plan = strategy_runtime_module._entry_exit_plan(
        10.0,
        _flat_candles(high=10.025, low=9.995),
        quantity=100,
        market_snapshot={"spread_pct": 0.0},
        evaluation={"final_score": 60},
    )

    assert plan["expected_upside"]["expected_upside_pct"] <= 0.0025
    assert plan["required_profit_pct"] > plan["expected_upside"]["expected_upside_pct"]
    assert plan["entry_viable"] is False
    assert plan["entry_viability_reason"] == "expected_upside_below_cost_floor"


def test_exit_plan_allows_entry_when_expected_upside_covers_cost_floor(monkeypatch) -> None:
    _apply_exit_settings(monkeypatch, commission_pct=0.001)

    plan = strategy_runtime_module._entry_exit_plan(
        10.0,
        _flat_candles(high=10.08, low=9.92),
        quantity=100,
        market_snapshot={"spread_pct": 0.0},
        evaluation={"final_score": 60},
    )

    assert plan["expected_upside"]["expected_upside_pct"] >= plan["required_profit_pct"]
    assert plan["entry_viable"] is True
    assert plan["entry_viability_reason"] == "expected_upside_covers_cost_floor"


def test_exit_plan_widens_targets_and_stop_for_high_liquidity_volatility(monkeypatch) -> None:
    _apply_exit_settings(monkeypatch)

    plan = strategy_runtime_module._entry_exit_plan(
        10.0,
        _trend_candles(start=9.40, end=10.0),
        quantity=100,
        market_snapshot={"spread_pct": 0.03},
        evaluation={
            "final_score": 82,
            "order_flow": {
                "volume_velocity_10s": 2.2,
                "trade_strength": 72,
                "sell_pressure": 0.28,
            },
        },
    )

    profile = plan["dynamic_exit_profile"]
    assert profile["strong_liquidity"] is True
    assert profile["high_volatility"] is True
    assert profile["recent_10bar_abs_change_pct"] > 0.018
    assert profile["partial_take_profit_pct"] > 0.01
    assert profile["take_profit_pct"] > 0.02
    assert plan["stop_loss_pct"] > 0.015
    assert plan["stop_loss_pct"] <= 0.035
