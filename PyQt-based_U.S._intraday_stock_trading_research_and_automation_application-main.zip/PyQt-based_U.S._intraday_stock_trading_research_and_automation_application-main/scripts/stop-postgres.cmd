@echo off
setlocal

cd /d "%~dp0.."

set CONDA_ENV_DIR=%USERPROFILE%\.conda\envs\kis-trading-research
if not exist "%CONDA_ENV_DIR%\python.exe" set CONDA_ENV_DIR=C:\ProgramData\anaconda3\envs\kis-trading-research
set PATH=%CONDA_ENV_DIR%;%CONDA_ENV_DIR%\Library\bin;%CONDA_ENV_DIR%\Scripts;%PATH%

if not exist "data\postgres\PG_VERSION" (
  echo PostgreSQL data directory does not exist.
  exit /b 0
)

echo Stopping PostgreSQL
pg_ctl -D "data\postgres" stop
