from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field

from app.domain.enums import OrderState, RealtimeEventType, StatusLevel


class Symbol(BaseModel):
    symbol: str
    exchange: str | None = None
    name: str | None = None


class Quote(BaseModel):
    symbol: str
    bid: float | None = None
    ask: float | None = None
    bid_depth: float | None = None
    ask_depth: float | None = None
    received_at: datetime
    is_delayed: bool = False


class TradeTick(BaseModel):
    symbol: str
    price: float
    quantity: float
    notional_usd: float
    aggressor_side: str = "unknown"
    received_at: datetime


class Candle(BaseModel):
    symbol: str
    interval: str = "1m"
    ts: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


class ScannerSnapshot(BaseModel):
    symbol: str
    company_name: str | None = None
    rank_total: int | None = None
    trade_notional_rank: int | None = None
    trade_volume_rank: int | None = None
    realtime_liquidity_rank: int | None = None
    realtime_volume_rank: int | None = None
    volume_surge_rank: int | None = None
    trade_strength_rank: int | None = None
    scanner_score: float = 0.0
    volume_score: float | None = None
    volume_1m: float | None = None
    volume_velocity_10s: float | None = None
    volume_surge_rate: float | None = None
    screener_source: str | None = None
    volume_source: str = "provider_ranking"
    last_price: float | None = None
    prev_close_price: float | None = None
    day_change_pct: float | None = None
    bid_price: float | None = None
    ask_price: float | None = None
    quote_mid_price: float | None = None
    current_price_source: str | None = None
    industry: str | None = None
    market_cap_usd: float | None = None
    market_cap_krw: float | None = None
    toss_trade_amount_krw: float | None = None
    toss_trade_volume: float | None = None
    toss_buy_volume: float | None = None
    toss_sell_volume: float | None = None
    toss_buy_ratio_pct: float | None = None
    daily_volume: float | None = None
    trade_count: float | None = None
    notional_1m: float | None = None
    volume_10m: float | None = None
    notional_10m: float | None = None
    change_1m_pct: float | None = None
    change_10m_pct: float | None = None
    latest_bar_age_sec: float | None = None
    notional_5m: float | None = None
    notional_velocity_10s: float | None = None
    trade_strength: float | None = None
    sell_pressure: float | None = None
    aggressive_buy_volume: float | None = None
    aggressive_sell_volume: float | None = None
    unknown_trade_volume: float | None = None
    spread_pct: float | None = None
    bid_ask_imbalance: float | None = None
    atr_pct: float | None = None
    relative_strength_vs_qqq: float | None = None
    relative_strength_vs_spy: float | None = None
    bb_state: str = "unknown"
    reclaim_state: str = "waiting"
    selected_for_ws: bool = False
    selected_for_strategy: bool = False
    reject_reason: str | None = None
    order_flow_notes: list[str] = Field(default_factory=list)
    last_update_age_sec: float | None = None


class SignalEvaluation(BaseModel):
    symbol: str
    strategy_name: str = "Bollinger Lower Band Reclaim"
    strategy_version: str = "0.1.0"
    parameter_set_id: str = "default-lbr-001"
    passed: bool
    final_score: float
    conditions: dict[str, bool | float | str | None]
    reject_reason: str | None = None


class RiskDecision(BaseModel):
    allowed: bool
    reason: str | None = None
    account_equity_usd: float = 2000.0
    risk_amount_usd: float = 4.0
    max_notional_usd: float = 300.0
    quantity: float | None = None
    stop_loss_price: float | None = None
    take_profit_price: float | None = None


class OrderRequest(BaseModel):
    symbol: str
    side: str
    # Which position this order acts on. "long": buy opens/adds, sell closes.
    # "short": sell opens/adds, buy covers. Default "long" keeps every existing
    # long-only path unchanged.
    position_side: str = "long"
    order_type: str = "marketable_limit"
    quantity: float
    limit_price: float | None = None
    mode: str = "internal_paper"
    strategy_signal_id: str | None = None


class OrderEvent(BaseModel):
    order_id: str
    previous_state: OrderState | None = None
    new_state: OrderState
    source: str
    message: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Fill(BaseModel):
    order_id: str
    symbol: str
    side: str = "buy"
    quantity: float
    price: float
    slippage_bps: float | None = None
    broker_fill_id: str | None = None


class Position(BaseModel):
    position_key: str | None = None
    symbol: str
    strategy_name: str | None = None
    parameter_set_id: str | None = None
    entry_mode: str | None = None
    # "long" or "short". Short positions profit when price falls; their stop sits
    # ABOVE entry and they trail the low_watermark instead of the high_watermark.
    direction: str = "long"
    quantity: float
    average_price: float
    entry_fees_usd: float = 0.0
    unrealized_pnl_usd: float = 0.0
    mode: str = "internal_paper"
    opened_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    stop_loss_price: float | None = None
    take_profit_price: float | None = None
    dynamic_take_profit_price: float | None = None
    dynamic_take_profit_reason: str | None = None
    dynamic_take_profit_updated_at: datetime | None = None
    partial_take_profit_price: float | None = None
    partial_exit_done: bool = False
    trailing_stop_price: float | None = None
    trailing_activation_price: float | None = None
    high_watermark: float | None = None
    low_watermark: float | None = None
    stop_loss_candidate_since: datetime | None = None
    stop_loss_hold_reason: str | None = None
    last_exit_check_at: datetime | None = None
    exit_plan: dict[str, Any] = Field(default_factory=dict)
    entry_snapshot: dict[str, Any] = Field(default_factory=dict)


class TradeSummary(BaseModel):
    symbol: str
    entry_price: float
    exit_price: float
    quantity: float
    gross_pnl_usd: float
    net_pnl_usd: float
    exit_reason: str
    mode: str


class BacktestRunRequest(BaseModel):
    symbols: list[str]
    start_date: str
    end_date: str
    initial_equity_usd: float = 2000.0
    strategy_name: str = "lower_band_reclaim"
    conservative_same_bar_exit: bool = True
    default_slippage_bps: float = 5.0
    stop_slippage_bps: float = 10.0


class StructuredLogEvent(BaseModel):
    level: str
    event_type: str
    message: str
    severity: StatusLevel = StatusLevel.NORMAL
    correlation_id: str | None = None
    mode: str = "internal_paper"
    symbol: str | None = None
    order_id: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    redaction_applied: bool = True


class RealtimeEnvelope(BaseModel):
    event_id: str
    event_type: RealtimeEventType
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    mode: str = "internal_paper"
    status_level: StatusLevel = StatusLevel.NORMAL
    correlation_id: str | None = None
    symbol: str | None = None
    payload: dict[str, Any]
