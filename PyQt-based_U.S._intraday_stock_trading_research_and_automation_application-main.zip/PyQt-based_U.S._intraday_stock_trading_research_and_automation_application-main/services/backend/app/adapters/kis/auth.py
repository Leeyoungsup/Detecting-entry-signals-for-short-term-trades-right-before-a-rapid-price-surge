from dataclasses import dataclass
from datetime import datetime
from typing import ClassVar

import httpx

from app.adapters.kis.errors import KisApiResponseError, KisConfigurationError
from app.core.config import Settings, get_settings


@dataclass
class KisAccessToken:
    access_token: str
    expires_at: str | None = None

    @property
    def expired(self) -> bool:
        if not self.expires_at:
            return False
        try:
            expires_at = datetime.strptime(self.expires_at, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return False
        return datetime.now() >= expires_at


def _base_url(settings: Settings) -> str:
    return (
        settings.kis_rest_base_url_live
        if settings.kis_environment == "live"
        else settings.kis_rest_base_url_mock
    )


class KisAuthClient:
    _shared_tokens: ClassVar[dict[str, KisAccessToken]] = {}

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self._token: KisAccessToken | None = None
        self._approval_key: str | None = None

    def _cache_key(self) -> str:
        return f"{self.settings.kis_environment}:{self.settings.kis_app_key or ''}"

    def _credentials(self) -> tuple[str, str]:
        if not self.settings.kis_app_key or not self.settings.kis_app_secret:
            raise KisConfigurationError("KIS_APP_KEY/KIS_APP_SECRET이 설정되어 있지 않습니다.")
        return self.settings.kis_app_key, self.settings.kis_app_secret

    def issue_access_token_sync(self) -> KisAccessToken:
        app_key, app_secret = self._credentials()
        url = f"{_base_url(self.settings)}/oauth2/tokenP"
        headers = {
            "Content-Type": "application/json",
            "Accept": "text/plain",
            "charset": "UTF-8",
            "User-Agent": self.settings.kis_user_agent,
        }
        payload = {
            "grant_type": "client_credentials",
            "appkey": app_key,
            "appsecret": app_secret,
        }
        response = httpx.post(url, json=payload, headers=headers, timeout=10.0)
        data = _json_or_empty(response)
        if response.status_code != 200 or not data.get("access_token"):
            raise KisApiResponseError(
                status_code=response.status_code,
                message=data.get("msg1") or data.get("error_description") or response.text,
                payload=data,
            )
        self._token = KisAccessToken(
            access_token=data["access_token"],
            expires_at=data.get("access_token_token_expired"),
        )
        self._shared_tokens[self._cache_key()] = self._token
        return self._token

    def get_access_token_sync(self) -> KisAccessToken:
        if self._token and not self._token.expired:
            return self._token
        cached = self._shared_tokens.get(self._cache_key())
        if cached and not cached.expired:
            self._token = cached
            return cached
        return self.issue_access_token_sync()

    def issue_ws_approval_key_sync(self) -> str:
        app_key, app_secret = self._credentials()
        url = f"{_base_url(self.settings)}/oauth2/Approval"
        headers = {
            "Content-Type": "application/json",
            "Accept": "text/plain",
            "charset": "UTF-8",
            "User-Agent": self.settings.kis_user_agent,
        }
        payload = {
            "grant_type": "client_credentials",
            "appkey": app_key,
            "secretkey": app_secret,
        }
        response = httpx.post(url, json=payload, headers=headers, timeout=10.0)
        data = _json_or_empty(response)
        if response.status_code != 200 or not data.get("approval_key"):
            raise KisApiResponseError(
                status_code=response.status_code,
                message=data.get("msg1") or data.get("error_description") or response.text,
                payload=data,
            )
        self._approval_key = data["approval_key"]
        return self._approval_key

    async def issue_access_token(self) -> str:
        token = self.issue_access_token_sync()
        return token.access_token

    async def refresh_access_token(self) -> str:
        token = self.issue_access_token_sync()
        return token.access_token


def _json_or_empty(response: httpx.Response) -> dict:
    try:
        return response.json()
    except ValueError:
        return {}


def mask_secret(value: str | None, visible: int = 4) -> str | None:
    if not value:
        return None
    if len(value) <= visible:
        return "*" * len(value)
    return f"{value[:visible]}***"


def now_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"
