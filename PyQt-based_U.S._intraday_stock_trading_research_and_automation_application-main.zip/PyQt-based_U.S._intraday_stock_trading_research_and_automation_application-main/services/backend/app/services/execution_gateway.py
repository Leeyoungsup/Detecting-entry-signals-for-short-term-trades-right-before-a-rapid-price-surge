from app.adapters.toss.client import TossExecutionClient
from app.core.config import get_settings
from app.services.kis_connection import KisConnectionService


class ExecutionGatewayService:
    """Execution/account gateway.

    KIS belongs here, not in primary realtime market-data.
    Toss live order capability is exposed through explicit live gates and caps.
    """

    def status(self) -> dict:
        settings = get_settings()
        if settings.execution_provider == "toss" or settings.toss_app_key or settings.toss_app_secret:
            return TossExecutionClient(settings).status()
        kis_status = KisConnectionService().status(ping=False)
        return {
            "provider": "kis",
            "role": "execution_account_gateway",
            "environment": kis_status.get("environment"),
            "configured": kis_status.get("configured"),
            "account_configured": kis_status.get("account_configured"),
            "status": kis_status.get("rest_status"),
            "message": kis_status.get("message"),
            "live_order_enabled": False,
            "live_order_message": "KIS 실주문은 검증 게이트 전까지 비활성화되어 있습니다.",
        }
