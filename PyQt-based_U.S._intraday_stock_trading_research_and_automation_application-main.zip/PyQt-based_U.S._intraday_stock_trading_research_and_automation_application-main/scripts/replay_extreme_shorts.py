"""Extreme-fade SHORT setups -- research replay (short-only, live blocked).

This is the primary strategy research track. The user trades short only, and the
long track has been disabled (config.py, 2026-07-20) after ~10 analyses showed no
out-of-sample edge for frequent directional long/short entries. The one thing
that survives walk-forward is the SELECTIVE fade of an unambiguous EXTREME. Two
independent, walk-forward-validated setups (each positive on BOTH the train and
holdout regime) are run here as separate shadow tracks:

  1. Parabolic Exhaustion Short -- a large run-up prints a new high on a bearish
     reversal bar with a volume spike while stretched above the upper Bollinger
     band. (config D: keeps the BB>=1.05 over-extension marker, relaxes the
     peripheral thresholds; ~doubled trade count vs the initial tight config
     while staying positive on both regimes.)
  2. Volume Blow-off Short -- an extreme (>=3x) volume climax after a run-up with
     a bearish reversal bar, without requiring a fresh new high. Only ~9% overlap
     with parabolic, so it adds genuinely new trades; positive on both regimes.

Execution (validated): enter short next bar at bid, -3.5% hard stop (bounded,
stop-limit style), tight trailing take-profit to capture the fast dump. Entry-
confirmation delay and wider trailing were both tested and made it worse.

RESEARCH artifact only. Live short submission is not implemented and stays
blocked (AGENTS.md). Small sample (tens of trades over 9 sessions) -- treat as
research until confirmed forward. Rejected siblings (regime-lucky, one split
negative): VWAP over-extension reject, failed-retest lower-high, gap-up fade.
See claudy_log 2026-07-20.
"""
from __future__ import annotations

import csv
import importlib.util
import json
import re
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ENGINE_PATH = PROJECT_ROOT / "scripts" / "replay_tc_shadow_strategies.py"
REPLAY_DIR = PROJECT_ROOT / "exports" / "strategy_replay"

# Early sessions used to tune; later sessions held out. Update as data grows.
TRAIN_DATES = {"2026-07-07", "2026-07-08", "2026-07-09", "2026-07-10"}
FILENAME_RE = re.compile(r"^([a-z0-9]+)_(\d{4}-\d{2}-\d{2})_")

# --- Parabolic Exhaustion Short (config D) ---
PARABOLIC_MIN_10BAR_RUN = 0.08
PARABOLIC_MIN_BB_POSITION = 1.05      # core over-extension marker
PARABOLIC_MIN_VOLUME_RATIO = 1.30
PARABOLIC_MAX_BAR_CLOSE_POSITION = 0.45
PARABOLIC_CLIMAX_LOOKBACK = 6

# --- Volume Blow-off Short (config C) ---
BLOWOFF_MIN_VOLUME_RATIO = 3.00       # extreme volume climax
BLOWOFF_MIN_10BAR_RUN = 0.06
BLOWOFF_MAX_BAR_CLOSE_POSITION = 0.40

# --- common short filter ---
MIN_NOTIONAL_1M_USD = 30_000.0
MIN_EXPECTED_EDGE_PCT = 0.002

# --- execution / risk (validated: tight trailing beats wide; bounded stop) ---
MAX_NOTIONAL_PER_TRADE = 300.0
FINAL_STOP_PCT = 0.035
TRAILING_ACTIVATE_PCT = 0.006
TRAILING_WIDTH_PCT = 0.006
ENTRY_SLIPPAGE_PCT = 0.0005
EXIT_SLIPPAGE_PCT = 0.0008
STOP_SLIPPAGE_PCT = 0.0015
STOP_SLIPPAGE_CAP_PCT = 0.005
REENTRY_COOLDOWN_BARS = 3
MAX_HOLD_BARS = 20


def load_engine():
    """Import the long replay module for shared bar/indicator/fee helpers."""
    spec = importlib.util.spec_from_file_location("tc_replay_engine", ENGINE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


engine = load_engine()


def _bar_close_position(row: dict) -> float:
    high, low, close = row.get("high"), row.get("low"), row.get("close")
    if high is None or low is None or close is None or high <= low:
        return 0.5
    return (close - low) / (high - low)


def _volume_ratio(row: dict) -> float:
    return (row.get("volume") or 0.0) / max(row.get("volume_ma20") or 0.0, 1.0)


def parabolic_exhaustion_signal(rows: list[dict], index: int) -> bool:
    if index < 25:
        return False
    row = rows[index]
    recent_run = engine.recent_10bar_change_fraction(rows, index) or 0.0
    bb_position = row.get("bb_position_0_1")
    prior = rows[max(0, index - PARABOLIC_CLIMAX_LOOKBACK):index]
    if not prior:
        return False
    climax_high = row["high"] >= max(item["high"] for item in prior) * 0.999
    reversal = row["close"] < row["open"] and _bar_close_position(row) <= PARABOLIC_MAX_BAR_CLOSE_POSITION
    return (
        recent_run >= PARABOLIC_MIN_10BAR_RUN
        and (bb_position is None or bb_position >= PARABOLIC_MIN_BB_POSITION)
        and climax_high
        and reversal
        and _volume_ratio(row) >= PARABOLIC_MIN_VOLUME_RATIO
    )


def volume_blowoff_signal(rows: list[dict], index: int) -> bool:
    if index < 25:
        return False
    row = rows[index]
    recent_run = engine.recent_10bar_change_fraction(rows, index) or 0.0
    reversal = row["close"] < row["open"] and _bar_close_position(row) <= BLOWOFF_MAX_BAR_CLOSE_POSITION
    return (
        _volume_ratio(row) >= BLOWOFF_MIN_VOLUME_RATIO
        and recent_run >= BLOWOFF_MIN_10BAR_RUN
        and reversal
    )


SETUPS = {
    "Parabolic Exhaustion Short": parabolic_exhaustion_signal,
    "Volume Blow-off Short": volume_blowoff_signal,
}


def common_short_ok(rows: list[dict], index: int) -> bool:
    row = rows[index]
    if engine.liquidity_notional(row) < MIN_NOTIONAL_1M_USD:
        return False
    close = row.get("close") or 0.0
    if engine.spread_fraction(row) > (0.0125 if close < 2.0 else 0.0085):
        return False
    range_fraction = max(0.0, (row.get("range_pct") or 0.0) / 100.0)
    recent_move = abs(engine.recent_10bar_change_fraction(rows, index) or 0.0)
    reachable = max(range_fraction * 0.5, recent_move * 0.4)
    return reachable >= engine.estimated_roundtrip_cost_fraction(row) + MIN_EXPECTED_EDGE_PCT


def _fee(side: str, quantity: int, price: float) -> float:
    return float(
        engine.toss_fee_breakdown(side=side, quantity=quantity, price=price, settings=engine.get_settings())[
            "total_fees_usd"
        ]
    )


def _short_entry_price(row: dict) -> float:
    base = row.get("first_bid") or row.get("avg_bid") or row["close"] * (1 - engine.spread_fraction(row) / 2)
    return base * (1 - ENTRY_SLIPPAGE_PCT)


def _cover_price(row: dict, *, stop_level: float | None = None) -> float:
    if stop_level is not None:
        return stop_level * (1 + min(STOP_SLIPPAGE_PCT, STOP_SLIPPAGE_CAP_PCT))
    base = row.get("first_ask") or row.get("avg_ask") or row["close"] * (1 + engine.spread_fraction(row) / 2)
    return base * (1 + EXIT_SLIPPAGE_PCT)


def _simulate_short(rows: list[dict], entry_index: int) -> dict | None:
    entry_price = _short_entry_price(rows[entry_index])
    quantity = int(MAX_NOTIONAL_PER_TRADE / entry_price)
    if quantity < 1 or entry_price <= 0:
        return None
    stop_price = entry_price * (1 + FINAL_STOP_PCT)
    low_watermark = entry_price
    trailing_stop: float | None = None
    entry_fees = _fee("sell", quantity, entry_price)
    for j in range(entry_index, min(entry_index + MAX_HOLD_BARS + 1, len(rows))):
        row = rows[j]
        high = row.get("high") or 0.0
        low = row.get("low") or low_watermark
        low_watermark = min(low_watermark, low)
        profit_pct = (entry_price - (row.get("close") or entry_price)) / entry_price
        reason = cover = None
        if high >= stop_price:
            reason, cover = "hard_stop_loss", _cover_price(row, stop_level=stop_price)
        else:
            if profit_pct >= TRAILING_ACTIVATE_PCT:
                trailing_stop = low_watermark * (1 + TRAILING_WIDTH_PCT)
            if trailing_stop is not None and high >= trailing_stop:
                reason, cover = "trailing_stop", trailing_stop * (1 + EXIT_SLIPPAGE_PCT)
            elif j - entry_index >= MAX_HOLD_BARS:
                reason, cover = "time_exit", _cover_price(row)
        if reason is None and j == len(rows) - 1:
            reason, cover = "eow_close", _cover_price(row)
        if reason is not None:
            exit_fees = _fee("buy", quantity, cover)
            gross = (entry_price - cover) * quantity
            net = gross - entry_fees - exit_fees
            return {
                "entry_index": entry_index,
                "exit_index": j,
                "quantity": quantity,
                "entry_price": round(entry_price, 6),
                "cover_price": round(cover, 6),
                "gross_pnl": round(gross, 4),
                "fees": round(entry_fees + exit_fees, 4),
                "net_pnl": round(net, 4),
                "return_pct": round((entry_price - cover) / entry_price * 100, 4),
                "exit_reason": reason,
            }
    return None


def replay_window(rows: list[dict], signal) -> list[dict]:
    """Independent shadow replay for one setup's signal."""
    trades: list[dict] = []
    last_exit_index = -REENTRY_COOLDOWN_BARS - 1
    for index in range(len(rows) - 1):
        if index - last_exit_index < REENTRY_COOLDOWN_BARS:
            continue
        if signal(rows, index) and common_short_ok(rows, index):
            trade = _simulate_short(rows, index + 1)
            if trade is not None:
                trade["signal_index"] = index
                trades.append(trade)
                last_exit_index = trade["exit_index"]
    return trades


def _split_of(date: str) -> str:
    return "train" if date in TRAIN_DATES else "holdout"


def _summarize(trades: list[dict]) -> dict:
    nets = [t["net_pnl"] for t in trades]
    wins = [n for n in nets if n > 0]
    return {
        "trades": len(nets),
        "wins": len(wins),
        "win_pct": round(len(wins) / len(nets) * 100, 2) if nets else 0.0,
        "net_pnl_usd": round(sum(nets), 4),
        "return_pct_on_2000": round(sum(nets) / 2000.0 * 100, 4),
    }


def main() -> None:
    files = sorted(REPLAY_DIR.glob("session_*/*_enriched.csv"))
    windows: list[tuple[str, str, list[dict]]] = []
    for path_file in files:
        match = FILENAME_RE.match(path_file.name)
        if not match:
            continue
        symbol, date = match.group(1).upper(), match.group(2)
        windows.append((symbol, date, engine.load_rows(path_file)))

    all_trades: list[dict] = []
    per_setup: dict[str, dict] = {}
    for setup_name, signal in SETUPS.items():
        by_split: dict[str, list[dict]] = {"train": [], "holdout": []}
        for symbol, date, rows in windows:
            for trade in replay_window(rows, signal):
                trade = {"setup": setup_name, "symbol": symbol, "date": date, "split": _split_of(date), **trade}
                by_split[_split_of(date)].append(trade)
                all_trades.append(trade)
        per_setup[setup_name] = {"train": _summarize(by_split["train"]), "holdout": _summarize(by_split["holdout"])}

    combined = {sp: _summarize([t for t in all_trades if t["split"] == sp]) for sp in ("train", "holdout")}
    combined["total"] = _summarize(all_trades)

    report = {
        "track": "Extreme-fade Short (short-only, live blocked, research)",
        "note": "walk-forward; small sample; treat as research until confirmed forward",
        "setups": per_setup,
        "combined": combined,
    }
    summary_path = REPLAY_DIR / "extreme_shorts_replay_summary.json"
    trades_path = REPLAY_DIR / "extreme_shorts_replay_trades.csv"
    summary_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if all_trades:
        fields = list(all_trades[0].keys())
        with trades_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(all_trades)

    print("Extreme-fade Short track -- research replay (short-only, live blocked)")
    for setup_name, s in per_setup.items():
        print(f"  [{setup_name}]")
        for split in ("train", "holdout"):
            r = s[split]
            print(f"    {split:8} trades={r['trades']:3}  win={r['win_pct']:5.1f}%  net=${r['net_pnl_usd']:+8.2f}")
    print("  [COMBINED]")
    for split in ("train", "holdout", "total"):
        r = combined[split]
        print(f"    {split:8} trades={r['trades']:3}  win={r['win_pct']:5.1f}%  "
              f"net=${r['net_pnl_usd']:+8.2f}  ret={r['return_pct_on_2000']:+.2f}%")
    print(f"summary : {summary_path.relative_to(PROJECT_ROOT)}")
    print(f"trades  : {trades_path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
