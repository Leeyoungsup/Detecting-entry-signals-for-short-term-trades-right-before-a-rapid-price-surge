import asyncio
from contextlib import suppress
from datetime import datetime, timezone

from app.core.config import get_settings
from app.domain.enums import RealtimeEventType, StatusLevel
from app.services.event_bus import event_bus
from app.services.event_log import record_event
from app.services.market_data import get_market_data_service
from app.services.market_session import us_equity_session
from app.services.scanner import ScannerService
from app.services import shared_state
from app.services import realtime_state
from app.services import toss_flow_recorder
from app.services.short_runtime import short_track_runtime
from app.services.strategy_runtime import strategy_runtime

RUNTIME_STATUS_KEY = "trading_lab:runtime:status"
RUNTIME_SYSTEM_STATUS_KEY = "trading_lab:runtime:system_status"
LEGACY_RUNTIME_STATUS_KEY = "kis:runtime:status"
LEGACY_RUNTIME_SYSTEM_STATUS_KEY = "kis:runtime:system_status"
RUNTIME_STATUS_TTL_SEC = 180


class RuntimeSupervisor:
    def __init__(self) -> None:
        self._scanner_task: asyncio.Task | None = None
        self._position_task: asyncio.Task | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._flow_recorder_task: asyncio.Task | None = None
        self._last_tick_at: str | None = None
        self._last_error: str | None = None
        self._last_position_tick_at: str | None = None
        self._last_position_error: str | None = None
        self._last_position_result: dict | None = None

    def start(self) -> None:
        settings = get_settings()
        if not settings.scanner_background_loop_enabled:
            return
        started = False
        if not self._scanner_task or self._scanner_task.done():
            self._scanner_task = asyncio.create_task(self._run_scanner_loop(), name="scanner-runtime-supervisor")
            started = True
        if not self._heartbeat_task or self._heartbeat_task.done():
            self._heartbeat_task = asyncio.create_task(self._run_status_heartbeat_loop(), name="runtime-status-heartbeat")
            started = True
        position_loop_enabled = settings.toss_position_quote_monitor_enabled or settings.trading_mode == "live"
        if position_loop_enabled and (not self._position_task or self._position_task.done()):
            self._position_task = asyncio.create_task(self._run_position_quote_loop(), name="toss-position-quote-monitor")
            started = True
        # Toss per-minute order-flow recorder. realtime_runtime._run (which also calls this)
        # only runs in the standalone realtime_worker process; in the combined role the poll
        # loop is driven by the scanner here, so record flow from this supervisor too.
        if not self._flow_recorder_task or self._flow_recorder_task.done():
            self._flow_recorder_task = asyncio.create_task(self._run_flow_recorder_loop(), name="toss-flow-recorder")
            started = True
        if not started:
            return
        record_event(
            level="INFO",
            event_type="runtime.supervisor_started",
            message="백그라운드 scanner/strategy/Toss 포지션 감시 루프를 시작했습니다.",
            severity=StatusLevel.NORMAL,
            payload={
                "scanner_interval_sec": settings.scanner_background_loop_interval_sec,
                "position_quote_interval_sec": settings.toss_position_quote_interval_sec,
                "position_quote_max_symbols_per_tick": settings.toss_position_quote_max_symbols_per_tick,
            },
        )

    async def stop(self) -> None:
        tasks = [task for task in (self._scanner_task, self._position_task, self._heartbeat_task, self._flow_recorder_task) if task]
        if not tasks:
            return
        for task in tasks:
            task.cancel()
        for task in tasks:
            with suppress(asyncio.CancelledError):
                await task
        self._scanner_task = None
        self._position_task = None
        self._heartbeat_task = None
        self._flow_recorder_task = None
        record_event(
            level="INFO",
            event_type="runtime.supervisor_stopped",
            message="백그라운드 scanner/strategy/Toss 포지션 감시 루프를 중지했습니다.",
            severity=StatusLevel.NORMAL,
        )

    def status(self) -> dict:
        local_status = {
            "running": bool(
                (self._scanner_task and not self._scanner_task.done())
                or (self._position_task and not self._position_task.done())
                or (self._heartbeat_task and not self._heartbeat_task.done())
            ),
            "last_tick_at": self._last_tick_at,
            "last_error": self._last_error,
            "position_quote_monitor": {
                "running": bool(self._position_task and not self._position_task.done()),
                "last_tick_at": self._last_position_tick_at,
                "last_error": self._last_position_error,
                "last_result": self._last_position_result,
            },
        }
        if local_status["running"]:
            return local_status
        shared = shared_state.get_json_any(RUNTIME_STATUS_KEY, LEGACY_RUNTIME_STATUS_KEY)
        return shared if isinstance(shared, dict) else local_status

    async def _run_flow_recorder_loop(self) -> None:
        """Record Toss per-minute order-flow (trade_strength, sell_pressure, imbalance, volumes)
        to exports/toss_flow for offline analysis / model training. Fully guarded; never trades."""
        while True:
            try:
                provider = get_market_data_service().provider
                snapshot = provider.order_flow_snapshot()
                prices = provider.latest_prices() if hasattr(provider, "latest_prices") else None
                toss_flow_recorder.record_flow(snapshot, prices)
            except asyncio.CancelledError:
                raise
            except Exception:
                pass
            await asyncio.sleep(2.0)

    async def _run_scanner_loop(self) -> None:
        service = ScannerService()
        while True:
            settings = get_settings()
            try:
                self._publish_runtime_status(scope="scanner_runtime_before_tick")
                await service.maintenance_tick()
                self._last_tick_at = datetime.now(timezone.utc).isoformat()
                self._last_error = None
                self._publish_runtime_status(scope="scanner_runtime")
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self._last_error = str(exc)[:300]
                record_event(
                    level="INFO",
                    event_type="runtime.supervisor_tick_failed",
                    message="백그라운드 scanner/strategy 감시 루프 tick 실패",
                    severity=StatusLevel.CAUTION,
                    payload={"reason": self._last_error},
                )
                self._publish_runtime_status(scope="scanner_runtime_failed")
            await asyncio.sleep(max(1, settings.scanner_background_loop_interval_sec))

    async def _run_position_quote_loop(self) -> None:
        while True:
            settings = get_settings()
            try:
                if settings.toss_position_quote_monitor_enabled or settings.trading_mode == "live":
                    self._last_position_result = await asyncio.to_thread(strategy_runtime.monitor_open_positions)
                    self._last_position_tick_at = datetime.now(timezone.utc).isoformat()
                    self._last_position_error = None
                    self._publish_runtime_status(scope="position_quote_monitor")
                # Short-track exit monitoring is self-gated (short track enabled +
                # internal_paper) and runs independently of the long position monitor.
                if settings.strategy_short_track_enabled and settings.trading_mode == "internal_paper":
                    await asyncio.to_thread(short_track_runtime.monitor_short_exits)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self._last_position_error = str(exc)[:300]
                record_event(
                    level="INFO",
                    event_type="runtime.position_quote_tick_failed",
                    message="Toss 보유종목 호가 감시 루프 tick 실패",
                    severity=StatusLevel.CAUTION,
                    payload={"reason": self._last_position_error},
                )
            await asyncio.sleep(max(0.5, float(settings.toss_position_quote_interval_sec)))

    async def _run_status_heartbeat_loop(self) -> None:
        while True:
            try:
                self._publish_runtime_status(scope="heartbeat")
            except asyncio.CancelledError:
                raise
            except Exception:
                pass
            await asyncio.sleep(1.0)

    def _publish_runtime_status(self, *, scope: str) -> None:
        try:
            ws_status = realtime_state.realtime_status() or get_market_data_service().provider.realtime_status()
        except Exception:
            ws_status = {}
        status_payload = self.status()
        shared_state.set_json(RUNTIME_STATUS_KEY, status_payload, ex=RUNTIME_STATUS_TTL_SEC)
        payload = {
            "scope": scope,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "runtime_supervisor": status_payload,
            "websocket": ws_status,
            "data_freshness": {
                "last_ws_message_at": ws_status.get("last_message_at"),
                "last_realtime_at": ws_status.get("last_realtime_at"),
                "last_trade_at": ws_status.get("last_trade_at"),
                "last_quote_at": ws_status.get("last_quote_at"),
                "state": _data_freshness_state(ws_status),
                "trade_state": _tick_freshness_state(ws_status.get("last_trade_at"), ws_status=ws_status),
                "quote_state": _tick_freshness_state(ws_status.get("last_quote_at"), ws_status=ws_status),
            },
            "session": us_equity_session(),
        }
        shared_state.set_json(RUNTIME_SYSTEM_STATUS_KEY, payload, ex=RUNTIME_STATUS_TTL_SEC)
        event_bus.publish(
            RealtimeEventType.SYSTEM_STATUS,
            payload,
            status_level=StatusLevel.NORMAL,
        )


runtime_supervisor = RuntimeSupervisor()


def _data_freshness_state(ws_status: dict) -> str:
    if ws_status.get("status") == "error":
        return "BLOCKED"
    return _tick_freshness_state(ws_status.get("last_realtime_at"), ws_status=ws_status)


def _tick_freshness_state(value: object, *, ws_status: dict) -> str:
    if not value:
        return "CAUTION" if ws_status.get("status") in ("starting", "connected") else "BLOCKED"
    parsed = _parse_ws_time(value)
    if parsed is None:
        return "CAUTION"
    max_age = max(15, int(get_settings().scanner_realtime_stale_restart_sec or 90))
    age_sec = (datetime.now(timezone.utc) - parsed).total_seconds()
    if age_sec <= max_age:
        return "NORMAL"
    return "CAUTION" if ws_status.get("status") in ("starting", "connected") else "BLOCKED"


def _parse_ws_time(value: object) -> datetime | None:
    raw = str(value or "")
    if not raw:
        return None
    if raw.endswith("Z"):
        raw = f"{raw[:-1]}+00:00"
    if "." in raw:
        head, tail = raw.split(".", 1)
        fraction = tail
        zone = ""
        for marker in ("+", "-"):
            if marker in tail:
                fraction, zone = tail.split(marker, 1)
                zone = marker + zone
                break
        raw = f"{head}.{fraction[:6]}{zone}"
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)
