from fastapi import APIRouter, Query

from app.domain.models import StructuredLogEvent
from app.services.event_log import ensure_boot_event, list_events

router = APIRouter()


@router.get("")
def logs(
    limit: int = Query(default=200, ge=1, le=1000),
    event_type: str | None = Query(default=None),
    symbol: str | None = Query(default=None),
    order_id: str | None = Query(default=None),
    severity: str | None = Query(default=None),
    correlation_id: str | None = Query(default=None),
    important_only: bool = Query(default=True),
    include_noise: bool = Query(default=False),
) -> dict:
    ensure_boot_event()
    events = list_events(
        limit=limit,
        event_type=event_type,
        symbol=symbol,
        order_id=order_id,
        severity=severity,
        correlation_id=correlation_id,
    )
    if event_type is None and not include_noise:
        events = [event for event in events if not _is_noisy_event(event)]
    if important_only and event_type is None:
        events = [event for event in events if _is_important_event(event)]
    return {"logs": [event.model_dump(mode="json") for event in events]}


def _is_noisy_event(event: StructuredLogEvent) -> bool:
    if event.event_type == "strategy.signal_evaluation":
        return not _strategy_signal_passed(event)

    noisy = {
        "strategy.waiting_for_candles",
        "scanner.session_paused",
        "runtime.supervisor_started",
        "runtime.supervisor_stopped",
        "scanner.snapshot",
    }
    return event.event_type in noisy


def _is_important_event(event: StructuredLogEvent) -> bool:
    if event.event_type == "strategy.signal_evaluation":
        return _strategy_signal_passed(event)

    if event.severity in {"CAUTION", "BLOCKED", "EMERGENCY"}:
        return True
    prefixes = (
        "live.",
        "paper.",
        "scanner.realtime",
        "scanner.minute_seed",
        "runtime.supervisor_tick_failed",
        "platform.boot",
    )
    return event.event_type.startswith(prefixes)


def _strategy_signal_passed(event: StructuredLogEvent) -> bool:
    return bool(event.payload.get("passed") or event.payload.get("entry_allowed"))
