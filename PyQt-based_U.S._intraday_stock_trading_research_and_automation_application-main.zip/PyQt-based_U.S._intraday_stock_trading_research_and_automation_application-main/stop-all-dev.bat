@echo off
setlocal
cd /d "%~dp0"
call scripts\stop-all-dev.cmd
echo.
echo All managed dev server stop command complete.
