import asyncio
import threading
from collections import deque
from datetime import datetime, timedelta, timezone
from typing import Any

from app.adapters.market_data.base import MarketDataUnavailableError
from app.adapters.toss.client import TossApiError, TossExecutionClient
from app.core.config import Settings


class TossMarketDataProvider:
    provider_name = "toss"

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.client = TossExecutionClient(settings)
        self._task: asyncio.Task | None = None
        self._status = "stopped"
        self._last_error: str | None = None
        self._last_message_at: str | None = None
        self._last_realtime_at: str | None = None
        self._last_trade_at: str | None = None
        self._last_quote_at: str | None = None
        self._started_at: str | None = None
        # Guards the shared stream state below (mutated by concurrent poll
        # threads via asyncio.to_thread, read by the main loop). RLock so a
        # locked writer can call back in without deadlocking.
        self._lock = threading.RLock()
        self._events: deque[dict] = deque(maxlen=3000)
        self._latest_quotes: dict[str, dict] = {}
        self._latest_trades: dict[str, dict] = {}
        self._latest_prices: dict[str, dict] = {}
        self._seen_trade_keys: deque[tuple] = deque(maxlen=3000)
        self._seen_trade_key_set: set[tuple] = set()
        self._subscriptions: set[str] = set()
        self._invalid_symbols: set[str] = set()
        self._subscription_rank: dict[str, int] = {}
        self._subscription_started_at: dict[str, datetime] = {}
        self._subscribe_quotes = True
        self._subscribe_trades = True
        self._poll_index = 0
        self._quote_poll_index = 0
        self._trade_poll_index = 0
        self._last_symbol_detail_event_at: dict[str, float] = {}
        self._last_data_error: str | None = None

    def status(self) -> dict:
        configured = bool(self.settings.toss_app_key and self.settings.toss_app_secret)
        return {
            "provider": self.provider_name,
            "provider_display_name": "Toss OpenAPI Market Data",
            "configured": configured,
            "status": "configured" if configured else "credentials_missing",
            "environment": self.settings.toss_environment,
            "rest_base_url": self.settings.toss_base_url,
            "last_data_error": self._last_data_error,
            "message": (
                "Toss OpenAPI market data configured."
                if configured
                else "TOSS_APP_KEY/TOSS_APP_SECRET is required for Toss market data."
            ),
            "checked_at": _now_iso(),
        }

    def scanner_rankings(self, exchange: str = "NAS") -> dict:
        del exchange
        self._last_data_error = None
        output_limit = max(1, min(int(self.settings.scanner_max_websocket_symbols or 30), 100))
        seed_limit = max(
            output_limit,
            min(int(self.settings.scanner_candidate_universe_size or 100), 100),
        )
        seed_rows, stock_meta = self._toss_seed_rows(limit=seed_limit)
        symbols = [str(row.get("symb") or "").upper() for row in seed_rows if row.get("symb")]
        prices = self._prices_for_symbols(symbols)

        rows: list[dict] = []
        for index, symbol in enumerate(symbols, start=1):
            active = next((row for row in seed_rows if row.get("symb") == symbol), {})
            meta = stock_meta.get(symbol) or {}
            price_row = prices.get(symbol) or {}
            latest_price = _to_float(price_row.get("lastPrice") or price_row.get("price")) or _to_float(active.get("last"))
            latest_price_at = _normalize_time(price_row.get("timestamp"))
            rows.append(
                {
                    "symb": symbol,
                    "company_name": meta.get("name") or active.get("company_name"),
                    "industry": active.get("industry"),
                    "market_cap_usd": active.get("market_cap_usd"),
                    "market_cap_krw": active.get("market_cap_krw"),
                    "toss_trade_amount_krw": active.get("toss_trade_amount_krw"),
                    "toss_trade_volume": active.get("toss_trade_volume"),
                    "toss_buy_volume": active.get("toss_buy_volume"),
                    "toss_sell_volume": active.get("toss_sell_volume"),
                    "toss_buy_ratio_pct": active.get("toss_buy_ratio_pct"),
                    "asset_class": "us_equity",
                    "asset_status": str(meta.get("status") or "ACTIVE").lower(),
                    "asset_tradable": True,
                    "asset_name": meta.get("name") or active.get("company_name"),
                    "asset_type": meta.get("securityType"),
                    "is_common_stock": _is_common_stock(meta),
                    "rank": index,
                    "trade_volume_rank": index,
                    "volume_1m": None,
                    "volume_10m": None,
                    "tvol": active.get("toss_trade_volume"),
                    "daily_volume": active.get("toss_trade_volume"),
                    "trade_count": None,
                    "screener_source": active.get("screener_source") or "toss_rankings_api",
                    "toss_wts_rank": active.get("toss_wts_rank") or active.get("rank") or index,
                    "toss_wts_notional": active.get("toss_wts_notional"),
                    "last": latest_price or active.get("last"),
                    "prev_close_price": active.get("prev_close_price"),
                    "day_change_pct": active.get("day_change_pct"),
                    "notional_1m": None,
                    "notional_10m": None,
                    "notional_velocity_10s": None,
                    "change_1m_pct": None,
                    "change_10m_pct": None,
                    "latest_bar_at": None,
                    "latest_trade_at": None,
                    "latest_quote_at": None,
                    "latest_bar_age_sec": None,
                    "latest_activity_age_sec": _age_seconds(latest_price_at),
                    "volume_source": active.get("volume_source") or "toss_rankings_api",
                    "market_data_error": None,
                    "realtime_bootstrap_candidate": True,
                }
            )
        rows = rows[:seed_limit]
        for index, row in enumerate(rows, start=1):
            row["rank"] = index
            row["trade_notional_rank"] = row.get("toss_wts_rank") or index
            row["trade_volume_rank"] = index
            row["volume_surge_rank"] = index
            row["realtime_liquidity_rank"] = None
            row["scanner_score"] = max(0.0, 101.0 - float(row.get("toss_wts_rank") or index))
            row["volume_score"] = row["scanner_score"]
            row["liquidity_impulse_score"] = row["scanner_score"]
        return {
            "trade_volume": {"output2": rows[:seed_limit]},
            "volume_surge": {"output2": rows[:seed_limit]},
            "trade_strength": {"output2": []},
            "_meta": {"market_data_error": self._last_data_error, "feed": "toss_openapi"},
        }

    async def start_realtime(
        self,
        *,
        symbols: list[str],
        exchange: str = "NAS",
        key_mode: str = "regular",
        subscribe_quotes: bool = True,
        subscribe_trades: bool = True,
    ) -> dict:
        del exchange, key_mode
        self._ensure_credentials()
        if self._task and not self._task.done():
            await self.stop_realtime()
        self._subscribe_quotes = subscribe_quotes
        self._subscribe_trades = subscribe_trades
        ordered = self._valid_symbols(_dedupe_upper(symbols))
        self._subscriptions = set(ordered)
        self._subscription_rank = {symbol: index for index, symbol in enumerate(ordered)}
        now = datetime.now(timezone.utc)
        self._subscription_started_at = {symbol: now for symbol in self._subscriptions}
        self._latest_quotes.clear()
        with self._lock:
            self._latest_trades.clear()
            self._latest_prices.clear()
            self._seen_trade_keys.clear()
            self._seen_trade_key_set.clear()
            self._events.clear()
        self._status = "starting"
        self._last_error = None
        self._last_realtime_at = None
        self._last_trade_at = None
        self._last_quote_at = None
        self._started_at = _now_iso()
        self._task = asyncio.create_task(self._run_polling(), name="toss-market-data-polling")
        await asyncio.sleep(0.2)
        return self.realtime_status()

    async def update_realtime(
        self,
        *,
        symbols: list[str],
        exchange: str = "NAS",
        key_mode: str = "regular",
        subscribe_quotes: bool = True,
        subscribe_trades: bool = True,
    ) -> dict:
        del exchange, key_mode
        self._ensure_credentials()
        ordered = self._valid_symbols(_dedupe_upper(symbols))
        desired = set(ordered)
        if self._status not in ("starting", "connected") or not self._task or self._task.done():
            return await self.start_realtime(
                symbols=ordered,
                subscribe_quotes=subscribe_quotes,
                subscribe_trades=subscribe_trades,
            )
        removed = set(self._subscriptions) - desired
        added = desired - set(self._subscriptions)
        self._subscriptions = desired
        self._subscription_rank = {symbol: index for index, symbol in enumerate(ordered)}
        self._subscribe_quotes = subscribe_quotes
        self._subscribe_trades = subscribe_trades
        now = datetime.now(timezone.utc)
        for symbol in added:
            self._subscription_started_at[symbol] = now
        for symbol in removed:
            self._latest_quotes.pop(symbol, None)
            self._latest_trades.pop(symbol, None)
            self._latest_prices.pop(symbol, None)
            self._subscription_started_at.pop(symbol, None)
        return self.realtime_status()

    async def stop_realtime(self) -> dict:
        self._status = "stopping"
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        self._status = "stopped"
        return self.realtime_status()

    def realtime_status(self) -> dict:
        return {
            "status": self._status,
            "environment": "external",
            "provider": self.provider_name,
            "feed": "polling",
            "url": self.settings.toss_base_url,
            "subscription_count": len(self._subscriptions),
            "invalid_symbols": sorted(self._invalid_symbols),
            "last_message_at": self._last_message_at,
            "last_realtime_at": self._last_realtime_at,
            "last_trade_at": self._last_trade_at,
            "last_quote_at": self._last_quote_at,
            "last_error": self._last_error,
            "started_at": self._started_at,
            "event_count": len(self._events),
            "latest_quote_symbols": sorted(self._latest_quotes.keys()),
            "latest_trade_symbols": sorted(self._latest_trades.keys()),
            "candidate_warmup_sec": self.settings.scanner_candidate_warmup_sec,
            "subscription_age_sec": {
                symbol: self._subscription_age_sec(symbol)
                for symbol in sorted(self._subscriptions)
            },
        }

    def realtime_snapshot(self) -> dict:
        return {
            "status": self.realtime_status(),
            "quotes": self._latest_quotes,
            "trades": self._latest_trades,
            "prices": self._latest_prices,
            "recent_events": self.recent_events(50),
        }

    def subscribed_symbols(self) -> set[str]:
        if self._status not in ("starting", "connected"):
            return set()
        return set(self._valid_symbols(sorted(self._subscriptions)))

    def latest_prices(self) -> dict[str, dict]:
        """Latest per-symbol price from the 1s batched /prices poll (see _poll_prices_batch)."""
        return dict(self._latest_prices)

    def order_flow_snapshot(self) -> dict[str, dict]:
        stats = {symbol: _empty_flow(symbol) for symbol in self.subscribed_symbols()}
        now = datetime.now(timezone.utc)
        previous_trade_price: dict[str, float] = {}
        # Concurrent poll threads mutate self._events; take a consistent snapshot
        # under the lock, then iterate the snapshot outside it.
        with self._lock:
            events_snapshot = list(self._events)
        for event in events_snapshot:
            symbol = event.get("symbol")
            if not symbol or event.get("event_type") not in ("quote", "trade"):
                continue
            flow = stats.setdefault(symbol, _empty_flow(symbol))
            received = _parse_dt(event.get("received_at"))
            age_sec = (now - received).total_seconds() if received else None
            if age_sec is not None:
                flow["last_update_age_sec"] = age_sec if flow["last_update_age_sec"] is None else min(flow["last_update_age_sec"], age_sec)
            if event["event_type"] == "quote":
                flow["quote"] = event
                flow["spread_pct"] = event.get("spread_pct")
                flow["bid_ask_imbalance"] = event.get("bid_ask_imbalance")
                continue
            flow["trade"] = event
            flow["spread_pct"] = flow.get("spread_pct") or event.get("spread_pct")
            volume = _to_float(event.get("trade_volume")) or 0.0
            price = _to_float(event.get("last"))
            side = _trade_side(price=price, quote=flow.get("quote"), previous_price=previous_trade_price.get(symbol))
            if side == "buy":
                flow["aggressive_buy_volume"] += volume
            elif side == "sell":
                flow["aggressive_sell_volume"] += volume
            else:
                flow["unknown_trade_volume"] += volume
            if price is not None:
                previous_trade_price[symbol] = price
            if age_sec is None:
                continue
            if 0 <= age_sec <= 10:
                flow["volume_10s"] += volume
            elif 10 < age_sec <= 20:
                flow["volume_prev_10s"] += volume
            if 0 <= age_sec <= 30:
                flow["volume_30s"] += volume
            if 0 <= age_sec <= 60:
                flow["volume_60s"] += volume
        for flow in stats.values():
            prev = flow.pop("volume_prev_10s")
            flow["volume_velocity_10s"] = flow["volume_10s"] / prev if prev and prev > 0 else None
            directional_volume = flow["aggressive_buy_volume"] + flow["aggressive_sell_volume"]
            if directional_volume > 0:
                flow["trade_strength"] = flow["aggressive_buy_volume"] / directional_volume * 100
                flow["sell_pressure"] = flow["aggressive_sell_volume"] / directional_volume
        return stats

    def recent_events(self, limit: int = 100) -> list[dict]:
        with self._lock:
            return list(self._events)[-limit:]

    def price(self, symbol: str, exchange: str = "NAS") -> dict:
        del exchange
        try:
            rows = self.client.prices(symbols=[symbol.upper()])
        except TossApiError as exc:
            raise MarketDataUnavailableError(str(exc)) from exc
        row = rows[0] if rows else {}
        return {"output": {"last": row.get("price") or row.get("last") or row.get("closePrice"), "source": "toss_prices", "received_at": row.get("timestamp")}}

    def quote(self, symbol: str, exchange: str = "NAS") -> dict:
        del exchange
        try:
            quote = self.client.orderbook_quote(symbol=symbol.upper(), max_cache_age_sec=0.0)
        except TossApiError as exc:
            raise MarketDataUnavailableError(str(exc)) from exc
        return {
            "output1": {},
            "output2": {
                "pbid1": quote.get("bid") or quote.get("best_bid"),
                "pask1": quote.get("ask") or quote.get("best_ask"),
                "vbid1": quote.get("bid_depth"),
                "vask1": quote.get("ask_depth"),
                "source": "toss_orderbook",
                "received_at": quote.get("received_at"),
            },
        }

    def minute_bars(self, symbol: str, exchange: str = "NAS", interval: str = "1", limit: int = 120) -> dict:
        del exchange
        if str(interval) != "1":
            raise MarketDataUnavailableError("Toss OpenAPI supports 1-minute candles through this provider.")
        try:
            rows = self.client.candles(symbol=symbol.upper(), interval="1m", count=limit)
        except TossApiError as exc:
            raise MarketDataUnavailableError(str(exc)) from exc
        return {"output2": [_toss_candle_to_provider_bar(symbol.upper(), row, interval="1m") for row in rows]}

    def minute_bars_history(
        self,
        symbol: str,
        exchange: str = "NAS",
        interval: str = "1",
        target_date: str | None = None,
        max_pages: int = 20,
    ) -> dict:
        del max_pages
        if target_date:
            now_utc = datetime.now(timezone.utc)
            today_dates = {now_utc.strftime("%Y%m%d"), (now_utc + timedelta(hours=9)).strftime("%Y%m%d")}
            if target_date not in today_dates:
                raise MarketDataUnavailableError(
                    "Toss OpenAPI historical 1-minute candle lookup is not verified for past dates. "
                    "Use current-session candles or replay data instead."
                )
        return self.minute_bars(symbol=symbol, exchange=exchange, interval=interval, limit=200)

    def daily_bars(
        self,
        symbol: str,
        exchange: str = "NAS",
        period: str = "0",
        bymd: str = "",
        adjusted: bool = True,
        max_pages: int = 5,
    ) -> dict:
        del exchange, period, bymd, adjusted, max_pages
        try:
            rows = self.client.candles(symbol=symbol.upper(), interval="1d", count=200)
        except TossApiError as exc:
            raise MarketDataUnavailableError(str(exc)) from exc
        return {"output2": [_toss_candle_to_provider_bar(symbol.upper(), row, interval="1d") for row in rows]}

    async def _run_polling(self) -> None:
        self._status = "connected"
        try:
            while True:
                started_at = datetime.now(timezone.utc)
                symbols = self._valid_symbols(sorted(self._subscriptions))
                if not symbols:
                    await asyncio.sleep(0.5)
                    continue
                priority_symbols = self._priority_symbols(symbols)
                tasks = []
                if self._subscribe_quotes:
                    for symbol in self._next_quote_symbols(priority_symbols):
                        tasks.append(asyncio.to_thread(self._poll_quote_symbol, symbol))
                if self._subscribe_trades:
                    for symbol in self._next_trade_symbols(priority_symbols):
                        tasks.append(asyncio.to_thread(self._poll_trade_symbol, symbol))
                if self.settings.toss_realtime_price_refresh_enabled:
                    tasks.append(asyncio.to_thread(self._poll_prices_batch, symbols))
                if tasks:
                    await asyncio.gather(*tasks, return_exceptions=True)
                elapsed = (datetime.now(timezone.utc) - started_at).total_seconds()
                await asyncio.sleep(max(0.05, 1.0 - elapsed))
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._last_error = str(exc)[:300]
            self._status = "error"
            with self._lock:
                self._events.append({"event_type": "poll_error", "message": self._last_error, "received_at": _now_iso()})
        finally:
            if self._status not in ("error", "stopping", "stopped"):
                self._status = "stopped"

    def _priority_symbols(self, symbols: list[str]) -> list[str]:
        """Restrict orderbook/trade round-robin polling to what actually needs freshness.

        Open paper positions always qualify (exit decisions need live spreads), plus the
        top-ranked scanner candidates up to toss_realtime_microstructure_top_n. Everything
        else in `symbols` still gets a coarse last-price update via _poll_prices_batch, just
        not the per-symbol orderbook/trade calls, so MARKET_DATA usage stays flat instead of
        scaling with the size of the subscribed universe.
        """
        top_n = int(self.settings.toss_realtime_microstructure_top_n or 0)
        ranked = sorted(
            self._valid_symbols(symbols),
            key=lambda symbol: self._subscription_rank.get(symbol, len(symbols)),
        )
        if top_n <= 0:
            return ranked
        priority = ranked[:top_n]
        seen = set(priority)
        for symbol in ranked[top_n:]:
            if symbol not in seen and _has_active_paper_position(symbol):
                priority.append(symbol)
                seen.add(symbol)
        return priority

    def _poll_prices_batch(self, symbols: list[str]) -> None:
        symbols = self._valid_symbols(symbols)
        if not symbols:
            return
        try:
            rows = self.client.prices(symbols=symbols)
        except TossApiError as exc:
            if _is_stock_not_found_error(exc):
                self._poll_prices_individually(symbols)
                return
            self._record_poll_error("*", "prices_batch", exc)
            return
        except Exception as exc:
            self._record_poll_error("*", "prices_batch", exc)
            return
        self._store_price_rows(rows)

    def _poll_prices_individually(self, symbols: list[str]) -> None:
        for symbol in symbols:
            try:
                rows = self.client.prices(symbols=[symbol])
            except TossApiError as exc:
                if _is_stock_not_found_error(exc):
                    self._mark_invalid_symbol(symbol, "prices", exc)
                    continue
                self._record_poll_error(symbol, "price", exc)
                continue
            except Exception as exc:
                self._record_poll_error(symbol, "price", exc)
                continue
            self._store_price_rows(rows)

    def _store_price_rows(self, rows: list[dict]) -> None:
        now_iso = _now_iso()
        for row in rows:
            symbol = str(row.get("symbol") or "").upper()
            price = _to_float(row.get("lastPrice") or row.get("price"))
            if not symbol or price is None:
                continue
            self._latest_prices[symbol] = {
                "symbol": symbol,
                "last": price,
                "received_at": _normalize_time(row.get("timestamp")) or now_iso,
                "source": "toss_prices_polling",
            }

    def _poll_symbol(self, symbol: str) -> None:
        if self._subscribe_quotes:
            self._poll_quote_symbol(symbol)
        if self._subscribe_trades:
            self._poll_trade_symbol(symbol)

    def _poll_quote_symbol(self, symbol: str) -> None:
        if self._is_invalid_symbol(symbol):
            return
        try:
            quote = self.client.orderbook_quote(symbol=symbol, max_cache_age_sec=0.0)
            event = _quote_event(symbol, quote)
            self._append_quote_event(event)
        except TossApiError as exc:
            if _is_stock_not_found_error(exc):
                self._mark_invalid_symbol(symbol, "quote", exc)
                return
            self._record_poll_error(symbol, "quote", exc)
        except Exception as exc:
            self._record_poll_error(symbol, "quote", exc)

    def _poll_trade_symbol(self, symbol: str) -> None:
        if self._is_invalid_symbol(symbol):
            return
        try:
            # NOTE: count is a hidden throttle, not just an API sampling knob. Every *new*
            # trade appended below fires the heavy per-trade pipeline in _append_trade_event
            # (candle_builder.on_trade + strategy_runtime.on_trade, which rebuilds the whole
            # order_flow_snapshot + evaluates the entry engine, + a symbol-detail publish).
            # Bumping this to 50 multiplied that ~8x on hot names and starved the poll loop
            # (candles/ticks went ~40s stale). Keep at 5 until that pipeline is decoupled so
            # all trades feed flow/candles cheaply while strategy eval fires once per poll.
            trades = self.client.trades(symbol=symbol, count=5)
            for row in reversed(trades):
                event = _trade_event(symbol, row)
                if event:
                    self._append_trade_event(event)
        except TossApiError as exc:
            if _is_stock_not_found_error(exc):
                self._mark_invalid_symbol(symbol, "trade", exc)
                return
            self._record_poll_error(symbol, "trade", exc)
        except Exception as exc:
            self._record_poll_error(symbol, "trade", exc)

    def _next_quote_symbols(self, symbols: list[str]) -> list[str]:
        count = max(1, int(self.settings.toss_realtime_quote_symbols_per_sec or self.settings.toss_realtime_poll_symbols_per_sec or 1))
        selected = _round_robin_slice(symbols, start=self._quote_poll_index, count=count)
        self._quote_poll_index += len(selected)
        return selected

    def _next_trade_symbols(self, symbols: list[str]) -> list[str]:
        count = max(1, int(self.settings.toss_realtime_trade_symbols_per_sec or self.settings.toss_realtime_poll_symbols_per_sec or 1))
        selected = _round_robin_slice(symbols, start=self._trade_poll_index, count=count)
        self._trade_poll_index += len(selected)
        return selected

    def _append_quote_event(self, event: dict) -> None:
        with self._lock:
            self._events.append(event)
            self._latest_quotes[event["symbol"]] = event
            self._last_message_at = event["received_at"]
            self._last_realtime_at = event["received_at"]
            self._last_quote_at = event["received_at"]
        self._publish_symbol_detail_event(event.get("symbol"), reason="quote")

    def _append_trade_event(self, event: dict) -> None:
        event_time = event.get("event_at") or event.get("received_at")
        dedupe_key = (event.get("symbol"), event_time, event.get("last"), event.get("trade_volume"))
        with self._lock:
            if dedupe_key in self._seen_trade_key_set:
                return
            self._seen_trade_keys.append(dedupe_key)
            self._seen_trade_key_set.add(dedupe_key)
            while len(self._seen_trade_key_set) > len(self._seen_trade_keys):
                self._seen_trade_key_set = set(self._seen_trade_keys)
            self._events.append(event)
            self._latest_trades[event["symbol"]] = event
            self._last_message_at = event["received_at"]
            self._last_realtime_at = event["received_at"]
            self._last_trade_at = event["received_at"]
        if not _has_active_paper_position(event.get("symbol")):
            from app.services.candle_builder import candle_builder

            candle = candle_builder.on_trade(event, source="toss_polling_tick")
            if self._candidate_warmup_done(event.get("symbol")):
                from app.services.strategy_runtime import strategy_runtime

                strategy_runtime.on_trade(event, candle)
        self._publish_symbol_detail_event(event.get("symbol"), reason="trade")

    def _record_poll_error(self, symbol: str, source: str, exc: Exception) -> None:
        self._last_error = str(exc)[:300]
        self._events.append(
            {
                "event_type": f"{source}_poll_error",
                "symbol": symbol,
                "message": self._last_error,
                "received_at": _now_iso(),
            }
        )

    def _mark_invalid_symbol(self, symbol: str, source: str, exc: Exception) -> None:
        normalized = str(symbol or "").upper()
        if not normalized:
            self._record_poll_error(symbol, source, exc)
            return
        message = str(exc)[:300]
        self._last_error = message
        self._last_data_error = message
        with self._lock:
            self._invalid_symbols.add(normalized)
            self._subscriptions.discard(normalized)
            self._subscription_rank.pop(normalized, None)
            self._subscription_started_at.pop(normalized, None)
            self._latest_quotes.pop(normalized, None)
            self._latest_trades.pop(normalized, None)
            self._latest_prices.pop(normalized, None)
            self._events.append(
                {
                    "event_type": "invalid_symbol",
                    "symbol": normalized,
                    "source": source,
                    "message": message,
                    "received_at": _now_iso(),
                }
            )

    def _is_invalid_symbol(self, symbol: str | None) -> bool:
        return str(symbol or "").upper() in self._invalid_symbols

    def _valid_symbols(self, symbols: list[str]) -> list[str]:
        return [symbol for symbol in symbols if not self._is_invalid_symbol(symbol)]

    def _toss_seed_rows(self, *, limit: int) -> tuple[list[dict], dict[str, dict]]:
        """Seed the scanner candidate universe from the official rankings endpoint.

        `realtime` can come back empty outside active trading hours (per the spec, an
        uncollated combination returns an empty `rankings` array rather than an error), so
        fall back to the `1d` window in that case. Results are filtered against `/stocks`
        metadata to drop ETFs/ETNs/leveraged funds (see `_is_common_stock`) before truncating
        to `limit`, so the ranking is over-fetched at the API's max (100) to leave headroom.
        """
        try:
            result = self.client.rankings(
                ranking_type="TOSS_SECURITIES_TRADING_AMOUNT",
                market_country="US",
                duration="realtime",
                count=100,
            )
            rows = result.get("rankings") or []
            if not rows:
                result = self.client.rankings(
                    ranking_type="TOSS_SECURITIES_TRADING_AMOUNT",
                    market_country="US",
                    duration="1d",
                    count=100,
                )
                rows = result.get("rankings") or []
        except TossApiError as exc:
            self._last_data_error = str(exc)
            raise MarketDataUnavailableError(str(exc)) from exc

        candidate_symbols: list[str] = []
        for row in rows:
            symbol = str(row.get("symbol") or "").upper()
            if symbol and symbol not in candidate_symbols:
                candidate_symbols.append(symbol)
        stock_meta = self._stocks_for_symbols(candidate_symbols)
        krw_rate = self._usd_krw_rate()

        seed_rows: list[dict] = []
        for row in rows:
            symbol = str(row.get("symbol") or "").upper()
            if not symbol:
                continue
            meta = stock_meta.get(symbol)
            if not _is_common_stock(meta):
                continue
            price = row.get("price") if isinstance(row.get("price"), dict) else {}
            notional_usd = _to_float(row.get("tradingAmount"))
            rank = _positive_int(row.get("rank")) or len(seed_rows) + 1
            change_rate = _to_float(price.get("changeRate"))
            seed_rows.append(
                {
                    "symb": symbol,
                    "company_name": (meta or {}).get("name") or (meta or {}).get("englishName"),
                    "rank": rank,
                    "last": _to_float(price.get("lastPrice")),
                    # basePrice is the prior-day reference close; keep it so the UI can derive a
                    # live day-change from the polling last price instead of the ranking snapshot.
                    "prev_close_price": _to_float(price.get("basePrice")),
                    "day_change_pct": change_rate * 100 if change_rate is not None else None,
                    "toss_trade_volume": _to_float(row.get("tradingVolume")),
                    "toss_trade_amount_krw": (
                        notional_usd * krw_rate if notional_usd is not None and krw_rate else None
                    ),
                    "toss_wts_rank": rank,
                    "toss_wts_notional": notional_usd,
                    "screener_source": "toss_rankings_api",
                    "volume_source": "toss_rankings_api",
                }
            )
            if len(seed_rows) >= limit:
                break
        return seed_rows, stock_meta

    def _usd_krw_rate(self) -> float | None:
        try:
            return self.client.exchange_rate(base_currency="USD", quote_currency="KRW")
        except TossApiError as exc:
            self._last_data_error = str(exc)
            return None

    def _stocks_for_symbols(self, symbols: list[str]) -> dict[str, dict]:
        output: dict[str, dict] = {}
        for start in range(0, len(symbols), 200):
            chunk = [symbol.upper() for symbol in symbols[start : start + 200] if symbol]
            if not chunk:
                continue
            try:
                for row in self.client.stocks(symbols=chunk):
                    symbol = str(row.get("symbol") or "").upper()
                    if symbol:
                        output[symbol] = row
            except TossApiError as exc:
                if _is_stock_not_found_error(exc) and len(chunk) > 1:
                    for symbol in chunk:
                        try:
                            for row in self.client.stocks(symbols=[symbol]):
                                row_symbol = str(row.get("symbol") or "").upper()
                                if row_symbol:
                                    output[row_symbol] = row
                        except TossApiError as inner:
                            if _is_stock_not_found_error(inner):
                                self._mark_invalid_symbol(symbol, "stocks", inner)
                                continue
                            self._last_data_error = str(inner)
                    continue
                if _is_stock_not_found_error(exc) and len(chunk) == 1:
                    self._mark_invalid_symbol(chunk[0], "stocks", exc)
                    continue
                self._last_data_error = str(exc)
                continue
        return output

    def _prices_for_symbols(self, symbols: list[str]) -> dict[str, dict]:
        output: dict[str, dict] = {}
        for start in range(0, len(symbols), 200):
            chunk = [symbol.upper() for symbol in symbols[start : start + 200] if symbol]
            if not chunk:
                continue
            try:
                for row in self.client.prices(symbols=chunk):
                    symbol = str(row.get("symbol") or "").upper()
                    if symbol:
                        output[symbol] = row
            except TossApiError as exc:
                if _is_stock_not_found_error(exc) and len(chunk) > 1:
                    for symbol in chunk:
                        try:
                            for row in self.client.prices(symbols=[symbol]):
                                row_symbol = str(row.get("symbol") or "").upper()
                                if row_symbol:
                                    output[row_symbol] = row
                        except TossApiError as inner:
                            if _is_stock_not_found_error(inner):
                                self._mark_invalid_symbol(symbol, "prices", inner)
                                continue
                            self._last_data_error = str(inner)
                    continue
                if _is_stock_not_found_error(exc) and len(chunk) == 1:
                    self._mark_invalid_symbol(chunk[0], "prices", exc)
                    continue
                self._last_data_error = str(exc)
                continue
        return output

    def _recent_minute_bars(self, symbols: list[str], *, limit: int = 10) -> dict[str, list[dict]]:
        output: dict[str, list[dict]] = {}
        for symbol in symbols:
            try:
                output[symbol.upper()] = self.minute_bars(symbol=symbol, interval="1", limit=limit).get("output2") or []
            except TossApiError as exc:
                if _is_stock_not_found_error(exc):
                    self._mark_invalid_symbol(symbol, "candles", exc)
                    continue
                self._last_data_error = str(exc)[:300]
            except Exception as exc:
                self._last_data_error = str(exc)[:300]
        return output

    def _ensure_credentials(self) -> None:
        if not self.settings.toss_app_key or not self.settings.toss_app_secret:
            raise MarketDataUnavailableError("TOSS_APP_KEY/TOSS_APP_SECRET is required for Toss market data.")

    def _subscription_age_sec(self, symbol: str | None) -> float | None:
        normalized = str(symbol or "").upper()
        started_at = self._subscription_started_at.get(normalized)
        if started_at is None:
            return None
        return max(0.0, (datetime.now(timezone.utc) - started_at).total_seconds())

    def _candidate_warmup_done(self, symbol: str | None) -> bool:
        if _has_active_paper_position(symbol):
            return True
        warmup_sec = max(0, int(self.settings.scanner_candidate_warmup_sec or 0))
        if warmup_sec <= 0:
            return True
        age_sec = self._subscription_age_sec(symbol)
        return age_sec is not None and age_sec >= warmup_sec

    def _publish_symbol_detail_event(self, symbol: str | None, *, reason: str) -> None:
        symbol = str(symbol or "").upper()
        if not symbol:
            return
        now = datetime.now(timezone.utc).timestamp()
        if now - self._last_symbol_detail_event_at.get(symbol, 0.0) < 0.8:
            return
        self._last_symbol_detail_event_at[symbol] = now
        from app.domain.enums import RealtimeEventType, StatusLevel
        from app.services.event_bus import event_bus

        event_bus.publish(
            RealtimeEventType.SYMBOL_DETAIL,
            {"event_type": f"market_data.{reason}", "symbol": symbol, "source": "toss_polling"},
            status_level=StatusLevel.NORMAL,
            symbol=symbol,
        )


def _quote_event(symbol: str, quote: dict) -> dict:
    bid = _to_float(quote.get("bid") or quote.get("best_bid"))
    ask = _to_float(quote.get("ask") or quote.get("best_ask"))
    bid_depth = _to_float(quote.get("bid_depth"))
    ask_depth = _to_float(quote.get("ask_depth"))
    return {
        "event_type": "quote",
        "symbol": symbol.upper(),
        "bid": bid,
        "ask": ask,
        "bid_depth": bid_depth,
        "ask_depth": ask_depth,
        "spread_pct": quote.get("spread_pct") or _spread_pct(bid, ask),
        "bid_ask_imbalance": _imbalance(bid_depth, ask_depth),
        "received_at": _normalize_time(quote.get("received_at")) or _now_iso(),
        "raw": quote,
        "source": "toss_orderbook_polling",
    }


def _dedupe_upper(symbols: list[str]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for symbol in symbols:
        normalized = str(symbol or "").upper()
        if normalized and normalized not in seen:
            seen.add(normalized)
            output.append(normalized)
    return output


def _round_robin_slice(symbols: list[str], *, start: int, count: int) -> list[str]:
    if not symbols or count <= 0:
        return []
    output: list[str] = []
    for offset in range(min(count, len(symbols))):
        output.append(symbols[(start + offset) % len(symbols)])
    return output


def _trade_event(symbol: str, row: dict) -> dict | None:
    price = _to_float(row.get("price") or row.get("last") or row.get("closePrice"))
    volume = _to_float(row.get("volume") or row.get("quantity"))
    if price is None:
        return None
    event_at = _normalize_time(row.get("timestamp"))
    return {
        "event_type": "trade",
        "symbol": symbol.upper(),
        "last": price,
        "trade_volume": volume,
        "received_at": _now_iso(),
        "event_at": event_at,
        "raw": {**row, "event_at": event_at},
        "source": "toss_trades_polling",
    }


def _toss_candle_to_provider_bar(symbol: str, row: dict, *, interval: str = "1m") -> dict:
    market_date, market_time, korea_date, korea_time = _split_timestamp(row.get("timestamp"), interval=interval)
    close = _to_float(row.get("closePrice"))
    volume = _to_float(row.get("volume"))
    return {
        "symb": symbol,
        "xymd": market_date,
        "xhms": market_time,
        "kymd": korea_date,
        "khms": korea_time,
        "open": _to_float(row.get("openPrice")),
        "high": _to_float(row.get("highPrice")),
        "low": _to_float(row.get("lowPrice")),
        "last": close,
        "evol": volume,
        "eamt": (close or 0.0) * (volume or 0.0),
        "source": "toss_openapi_candle",
        "provider_timestamp": row.get("timestamp"),
        "timestamp_role": "bar_time",
    }


# Non-common-stock instrument types per toss_openAPI.json's StockInfo.securityType enum.
# These are excluded from scanner candidates: ETFs (incl. leveraged/inverse funds like
# SOXL/SOXS), ETNs, warrants, REITs, depositary receipts, and infrastructure funds.
_NON_STOCK_SECURITY_TYPES = {
    "ETF",
    "FOREIGN_ETF",
    "ETN",
    "STOCK_WARRANTS",
    "REIT",
    "DEPOSITARY_RECEIPT",
    "INFRASTRUCTURE_FUND",
}


def _is_common_stock(row: dict | None) -> bool:
    if not row:
        return True
    if str(row.get("currency") or "").upper() != "USD":
        return False
    if str(row.get("status") or "").upper() not in {"", "ACTIVE", "N"}:
        return False
    # leverageFactor is only populated for ETF/ETN per the spec, so any non-null value is a
    # reliable leveraged/inverse-fund signal even if securityType were ever misreported.
    if row.get("leverageFactor") not in (None, ""):
        return False
    security_type = str(row.get("securityType") or row.get("group", {}).get("code") or "").upper()
    if security_type in _NON_STOCK_SECURITY_TYPES:
        return False
    is_stock = security_type in {"", "STOCK", "ST", "FOREIGN_STOCK"}
    return is_stock and bool(row.get("isCommonShare", row.get("commonShare", True)))


def _positive_int(value: Any) -> int | None:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def _empty_flow(symbol: str) -> dict:
    return {
        "symbol": symbol,
        "last_update_age_sec": None,
        "volume_10s": 0.0,
        "volume_prev_10s": 0.0,
        "volume_30s": 0.0,
        "volume_60s": 0.0,
        "aggressive_buy_volume": 0.0,
        "aggressive_sell_volume": 0.0,
        "unknown_trade_volume": 0.0,
        "trade_strength": None,
        "sell_pressure": None,
        "spread_pct": None,
        "bid_ask_imbalance": None,
        "quote": None,
        "trade": None,
    }


def _has_active_paper_position(symbol: str | None) -> bool:
    if not symbol:
        return False
    try:
        from app.services.paper_broker import InternalPaperBroker

        return any(
            str(row.get("symbol") or "").upper() == str(symbol).upper()
            for row in InternalPaperBroker().state().get("positions", [])
        )
    except Exception:
        return False


def _sort_bars_desc(rows: list[dict]) -> list[dict]:
    return sorted(rows, key=lambda row: f"{row.get('xymd') or ''}{str(row.get('xhms') or '').zfill(6)}", reverse=True)


def _sum_bar_volume(rows: list[dict]) -> float | None:
    values = [_to_float(row.get("evol")) for row in rows[:10]]
    values = [value for value in values if value is not None]
    return sum(values) if values else None


def _sum_bar_notional(rows: list[dict]) -> float | None:
    values = [_to_float(row.get("eamt")) or ((_to_float(row.get("last")) or 0.0) * (_to_float(row.get("evol")) or 0.0)) for row in rows[:10]]
    values = [value for value in values if value]
    return sum(values) if values else None


def _bar_notional(row: dict) -> float | None:
    amount = _to_float(row.get("eamt"))
    if amount is not None:
        return amount
    close = _to_float(row.get("last"))
    volume = _to_float(row.get("evol"))
    if close is None or volume is None:
        return None
    return close * volume


def _notional_velocity_1m(rows: list[dict]) -> float | None:
    if len(rows) < 2:
        return None
    current = _bar_notional(rows[0])
    previous = _bar_notional(rows[1])
    if current is None or not previous:
        return None
    return current / previous


def _bar_change_pct(row: dict) -> float | None:
    open_price = _to_float(row.get("open"))
    close = _to_float(row.get("last"))
    if not open_price or close is None:
        return None
    return (close - open_price) / open_price * 100


def _bars_change_pct(rows: list[dict]) -> float | None:
    if not rows:
        return None
    latest = _to_float(rows[0].get("last"))
    oldest = _to_float(rows[min(len(rows), 10) - 1].get("open"))
    if latest is None or not oldest:
        return None
    return (latest - oldest) / oldest * 100


def _split_timestamp(value: str | None, *, interval: str = "1m") -> tuple[str | None, str | None, str | None, str | None]:
    del interval
    parsed = _parse_dt(value)
    if parsed is None:
        return None, None, None, None
    utc = parsed.astimezone(timezone.utc)
    kst = utc + timedelta(hours=9)
    return (
        utc.strftime("%Y%m%d"),
        utc.strftime("%H%M%S"),
        kst.strftime("%Y%m%d"),
        kst.strftime("%H%M%S"),
    )


def _normalize_time(value: object) -> str | None:
    parsed = _parse_dt(value)
    return parsed.isoformat() if parsed else None


def _parse_dt(value: object) -> datetime | None:
    raw = str(value or "")
    if not raw:
        return None
    if raw.endswith("Z"):
        raw = f"{raw[:-1]}+00:00"
    if "." in raw:
        head, tail = raw.split(".", 1)
        fraction = tail
        zone = ""
        for marker in ("+", "-"):
            if marker in tail:
                fraction, zone = tail.split(marker, 1)
                zone = marker + zone
                break
        raw = f"{head}.{fraction[:6]}{zone}"
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _age_seconds(value: str | None) -> float | None:
    parsed = _parse_dt(value)
    if parsed is None:
        return None
    return max(0.0, (datetime.now(timezone.utc) - parsed).total_seconds())


def _trade_side(*, price: float | None, quote: dict | None, previous_price: float | None) -> str | None:
    if price is None:
        return None
    bid = _to_float((quote or {}).get("bid"))
    ask = _to_float((quote or {}).get("ask"))
    if ask is not None and price >= ask:
        return "buy"
    if bid is not None and price <= bid:
        return "sell"
    if previous_price is not None:
        if price > previous_price:
            return "buy"
        if price < previous_price:
            return "sell"
    return None


def _spread_pct(bid: float | None, ask: float | None) -> float | None:
    if bid is None or ask is None:
        return None
    midpoint = (bid + ask) / 2
    if midpoint <= 0:
        return None
    return (ask - bid) / midpoint * 100


def _imbalance(bid_depth: float | None, ask_depth: float | None) -> float | None:
    bid = bid_depth or 0.0
    ask = ask_depth or 0.0
    total = bid + ask
    return bid / total if total > 0 else None


def _to_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").replace("$", "").strip())
    except (TypeError, ValueError):
        return None


def _is_stock_not_found_error(exc: Exception) -> bool:
    if not isinstance(exc, TossApiError):
        return False
    payload = getattr(exc, "payload", {}) or {}
    error = payload.get("error") if isinstance(payload, dict) else None
    code = None
    if isinstance(error, dict):
        code = error.get("code")
    if code is None and isinstance(payload, dict):
        code = payload.get("code")
    message = str(exc).lower()
    return (
        getattr(exc, "status_code", None) == 404
        and str(code or "").lower() == "stock-not-found"
    ) or "stock-not-found" in message


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
