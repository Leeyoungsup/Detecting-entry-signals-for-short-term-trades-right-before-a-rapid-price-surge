# Claudy 작업 로그

### [2026-07-08 06:00]
**Q:** (개장 중) "deque mutated during iteration" 로그 뜨고 토스가 잠깐 꺼짐. + 스트림 상태에 threading.Lock 정석대로 지금 처리해줘(페이퍼니까). candle_builder 컴프리헨션도 같이.

**A:** 동시성 버그 수정. 원인: 폴링 스레드들(`asyncio.to_thread`)이 공유 deque에 append하는 동안 메인 루프가 **Python for-loop으로 순회** → RuntimeError. `order_flow_snapshot()`이 매 평가 사이클마다 호출돼 예외 시 사이클 중단 → 토스 순간 끊김.

- **1차(핫픽스)**: `for event in self._events:` → `list()` 스냅샷 순회. `toss.py:271`(활성), `alpaca.py`, `kis/websocket_client.py`(비활성) 3곳.
- **2차(정석 락) — toss.py**: `threading.RLock` 추가. 진짜 위험은 `_append_trade_event`의 dedup(_seen_trade_key_set + deque 다단계 read-modify-write)이 멀티스레드에서 깨지는 것 → 스냅샷만으론 부족. 그래서 두 writer(`_append_quote_event`/`_append_trade_event` 상태변경부), reader 스냅샷(`order_flow_snapshot`/`recent_events`), `clear`, poll_error append를 락으로 보호. 단 `_publish_symbol_detail_event`·`candle_builder.on_trade`는 락 밖(다른 서브시스템).
- **candle_builder**: `shared_state`가 **redis(0.2s 타임아웃)**라 락을 persist/hydrate I/O에 걸면 트레이딩 루프 정지 위험 → 락 대신 **원자적 `list()` 스냅샷**으로 모든 deque/dict 순회 보호(on_trade의 reversed×2, seed, live_tick_candles, status의 items+inner). 크래시 클래스 완전 제거, redis-under-lock 위험 없음.
- **검증**: import 클린, 백엔드 테스트 **70건 통과**, + **동시성 스트레스 테스트**(toss 4append/3read + candle_builder 4write/3read, 4초) **에러 0 = PASS**.
- **주의**: 실행 중 워커는 **재시작해야** 적용. candle_builder의 on_trade RMW(중복캔들) 미세 레이스는 크래시 아니라 데이터 저하 수준 → 세션 후 락으로 마저 정리 권장.

**변경사항:** `services/backend/app/adapters/market_data/toss.py`(RLock), `services/backend/app/adapters/market_data/alpaca.py`·`app/adapters/kis/websocket_client.py`(스냅샷), `services/backend/app/services/candle_builder.py`(스냅샷), `claudy_log.md`.

### [2026-07-08 05:00]
**Q:** 2026-07-06 랭킹 불러온 거 맞아? → (07-06 검증이 07-07 유니버스 재사용이라 오염) 07-06 지우고, 매일 장마감 시 랭킹을 불러와 저장하는 자동화(크론)로 가자. 캡처 시각은 08:00 KST.

**A:** 07-06 검증 결과(-$204, 승률30%)는 **유니버스가 07-07 거래대금 상위(07-06 기준 아님)라 오염** → 성급한 "튜닝 실패" 결론 철회, 07-06 세션 삭제. 매일 랭킹 스냅샷 자동 캡처 구축.

- **왜 자동화**: Toss `rankings` API는 롤링 구간(realtime/1d/1w/...)만 지원, **과거 특정일 랭킹 소급 불가**. 랭킹만 시간민감(비소급)이고 차트는 Alpaca로 언제든 소급 가능 → 랭킹을 매일 캡처해 쌓는 게 유일한 정답.
- **타이밍 정정**: 미국 정규장 마감=16:00 ET=**05:00 KST(EDT)/06:00 KST(EST)**. 사용자가 말한 08:00은 애프터장 중(예전 차트창 끝). 랭킹은 마감~다음 프리마켓(17:00 KST)까지 고정이라 06~17시 KST 아무때나 동일값. → **08:00 KST 채택**.
- **신규 `scripts/capture_toss_ranking.py`**: `TOSS_SECURITIES_TRADING_AMOUNT` realtime(→1d 폴백) 캡처, ≤$20 공통주 필터, **ET "마지막 마감 세션"으로 자동 태깅**(실행시각·DST 무관 정확), `exports/strategy_replay/rankings/ranking_<ET날짜>.json` + `index.jsonl` 누적, 중복 skip, CWD무관(`__file__` 기준·`.env`는 config가 절대경로 `REPO_ROOT/.env`로 로드).
- **Windows Task Scheduler**: `TossRankingCapture` 매일 **08:00 KST**, `StartWhenAvailable`(PC 꺼져있었으면 다음 부팅 시 실행), 10분 제한. 수동 실행 검증 LastResult=0, 다음 실행 07-09 08:00, 기존 스냅샷 자동 skip 확인.
- **런타임 포팅 주의**: 앞서 포팅한 튜닝은 **1일(07-07) 기준이라 아직 미검증**. 며칠 쌓아 레짐별로 봐야 함. 실매매 전 재검증 필요.
- **후속 워크플로**: 며칠 쌓이면 `collect_toss_ranking_charts.py --symbols <ranking json의 symbols_csv>`로 그날 차트 뽑아 replay → 진짜 아웃오브샘플.

**변경사항:** `scripts/capture_toss_ranking.py`(신규), `scripts/collect_toss_ranking_charts.py`(`--symbols` 옵션 추가), `exports/strategy_replay/session_2026-07-06/`(삭제), `exports/strategy_replay/rankings/`(신규 스냅샷), Windows 예약작업 `TossRankingCapture`(신규), `claudy_log.md`.

### [2026-07-08 04:00]
**Q:** (종목명 하드코딩 없음 확인 후) 런타임 엔진 포팅 진행해줘.

**A:** replay 샌드박스 튜닝을 실거래 런타임 엔진(`strategy_engine.py`, config, `.env`)에 포팅. 종목명 하드코딩 전무(전부 종목무관 일반 로직) 확인. 두 엔진은 아키텍처가 다름(replay=불리언 AND, runtime=가중 스코어+하드게이트)이라 의미 기준으로 포팅.

- **매핑**: 전략 활성화는 `evaluate_all`이 `strategy_*_enabled` 플래그로 게이트. 손절은 `strategy_runtime.py`의 ATR/구조 적응형 스톱을 `paper_adaptive_max_stop_loss_pct`(상한 3.5%)로 캡. `.env`가 config 기본값을 오버라이드함(중요).
- **포팅 내역**:
  1. Micro Breakout 볼륨 게이트 1.05→**1.3** (`strategy_engine.py` `_micro_breakout_absorption_patterns`, 신규 설정 `strategy_micro_breakout_min_volume_ratio`).
  2. First Pullback: `reclaim_confirmed`에 **volume_ratio>=1.2** AND 추가(신규 설정 `strategy_volume_shock_reclaim_min_volume_ratio`).
  3. Surge Pullback·Liquidity Sweep **은퇴**: config 기본값 False + `.env`의 `STRATEGY_SURGE_PULLBACK_ENABLED=true→false`. `strategy_primary_name` surge→**vwap_soft_reclaim** 재지정(surge가 primary였음, API 라벨용).
  4. 손절 상한 `paper_adaptive_max_stop_loss_pct` 3.5%→**2.5%** (config + `.env` PAPER_ADAPTIVE_MAX_STOP_LOSS_PCT).
- **미포팅(의도)**: replay의 스톱 **슬리피지 캡 0.5%는 백테스트 체결현실화(min_bid 과비관) 보정용 아티팩트**라 실거래엔 불필요. 런타임은 실제 체결 + `paper_stop_loss_emergency_limit_buffer_pct`(0.5%)로 이미 처리.
- **검증**: 설정 실효값 확인(surge/sweep False, micro_vol 1.3, reclaim_vol 1.2, adaptive_max 0.025, primary vwap_soft_reclaim). 백엔드 테스트 **70건 전부 통과**. 기본 활성셋이 정확히 3종(First Pullback, VWAP Soft, Micro Breakout)으로 축소 확인. `.env.conda.example`도 동기화.
- **주의**: runtime 스톱은 replay보다 정교(ATR/구조 적응형)라 동작이 bit-identical하지 않음. 여전히 **새 세션 아웃오브샘플 검증 후 실매매 권장**. `test_strategy_single_active.py`는 플래그 강제 True라 미변경(라우터 능력 테스트).

**변경사항:** `services/backend/app/services/strategy_engine.py`(Micro/First Pullback 볼륨 게이트), `services/backend/app/core/config.py`(플래그 기본값·신규 볼륨설정·adaptive_max·primary), `.env`(SURGE off, ADAPTIVE_MAX 0.025), `.env.conda.example`(동기화), `claudy_log.md`.

### [2026-07-08 03:00]
**Q:** (out-of-sample 전략별 손익 확인 후) 튜닝 진행하자. + session_2026-07-07만 사용하는 게 좋겠다.

**A:** 신규 세션을 1차 기준으로, 기존 튜닝셋을 일반화 가드로 병행 평가하며 과최적 회피. 순적자 전략 2종(Micro Breakout·Surge) 진단→스윕→적용.

- **진단(세션)**: 두 드래그 전략 모두 승자 MFE 캡처 70~75%(정상), 손실은 structure/ema20 스톱에 집중. Micro는 avg익<avg손 구조.
- **스윕(세션 vs 튜닝 병행)**: Micro flow 게이트(55/48)는 세션만 좋고 튜닝 붕괴(+75→−16)=과최적, 기각. Micro **볼륨 게이트 1.05→1.3**은 메커니즘 타당(저볼륨 브레이크아웃=저확신)하며 세션 −26→+7, 튜닝 +75→+19 유지. Surge는 어떤 게이트도 두 셋 모두 개선 못 함(구조적 marginal).
- **은퇴 시나리오 발견**: Surge 은퇴 시 튜닝 +437→+543 급등 — Surge 손실이 symbol 쿨다운을 유발해 건강한 전략 진입을 막고 있었음(cross-strategy 효과). Surge 은퇴 + Micro vol1.3 조합이 **두 셋 모두 개선**.
- **적용**: `signal_micro_breakout_absorption` volume_ratio 1.05→**1.3**. `Surge Pullback Reclaim`을 STRATEGIES→ARCHIVED_STRATEGIES 은퇴(사유 주석). 활성 전략 4→3(First Pullback, VWAP Soft, Micro Breakout).
- **최종 검증**: 세션 +$10.4→**+$70.7(+3.5%, 승률 53.8%)**, 튜닝셋 +$436.7→**+$503.6(+25.2%)**. 둘 다 개선=과최적 아님. 전략/replay 테스트 20건 통과(STRATEGIES 어서션·ARCHIVED 갱신).
- **주의/후속**: 세션 단일 튜닝의 진짜 검증은 **다른 날 세션을 새로 뽑아** 확인 필요(같은 데이터 튜닝+검증 불가). VWAP Soft는 세션에서 −$2(≈0)지만 튜닝 +$297로 건재. 여전히 replay 샌드박스 한정(런타임 엔진 미포팅).

**변경사항:** `scripts/replay_tc_shadow_strategies.py`(Micro 볼륨 게이트 1.3, Surge 은퇴), `services/backend/tests/test_strategy_replay_script.py`(STRATEGIES 3종·ARCHIVED 2종 어서션), `exports/strategy_replay/**/active_strategies_replay_*`(재생성), `claudy_log.md`. 진단/스윕 스크립트는 일회성이라 삭제.

### [2026-07-08 02:00]
**Q:** 장마감직전 토스 거래대금순 종목 중 주당 $20 이하의, 어제 17:00~오늘 08:00(KST) 차트를 replay 차트처럼 가져와 테스트 가능? (이어서) toss api로는 못읽어?

**A:** 가능. 브라우저 크롤 대신 **Toss Open API** 직접 사용으로 전환. 수집→아웃오브샘플 replay까지 완료.

- **랭킹 소스**: `TossExecutionClient(Settings()).rankings(ranking_type="TOSS_SECURITIES_TRADING_AMOUNT", market_country="US", duration="realtime", count=100)`, 빈 응답 시 `1d` 폴백(당일 누적=장마감 거래대금순, 의도에 더 정확). `.env`의 `TOSS_APP_KEY/SECRET` 인증. Playwright 크롤(`TossWtsRankingClient`)은 불필요해 미사용.
- **필터**: lastPrice ≤ $20 → 35개. 앱 자체 `_is_common_stock`로 레버리지/인버스 ETF 21개 제외 → 일반주 14개(+`--always-keep TC` 보정, TC는 메타 오분류).
- **수집**: 신규 `scripts/collect_toss_ranking_charts.py` — 랭킹 API→필터→종목별 2단계(`export_alpaca_bars_csv`→`export_alpaca_enriched_bars_csv`) 내보내기, 재실행 시 skip. 창 07-07 17:00~07-08 08:00 KST(UTC 07-07 08:00~23:00 = 미국 07-07 세션 프리~애프터 전체). 14종목 전부 성공, `exports/strategy_replay/session_2026-07-07/`에 저장 + `collection_manifest.json`.
- **replay 러너**: `replay_all_strategy_replay.py`에 `--dir` 추가(세션 폴더만 replay).
- **아웃오브샘플 결과(튜닝에 안 쓴 14종목)**: 300거래 승률 **52.67%** 순손익 **+$10.37(+0.5%)** ≈ 브레이크이븐. 승률은 튜닝셋(52.5%)과 일치→진입 엣지 일반화. 단 net은 얇음(튜닝셋 +$437 대비). First Pullback(내가 볼륨 게이트 추가한 전략)이 최고(+$37.6, 57%승)로 게이트 일반화 양호. CLRO(+$144)·SKYQ(+$103)가 견인, ONDS(-$58, 4.8%승)·IOTR(-$62)·VEEE(-$36)가 실점.
- **주의**: `realtime` 랭킹은 라이브 스냅샷이라 시점마다 종목이 바뀜(수집 시 ALM/VIVK/YHC가 앞선 프로브의 일부 종목 대체). "장마감직전" 재현하려면 `1d` 사용 또는 마감 시점 캡처 필요. 튜닝은 여전히 replay 샌드박스 한정(런타임 엔진 미포팅).

**변경사항:** `scripts/collect_toss_ranking_charts.py`(신규), `scripts/replay_all_strategy_replay.py`(`--dir` 추가), `exports/strategy_replay/session_2026-07-07/`(14종목 bars/enriched + summary/trades/manifest 신규), `claudy_log.md`. kis-trading-research conda 환경에 playwright는 이미 설치돼 있었으나 최종적으로 미사용.

### [2026-07-08 01:00]
**Q:** 전략 수정 vs 튜닝 판단 후, 1순위 손절/리스크 튜닝 + 2순위 TC 진입 게이트 + 3순위 Liquidity Sweep Reclaim 완화/은퇴를 전부 진행해줘.

**A:** MFE/MAE·보유봉수 계측 → 스윕 → 적용 → 재-replay 순으로 3건 모두 실측 기반 튜닝. `replay_tc_shadow_strategies.py` 엔진 수정, 전체 16윈도우 replay로 검증.

- **진단(계측)**: 손실 57%가 "straight-down"(진입 후 0.5%도 못 오름), 보유 중앙값 0봉(진입봉 인트라바 손절). 손절은 -3.5% 트리거인데 `min_bid`(봉내 최저 호가) 체결 가정 탓에 평균 -5.5%로 체결 → ~2%p가 인위적 손실. 손절 -2%로 캡 시 ~333%p 회복 여지.
- **1순위(손절)**: 스윕 결과 `FINAL_STOP_PCT` 3.5%→**2.5%** + 신규 상수 `STOP_SLIPPAGE_CAP_PCT=0.5%`(`execution_price`에서 스톱 체결을 트리거*(1-cap) 이하로 안 새게 캡, stop-limit 모델링). 0.3%캡이 net는 더 높으나 과최적 회피로 0.5% 채택. → **-$530.92 → +$178.61**, TC -$456→-$18로 대부분 회복.
- **2순위(TC 드래그의 진짜 원인)**: TC 손실은 종목이 아니라 `First Pullback After Volume Shock`×TC(-$156, 승31%)에 집중. 종목 밴 대신 해당 전략에 **`volume_ratio>=1.2`(리클레임 봉 참여도)** 게이트 추가. TC First Pullback -$156→+$2.5, CLRO(+$50)·BYAH 흑자 유지. → **+$178.61 → +$436.66**.
- **3순위(죽은 전략)**: `Liquidity Sweep Reclaim` 16윈도우 0거래. 컨디션 퍼널상 구조 게이트는 25개 통과하나 expectancy 게이트에서 1개로 소거(엣지 없음). 완화 시 6거래 33%승 +$17.7뿐 → 완화 대신 **은퇴**(STRATEGIES→ARCHIVED_STRATEGIES 이동).
- **최종 검증**: 16윈도우 242거래 승률 52.5% 순손익 **+$436.66(+21.8%)**, 활성 4전략 전부 흑자, TC가 최대 흑자(+$264)로 반전. 전략/replay 테스트 20건 통과(신규 슬리피지 캡 테스트 포함).
- **주의(미완/후속)**: 튜닝은 **replay 샌드박스(`scripts/`)에만** 반영됨. 실거래 런타임 `services/backend/app/services/strategy_engine.py`에는 미포팅 → live 반영하려면 별도 포팅 + `strategy_liquidity_sweep_reclaim_enabled` 플래그 off 필요. `test_strategy_single_active.py`는 백엔드 대상이라 의도적으로 미변경.

**변경사항:** `scripts/replay_tc_shadow_strategies.py`(FINAL_STOP 2.5%, STOP_SLIPPAGE_CAP_PCT 신설·execution_price 캡, First Pullback volume 게이트, Liquidity Sweep 은퇴), `scripts/replay_all_strategy_replay.py`(배치 러너, 앞 세션 신규), `services/backend/tests/test_strategy_replay_script.py`(전략셋 어서션 갱신 + 슬리피지 캡 테스트 추가), `exports/strategy_replay/active_strategies_replay_summary.json`·`active_strategies_replay_trades.csv`(재생성), `claudy_log.md`.

### [2026-07-08 00:00]
**Q:** 전략 수립/튜닝 중. runtime과 동일하게 동작하는 replay가 있고 `exports/strategy_replay/`에 테스트했던 종목·시간대가 있음. 내 전략 전체를 전부 replay 적용해봐.

**A:** `replay_tc_shadow_strategies.replay()`(runtime 동등 엔진)을 재사용하는 배치 러너 `scripts/replay_all_strategy_replay.py` 신규 작성. `exports/strategy_replay`의 `*_enriched.csv` 29개를 (symbol/date/timerange) 기준 16개 윈도우로 dedup(재-export는 최신 mtime 채택) 후, 현재 활성 전략 5종(Surge Pullback Reclaim, First Pullback After Volume Shock, Liquidity Sweep Reclaim, VWAP Soft Reclaim, Micro Breakout With Absorption)을 전 윈도우에 replay. 결과 요약 JSON/합산 거래 CSV 출력.

- **핵심 결과**: 16윈도우/8종목, 249거래, 승률 51.0%, 순손익 **-$530.92 (-26.5%, 전략당 $2000 기준)**.
- **진단**: 승률은 50% 넘지만 payoff ratio 0.65(평균이익 $8.84 vs 평균손실 $13.55) → 구조적 음의 기대값. exit 사유 분석상 `structure_or_final_stop` 91건 **-$1495**가 손실의 원천이고 `intrabar_trailing_stop_after_profit` 139건 +$1117이 이익 엔진. 손절(FINAL_STOP 3.5%)이 이익실현(트레일링) 대비 너무 넓음 = 이익은 짧게, 손실은 길게.
- **종목 편중**: TC가 8윈도우에서 -$456로 전체 손실 대부분 차지. BYAH(+$62.7)/CWD(+$54.8)만 흑자. Liquidity Sweep Reclaim은 0거래(과도하게 엄격).

**변경사항:** `scripts/replay_all_strategy_replay.py`(신규), `exports/strategy_replay/active_strategies_replay_summary.json`(신규), `exports/strategy_replay/active_strategies_replay_trades.csv`(신규), `claudy_log.md`.

### [2026-07-07 00:00]
**Q:** Toss API rate limit(429)이 계속 발생함. 공식 Rate Limits Group 한도표와 응답 헤더(`X-RateLimit-Limit/Remaining/Reset`, `Retry-After`)를 참고해 limit이 안 뜨게 해달라.

**A:** `services/backend/app/adapters/toss/client.py`의 레이트 리미터를 서버 헤더 기반 적응형으로 재작성.
- **응답 헤더 반영(`_note_rate_limit_headers`)**: 매 응답에서 `X-RateLimit-Limit/Remaining/Reset`을 그룹별 공유 상태에 반영. `remaining<=1`이면 `reset`만큼 쿨다운. api/worker/realtime_worker 3개 프로세스가 같은 토큰 버킷을 공유하므로, 버킷을 소진한 프로세스가 관찰한 `remaining=0`으로 모두가 백오프 → 프로세스 간 조율 효과.
- **429 처리(`_apply_rate_limit_penalty`)**: 전역 60초 쿨다운 제거 → `Retry-After`(없으면 `X-RateLimit-Reset`) 기반 **그룹별** 쿨다운. GET/토큰 요청은 최대 3회 재시도(`_MAX_RATE_LIMIT_RETRIES`)로 429가 호출자에게 노출되지 않도록 흡수.
- **안전 마진**: 각 그룹 초당 한도의 20%를 여유로 확보(`_RATE_LIMIT_HEADROOM_RATIO`), 서버가 광고한 `X-RateLimit-Limit`도 동적 채택(`min`).
- **그룹 매핑 교정(`_rate_limit_group`)**: `toss_openAPI.json` 명세 기준으로 재작성. `/buying-power`→ORDER_INFO(기존 ACCOUNT 오류), `/holdings`→ASSET, `/orders` GET→ORDER_HISTORY·POST→ORDER 메서드 분리, RANKING/MARKET_INDICATOR(_CHART)/CONDITIONAL_ORDER(_HISTORY) 등 누락 그룹 추가. 한도표를 공식 값(MARKET_DATA 10, MARKET_DATA_CHART 5 등)으로 정정.

**변경사항:** `services/backend/app/adapters/toss/client.py`, `services/backend/claudy_log.md`(신규). 테스트 `test_toss_client.py`/`test_toss_market_data_provider.py`/`test_toss_wts_ranking.py` 8건 통과.

### [2026-07-09 00:00]
**Q:** 전략 파라미터 수정 패널을 전략모니터 페이지에서 없애고, Runtime을 replay처럼 불리언 AND로 진행하자.

**A:**
- **Runtime 불리언 AND 전환(`strategy_engine.py:_build_rule_evaluation`)**: 기존 `entry_allowed = (모든 조건 통과) AND (final_score >= min_score)` 및 "전략 점수 미달" 실패조건 추가 로직 제거 → `entry_allowed = not failed_conditions`. weighted score / min_score는 모니터링·표시용으로만 유지되고 진입을 게이팅하지 않음. 활성 3개 전략(volume_shock_first_pullback, vwap_soft_reclaim, micro_breakout_absorption)은 모두 이 함수를 경유하므로 replay의 하드 AND와 동일하게 동작.
- **프론트 패널 제거**: `apps/web/app/strategies/page.tsx`에서 `<StrategySettingsEditor>` 사용부·import·미사용 `settingsFields` 변수 삭제. 고아가 된 `apps/web/components/strategy-settings-editor.tsx` 컴포넌트 파일 삭제(다른 참조 없음 확인).
- **검증**: 백엔드 테스트 70건 전체 통과.

**변경사항:** `services/backend/app/services/strategy_engine.py`, `apps/web/app/strategies/page.tsx`, `apps/web/components/strategy-settings-editor.tsx`(삭제).

### [2026-07-09 00:30]
**Q:** replay의 entry_expectancy_ok / prefill_entry_ok 게이트를 런타임에 적용해줘.

**A:**
- **정정**: expectancy는 런타임에 이미 하드 조건으로 존재(각 활성 전략 conditions의 `edge_ok` = `_scalp_expected_edge_ok`). 불리언 AND가 이미 강제 중. 이전에 "빠졌다"고 한 설명은 부정확.
- **expectancy 비용 상수 정합(`strategy_engine.py:_scalp_expected_edge_ok`)**: `estimated_cost = spread_fraction + 0.0023`이 수수료 0.1%/편도 반영 전 값이라 → `+ 0.0033`으로 교정(진입슬립 0.0005 + 청산슬립 0.0008 + 수수료 0.002 + SEC 0.0000278 ≈ 0.00333, replay `estimated_roundtrip_cost_fraction`과 일치).
- **추격(chase) 게이트 신규(`strategy_runtime.py` 진입 경로)**: 체결시점 매수호가(`_raw_ask`)가 신호 종가(`evaluation["indicators"]["close"]`) 대비 `paper_entry_max_chase_pct`(기본 1.2%) 초과 상승 시 진입 차단. replay `prefill_entry_ok`의 chase 캡과 동일. 체결시점 첫 스프레드 체크는 기존 `_max_entry_spread_pct`(1.25/0.85%)가 이미 담당.
- **설정 추가(`config.py`)**: `paper_entry_max_chase_pct: float = 0.012`.
- **검증**: 백엔드 테스트 70건 전체 통과.

**변경사항:** `services/backend/app/services/strategy_engine.py`, `services/backend/app/services/strategy_runtime.py`, `services/backend/app/core/config.py`.

### [2026-07-09 01:00]
**Q:** replay session_2026-07-08 만들어야지.

**A:**
- **`--ranking-file` 옵션 추가(`collect_toss_ranking_charts.py`)**: 저장된 랭킹 스냅샷(`rankings/ranking_YYYY-MM-DD.json`)의 universe를 읽어 그날의 종목을 rank/price/trade_amount 메타데이터까지 재현. 라이브 랭킹(현재 시점)이 아닌 해당일 기준으로 세션 재생성 가능.
- **네트워크 견고성**: 종목별 fetch를 `MAX_FETCH_ATTEMPTS=3` 재시도 + 백오프로 감싸고, except를 `(SystemExit, Exception)`으로 확대. 첫 실행이 RPGL enrich 중 ConnectionReset(WinError 10054)로 전체 중단됐던 문제 해결(한 종목 실패가 배치 전체를 죽이지 않음).
- **07-08 세션 수집 완료**: `exports/strategy_replay/session_2026-07-08/` 25종목 전부 성공(PHGE,IOTR,RPGL,CCHH,SUNE,SKYQ,BATL,DCX,SRXH,VTAK,CLRO,FRTT,NVVE,JOBY,EDBL,ONFO,LHAI,YHC,RITR,OPEN,CPOP,TVRD,JLHL,RDW,BNRG). 윈도우 KST 07-08 17:00~07-09 08:00.
- **out-of-sample replay 결과(중요)**: 활성 3전략 합산 **711 trades / 승률 49.37% / net -$394.43 / -19.72%**(전략당 $2000 기준). 07-07 튜닝셋에서 흑자였던 설정이 07-08에서는 3전략 모두 손실(Micro -$68.7, VWAP -$138.7, First Pullback -$187.0) → **과최적화(overfitting) 경고**. 승률은 ~49%지만 손실이 이익보다 커서 net 마이너스.

**변경사항:** `scripts/collect_toss_ranking_charts.py`, `exports/strategy_replay/session_2026-07-08/`(신규 데이터 25종목 + summary/trades).

### [2026-07-09 02:00]
**Q:** 07-08 손실 해부 → 07-07+07-08 합산 재튜닝. (저가 필터는 종목을 버리므로 불가) 그리고 "20바는 왜 고립된 peak?"

**A:**
- **07-08 손실 해부**: net -$394(gross -$138 + 수수료 $256). 원인 (1) 손절 비대칭 — `structure_or_final_stop` 201건 -$1,782(0% 승률, 평균 -$8.87) vs 익절 `intrabar_trailing` 436건 +$1,733(평균 +$3.97). (2) 손실 종목 홀딩/재진입 출혈 — 같은봉 청산 +$432 vs 홀딩 트레이드 전부 적자. (3) 초저가 EDBL($0.12)이 최악 12건 독점.
- **그리드 서치 발견**: 손절 조이면 악화(휩쏘), 넓혀야 함. 트레일링 0.4% 최적(넓히면 대참사). 진입 선별(min_edge) 효과 없음.
- **저가 필터 철회**: 사용자 요구 "종목 버리는건 안돼" → price floor 제거. 대신 **동적 심볼 손실 쿨다운**(손절난 종목만 일정시간 재진입 중단, 영구배제 아님)으로 해결.
- **"고립된 peak" 정정**: 성긴 그리드(5/10/15/20/30바)에서 20바가 고립 spike로 보여 과최적화로 오판. **촘촘히(12~40바) 재검증하니 19~26바가 넓은 안정 plateau**(합산 +$212~406). 15→19 사이 가파른 램프를 성긴 샘플링이 가렸던 것. 20바는 plateau 중심(고립 아님). 처음 적용한 30바는 오히려 plateau 하락 구간이라 20바로 수정.
- **최종 적용값(replay+runtime)**: `FINAL_STOP_PCT 0.025→0.035`(runtime `paper_adaptive_max_stop_loss_pct 0.025→0.035`), `SYMBOL_LOSS_REENTRY_COOLDOWN_BARS 5→20`(runtime `paper_symbol_any_strategy_loss_cooldown_seconds 600→1200`).
- **결과**: 07-07 +$100→**+$344**(승률 56.2%), 07-08 **-$394→-$13**(승률 56.3%), 합산 **-$294→+$332**. 07-08은 사실상 손익분기. 잔여 약점: First Pullback 07-08 -$166(추후 과제).
- **경고**: 여전히 2일치. 07-08 개별값은 노이즈 큼(합산은 20~24바에서 견고). 07-07이 매끄러운 드라이버.
- **검증**: 백엔드 70건 통과. `test_replay_blocks_symbol_reentry_after_loss_cluster`를 상수 상대값 기준으로 갱신(하드코딩 인덱스 → 상수 참조).

**변경사항:** `scripts/replay_tc_shadow_strategies.py`, `services/backend/app/core/config.py`, `.env`, `services/backend/tests/test_strategy_replay_script.py`, `exports/strategy_replay/session_2026-07-0{7,8}/`(요약 갱신).

### [2026-07-09 03:00]
**Q:** 7/8에서 왜 First Pullback만 -$166 지는가 구조적 원인 찾기 → 두 날 모두 흑자 튜닝(종목 배제 없이, replay=runtime 통일).

**A:**
- **구조적 원인 규명**: First Pullback 07-08 244건(07-07 85건의 3배 발화). 승자/패자 진입지표(trade_strength/sell_pressure/spread/exp_upside)는 거의 동일 → 기존 필터가 승패 구분 못 함. 더 깊이 파니 **두 날 모두 일관된 판별 특징 발견**: 승자는 VWAP 위(07-08 승자 vwap_gap +2.1% vs 패자 -0.2%), 초기 급등폭↑, 눌림 깊이↑. 특히 **패자는 VWAP 근처/아래에서 진입**(하락장 데드캣바운스). 원인: `support`가 [ema9/ema20/bb_mid/VWAP] 중 아무거나 인정 → VWAP 아래 진입 허용.
- **수정: VWAP 위 진입 게이트 추가** (`above_vwap = close >= session_vwap`). 자연 경계선(튜닝값 아님). 0.0~1.0% 전 구간이 합산 +$520~557로 평평 → 견고한 plateau, curve-fit 아님.
- **replay+runtime 동일 적용**: replay `signal_volume_shock_first_pullback`에 `above_vwap` AND 조건 추가. runtime `FirstPullbackAfterVolumeShockEngine` conditions에 `"above_vwap"` 추가(불리언 AND가 강제) + pullback_quality 스코어 컴포넌트에 포함.
- **결과(두 날 모두 흑자)**: 07-07 +$340(승률 55.9%), 07-08 **-$13→+$195**(승률 58.1%), 합산 **+$332→+$534**. First Pullback 07-08 **-$162→+$20** 흑자 전환. 3전략 모두 두 날 흑자.
- **검증**: 백엔드 70건 통과.

**변경사항:** `scripts/replay_tc_shadow_strategies.py`, `services/backend/app/services/strategy_engine.py`, `exports/strategy_replay/session_2026-07-0{7,8}/`(요약 갱신).

### [2026-07-09 10:20]
**Q:** 장 마감 후 백엔드 리팩토링 — 죽은 코드/중복 제거(저위험), 단계별 증분 커밋.

**A:** 동작 변경 0. 각 단계 테스트로 검증(활성 3전략·라우터 로직 보존).
- **Commit1(9e7de29)**: 미사용 독립 함수 11개 제거(engine `_max_spread_pct_for_session`, runtime `_momentum_weak`, toss `_bar_timestamp`, scanner 8개 + 고아 전역 `_focused_symbols`). 어디서도 호출 안 됨.
- **Commit2(21e8df3)**: 미사용 config 15개 제거(app_name, validation 플래그, initial/backtest_equity, base_currency, daymarket 시각, 미사용 전략 enable 플래그 7개). extra=ignore라 .env 무해. test_strategy_single_active의 삭제 플래그 monkeypatch 정리.
- **Commit3(2c80126, 자동커밋)**: 인스턴스화 안 되는 죽은 엔진 클래스 7개(LowerBandSnapback/OrderFlowImbalance/LiquidityImbalance/LiquidityAbsorptionBreakout/VwapReclaim/OpeningLiquidityImbalance/LowerBandReclaim) + `LowerBandEvaluation` + 전용 헬퍼 11개(`_snapback_patterns`, `_strategy_context`, `_above_or_reclaimed_vwap`, `_above_vwap`, `_failed_conditions_for_mode`, `_lte_abs` 등) + 미사용 import 2개. strategy_engine.py 2305→1622줄(−683). 죽은 엔진만 테스트하던 test_strategy_explanations.py·test_strategy_vwap_gate.py 삭제.
- **검증**: 각 커밋마다 py_compile + pytest. 최종 68건 통과(죽은 테스트 2개 제거로 70→68). pyflakes 미사용 import 0.
- **판단 보류**: 은퇴 전략 Surge/Liquidity Sweep은 config에 "재활성 가능하도록 유지" 명시 + replay ARCHIVED_STRATEGIES라 **의도적 보존** → 죽은 코드 아님, 유지 권장.
- **주의**: 환경에 주기적 자동 커밋(Author Leeyoungsup) 존재 — 단계별 커밋 메시지가 가끔 자동 메시지로 덮임(기능 무해).

**변경사항:** `services/backend/app/services/{strategy_engine,strategy_runtime,scanner}.py`, `app/adapters/market_data/toss.py`, `app/core/config.py`, `tests/test_strategy_single_active.py`, `tests/test_strategy_explanations.py`(삭제), `tests/test_strategy_vwap_gate.py`(삭제).

### [2026-07-09 11:00]
**Q:** 백엔드가 Alpaca+Toss→Toss(테스트 예외)로 바뀐 만큼 프론트 전면 정비. → 전체 페이지 감사.

**A:**
- **핵심 발견**: 프론트는 이미 Toss와 대체로 동기화됨. Alpaca 참조 0건, provider 표시=toss, `initial_equity_usd` API 정상(paper_initial_equity_usd를 그 키로 노출), 스캐너 퍼널 백↔프 일치. 예상한 "전면 교체" 스테일함 없음. (Alpaca는 replay 과거 호가/체결 데이터 소스라 대체 불가·유지 — Toss는 과거 tick 없음).
- **10개 페이지 감사 완료**: 대부분 정상. 실제 스테일은 은퇴 전략 "Surge Pullback Reclaim"이 기본값/하드코딩으로 남은 것.
- **Fix1(수정 완료)**: "Surge Pullback Reclaim" 스테일 제거 —
  - 백엔드 strategies.py `_event_strategy_name`/`_trade_strategy_name` fallback → 빈 문자열(동작 동일: 이름없는 이벤트는 breakdown에서 스킵).
  - 백엔드 symbols.py signal_explanation에 실제 `strategy_name` 추가.
  - 프론트 symbols/[symbol] "매매 판단" 자막 하드코딩 → 실제 `signal.strategy_name` 표시(옵셔널).
  - 검증: 백엔드 68건 통과.
- **환경 제약**: 이 환경에 node/node_modules 없어 프론트 build/tsc 검증 불가 → TS 변경은 수동 검토, 사용자 로컬 `npm run build`/`lint` 확인 필요.
- **남은 선택 항목(저위험·저가치)**: (a) 고아 백엔드 `/strategies/settings`+STRATEGY_PARAM_META(제거한 param 에디터 패널 잔재, 프론트 미소비) 제거, (b) 퍼널 단계명 "Lower Band Reclaim watch"→"전략 신호 감시" rename(백+프), (c) strategies PatternPanel Surge 죽은 분기 정리.

**변경사항:** `services/backend/app/api/routes/{strategies,symbols}.py`, `apps/web/app/symbols/[symbol]/page.tsx`.

### [2026-07-09 11:40]
**Q:** 남은 (a)/(b)/(c) 진행 + (d) 전략 모니터 Score Components를 조건 pass/fail로 교체(불리언 AND라 점수 무의미).

**A:**
- **(a) 고아 param-에디터 백엔드 제거(strategies.py)**: 제거한 "전략 파라미터 수정" 패널의 백엔드 잔재 삭제 — EDITABLE_SETTINGS(+update), StrategySettingsPatch, GET/PATCH `/strategies/settings`, `_editable_settings_payload`, `_coerce_setting_value`, `_score_weights_payload`, 메인 응답의 `"settings"` 키. 미사용 import 4개 정리. 378→213줄(−165). 프론트 미소비 확인.
- **(d) Score→조건 pass/fail**: runtime이 불리언 AND라 가중점수는 게이트가 아님. 백엔드 strategies 응답의 `latest_score/score_components/score_weights` → `latest_conditions`(gate_status, 조건→bool)로 교체. 프론트 strategies 페이지: `ScorePanel`(점수 막대)→`ConditionsPanel`(조건별 통과/실패 + "n/N 통과, AND"), 헤더 "Latest Score"→"조건 통과", 고아 타입/헬퍼(StrategyField, settings, defaultScoreMax) 제거.
- **(b) 퍼널 단계명**: "Lower Band Reclaim watch"(제거된 전략명)→"Strategy signal watch"/"전략 신호 감시". 백엔드 scanner.py 3곳 + 프론트 scanner 페이지 funnelOrder·stageMeta 함께 rename(키 일치 유지).
- **(c) PatternPanel Surge 죽은 분기**: surgeRows/hasSurgeState 분기 제거, generic 렌더로 단순화.
- **검증**: 백엔드 68건 통과, pyflakes 0. **프론트는 이 환경에 node 없어 build 검증 불가 → 로컬 `npm run build`/`lint` 필요.**
- **남은 일관성 항목(선택)**: symbols 상세 DecisionPanel은 여전히 final_score 큰 숫자 + ScoreBreakdown 표시(ConditionList도 병행). 원하면 동일하게 조건 중심으로 전환 가능.

**변경사항:** `services/backend/app/api/routes/strategies.py`, `services/backend/app/services/scanner.py`, `apps/web/app/strategies/page.tsx`, `apps/web/app/scanner/page.tsx`.

### [2026-07-09 12:20]
**Q:** 페이지별 UI 개선 시작 — 운영 센터부터. 표시 필요/불필요 구분해 가시성 계층화.

**A:** 운영 센터(app/page.tsx) 재구성 (동작 결정: 긴급중단 버튼 제거 + Tier3 압축유지).
- **제거**: (1) 동작 안 하는 "긴급 중단" 버튼(onClick 없고 글로벌 halt 엔드포인트 부재 → 오해 위험). (2) 죽은 KIS 타입 필드(kis_rest_status/kis_websocket_status, 백엔드가 보내지만 미표시). (3) 중복 "실전매매" 타일(상태 뱃지에 이미 있음). (4) 미사용 import 4개(Power/Clock3/RadioTower/Wifi).
- **가시성 계층화**: Tier1(시스템 상태+3칩, 페이퍼 계좌 P&L, 리스크 사용률) 크게 유지 → Tier2(오늘 요약 5타일, 최근 경고) → Tier3(진단 디테일)는 3개 큰 InfoPanel(각 header+3~5행+footer) → **압축 "시스템 진단" 스트립**(DiagItem 8개 4열 그리드: 데이터상태/세션/미국·한국시간/trade·quote·loop tick/보유종목호가)으로 대체. InfoPanel 컴포넌트 삭제, DiagItem 신규.
- **검증**: 잔여 참조 0, 아이콘 전부 사용, JSX 구조 육안 검토. **node 없어 build 검증 불가 → 로컬 `npm run build` 필요.**

**변경사항:** `apps/web/app/page.tsx`.

### [2026-07-09 12:45]
**Q:** 스캐너 퍼널 페이지 UI 정비.

**A:** apps/web/app/scanner/page.tsx —
- **죽은 코드 제거**: (1) `CandidateTable` 컴포넌트(~56줄) — `TossCandidateTable`과 거의 동일한데 미사용 중복. (2) "REST coarse scanner" stageMeta — 백엔드가 안 보내고 funnelOrder에도 없는 죽은 항목("Legacy" 표기).
- **중복 제거**: "Toss 감시" MetricPanel — 상단 상태패널 "감시 종목"과 같은 subscribedSymbols 값 → 제거, 5열→4열. 고아 변수 candidateSymbols/subscribedOutsideCandidates도 삭제.
- **가시성 계층화**: 수동후보 입력 도구(ManualCandidatePanel)를 퍼널 위 → **결과 테이블 아래로 이동**. 순서: 상태 → 파이프라인 메트릭(4) → **퍼널(핵심)** → 후보 테이블(결과) → 수동입력(도구). 퍼널/결과 우선, 입력 도구는 하단.
- 백엔드 stage명 대조 확인: funnelOrder 8단계 모두 백엔드 전송 일치(+Scanner cache는 프론트 의도적 생략).
- **검증**: 잔여 참조 0, 아이콘 전부 사용. node 없어 build 검증 불가 → 로컬 `npm run build` 필요.

**변경사항:** `apps/web/app/scanner/page.tsx`.

### [2026-07-09 13:10]
**Q:** 페이지별 UI 정비 계속 — 종목목록/종목상세/주문.

**A:**
- **종목 목록(symbols/page.tsx)**: 제목·네비 오표기 "종목 상세"→"종목 목록"(상세 페이지와 충돌 해소), 목록형 설명으로 변경, **상태 컬럼 추가**(전략 감시/실시간 구독/랭킹 뱃지). app-shell 네비 라벨도 수정.
- **종목 상세(symbols/[symbol]/page.tsx)**: 무의미한 "진입 점수" 큰숫자+막대 제거, 스테일 ScoreBreakdown(옛 전략 키 하드코딩) 제거 → **조건 통과 중심(n/N + AND + 통과/실패 뱃지)**으로 전환(전략 모니터와 일관). 백엔드 symbols.py signal_explanation에서 final_score/score_components/score_weights 제거, 프론트 타입/설명 정리.
- **주문(orders/page.tsx)**: 청산거래 리뷰 "점수 X" 무의미 표시 제거, 미사용 XCircle import 제거. (구조는 이미 양호.)
- **발견**: app-shell 네비에 `/alerts`(알림)가 누락됨 → 알림 페이지 접근 불가(알림 단계에서 처리 예정).
- **검증**: 백엔드 68건 통과, 프론트 잔여 참조 0. node 없어 build 검증 불가(로컬 확인 필요).

**변경사항:** `apps/web/app/symbols/page.tsx`, `apps/web/app/symbols/[symbol]/page.tsx`, `apps/web/components/app-shell.tsx`, `apps/web/app/orders/page.tsx`, `services/backend/app/api/routes/symbols.py`.

### [2026-07-09 13:40]
**Q:** 전략 모니터 진입 조건 패널이 어느 전략인지 안 보임. 전략 늘어날 수 있으니 3개 하드코딩 말고 동적으로.

**A:** strategies 페이지 —
- **데이터 주도 전략별 조건 패널**: 백엔드 strategies 응답에 `strategy_conditions` 배열 추가(`_latest_conditions_by_strategy`) — enabled 전략마다 최근 signal_evaluation의 gate_status/symbol/entry_allowed/reject_reason. 전략 추가/은퇴 시 자동 반영(하드코딩 없음). 프론트는 배열을 map으로 반응형 그리드(1/2/3열) 렌더. 각 패널 = 전략명+종목+진입가능/대기+n/N+조건별 통과/실패.
- 단일 ConditionsPanel(latest 1개만) → 전략별 N개 패널로 교체. `latest_strategy_name`(단일용, 임시 추가분) 제거. 헤더 요약은 `latest_conditions`로 유지.
- 헤더 중복 MiniStatus(Signals/Rejects, Orders/Fills — OverviewGrid와 겹침) 제거 + 미사용 Target/ShieldCheck import 제거.
- **검증**: 백엔드 68건 통과, pyflakes 0, 프론트 잔여 참조 0.

**변경사항:** `services/backend/app/api/routes/strategies.py`, `apps/web/app/strategies/page.tsx`.

### [2026-07-09 14:00]
**Q:** 페이지별 UI 정비 마무리 — 로그/알림/백테스트/설정.

**A:**
- **로그(logs)**: 죽은 이벤트 `strategy.settings_updated`(제거한 /strategies/settings가 emit하던 것) 참조 3곳 제거(백엔드 logs.py 필터, 프론트 isImportant·eventLabel). 그 외 검색/필터/확장 기능 이미 양호 → 변경 최소.
- **알림(alerts)**: 실제 페이지 아님 — `/settings`로 redirect하는 스텁. 정비할 UI 없음(알림 설정은 설정 페이지에 통합). 네비 미추가가 맞음.
- **백테스트(backtests)**: 이미 완성도 높음 — 입력폼+커스텀 SVG 차트(캔들/BB/VWAP/EMA/BS마커)+전략별 손익 비교+미체결 진단+매매로그, 전부 데이터 주도(하드코딩 없음), 스테일 참조 없음 → 변경 불필요.
- **설정(settings)**: 이미 깔끔 — 읽기전용 카드(all-Toss)+데이터 주도 편집기(스캐너/세션/분봉/paper테스트/비용 그룹). 전략파라미터·KIS·Alpaca 스테일 항목 없음 → 변경 불필요.
- **검증**: 백엔드 68건 통과.

**페이지별 UI 정비 8개 전부 완료.** 변경사항: `services/backend/app/api/routes/logs.py`, `apps/web/components/logs-realtime-table.tsx`.

### [2026-07-09 14:30]
**Q:** 전략 테스트 시작/종료를 날짜와 함께 24시간(am/pm말고) 입력, 종료날짜는 시작날짜 이상만 선택.

**A:**
- **프론트(backtests/page.tsx)**: 단일 날짜+시간2개 → 시작(날짜+시간)/종료(날짜+시간). 시간은 네이티브 type=time의 로케일 AM/PM 문제로 24h 강제가 불가 → 텍스트 HH:MM 입력(정규식 검증, 무효시 빨간테두리)으로 24시간 보장. 종료날짜 min=시작날짜 + updateStartDate로 자동보정 + rangeValid(종료일시>시작일시)로 버튼 비활성/에러. 결과 카드에 날짜범위 표시.
- **백엔드**: `StrategyReplayRequest`/`run_strategy_replay`/`_parse_kst_window`에 `end_date_kst`(옵션, 기본=시작날짜) 추가 → 오버나이트(자정 넘김) 지원. MAX_REPLAY_MINUTES 8h→16h(오버나이트 세션 15h 수용). 응답에 end_date_kst 추가. 하위호환(옵션 기본값).
- **검증**: 백엔드 컴파일+68건 통과, 프론트 잔여 참조 0.

**변경사항:** `apps/web/app/backtests/page.tsx`, `services/backend/app/services/strategy_replay_api.py`, `services/backend/app/api/routes/backtests.py`.

### [2026-07-09 14:45]
**Q:** (backtests) 종료 없애고 시작만 정한 뒤 "몇 시간짜리"(지속 시간)로 받는 게 낫겠다.

**A:** backtests/page.tsx — 종료(날짜+시간) 제거, **시작(날짜+24h시간) + 지속 시간(시간+분)**으로 변경. `computeEnd`가 시작+지속으로 종료 일시를 순수 KST 컴포넌트 연산으로 계산(자정 넘김=날짜 자동 증가). 종료≥시작 제약 불필요(지속>0), 최대 16시간. 계산된 종료를 실시간 표시("→ 종료 YYYY-MM-DD HH:MM KST"). 프론트가 end_date_kst/end_time_kst를 계산해 전송하므로 **백엔드 추가 변경 없음**(직전 오버나이트 지원 재사용). endDate/endTime state·updateStartDate 제거. 잔여 참조 0.

**변경사항:** `apps/web/app/backtests/page.tsx`.

### [2026-07-09 15:20]
**Q:** 사이트 제목 "미국장단타연구/US Intraday Lab" 별로, GUI(비주얼) 개선. (레이아웃은 OK)

**A:** 리브랜딩 + 전역 비주얼 폴리시.
- **리브랜딩 → "Nocturne"**(한국 밤=미국장 컨셉, 사용자 선택). 부제 "US Intraday Desk". 로고 아이콘 Activity→Moon(그라디언트 틴트). app-shell 2곳 + layout metadata title 적용.
- **웹폰트 Inter 적용**(next/font/google, `--font-inter` variable) — GUI가 밋밋했던 최대 원인이 웹폰트 부재였음. body font-family를 Inter+한글폴백(Pretendard/Malgun)으로, antialiasing/tnum. tailwind fontFamily.sans도 동일 스택. **가장 큰 시각 개선.**
- **전역 폴리시**: 기본 border-radius 4px→8px(더 현대적), card 그림자 토큰 추가, 얇은 스크롤바, indigo ::selection.
- **주의**: next/font는 빌드 시 폰트 다운로드(네트워크 필요). 반경 변경은 전역이라 라이브 확인 권장. node 없어 build 검증 불가.

**변경사항:** `apps/web/app/layout.tsx`, `apps/web/app/globals.css`, `apps/web/tailwind.config.ts`, `apps/web/components/app-shell.tsx`.

### [2026-07-09 15:40]
**Q:** 더 깊은 폴리시 + 주소바(탭) title icon(파비콘) 추가.

**A:**
- **파비콘**: `apps/web/app/icon.svg` 생성 — Nocturne crescent 달 + 별, 다크 그라디언트 rounded square. Next.js App Router가 app/icon.svg를 자동으로 favicon으로 링크.
- **카드 그림자(전역 depth)**: globals.css에 `.rounded.border.border-line.bg-white` 선택자로 은은한 box-shadow 일괄 적용 — 카드/칩만 잡고(입력창은 bg-white 클래스 없어 제외), 파일별 수정 없이 60여 개 카드에 일관된 깊이감. 평면감 제거.
- **주의**: 로컬 dev/build에서 확인 필요(파비콘은 재빌드 후 반영, next/font 네트워크 필요). node 없어 여기 검증 불가.

**변경사항:** `apps/web/app/icon.svg`(신규), `apps/web/app/globals.css`.

### [2026-07-09 16:00]
**Q:** (GUI 확인 후) 왼쪽 사이드바 색 조정.

**A:** app-shell.tsx —
- **active 상태 하이라이트 신규**: `usePathname`으로 현재 경로 감지, 활성 nav에 인디고 좌측 액센트 바 + 아이콘 틴트(bg-indigo-500/20) + 흰 텍스트. 모바일 nav도 활성 시 인디고 pill. (기존엔 현재 페이지 표시 없었음)
- **사이드바 그라디언트**: bg-navy 단색 → `from-[#141d33] to-[#0b1220]` 세로 그라디언트로 밤 무드 depth.
- app-shell을 "use client"로 전환(정적 nav+usePathname). children 페이지는 서버 렌더 유지.

**변경사항:** `apps/web/components/app-shell.tsx`.

### [2026-07-09 16:30]
**Q:** 전략 모니터 Runtime State의 "Candle Window"에 AAPL/MSFT/T00~T09 이상한 심볼 표시.

**A:** 원인 규명 + 수정.
- **원인**: candle_builder가 캔들을 shared_state(캔들 캐시, TTL 1h)에 영속화하고 `status()`가 `_hydrate_known_symbols()`로 저장된 모든 심볼(+레거시 `kis:` 키)을 재로드. T00~T09는 코드에 없음(grep 0건) = 과거 dev-tick/dev-simulate API로 수동 주입된 테스트 심볼이 캐시에 잔존. 실제 후보 아님(1h 후 만료/재시작 시 삭제). RuntimePanel이 캐시된 전 심볼을 그대로 보여줘서 이상하게 보였음.
- **수정(strategies.py)**: "Candle Window"(ws_candle_counts/ws_candle_symbols)를 **현재 subscribed(감시 중) 심볼로 필터링**. 스테일/dev 주입 심볼이 더는 안 보임. 감시 종목 0이면 빈 창(정상).
- **검증**: 백엔드 68건 통과.

**변경사항:** `services/backend/app/api/routes/strategies.py`.

### [2026-07-09 17:20]
**Q:** 익절이 수수료 수준(+0.15%)밖에 못 먹음. 익절 타깃을 replay처럼 키워 승자를 굴려라.

**A:** 원인 규명 + 익절 타깃 상향.
- **원인**: 런타임 익절 base target = 진입가×(1+`paper_take_profit_pct` 0.35%) 고정. dynamic update는 momentum strong/runner일 때만 타깃 상향. 대부분 승자(neutral/weak)는 +0.35%에서 약세(거래량감소) 확인 즉시 청산. profit_floor도 fees+min_net(0.15%)라 ~0.35%. → replay는 base target이 dynamic max(min_net, cost+edge, spread*1.8+edge) ≈ 0.6~0.8%라 더 굴러감.
- **수정(config+.env)**: `paper_take_profit_pct` 0.0035→0.006(타깃 0.6%), `paper_min_net_take_profit_pct` 0.0015→0.003(순익 바닥 0.3%), `paper_partial_take_profit_pct` 0.0025→0.004. 트레일링(발동 0.35% 유지)이 0.35~0.6% 사이에서 꺾이는 승자를 잡음.
- **효과(기대)**: 승자 ~+0.35%→~+0.6%(순익 ~+0.15%→~+0.4%, 약 2.7배). 승자가 굴러갈 여지 확보.
- **미해결(중요)**: 손절 초과(issue A) — 런타임은 손절을 현재 bid로 체결(캡 없음)해 급락 시 −5~6%로 초과. replay는 stop×(1−0.5%) 캡. 익절만 고쳐선 손익비 여전히 나쁨(승 0.6% vs 손 5~6%). **다음에 손절 슬리피지 캡 정렬 필요.**
- **검증**: 백엔드 68건 통과. *실행 모델이 달라 런타임 값은 replay로 직접 검증 불가 — 라이브 관찰하며 미세조정 권장.*

**변경사항:** `services/backend/app/core/config.py`, `.env`.

### [2026-07-09 17:35]
**Q:** 약세(거래량감소) 확인은 방금 받은 1분봉이라 초반엔 당연히 거래량 적은 거 아니냐?

**A:** 정확한 지적 — 근본 원인 규명 + 수정.
- **버그**: `_volume_decay_for_exit`가 `include_current=True`로 **forming candle(부분봉) 포함**해 recent 3봉 평균 vs previous 3봉 평균 비교. 매분 초반 부분봉 거래량이 몇 초치라 recent_avg가 떨어져 **거의 매분 "거래량감소=약세" 오탐** → 승자 조기 청산(익절/트레일링/약세 경로). 익절 타깃 크기보다 이게 진짜 근본.
- **수정**: `include_current=False` (완성봉만 비교). 부분봉 왜곡 제거 → 약세는 실제 거래량 fading에만 확인. `_high_failure_count_for_exit`는 가격 기반(고점거부)이라 intra-bar도 유효 → 유지.
- **직전 익절 타깃 상향(0.35%→0.6%)과 상보적**: 오탐 제거로 승자가 굴러가고, 타깃은 replay cost+edge 수준 목표 제공.
- **검증**: 백엔드 68건 통과.

**변경사항:** `services/backend/app/services/strategy_runtime.py`.

### [2026-07-09 18:10]
**Q:** replay와 runtime가 너무 달라진다 / 손절 초과 잡아라.

**A:** 손절 초과 = replay와의 유일한 손절 divergence였음 → 체결 캡으로 정렬.
- **정정**: 실효 손절폭은 이미 replay와 동일. `_stop_loss_decision` 첫 게이트가 `price > stop_loss_price(적응형 ≤3.5%)`라, 1.5% hard_stop은 적응형 뒤에 가려져 조기에 안 물림. 실효 손절 = 적응형(≤3.5%) = replay FINAL_STOP. → 손절 레벨은 안 건드림.
- **유일한 문제 = 체결 초과**: 런타임은 손절 감지 시 현재 bid로 체결(캡 없음) → 1초 폴링 사이 갭/스파이크로 −6% 초과. replay는 `max(fill, stop×(1−0.5%))` 캡.
- **수정**: `paper_stop_slippage_cap_pct=0.005` 신설. `_monitor_exit`에서 손절 계열(_EMERGENCY_EXIT_REASONS) 청산 시 `exit_price`와 broker용 bid를 `stop_loss_price×(1−0.005)`로 floor. broker sell reference=bid라 체결가가 캡됨 → 손실 ~stop+0.5%로 바운드(3.5%면 ~4%, −6% 방지). replay와 정렬.
- **남은 divergence(참고)**: 런타임엔 replay에 없는 추가 청산(rapid/liquidity/deep/high_failure/time/vwap_break)이 있음. 이들도 이제 체결 캡 대상. 완전 parity 원하면 별도 검토 필요.
- **검증**: 백엔드 68건 통과.

**변경사항:** `services/backend/app/core/config.py`, `services/backend/app/services/strategy_runtime.py`.

### [2026-07-11 21:00]
**Q:** live 전환 상태 점검 + replay와 live의 진입 신호가 같은지 확인, 다르면 replay를 live 엔진 호출로 통합.

**A:** replay는 진입을 별도 `signal_*` 하드게이트로, live는 `EntryPatternEngine`(가중 점수 ≥ 임계값 + hard_checks)로 판정 → **구조가 달랐음**. 청산/게이트는 이미 `strategy_decision` 공유.
- **정합성 측정**: replay가 실제 매수한 62개 봉(7/7~7/10)에서 live 엔진 재평가 → **95.2% 일치**(59/62), 어긋난 3건은 전부 live가 더 보수적(스킵). live의 유일한 외부 의존성은 `get_market_data_service().provider.order_flow_snapshot()`뿐 → enriched CSV flow를 stub provider로 주입하면 offline 재현 가능.
- **통합**: `replay_tc_shadow_strategies.py`에 `ENTRY_MODE`/`set_entry_mode` + `_LiveEngineEntryAdapter`(flow stub 주입, `record_event` no-op, 봉당 evaluate_all 1회 캐시) + `entry_signal()` 디스패처 추가. 두 replay 루프의 `detector(rows,index)` → `entry_signal(name,rows,index)`. 기본 `hard_gate` 유지(회귀 안전), `--entry-engine live_engine`로 전환.
- **잠재 버그 발견(live 코드)**: `_volume_shock_pullback_patterns`가 봉<12일 때 `volume_ratio` 키 없는 dict를 early-return하는데 `evaluate()`가 무조건 `patterns["volume_ratio"]` 읽음 → KeyError. 현재는 호출부(`strategy_runtime.py:66`)의 30봉 가드로 가려져 미발현. 어댑터도 30봉 미만 스킵으로 동일 처리.
- **검증**: SKYQ 7/7 hard_gate=live_engine 결과 완전 동일(2/0/4/1, net $59.36). live_engine ~33s/window(봉마다 지표 재계산).

**변경사항:** `scripts/replay_tc_shadow_strategies.py`, `scripts/replay_all_strategy_replay.py`.

### [2026-07-11 23:30]
**Q:** live_engine 4일 배치 → 느림 원인/튜닝/forming(intrabar) 진입/체계적 스윕.

**A:**
- **속도 21배**: live 엔진이 봉마다 `record_event`→`shared_state.push_json`(.runtime JSON read-append-rewrite, O(n²) 디스크IO)로 73s/window. 어댑터에서 `push_json`/`event_bus.publish` no-op + 봉당 지표 context 메모(4엔진 공유) → 3.5s. **API 호출 아님, 로컬 IO였음.**
- **4일 live_engine 결과**: 완성봉 진입 +$189.08(63거래). hard_gate replay(+$186.45)보다 낮지 않고 오히려 상회. replay가 live 진입과 95% 일치하지만 live_only 신규거래 존재(7/10 −$26 등).
- **live 버그 수정**: `_volume_shock_pullback_patterns` 봉<12 early-return이 `volume_ratio` 등 키 누락 → `evaluate()` KeyError. 정상 return과 동일 키로 보강. 런타임은 30봉 가드(strategy_runtime:66)로 미발현이었음.
- **튜닝(데이터 기반)**: 진입 score는 모두 100점→무의미. 실제 지표 분포로 VWAP Soft 승자 trade_strength≥73.67 vs 패자≤73.08 clean gap → `strategy_vwap_soft_min_trade_strength` 72→**73.5**. VWAP 60%승/+$8 → 100%승/+$50, 4일 합계 **+$189.08**. Liquidity Pullback은 승/패 분리선 없어 미조정(오버피팅 방지).
- **forming(intrabar) 진입 구현**: `ENTRY_MODE=live_engine_forming`. 봉 진행 중 synthetic 가격경로로 실시간 진입, flow는 N-1 완성봉 고정(lookahead 없음). 결과 **−$559.70(4일)** = intrabar 고점 chase 참사. → **live는 `strategy_include_live_forming_candle=False`(완성봉) 유지 권장.** 청산은 forming과 무관(live 1초 bid 폴링, replay synthetic 경로 = 둘 다 실시간).
- **스윕 하네스**: 어댑터 `reset_caches()` 추가. `sweep_live_engine.py`로 10개 임계값 OAT 병렬 스윕(baseline +$189.08 재현 검증).

**변경사항:** `scripts/replay_tc_shadow_strategies.py`, `scripts/replay_all_strategy_replay.py`, `services/backend/app/core/config.py`, `services/backend/app/services/strategy_engine.py`.

### [2026-07-12 01:30]
**Q:** 일반화(모든 날 승률·거래밀도·수익률 일정 이상) 기준으로 튜닝. 조건 ablation → Config D 반영 + 안 쓰는 전략 정리(UI 포함).

**A:**
- **일반화 스코어카드**: baseline 4일 중 7/10만 실패(승률43%/거래밀도0.22/수익률−0.17%). 편차 큼(일 수익률 std 0.53). Liquidity Pullback이 안티-일반화(7/8 +3.8% 한탕, 나머지 3일 부진).
- **조건 ablation(33 게이트, live_engine, 병렬)**: 전역 하드게이트 5개 전부 무의미(중복). 풀어서 이득은 딱 2개 — MICRO min_10bar_change 제거(+6거래/+$23), GLOBAL min_notional 30k→0(+3/+$7, 7/10 최대 개선). 나머지는 보호막(풀면 손해) → 전략은 이미 타이트.
- **Config D 채택**: Liquidity Pullback 컷 + MICRO 10bar 게이트 제거 + GLOBAL notional 0. 결과 46거래 65.2%승 $181.5, **4일 전부 양수**(+0.59/+0.42/+1.06/+0.20%), 일 수익률 std 0.53→0.32, worst day −0.17%→+0.20%. (총액 최대는 Config B $219.7이나 3일 양수라 일반화 열세.)
- **반영**: `config.py`(3값+주석), `.env`, `.env.conda.example`에 Config D. `strategies.py _active_strategies_payload`를 활성 3개(First Pullback/VWAP Soft/Micro Breakout)만 반환하도록 정리(enabled 필터) → UI 자동 정리. Surge/Liquidity Sweep/Liquidity Pullback 숨김.
- **검증**: 기본 설정으로 재실행 → Config D 재현($181.5, 4/4). live 가드 통과. **주의: 실행 중 백엔드는 재시작해야 반영(get_settings lru_cache). notional=0은 live 슬리피지 위험 → 필요시 10000 floor 권장. 4일은 일반화 확언엔 부족.**

**변경사항:** `services/backend/app/core/config.py`, `services/backend/app/api/routes/strategies.py`, `.env`, `.env.conda.example`.

### [2026-07-12 03:00]
**Q:** 새 단타 전략 3개 수립해서 기존+새것 replay 비교 (여러 라운드) + Config D 반영 후 백엔드 재시작.

**A:**
- **백엔드/웹 재시작**: stop-dev.cmd로 정지, Start-Process(detached)로 run-backend.cmd/run-web.cmd 재기동. Config D 로드 확인(strategies API가 활성 3개만 반환). live 포지션/주문 0 확인 후 진행. notional floor는 검증값 0에서 **live 안전용 10,000**으로 상향(config/.env/.env.example).
- **replay hard_gate가 runtime과 불일치**: hard_gate는 STRATEGIES dict의 signal_*를 직접 호출하며 `*_enabled` 플래그를 무시 → retired Liquidity Pullback이 replay에 나옴. STRATEGIES를 활성 3개(First Pullback/VWAP Soft/Micro Breakout)로 축소해 runtime과 정렬.
- **신규 전략 4라운드 전부 실패**(hard_gate 4일): v1 돌파형(Bull Flag/Coil/Trend-Day) −$60~−329, v2 반전형(Capitulation/Failed Breakdown/Absorption) −$11~−73, v3 논문(ORB-Zarattini/Connors RSI-2/Gao Momentum) −$12~−167, ABCD −$426. 공통: 많이 발동·낮은 승률(23~38%)·큰 손실.
- **결론**: 유니버스가 $0~20 페니스톡(median $1.54, ETF 제외 = 저가주 단타 전용). 논문 전략은 대형주/지수용이라 실패. 내 아키타입은 "기존 게이트가 거부한=지는 셋업"에서만 거래 생성 → 손실. **4일론 새 엣지 검증 불가(과적합).** 기존 튜닝된 3전략이 이 데이터의 엣지에 근접. **진짜 레버는 전략이 아니라 더 많은 날 데이터 수집.**
- 모든 실험 코드(v1/v2/v3/ABCD signal_* + 헬퍼) 완전 삭제. STRATEGIES = 활성 3개 유지.

**변경사항:** `scripts/replay_tc_shadow_strategies.py`(ma120 파싱 추가, 실험 전략 추가/삭제 후 원복), `services/backend/app/core/config.py`, `.env`, `.env.conda.example`.

### [2026-07-12 04:30]
**Q:** 데이터 수집 파이프라인 점검/실행 (더 많은 날 데이터 확보). B(Alpaca 백필)는 Toss 랭킹 재현 불가 → A(전진 캡처)로.

**A:**
- **파이프라인 구조**: ① `capture_toss_ranking.py`(매일 장마감, 랭킹=유일한 비복구 데이터 저장) ② `collect_toss_ranking_charts.py --ranking-file`(Alpaca 과거 차트로 enriched CSV 생성, 언제든). 세션 ET날짜 D → KST window [D 17:00, D+1 08:00], out-dir session_D, max_price 20.
- **점검 결과**: 랭킹 7/07~7/10 캡처 완료, Toss/Alpaca 자격증명 OK. `TossRankingCapture` 스케줄 작업이 **이미 존재·정상**(매일 08:00 KST, last result 0). 즉 A의 랭킹 단계는 자동화 완료. 갭 = 차트 수집이 수동.
- **B 기각**: Alpaca 거래대금 랭킹 ≠ Toss 랭킹(실제 거래 유니버스) → 백필하면 다른 유니버스 검증이 됨. 또한 Toss API는 과거 날짜 랭킹 미제공 → 과거 백필 불가. A가 정답.
- **완성**: 신규 `scripts/collect_latest_ranking_charts.py`(최신 랭킹 스냅샷 찾아 collect 자동 실행, idempotent) + 신규 스케줄 작업 `TossChartCollect`(매일 08:30 KST, liive/Interactive/Limited, 30분 제한, StartWhenAvailable). → 파이프라인 end-to-end 자동. 주말 자동 skip. PC 켜짐+로그인 필요.
- **다음**: 매 거래일 1일 누적. ~15-20일 쌓이면 기존 3전략 일반화 재검증 + 패턴 마이닝.

**변경사항:** `scripts/collect_latest_ranking_charts.py`(신규), Windows 스케줄 작업 `TossChartCollect`(신규).

### [2026-07-13 최종 검증]
**Q:** ABCD 조건 추가/삭제로 튜닝 재시도 + replay와 runtime이 전체적으로 같은 프로세스인지 최종 확인.

**A:**
- **ABCD 튜닝 3중 검증 후 폐기**: (1) 기존 조건 지표 승/패 분리 없음, (2) entry_indicators_json 전체 ~18지표 스캔 → 최고 분리 recent_10bar_change 0.21(약함), (3) 그걸 조건 추가+스윕(0~0.08) → 승률 27%→35% 한계, 모든 임계값에서 순손익 마이너스(−$426~−$41). 결론: 진입 시점에 승/패 구분 정보가 없음(돌파는 진입후 노이즈가 결정) → 튜닝 불가. ABCD 코드/STRATEGIES 완전 제거, 3전략 복구.
- **replay↔runtime 정합 최종 확인**: 활성 전략 3개가 config 플래그 / live EntryPatternEngine / replay STRATEGIES / 백엔드 UI payload 네 곳 모두 일치(MATCH True). 공유 모듈 확인: 진입=EntryPatternEngine(runtime & replay live_engine 동일 클래스), 청산/게이트=strategy_decision(evaluate_exit_decision, evaluate_entry_fill_gate, advance_trailing_stop, bounded_stop_exit_price), 수수료=fee_model.toss_fee_breakdown, 설정=get_settings(). → **replay live_engine ≡ runtime (로직 동일)**. hard_gate는 진입만 별도 signal_*(≈95% 근사). 필연 차이는 데이터 소스(Alpaca 녹화 vs 실시간 Toss)·체결가·시뮬 vs 실주문뿐. **지침: runtime-충실 검증은 --entry-engine live_engine.**

**변경사항:** `scripts/replay_tc_shadow_strategies.py`(ABCD 추가 후 삭제, 3전략 유지 — net no-op).

### [2026-07-13 라이브 실측 로깅]
**Q:** replay 기본을 live_engine으로 / 점수 게이트 제거 / 매일 아침 라이브 매수·매도 타임라인 + 각 주문 시점 120봉 확인.

**A:**
- **replay 기본 = live_engine**: 모듈 `ENTRY_MODE="live_engine"`, replay_all `--entry-engine` 기본 live_engine, 출력 파일도 live_engine이 정식(무접미사) 소유. hard_gate는 빠른 근사 opt-in. → 기본 replay = runtime.
- **점수 게이트 정정**: 활성 3전략은 `_build_rule_evaluation`에서 이미 `entry_allowed = not failed_conditions`(순수 하드 AND, 점수는 표시 전용). min_score=0 테스트해도 결과 불변(inert) 확인. 앞서 "live=점수제" 설명은 오류였음 — 활성 경로는 replay와 동일 AND. 점수 게이트는 비활성 구식 2엔진에만 남음(거기선 inert 아님, 그대로 둠).
- **손익률 정합**: replay live_engine ↔ runtime은 로직 동일하나 손익 숫자는 다름(데이터 소스 Alpaca녹화 vs Toss실시간, 가정체결 vs 실주문·슬리피지). "같은 결정규칙, 다른 실현결과". 라이브가 보통 더 나쁨(슬리피지) → 소액으로 실측 대조 필요.
- **라이브 결정 로깅 신설**: `services/backend/app/services/live_decision_log.py`(안전 append-only JSONL, 주문 흐름 절대 차단 안 함). strategy_runtime 진입/청산 주문 시점에 `_log_live_decision` 훅 → 각 매수/매도 결정 + **그 시점 120봉 + 지표**를 `exports/live_snapshots/live_<ET날짜>.jsonl`에 기록(replay session_<ET날짜>와 동일 날짜체계). 뷰: `scripts/show_live_snapshots.py [날짜] [--export]`(타임라인 + 봉 CSV). 시뮬 테스트 통과(120봉 저장 확인). 백엔드·웹 재기동으로 활성화.

**변경사항:** `scripts/replay_tc_shadow_strategies.py`, `scripts/replay_all_strategy_replay.py`, `services/backend/app/services/strategy_runtime.py`, `services/backend/app/services/live_decision_log.py`(신규), `scripts/show_live_snapshots.py`(신규).

### [2026-07-13 10:15]
**Q:** Alpaca에선 Micro가 잡히고 Toss에선 안 잡힌 원인 규명 + "체결을 덜 보는 게 문제면 flow 임계값을 Toss 스케일로 재튜닝"
**A:** 원인 = **데이터 소스별 trade_strength 계산 차이**. Micro 4진입(BATL/SKYQ/QTTB/MIMI)의 Alpaca 신호봉 ts=80.5~87.6(전부 80 문턱 아슬), 같은 종목 현재 Toss ts=35.8~50.6 → −31~−46 갭. Micro flow_ok(ts≥80) 기준: Alpaca 통과→replay 진입, Toss 미달→runtime 미진입. 근본: Toss는 REST 폴링(`_poll_trade_symbol` **count=5**, 초당 2종목→종목당 ~15초)이라 체결을 극히 적게 봐서 ts가 저평가/노이지. 함의: 전략은 Alpaca flow로 튜닝됐는데 라이브는 Toss flow로 돎 → 라이브가 replay보다 진입 훨씬 적음(오늘 runtime 0건).
- **재튜닝 순서(사용자 채택: 샘플링 개선+레코더 먼저)**: ①체결 샘플링 `count=5→50`(API 상한, 요청 수 무변화라 rate 안전) ②Toss 봉별 flow 레코더 신설 → 개선된 Toss 분포 수집 후 ③실제 갭 재측정(샘플링만 고쳐도 갭 상당 축소 가능) ④Toss 스케일 임계값 재튜닝. 지금 값(언더샘플 노이즈)에 바로 맞추면 정규장/샘플링개선 시 과진입 위험 → 순서 중요.
- **신규**: `services/backend/app/services/toss_flow_recorder.py`(종목×분당 1행, 분마감 시점 flow≈close, ts=None행 제외, `exports/toss_flow/toss_flow_<ET날짜>.csv`, 전 구간 try/except로 realtime 루프 차단 안 함). realtime_runtime `_run` 루프(1초 주기)에 `record_flow(flow_snapshot, latest_prices)` 훅. 스모크테스트 통과(분 롤오버 flush→close-time 라벨 CSV 정상). 백엔드 재시작으로 활성화(사용자 직접 재시작 예정).
**변경사항:** `services/backend/app/adapters/market_data/toss.py`(count=5→50), `services/backend/app/services/toss_flow_recorder.py`(신규), `services/backend/app/services/realtime_runtime.py`(레코더 훅+import).

### [2026-07-14 00:05]
**Q:** "ts는 무시해도 되나(거래대금도 보는데)?" → ablation으로 검증 → "Toss는 호가 기준으로 ts 구하는 것 같고 이게 맞다" → "aggressive_buy/sell을 60초로 윈도우로 가자 (단 count=50은 limit 걸림)"
**A:**
- **ts ablation(4일, Alpaca clean 데이터)**: baseline 49t/61%/+$151.6 → **ts 게이트 제거 시 86t/40%/−$183.6**(승률·손익 붕괴, ts가 막던 +37건이 전부 순손실) → **ts는 가장 load-bearing한 필터, 제거 불가**. sell_pressure 제거는 결과 완전 동일(inert). notional은 크기, ts는 방향 → 대체 불가.
- **Toss ts 방법 확인**: `_trade_side`는 호가(≥ask=buy, ≤bid=sell)+틱룰 폴백 = **Lee-Ready 표준, 올바름**(사용자 관찰 정확). 갭의 진짜 원인은 **집계 윈도우**: `_events=deque(maxlen=3000)≈3.5분`, aggressive_buy/sell이 **age 윈도우 없이 버퍼 전체 누적** → ts가 3.5분 평균이라 50쪽 희석(hot 매수분이 Toss 45 vs Alpaca 봉당 85). enriched CSV(백테스트)는 봉당 60초라 갭 발생.
- **수리(관찰 우선 채택)**: aggressive_buy/sell을 60초 윈도우로 뜬 `trade_strength_60s`(shadow) 신설. **전략이 쓰는 `trade_strength`는 무윈도우 그대로 유지(라이브 무변화)**, 레코더가 둘 다 기록 → 1세션 수집 후 60s가 Alpaca 스케일(80대)로 정렬·저노이즈면 전략 전환(1줄). count=50은 백프레셔(limit) 유발이라 **안 함**; 필요시에만 디커플링(틱당 평가→폴링당 1회) 후 얹기. 유닛테스트 통과(무윈도우 95.65 유지, 60s 66.67 분리).
**변경사항:** `services/backend/app/adapters/market_data/toss.py`(_empty_flow + order_flow_snapshot 60s 윈도우/trade_strength_60s), `services/backend/app/services/toss_flow_recorder.py`(trade_strength_60s 필드).

### [2026-07-14 later]
**Q:** 5일치로 새 전략(느슨하게/RL) 만들어 일반화+트레이드↑ 시도 → 다 실패 → Micro ts 80→90 적용, 차트 로딩 개수 확인
**A:**
- **새 전략 시도 전부 기각(엄밀 검증)**: Dip-in-Leader/MPC(느슨) → train 전부 손실(승률 23~32%, 비용에 짐). 조합 채굴(~450, proxy) → 양수 0개. **실제 replay 조합채굴+홀드아웃**: train 양수 7개 → **test(07-10,13) 전멸**(승률 60%→47%, 과적합 지문). 결론: 비용 넘는 셋업이 ~1/일 희소 → 5일 표본 부족. RL은 데이터를 가장 많이 먹는 방법이라 가장 안 맞음(효과적 표본 5~15개에 수천 파라미터=암기). 병목은 알고리즘 아니라 데이터.
- **유일한 검증된 5일 개선 적용**: `strategy_micro_breakout_min_trade_strength` **80→90** (config.py). 5일 replay에서 Micro [+23,+1,+51,−17,−70]→[+45,+49,+45,+3,−6](적자일 −6, +days 4/5, 총 +$135). **⚠️ 이 숫자는 Alpaca-flow 기준**; 라이브 Toss ts는 35~50이라 ts≥90이면 Micro는 라이브에서 거의 발화 안 함(=손실 진입 억제). ts-윈도우(trade_strength_60s) 정렬 후에야 라이브에서 의미. VWAP/FP는 그대로(650k/300k).
- **차트 로딩 = 30개** (SCANNER_MAX_WEBSOCKET_SYMBOLS=30, microstructure_top_n=30). 50 아님.
**변경사항:** `services/backend/app/core/config.py`(micro ts 90), `claudy_log.md`.

### [2026-07-15]
**Q:** toss_flow 레코더가 재시작 후에도 기록 0 — 검증 불가
**A:** 원인 = **레코더 훅을 안 도는 루프에 넣음**. `realtime_runtime._run`(내 훅 위치)은 독립 `app.realtime_worker` 프로세스 전용인데, 이 배포는 combined 모드라 API가 `runtime_supervisor`(scanner 루프)로 realtime을 돌림 → realtime_runtime._run 미실행 → 훅 죽은 코드. (60s윈도우는 order_flow_snapshot에 있어 정상 계산됨, 기록만 누락.) 프로세스 진단: PID 82320=combined API(포트18001, 새코드), PID 1372=`python -`(무관 잔여). **수정**: `runtime_supervisor`에 `_run_flow_recorder_loop`(2초 주기, get_market_data_service().provider.order_flow_snapshot() → toss_flow_recorder.record_flow) 추가 + start/stop wiring. Micro ts=90은 이미 라이브(진입평가가 API 프로세스, 08:06 재시작으로 새 config 로드). 백엔드 재시작 1회면 레코더 기록 시작.
**변경사항:** `services/backend/app/services/runtime_supervisor.py`(flow recorder loop 추가).

### [2026-07-15] 코드 정리 (AI 새 전략 기반)
**Q:** trade_strength_60s 그림자 제거 + runtime/replay 전략 죽은·실험 코드 정리 (AI로 새 전략 만들 예정)
**A:**
- **trade_strength_60s 그림자 제거**: toss.py `order_flow_snapshot`/`_empty_flow`에서 60s 윈도우·trade_strength_60s 제거(무윈도우 원복), 레코더 컬럼 삭제, 옛 스키마 CSV 삭제, runtime_supervisor 독스트링 정리. 검증 근거: 60s 윈도우가 Toss ts를 Alpaca 스케일로 안 올림(라이브 88행 실측 mean 47→42, 오히려 하락). **관찰-우선 설계가 잘못된 가설을 라이브 반영 전에 차단**.
- **replay 죽은·실험 코드 제거** (AST 라인범위 기반, 주석 보존): 죽은 signal 함수 9개(pullback_reclaim, liquidity_pullback_reclaim, lower_band_snapback, vwap_reclaim, order_flow_proxy, liquidity_imbalance_proxy, absorption_breakout, runner_continuation, opening_imbalance) + 이번 세션 실험(CONDITION_PASS_FRACTION/_HARD_BASE_CONDITIONS/_fractional_entry_allowed, 호출부는 `bool(item.entry_allowed)`로 대체). 225줄 삭제(2386→2150). **활성 3전략·ARCHIVED 2개·live_engine·hard_gate 모두 유지·정상**(검증 완료).
- **stale 테스트 수정**: `test_replay_registers_current_scalp_strategy_set`가 STRATEGIES 4개(은퇴된 Liquidity Pullback 포함) 기대 → 실제 3개로 정정. 테스트 12개 전부 통과.
- **레코더 유지**: toss_flow 레코더는 AI 학습용 라이브 데이터 수집원이라 존치(무윈도우 trade_strength 등 기록). runtime 전략엔진은 라이브라 미변경(config-gated 비활성 전략은 무해).
**변경사항:** `services/backend/app/adapters/market_data/toss.py`, `services/backend/app/services/toss_flow_recorder.py`, `services/backend/app/services/runtime_supervisor.py`, `scripts/replay_tc_shadow_strategies.py`, `services/backend/tests/test_strategy_replay_script.py`.

### [2026-07-16] VWAP Soft Reclaim 은퇴(코드 전면 제거) + 2전략 walk-forward
**Q:** 3전략 일반화 안 됨(앞 날짜에 과적합) → 진단 후 VWAP Soft을 front/backend/replay/runtime 코드에서 전면 제거하고 2전략으로 walk-forward 재측정
**A:**
- **진단(7세션 07-07~15 replay, live_engine)**: train(07-07~10) 18t/83%/+$141 → holdout(07-13~15) 10t/**20%**/**−$60**. 세 전략 모두 OOS 양수→음수. train 수익의 53%가 상위 3거래(fat-tail). **사용자 진단 정량 확증**.
- **VWAP Soft 결정타**: 승리 6 vs 패배 4를 진입지표(ts/sell_pressure/notional/10bar/expected_upside/bb/spread/imbalance) 전부 비교 → **분포 구분 불가**(07-09 JLHL 승 ≡ 07-15 KUST/SOBR 패, 같은 셋업). JLHL(+$33.9) 한 종목 빼면 VWAP Soft 7일 −$27.9. **일반화 엣지 없음 → 은퇴가 답**(진입 필터로 승/패 분리 불가).
- **코드 전면 제거**: config.py(플래그·9파라미터·primary_name→micro_breakout, `strategy_vwap_soft_min_10bar_change_pct`는 공유 헬퍼 `_strong_momentum_without_vwap`가 써서 `strategy_strong_momentum_min_10bar_change_pct`로 개명 존치), strategy_engine.py(VwapSoftReclaimEngine·evaluate_all 분기·`_vwap_soft_reclaim_patterns`·`_recent_below_vwap` 제거), strategies.py route(목록 항목), replay 스크립트(signal 함수·STRATEGIES·전용 상수 7개·is_momentum 목록; `VWAP_SOFT_MIN_10BAR_CHANGE_PCT`→`STRONG_MOMENTUM_MIN_10BAR_CHANGE_PCT` 개명), .env.conda.example, 테스트 3개. 프론트는 `/api/strategies` 구동이라 코드 변경 불필요.
- **검증**: 내가 만진 파일 ruff clean, 전체 pytest 96 passed·회귀 0건. 남은 실패 3건(candle_builder 2 + Liquidity Pullback stale 테스트 1)은 **clean HEAD에서도 실패하는 기존 이슈**(stash로 확인).
- **2전략 walk-forward(재측정)**: train 12t/75%/**+$90.84** → holdout 6t/33%/**−$15.81**(3전략 −$60 대비 최악 −$45 출혈 제거). 7일 합 18t/**+$75.03**. First Pullback: train +$43 / holdout 0t(비참여). Micro: train +$48 / holdout −$16(VIVS 07-15 −$12.3 hard_stop 포함). **홀드아웃 잔여 손실은 07-15 레짐 문제로 좁혀짐** → 다음 후보: 07-15류 나쁜 장세 회피 레짐 필터.
- **주의**: replay 스크립트는 0거래 세션의 trades.csv를 안 덮어써 07-10에 stale VWAP Soft 행이 남았었음(집계 시 VWAP Soft 행 제외로 보정, 07-10 파일 헤더만 남기고 정리).
**변경사항:** `services/backend/app/core/config.py`, `services/backend/app/services/strategy_engine.py`, `services/backend/app/api/routes/strategies.py`, `scripts/replay_tc_shadow_strategies.py`, `.env.conda.example`, `services/backend/tests/test_strategy_decision.py`, `services/backend/tests/test_strategy_single_active.py`, `services/backend/tests/test_strategy_replay_script.py`, `exports/strategy_replay/session_2026-07-10/active_strategies_replay_trades.csv`, `claudy_log.md`.

### [2026-07-20] 기대값 게이트 검토·정리 + GBM 천장 측정 (9세션)
**Q:** 거래가 어디서 줄어드나 → 기대값 계산 검토 → 전체 수정 → (검증) 비-binding 확인 → ①게이트 정리 ②GBM 둘 다 적용
**A:**
- **신규 데이터**: 07-16(17종목)·07-17(21종목) 수집 → 총 9세션. 현재 2전략 전진테스트: 07-16 1거래 +$10.85, 07-17 0거래. **미지 데이터에서 안 터짐(보수적 게이트 유지)이나 거의 참여 안 함.** 9세션 통산 19거래 +$85.89.
- **진입 퍼널(9세션, 12.7만 바→6~9신호)**: 3관문 곱연산 — ①common_entry_ok(기대값+유동성, −64~69% 첫 최대컷) ②셋업형태(volume_shock/전고돌파, −67~89%) ③ts flow(−89~91% 최종 학살). 절대량 최대=①, 최종 9할컷=③(ts).
- **기대값 게이트 검토**: `entry_expectancy_ok`은 EV가 아니라 **한쪽 reachability 체크** — P(승)·손실(손절폭) 항 없음. 상승여력 vs TP만 봄 → 저승률×상한상승 vs 큰손절 셋업을 통과시킴(음의 EV 통과). 순환(분자·분모 둘다 변동성 비례)·폴백 약화.
- **⚠️ 검증으로 "전체 수정" 기각**: bracket 테스트(accept-all vs reject-all vs R:R k=0.8~2.0) → **strict ts(90/80)에서 게이트 완전 제거해도 거래 불변**(non-binding). loose ts(58/55)에서도 R:R k=2.0까지 조여도 holdout −$121(홍수 못 거름). 이유: 보상항(expected_upside)이 승/패 구분 못 함(7번째 벽). **기대값 계산 통째로 고쳐도 손익 0.01달러도 안 변함** → 검증이 헛수고 refactor를 차단.
- **①정리 적용(동작 불변)**: replay `entry_expectancy_ok`→`entry_reachability_ok` 개명+정직 docstring(non-binding 명시), 호출부 2곳(common_entry_ok, experiment_chart_reset) 갱신. live `_scalp_expected_edge_ok`에 "비용 floor지 EV 아님" docstring. ruff 통과, 테스트 11개 통과, 07-08 replay 결과 동일(+$34.94).
- **②GBM 천장 측정(sklearn 1.9 신규설치, HistGradientBoosting)**: 라벨 +3%TP before −3%SL/5봉, 피처 14개, train 07-07~10 / test 07-13~17. **holdout ROC-AUC 0.7508(진짜 예측력!)** — 승률 base 22%→상위예측 46%로 2배. **단 range_pct 독주(중요도 11배)=변동성 동어반복**, 방향천장 46%<손익분기65% → ±3% 대칭 롱은 최고예측도 −EV(−1.15%). 자기상관으로 AUC 낙관편향. **함의**: GBM은 ±3% 신호론 못 쓰나 **변동성 랭커론 유효** → GBM 랭킹 + 비대칭(트레일링) 청산으로 fat-tail 포획이 유일하게 뚫릴 여지(parabolic 숏 양의 스큐와 동일 구조). "엣지는 극단/변동성에 있다"를 GBM이 독립 확증.
**변경사항:** `scripts/replay_tc_shadow_strategies.py`(entry_reachability_ok 개명+docstring), `scripts/experiment_chart_reset_replay_strategies.py`(호출부), `services/backend/app/services/strategy_engine.py`(docstring), env에 scikit-learn 설치.

### [2026-07-20] Parabolic 숏 해부·튜닝·코드 편입 (사용자: 원래 숏 전용)
**Q:** 롱 GBM+비대칭이 안 됨 → 숏 라벨로 재적용 → (사용자: 원래 숏만 했음) → parabolic 손절 해부·진입개선 → 코드 편입, 근데 거래수 너무 적음
**A:**
- **숏 GBM+비대칭도 holdout −$1491**(롱 −$1474와 거울상). broad/빈번 방향예측은 롱·숏 둘 다 엣지 없음. **유일 엣지=선택적 극단(parabolic), broad 모델이 희석**. 9세션 parabolic 숏 holdout 11t/64%/+$21 유지.
- **손절 7건 해부**: 전부 신호봉이 신고가 만들고 진입봉이 더 급등(SOBR 진입후 +17%)=**아직 안 끝난 climax에 일찍 숏**. 7건 전부 진입시 하락확인 없었음.
- **진입 타이밍 개선 시도 → backfire**: "신호봉 저점 깨질 때까지 확인 후 진입"이 train +$36→−$5, holdout +$21→−$18. 덤핑이 빨라 확인 대기=승자 조기진입 엣지 훼손>손절 회피. **청산 폭 확대도 backfire**(타이트 트레일이 최적). → **현재 진입/청산 이미 최적, 손절은 줄일 수 없는 비용(양의 스큐가 덮음)**.
- **거래수: 임계값 완화 sweep**. ⚠️ A/B/C/E는 **train 음수/breakeven인데 holdout 폭등**=레짐(초반 급등주장=숏손실, 후반=숏이득). holdout 최대로 고르면 메타 과적합. **정직 기준(양쪽 양수·최악값 최대)=config D**(10bar 8%/**bb1.05 유지**/vol1.3/pos.45): train +$24 / holdout +$37, **거래 ~2배**. C(+$166 holdout)는 train breakeven=레짐베팅이라 기각.
- **코드 편입**: `scripts/replay_parabolic_short.py` 신규(연구 모듈, 숏 전용, **라이브 숏 차단 유지**). config D + 검증된 실행모델(bounded stop, 타이트 트레일). walk-forward train/holdout 분리, summary JSON+trades CSV 출력. ruff 통과, 실행 확인(train 12t/+$24, holdout 14t/+$37, 총 26t/+$62). 세션 쌓이며 forward 검증 예정. 추가 거래는 완화 아닌 형제 극단셋업+데이터.
**변경사항:** `scripts/replay_parabolic_short.py`(신규), `exports/strategy_replay/parabolic_short_replay_{summary.json,trades.csv}`(출력), `claudy_log.md`.

### [2026-07-20] 숏 트랙 주력화 1단계: 롱 비활성화 + 형제셋업(blow-off) 편입
**Q:** (사용자: live paper 앱 돌리지만 롱 다 제거 OK, 숏 주력) 형제 극단-숏 시제작 → 1단계 진행
**A:**
- **형제 극단-숏 4개 시험**: A(VWAP과확장) train −$124/holdout +$64=레짐, B(실패리테스트) train +$78/holdout −$220=레짐, D(갭업) 1건, **C(거래량 blow-off vr≥3+6%급등+반전봉) train +$68/holdout +$37 양쪽 양수, parabolic과 9%만 중복=새거래.** A/B/D 기각(레짐/표본부족), **C 채택**.
- **1단계 실행(롱 비활성화)**: config.py 롱 플래그 전부 False(volume_shock·micro도 False로), .env 동일. 롱 엔진 코드는 존치(삭제-대기, 런타임 통합 후 3단계에서 물리삭제). pytest 96 passed, **새 실패 0**(기존 3건만).
- **1단계 실행(blow-off 편입)**: `replay_parabolic_short.py`→**`replay_extreme_shorts.py`로 개명·다중셋업화**(Parabolic + Volume Blow-off, shadow 분리집계). config C blow-off(vr≥3.0/10bar 6%/pos.40) 추가. 구 단일모듈+출력 삭제. ruff 통과, 실행: Parabolic train12/+$24·holdout14/+$37, Blow-off train73/+$102·holdout70/+$40, **COMBINED 169거래·양쪽양수·holdout +$77(+3.86%)**. 거래수 18→169로 선택성 유지하며 대폭 증가.
- **주의**: blow-off 승률 49%(스큐로 순양수), 다중비교 위험 있어 forward 검증 필요는 parabolic과 동일. 남은 단계: 2)숏 런타임 통합 3)롱 엔진 물리삭제.
**변경사항:** `services/backend/app/core/config.py`(롱 플래그 False), `.env.conda.example`, `scripts/replay_extreme_shorts.py`(신규·개명), `scripts/replay_parabolic_short.py`(삭제), `exports/strategy_replay/extreme_shorts_replay_*`(출력), `claudy_log.md`.

### [2026-07-20] 2단계-A: 페이퍼 브로커 숏 포지션 정식 지원 + 테스트
**Q:** (사용자: 페이퍼 브로커에 숏 정식 지원 + 테스트) 2단계 진행
**A:**
- **발견**: 페이퍼 브로커는 롱 전용 — `_apply_fill`에서 buy=롱오픈(손절 아래), sell=롱청산((청산−진입)손익). sell without position=무시. 숏(매도오픈/매수커버/손절위/손익반전) 개념 없음. 런타임 on_trade도 side="buy" 하드코딩. → 정식 지원=주문 안전 코드 변경(신중).
- **설계**: `OrderRequest.position_side`("long"/"short", default long=완전 호환), `Position.direction`+`low_watermark` 추가. is_close = (long&sell) or (short&buy). open=(long&buy)or(short&sell).
- **구현**: `_simulate_fill`(청산 판정 방향-인지, 숏오픈은 기존포지션 불필요, 부분체결 open 일반화). `_apply_fill`→open/close 라우팅: 청산 손익 방향-인지(숏=(진입−청산)×수량), 수수료 side=fill.side(숏오픈=sell로 SEC/TAF, 커버=buy), 부분청산 model_copy로 direction/워터마크 보존. open: 숏이면 손절 위(×1.035)·목표 아래(×0.97)·low_watermark, 롱이면 기존. 평균단가 병합도 방향-인지. risk(`_paper_open_risk_reject_payload`)는 open(롱매수/숏매도)에만 적용.
- **테스트**(`test_paper_broker_short.py` 신규 7개): 숏오픈(손절>진입·low_watermark), 하락시 커버=이익, 상승시 커버=손실, 부분커버 direction 보존, 포지션없이 커버=거부, 숏 max_open_positions 리스크, 롱 왕복 호환. **ruff 통과, 전체 103 passed(기존 96+7), 회귀 0**(기존 실패 3건만).
- **주의**: 라이브 숏 여전히 차단(internal_paper만). 남은 2단계-B: on_trade에 숏 진입 생성 + `_monitor_exit` 숏 청산(손절 위/트레일 low) + extreme_shorts 신호를 라이브 캔들에 포팅.
**변경사항:** `services/backend/app/domain/models.py`(position_side/direction/low_watermark), `services/backend/app/services/paper_broker.py`(숏 지원), `services/backend/tests/test_paper_broker_short.py`(신규), `claudy_log.md`.

### [2026-07-20] 2단계-B: 숏 런타임 통합 (라이브 신호 포팅 + 진입 + 청산 모니터링)
**Q:** 2-B 이어가기 (on_trade 숏 진입 + 청산 + extreme_shorts 신호 라이브 포팅)
**A:**
- **신규 `services/backend/app/services/short_runtime.py`** (격리 모듈): 라이브 완성 캔들에서 지표 계산(recent_10bar/bb_position(SMA20±2std)/volume_ratio/bar_close_pos/climax), Parabolic(config D)·Blow-off(config C) 신호 + common_short_ok. `on_completed_candle`→숏 진입(execution snapshot side="sell" bid, position_side="short", exit_plan 손절 위/목표 아래). `monitor_short_exits`→숏 포지션 순회, latest_price로 하드스톱(price≥stop)·트레일링(low_watermark 래칫, profit≥0.6%면 low×1.006 위로 반등 시 커버), execution snapshot side="buy" ask로 커버. 전 경로 try/except로 런타임 루프 보호.
- **config**: `strategy_short_track_enabled`(기본 **False**=아무것도 안 바뀜), `strategy_short_max_notional_usd=300`. 게이트: enabled AND trading_mode==internal_paper. **라이브 숏 주문은 절대 안 함**(internal_paper 브로커만).
- **와이어링(최소, 게이트)**: strategy_runtime `on_trade`에 `short_track_runtime.on_completed_candle` 훅(캔들 윈도우 준비 후, 롱과 독립—롱 비활성이라 롱은 조기 return). runtime_supervisor 포지션 루프에 `monitor_short_exits` 호출(self-gated). import 순환 없음(short_runtime은 strategy_runtime import 안 함).
- **테스트**(`test_short_runtime.py` 6개): 피처 헬퍼, blow-off 신호 발화, on_completed_candle 숏 오픈(손절>진입), 비활성 시 no-op, 하드스톱 커버, 트레일링 커버(2콜 low_watermark 래칫→반등 커버, 이익 확인). ruff 통과, **전체 109 passed(103+6), 회귀 0**(기존 3건만). 앱 부팅 OK.
- **운영 노트**: 로컬 `.env`가 `trading_mode=live`라 숏 트랙 현재 휴면. 활성화 = TRADING_MODE=internal_paper + STRATEGY_SHORT_TRACK_ENABLED=true. 남은: 3단계(롱 엔진 물리삭제).
**변경사항:** `services/backend/app/services/short_runtime.py`(신규), `services/backend/app/core/config.py`(플래그 2개), `services/backend/app/services/strategy_runtime.py`(훅+import), `services/backend/app/services/runtime_supervisor.py`(훅+import), `services/backend/tests/test_short_runtime.py`(신규), `claudy_log.md`.

### [2026-07-20] 3단계 시작: 롱 엔진 물리삭제 (blast-radius 매핑 + Stage A.1)
**Q:** 3단계 롱 엔진 물리삭제 진행
**A:**
- **blast-radius 매핑**: 롱 엔진은 라이브 런타임 중심 허브 — `EntryPatternEngine` 사용처=strategy_runtime.on_trade + orders.py(롱 페이퍼 엔드포인트 ~540-620) + symbols.py(종목상세 평가). 공유 지표 헬퍼(`_indicator_snapshot`/`_normalize_candles`/`_high_failure_count`/`_macd_recovery_status`)는 롱 아니라 runtime 청산·symbols가 계속 씀 → strategy_engine 통째 삭제 불가(헬퍼 존치 필요). strategy_runtime은 시장데이터 어댑터가 on_trade 호출하는 허브라 삭제 불가, 롱 경로만 도려내야 함. **삭제는 의존성 순서 필요**: 라우트 사용처→엔진 클래스→config 플래그→테스트.
- **Stage A.1 실행+검증**: strategy_runtime.on_trade의 **롱 진입 생성 블록 제거**(risk preview·EntryPatternEngine.evaluate_all·live/paper 제출 루프, ~66줄). 숏 훅 유지. `EntryPatternEngine` import 제거(4 헬퍼 존치). **런타임이 더 이상 롱 진입 생성 안 함**(기능적 핵심). ruff 클린, 전체 109 passed, 회귀 0.
- **남은 3단계(대형·cascade)**: strategy_runtime 죽은 롱 메서드(_record_live_strategy_candidate ~226줄, _submit_internal_paper_order ~183줄, 호출처 0 확인)+_monitor_exit 롱 청산 삭제, strategy_engine 엔진 클래스 삭제(헬퍼 존치), orders.py 롱 엔드포인트, symbols.py 평가, config 롱 플래그, strategies 라우트, 롱 테스트, .env. 대형 연속블록이라 안전상 dedicated 패스로 이어가야 함.
**변경사항:** `services/backend/app/services/strategy_runtime.py`(on_trade 롱블록·EntryPatternEngine import 제거), `claudy_log.md`.

### [2026-07-20] 숏 런타임 신호 parity 검증 + 포팅 버그 2건 수정
**Q:** (장마감) 숏 런타임과 같은 조건의 replay로 검증
**A:**
- **검증 방법**: 숏 런타임(`short_runtime.py`, 라이브 캔들에서 지표 계산)의 신호가 검증된 replay(`replay_extreme_shorts.py`, enriched 컬럼 읽음)와 **같은 봉에서 발화하는지** 대조(137,123봉, 9세션).
- **버그 발견**: 초기 런타임이 replay보다 과다 발화(parabolic 30 vs 29, **blowoff 253 vs 194**). bb_position은 정확 일치, 원인 2건: ①`_recent_10bar_change` off-by-one(`candles[-11]` vs replay lookback=10=`candles[-10:]`) ②`_volume_ratio` 기준선(런타임 현재봉 제외 20 vs enriched `volume_ma20`=**현재봉 포함 20봉 SMA**, 경험적 확정 col==mean(vol[i-19:i+1])).
- **수정**: 두 함수를 replay 정의와 정확히 일치하도록 고침. 재검증 **parity 100.000%**(parabolic 29=29, blowoff 194=194, 불일치 0). 옛 버그 동작을 검증하던 test_feature_helpers 기대값 정정(rows[-11]→rows[-10]). ruff 클린, 전체 109 passed 회귀 0.
- **의미**: 라이브 숏 런타임이 **검증된 백테스트와 정확히 같은 봉에서 진입 신호**를 냄(활성화 시 과다거래 없음). 미검증 잔여: 청산 경로는 라이브가 per-tick latest_price, replay는 봉 high/low라 intrabar 그래뉼래러티 차이 존재(신호 parity와 별개).
**변경사항:** `services/backend/app/services/short_runtime.py`(_recent_10bar_change·_volume_ratio 정정), `services/backend/tests/test_short_runtime.py`(기대값 정정), `claudy_log.md`.
