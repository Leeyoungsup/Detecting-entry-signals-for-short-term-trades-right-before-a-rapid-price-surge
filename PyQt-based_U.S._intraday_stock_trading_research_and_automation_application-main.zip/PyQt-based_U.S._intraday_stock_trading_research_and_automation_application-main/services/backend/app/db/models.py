from datetime import datetime
from uuid import uuid4

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, JSON, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


def new_id() -> str:
    return str(uuid4())


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


class SystemSnapshot(Base, TimestampMixin):
    __tablename__ = "system_snapshots"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    trading_mode: Mapped[str] = mapped_column(String(32), nullable=False, default="internal_paper")
    status_level: Mapped[str] = mapped_column(String(32), nullable=False, default="NORMAL")
    live_enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    market_data_status: Mapped[str] = mapped_column(String(32), nullable=False, default="unknown")
    execution_gateway_status: Mapped[str] = mapped_column(String(32), nullable=False, default="unknown")
    kis_rest_status: Mapped[str] = mapped_column(String(32), nullable=False, default="TODO_KIS_VERIFY")
    kis_websocket_status: Mapped[str] = mapped_column(String(32), nullable=False, default="TODO_KIS_VERIFY")
    last_tick_age_sec: Mapped[float | None] = mapped_column(Float)
    equity_usd: Mapped[float] = mapped_column(Float, nullable=False, default=2000.0)
    realized_pnl_usd: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    unrealized_pnl_usd: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    exposure_pct: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    open_positions: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    open_orders: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    recent_warnings: Mapped[list] = mapped_column(JSON, nullable=False, default=list)


class ScannerCandidate(Base, TimestampMixin):
    __tablename__ = "scanner_candidates"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    symbol: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    rank_total: Mapped[int | None] = mapped_column(Integer)
    scanner_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    notional_1m: Mapped[float | None] = mapped_column(Float)
    notional_5m: Mapped[float | None] = mapped_column(Float)
    notional_velocity_10s: Mapped[float | None] = mapped_column(Float)
    trade_strength: Mapped[float | None] = mapped_column(Float)
    sell_pressure: Mapped[float | None] = mapped_column(Float)
    spread_pct: Mapped[float | None] = mapped_column(Float)
    bid_ask_imbalance: Mapped[float | None] = mapped_column(Float)
    atr_pct: Mapped[float | None] = mapped_column(Float)
    relative_strength_vs_qqq: Mapped[float | None] = mapped_column(Float)
    relative_strength_vs_spy: Mapped[float | None] = mapped_column(Float)
    bb_state: Mapped[str] = mapped_column(String(64), nullable=False, default="unknown")
    reclaim_state: Mapped[str] = mapped_column(String(64), nullable=False, default="waiting")
    selected_for_ws: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    selected_for_strategy: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    reject_reason: Mapped[str | None] = mapped_column(Text)
    data_latency_ms: Mapped[int | None] = mapped_column(Integer)
    is_estimated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)


class StrategySignal(Base, TimestampMixin):
    __tablename__ = "strategy_signals"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    symbol: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    strategy_name: Mapped[str] = mapped_column(String(80), nullable=False)
    strategy_version: Mapped[str] = mapped_column(String(32), nullable=False)
    parameter_set_id: Mapped[str] = mapped_column(String(64), nullable=False)
    signal_type: Mapped[str] = mapped_column(String(32), nullable=False)
    final_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    passed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    conditions: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    reject_reason: Mapped[str | None] = mapped_column(Text)


class Order(Base, TimestampMixin):
    __tablename__ = "orders"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    client_order_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    mode: Mapped[str] = mapped_column(String(32), nullable=False, default="internal_paper")
    symbol: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    side: Mapped[str] = mapped_column(String(8), nullable=False)
    order_type: Mapped[str] = mapped_column(String(32), nullable=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    limit_price: Mapped[float | None] = mapped_column(Float)
    state: Mapped[str] = mapped_column(String(48), index=True, nullable=False, default="CREATED")
    broker_order_id: Mapped[str | None] = mapped_column(String(80))
    broker_original_order_id: Mapped[str | None] = mapped_column(String(80))
    risk_snapshot: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    reject_reason: Mapped[str | None] = mapped_column(Text)
    events: Mapped[list["OrderEvent"]] = relationship(back_populates="order", cascade="all, delete-orphan")


class OrderEvent(Base, TimestampMixin):
    __tablename__ = "order_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    order_id: Mapped[str] = mapped_column(ForeignKey("orders.id"), nullable=False)
    previous_state: Mapped[str | None] = mapped_column(String(48))
    new_state: Mapped[str] = mapped_column(String(48), nullable=False)
    source: Mapped[str] = mapped_column(String(48), nullable=False)
    message: Mapped[str | None] = mapped_column(Text)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    order: Mapped[Order] = relationship(back_populates="events")


class Fill(Base, TimestampMixin):
    __tablename__ = "fills"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    order_id: Mapped[str] = mapped_column(ForeignKey("orders.id"), nullable=False)
    symbol: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    price: Mapped[float] = mapped_column(Float, nullable=False)
    slippage_bps: Mapped[float | None] = mapped_column(Float)
    broker_fill_id: Mapped[str | None] = mapped_column(String(80))


class ClosedTrade(Base, TimestampMixin):
    __tablename__ = "closed_trades"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    position_key: Mapped[str | None] = mapped_column(String(128), index=True)
    symbol: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    strategy_name: Mapped[str | None] = mapped_column(String(80))
    parameter_set_id: Mapped[str | None] = mapped_column(String(64), index=True)
    entry_mode: Mapped[str | None] = mapped_column(String(64))
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    entry_price: Mapped[float] = mapped_column(Float, nullable=False)
    exit_price: Mapped[float] = mapped_column(Float, nullable=False)
    gross_pnl_usd: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    net_pnl_usd: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    fees_usd: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    exit_reason: Mapped[str | None] = mapped_column(String(128))
    mode: Mapped[str] = mapped_column(String(32), nullable=False, default="internal_paper")
    entry_snapshot: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    exit_snapshot: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)


class Position(Base, TimestampMixin):
    __tablename__ = "positions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    symbol: Mapped[str] = mapped_column(String(16), unique=True, nullable=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    average_price: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    unrealized_pnl_usd: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    mode: Mapped[str] = mapped_column(String(32), nullable=False, default="internal_paper")


class LogEvent(Base, TimestampMixin):
    __tablename__ = "log_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    level: Mapped[str] = mapped_column(String(16), index=True, nullable=False)
    event_type: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    correlation_id: Mapped[str | None] = mapped_column(String(64), index=True)
    mode: Mapped[str] = mapped_column(String(32), nullable=False, default="internal_paper")
    symbol: Mapped[str | None] = mapped_column(String(16), index=True)
    order_id: Mapped[str | None] = mapped_column(String(64), index=True)
    severity: Mapped[str] = mapped_column(String(24), nullable=False, default="NORMAL")
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    redaction_applied: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


class Alert(Base, TimestampMixin):
    __tablename__ = "alerts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    severity: Mapped[str] = mapped_column(String(24), nullable=False)
    title: Mapped[str] = mapped_column(String(120), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    source: Mapped[str] = mapped_column(String(64), nullable=False)
    acknowledged: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
