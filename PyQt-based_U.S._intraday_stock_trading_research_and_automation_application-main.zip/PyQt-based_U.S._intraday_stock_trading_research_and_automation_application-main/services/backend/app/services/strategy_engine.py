from dataclasses import dataclass
from app.core.config import get_settings
from app.domain.enums import StatusLevel
from app.services.event_log import record_event
from app.services.market_data import get_market_data_service


@dataclass
class IndicatorSnapshot:
    close: float | None
    vwap: float | None
    ema9: float | None
    ema20: float | None
    atr20: float | None
    atr_pct: float | None
    bb_upper: float | None
    bb_mid: float | None
    bb_lower: float | None
    macd: float | None
    macd_signal: float | None
    macd_histogram: float | None
    macd_histogram_delta: float | None
    vwap_distance_atr: float | None


@dataclass
class RealtimeVolumeEvaluation:
    symbol: str
    strategy_name: str
    strategy_version: str
    parameter_set_id: str
    passed: bool
    final_score: float
    entry_allowed: bool
    watch_only: bool
    passed_conditions: list[str]
    failed_conditions: list[str]
    reject_reason: str | None
    indicators: IndicatorSnapshot
    order_flow: dict
    score_components: dict
    score_weights: dict
    gate_status: dict
    pattern_status: dict
    lower_band_status: dict
    risk_preview: dict | None = None
    entry_mode: str = "score"

    def model_dump(self) -> dict:
        return {
            "symbol": self.symbol,
            "strategy_name": self.strategy_name,
            "strategy_version": self.strategy_version,
            "parameter_set_id": self.parameter_set_id,
            "passed": self.passed,
            "final_score": self.final_score,
            "entry_allowed": self.entry_allowed,
            "watch_only": self.watch_only,
            "passed_conditions": self.passed_conditions,
            "failed_conditions": self.failed_conditions,
            "reject_reason": self.reject_reason,
            "indicators": self.indicators.__dict__,
            "order_flow": self.order_flow,
            "score_components": self.score_components,
            "score_weights": self.score_weights,
            "gate_status": self.gate_status,
            "pattern_status": self.pattern_status,
            "lower_band_status": self.lower_band_status,
            "risk_preview": self.risk_preview,
            "entry_mode": self.entry_mode,
        }


class RealtimeVolumePullbackReclaimEngine:
    strategy_name = "Pullback Reclaim"
    strategy_version = "1.0.0"
    parameter_set_id = "pullback-reclaim-v1"

    def evaluate(self, *, symbol: str, candles: list[dict], risk_preview: dict | None = None) -> RealtimeVolumeEvaluation:
        settings = get_settings()
        symbol = symbol.upper()
        normalized = _normalize_candles(candles)
        indicators = _indicator_snapshot(normalized)
        flow = get_market_data_service().provider.order_flow_snapshot().get(symbol, {})
        lower_band_breached, lower_band_reclaimed, bars_since_breach = _lower_band_reclaim_state(normalized)
        pattern_status = _volume_pullback_patterns(normalized, indicators)
        bb_position_ratio = _bb_position_ratio(indicators)
        bb_upper_entry_blocked = _bb_upper_entry_blocked(
            indicators,
            settings.strategy_upper_band_block_position,
        )
        lower_band_status = {
            "lower_band_breached": lower_band_breached,
            "lower_band_reclaimed": lower_band_reclaimed,
            "bars_since_breach": bars_since_breach,
            "bb_position": _bb_position(indicators),
            "bb_position_ratio": bb_position_ratio,
            "bb_upper_entry_blocked": bb_upper_entry_blocked,
            "bb_overheated": bb_upper_entry_blocked
            or _bb_overheated(indicators, settings.strategy_max_over_upper_band_atr),
            "entry_role": "하단/중앙 회복은 보조 가점, 상단 근접은 추격매수 차단",
        }
        score_components = _volume_pullback_score(
            candles=normalized,
            indicators=indicators,
            flow=flow,
            patterns=pattern_status,
            lower_band_status=lower_band_status,
        )
        score_weights = _score_weights(settings)
        final_score = round(sum(score_components.values()), 2)
        required_count = (
            settings.strategy_live_tick_min_candles
            if settings.strategy_prefer_live_tick_candles
            else settings.strategy_official_min_candles
        )
        required_label = (
            f"WebSocket tick-built 1분봉 {settings.strategy_live_tick_min_candles}개 이상"
            if settings.strategy_prefer_live_tick_candles
            else f"최신 공식 1분봉 {settings.strategy_official_min_candles}개 이상"
        )
        volume_60s = _to_float(flow.get("volume_60s")) or (normalized[-1]["volume"] if normalized else 0.0)
        spread_pct = _to_float(flow.get("spread_pct"))
        trade_strength = _to_float(flow.get("trade_strength"))
        sell_pressure = _sell_pressure_fraction(flow.get("sell_pressure"))
        bid_ask_imbalance = _to_float(flow.get("bid_ask_imbalance"))
        latest_price = _to_float((flow.get("trade") or {}).get("last")) or indicators.close
        directional_confirmed = _directional_confirmation(normalized, indicators, pattern_status)
        data_fresh = not _flow_stale_blocked(flow)
        hard_checks = {
            required_label: len(normalized) >= required_count,
            "리스크 매니저 허용": bool((risk_preview or {}).get("allowed", False)),
            f"최근 60초 거래량 {settings.strategy_min_volume_60s:.0f}주 이상": _volume_60s_ok(volume_60s),
            "실시간 가격/거래량 존재": bool(flow.get("trade") or normalized),
            f"tick 지연 {settings.strategy_tick_stale_block_sec}초 미만": data_fresh,
            "스프레드 데이터 허용": spread_pct is None or spread_pct <= _max_spread_pct_for_flow(flow),
        }
        hard_checks[f"체결강도 {settings.strategy_min_trade_strength_for_entry:.0f} 이상 또는 미측정"] = (
            trade_strength is None or trade_strength >= settings.strategy_min_trade_strength_for_entry
        )
        hard_checks[f"매도압력 {settings.strategy_max_sell_pressure_for_entry:.0%} 이하 또는 미측정"] = (
            sell_pressure is None or sell_pressure <= settings.strategy_max_sell_pressure_for_entry
        )
        hard_checks[f"호가 불균형 {settings.strategy_min_bid_ask_imbalance_for_entry:.2f} 이상 또는 미측정"] = (
            bid_ask_imbalance is None or bid_ask_imbalance >= settings.strategy_min_bid_ask_imbalance_for_entry
        )
        if settings.strategy_require_directional_confirmation:
            hard_checks["방향 확인: EMA/VWAP 회복, micro breakout, 또는 종가 고가권"] = directional_confirmed
        if latest_price is not None and latest_price < settings.strategy_low_price_threshold:
            hard_checks[f"저가주 체결강도 {settings.strategy_low_price_min_trade_strength:.0f} 이상"] = (
                trade_strength is None or trade_strength >= settings.strategy_low_price_min_trade_strength
            )
            hard_checks[f"저가주 매도압력 {settings.strategy_low_price_max_sell_pressure:.0%} 이하"] = (
                sell_pressure is None or sell_pressure <= settings.strategy_low_price_max_sell_pressure
            )
        if settings.strategy_block_upper_band_entry:
            hard_checks[f"BB 상단 추격매수 금지({settings.strategy_upper_band_block_position:.0%} 미만)"] = (
                not bb_upper_entry_blocked
            )
        liquidity_or_price_impulse = bool(
            volume_60s >= settings.strategy_min_volume_60s
            and (
                (_to_float(flow.get("volume_velocity_10s")) or 0.0) >= settings.strategy_min_volume_velocity_10s
                or pattern_status.get("micro_breakout")
                or _latest_candle_green(normalized)
            )
        )
        if settings.strategy_gate_liquidity_impulse_enabled:
            hard_checks["유동성/가격 가속 조건"] = liquidity_or_price_impulse
        passed_conditions = [name for name, passed in hard_checks.items() if passed]
        hard_failed = [name for name, passed in hard_checks.items() if not passed]
        watch_only = (
            not hard_failed
            and final_score >= settings.strategy_volume_pullback_watch_score
            and final_score < settings.strategy_volume_pullback_min_score
        )
        failed_conditions = list(hard_failed)
        if final_score < settings.strategy_volume_pullback_min_score:
            failed_conditions.append(
                f"{'관찰 점수' if watch_only else '진입 점수'} 미달({final_score:.2f} < {settings.strategy_volume_pullback_min_score:.2f})"
            )
        entry_allowed = not hard_failed and final_score >= settings.strategy_volume_pullback_min_score
        reject_reason = None if entry_allowed else ", ".join(failed_conditions[:4])
        evaluation = RealtimeVolumeEvaluation(
            symbol=symbol,
            strategy_name=self.strategy_name,
            strategy_version=self.strategy_version,
            parameter_set_id=self.parameter_set_id,
            passed=entry_allowed,
            final_score=final_score,
            entry_allowed=entry_allowed,
            watch_only=watch_only,
            passed_conditions=passed_conditions,
            failed_conditions=failed_conditions,
            reject_reason=reject_reason,
            indicators=indicators,
            order_flow=flow,
            score_components=score_components,
            score_weights=score_weights,
            gate_status=hard_checks,
            pattern_status=pattern_status,
            lower_band_status=lower_band_status,
            risk_preview=risk_preview,
            entry_mode="pullback_reclaim",
        )
        record_event(
            level="INFO",
            event_type="strategy.signal_evaluation",
            message="Pullback Reclaim 평가 완료" if entry_allowed else "Pullback Reclaim 진입 차단",
            severity=StatusLevel.NORMAL if entry_allowed else StatusLevel.CAUTION,
            symbol=symbol,
            payload=evaluation.model_dump(),
        )
        return evaluation


class SurgePullbackReclaimEngine:
    strategy_name = "Surge Pullback Reclaim"
    strategy_version = "1.0.0"
    parameter_set_id = "surge-pullback-reclaim-v1"

    def evaluate(self, *, symbol: str, candles: list[dict], risk_preview: dict | None = None) -> RealtimeVolumeEvaluation:
        settings = get_settings()
        symbol = symbol.upper()
        normalized = _normalize_candles(candles)
        indicators = _indicator_snapshot(normalized)
        flow = get_market_data_service().provider.order_flow_snapshot().get(symbol, {})
        patterns = _surge_pullback_patterns(normalized, indicators)
        macd_status = _macd_recovery_status(
            normalized,
            lookback=settings.strategy_surge_macd_hist_slope_lookback,
        )
        patterns["macd"] = macd_status
        score_components = _surge_pullback_score_components(
            candles=normalized,
            indicators=indicators,
            flow=flow,
            patterns=patterns,
        )
        final_score = round(sum(score_components.values()), 2)
        volume_60s = _to_float(flow.get("volume_60s")) or (normalized[-1]["volume"] if normalized else 0.0)
        volume_velocity = _to_float(flow.get("volume_velocity_10s"))
        spread_pct = _to_float(flow.get("spread_pct"))
        data_fresh = not _flow_stale_blocked(flow)
        required_count = (
            settings.strategy_live_tick_min_candles
            if settings.strategy_prefer_live_tick_candles
            else settings.strategy_official_min_candles
        )
        hard_checks = {
            "전략 기준 candle 충분": len(normalized) >= required_count,
            "리스크 매니저 허용": bool((risk_preview or {}).get("allowed", False)),
            f"최근 급등 {settings.strategy_surge_min_move_pct:.0%} 이상": bool(patterns.get("surge_detected")),
            "급등 후 눌림 발생": bool(patterns.get("pullback_seen")),
            "BB/EMA/VWAP 지지 확인": bool(patterns.get("support_confirmed")),
            "재상승 확인": bool(patterns.get("reclaim_confirmed")),
            "BB 상단 추격 아님": bool(patterns.get("not_upper_chase")),
            "구조적 저점 유지": bool(patterns.get("structure_low_held")),
            f"최근 60초 거래량 {settings.strategy_min_volume_60s:.0f}주 이상": _volume_60s_ok(volume_60s),
            "tick 지연 차단 아님": data_fresh,
            "스프레드 허용": spread_pct is None or spread_pct <= _max_spread_pct_for_flow(flow),
        }
        if settings.strategy_surge_require_macd_not_both_negative:
            hard_checks["MACD선/시그널선이 모두 0 아래가 아님"] = not macd_status.get("both_below_zero")
        hard_checks["MACD histogram 음수권 회복 기울기 또는 0선 위"] = bool(
            macd_status.get("histogram_recovering_from_negative") or macd_status.get("histogram_above_zero")
        )
        if volume_velocity is not None:
            hard_checks[f"거래량 재가속 {settings.strategy_min_volume_velocity_10s:.1f} 이상"] = (
                volume_velocity >= settings.strategy_min_volume_velocity_10s
            )
        passed_conditions = [name for name, passed in hard_checks.items() if passed]
        hard_failed = [name for name, passed in hard_checks.items() if not passed]
        watch_only = (
            not hard_failed
            and final_score >= settings.strategy_surge_pullback_watch_score
            and final_score < settings.strategy_surge_pullback_min_score
        )
        failed_conditions = list(hard_failed)
        if final_score < settings.strategy_surge_pullback_min_score:
            failed_conditions.append(
                f"진입 점수 미달({final_score:.2f} < {settings.strategy_surge_pullback_min_score:.2f})"
            )
        entry_allowed = not hard_failed and final_score >= settings.strategy_surge_pullback_min_score
        reject_reason = None if entry_allowed else ", ".join(failed_conditions[:4])
        lower_band_status = {
            "lower_band_breached": patterns.get("support_zone") == "bb_lower",
            "lower_band_reclaimed": patterns.get("support_confirmed"),
            "bars_since_breach": patterns.get("bars_since_peak"),
            "bb_position": _bb_position(indicators),
            "bb_position_ratio": _bb_position_ratio(indicators),
            "bb_upper_entry_blocked": not patterns.get("not_upper_chase"),
            "entry_role": "급등 후 눌림 지지와 재상승 확인",
        }
        evaluation = RealtimeVolumeEvaluation(
            symbol=symbol,
            strategy_name=self.strategy_name,
            strategy_version=self.strategy_version,
            parameter_set_id=self.parameter_set_id,
            passed=entry_allowed,
            final_score=final_score,
            entry_allowed=entry_allowed,
            watch_only=watch_only,
            passed_conditions=passed_conditions,
            failed_conditions=failed_conditions,
            reject_reason=reject_reason,
            indicators=indicators,
            order_flow=flow,
            score_components=score_components,
            score_weights={
                "surge_context": 25.0,
                "pullback_support": 30.0,
                "reclaim_confirmation": 25.0,
                "chase_avoidance": 10.0,
                "liquidity_reacceleration": 10.0,
            },
            gate_status=hard_checks,
            pattern_status=patterns,
            lower_band_status=lower_band_status,
            risk_preview=risk_preview,
            entry_mode="surge_pullback_reclaim",
        )
        record_event(
            level="INFO",
            event_type="strategy.signal_evaluation",
            message=f"{self.strategy_name} {'진입 가능' if entry_allowed else '진입 차단'}",
            severity=StatusLevel.NORMAL if entry_allowed else StatusLevel.CAUTION,
            symbol=symbol,
            payload=evaluation.model_dump(),
        )
        return evaluation


class FirstPullbackAfterVolumeShockEngine:
    strategy_name = "First Pullback After Volume Shock"
    strategy_version = "1.0.0"
    parameter_set_id = "volume-shock-first-pullback-v1"
    entry_mode = "volume_shock_first_pullback"

    def evaluate(self, *, symbol: str, candles: list[dict], risk_preview: dict | None = None) -> RealtimeVolumeEvaluation:
        settings = get_settings()
        normalized, indicators, flow, base = _scalp_strategy_context(symbol, candles, risk_preview)
        patterns = _volume_shock_pullback_patterns(normalized, indicators, flow)
        roundtrip_cost = _roundtrip_cost_fraction(flow)
        notional_1m = _latest_notional_1m(normalized, flow)
        flow_ok = _scalp_flow_ok(
            flow,
            min_trade_strength=settings.strategy_volume_shock_min_trade_strength,
            max_sell_pressure=settings.strategy_volume_shock_max_sell_pressure,
        )
        conditions = {
            **base,
            "volume_shock": patterns["volume_shock"],
            "first_pullback": patterns["first_pullback"],
            "support_held": patterns["support_held"],
            "reclaim_confirmed": patterns["reclaim_confirmed"],
            "reclaim_on_volume": patterns["volume_ratio"] >= settings.strategy_volume_shock_reclaim_min_volume_ratio,
            # Only take the pullback when price reclaims ABOVE VWAP: a reclaim below
            # VWAP is a downtrend dead-cat bounce that structurally fails. Confirmed on
            # combined 2026-07-07 + 07-08: winners sit above VWAP, losers at/below it.
            "above_vwap": indicators.close is None or indicators.vwap is None or indicators.close >= indicators.vwap,
            "flow_ok": flow_ok,
            "edge_ok": _scalp_expected_edge_ok(normalized, flow, settings.strategy_volume_shock_min_10bar_change_pct),
            "volume_shock_recent_move_ok": patterns["recent_10bar_change"] >= settings.strategy_volume_shock_min_10bar_change_pct,
            "volume_shock_notional_ok": (
                notional_1m is not None
                and notional_1m >= settings.strategy_volume_shock_min_notional_1m_usd
            ),
            "volume_shock_roundtrip_cost_ok": roundtrip_cost <= settings.strategy_volume_shock_max_roundtrip_cost_pct,
            "failed_follow_through_ok": _failed_follow_through_ok(normalized, flow),
        }
        weights = {
            "volume_context": 30.0,
            "pullback_quality": 25.0,
            "reclaim_flow": 25.0,
            "execution_risk": 20.0,
        }
        score_components = _rule_score_components(
            conditions=conditions,
            components={
                "volume_context": ["volume_shock", "edge_ok", "volume_shock_recent_move_ok", "volume_shock_notional_ok"],
                "pullback_quality": ["first_pullback", "support_held", "above_vwap"],
                "reclaim_flow": ["reclaim_confirmed", "reclaim_on_volume", "flow_ok"],
                "execution_risk": [
                    "candle_window_ready",
                    "risk_allowed",
                    "spread_ok",
                    "data_fresh",
                    "volume_shock_roundtrip_cost_ok",
                    "failed_follow_through_ok",
                ],
            },
            weights=weights,
        )
        return _build_rule_evaluation(
            symbol=symbol,
            strategy_name=self.strategy_name,
            strategy_version=self.strategy_version,
            parameter_set_id=self.parameter_set_id,
            entry_mode=self.entry_mode,
            min_score=settings.strategy_volume_shock_pullback_min_score,
            conditions=conditions,
            score_components=score_components,
            score_weights=weights,
            indicators=indicators,
            flow=flow,
            risk_preview=risk_preview,
            pattern_status=patterns,
        )


class LiquiditySweepReclaimEngine:
    strategy_name = "Liquidity Sweep Reclaim"
    strategy_version = "1.0.0"
    parameter_set_id = "liquidity-sweep-reclaim-v1"
    entry_mode = "liquidity_sweep_reclaim"

    def evaluate(self, *, symbol: str, candles: list[dict], risk_preview: dict | None = None) -> RealtimeVolumeEvaluation:
        settings = get_settings()
        normalized, indicators, flow, base = _scalp_strategy_context(symbol, candles, risk_preview)
        patterns = _liquidity_sweep_patterns(normalized, indicators, flow)
        conditions = {
            **base,
            "liquidity_sweep": patterns["liquidity_sweep"],
            "reclaimed_sweep_level": patterns["reclaimed_sweep_level"],
            "lower_wick_absorption": patterns["lower_wick_absorption"],
            "sell_pressure_relief": patterns["sell_pressure_relief"],
            "flow_ok": _scalp_flow_ok(flow),
            "edge_ok": _scalp_expected_edge_ok(normalized, flow, settings.strategy_liquidity_sweep_min_reclaim_pct),
            "failed_follow_through_ok": _failed_follow_through_ok(normalized, flow),
        }
        weights = {
            "sweep_structure": 35.0,
            "absorption_quality": 25.0,
            "flow_confirmation": 20.0,
            "execution_risk": 20.0,
        }
        score_components = _rule_score_components(
            conditions=conditions,
            components={
                "sweep_structure": ["liquidity_sweep", "reclaimed_sweep_level"],
                "absorption_quality": ["lower_wick_absorption", "sell_pressure_relief"],
                "flow_confirmation": ["flow_ok", "edge_ok"],
                "execution_risk": ["candle_window_ready", "risk_allowed", "spread_ok", "data_fresh", "failed_follow_through_ok"],
            },
            weights=weights,
        )
        return _build_rule_evaluation(
            symbol=symbol,
            strategy_name=self.strategy_name,
            strategy_version=self.strategy_version,
            parameter_set_id=self.parameter_set_id,
            entry_mode=self.entry_mode,
            min_score=settings.strategy_liquidity_sweep_reclaim_min_score,
            conditions=conditions,
            score_components=score_components,
            score_weights=weights,
            indicators=indicators,
            flow=flow,
            risk_preview=risk_preview,
            pattern_status=patterns,
        )


class MicroBreakoutWithAbsorptionEngine:
    strategy_name = "Micro Breakout With Absorption"
    strategy_version = "1.0.0"
    parameter_set_id = "micro-breakout-absorption-v1"
    entry_mode = "micro_breakout_absorption"

    def evaluate(self, *, symbol: str, candles: list[dict], risk_preview: dict | None = None) -> RealtimeVolumeEvaluation:
        settings = get_settings()
        normalized, indicators, flow, base = _scalp_strategy_context(symbol, candles, risk_preview)
        patterns = _micro_breakout_absorption_patterns(normalized, indicators, flow)
        recent_change = _recent_close_change_fraction(normalized, lookback=10) or 0.0
        roundtrip_cost = _roundtrip_cost_fraction(flow)
        conditions = {
            **base,
            "micro_breakout": patterns["micro_breakout"],
            "prior_absorption": patterns["prior_absorption"],
            "range_compression": patterns["range_compression"],
            "close_near_high": _latest_close_near_high(normalized),
            "flow_ok": _scalp_flow_ok(
                flow,
                min_trade_strength=settings.strategy_micro_breakout_min_trade_strength,
                max_sell_pressure=settings.strategy_micro_breakout_max_sell_pressure,
            ),
            "recent_move_ok": recent_change >= settings.strategy_micro_breakout_min_10bar_change_pct,
            "not_overheated_move": recent_change <= settings.strategy_micro_breakout_max_10bar_change_pct,
            "range_expansion_ok": patterns["range_fraction"] >= settings.strategy_micro_breakout_min_range_pct,
            "micro_roundtrip_cost_ok": roundtrip_cost <= settings.strategy_micro_breakout_max_roundtrip_cost_pct,
            "edge_ok": _scalp_expected_edge_ok(normalized, flow, 0.020),
            "failed_follow_through_ok": _failed_follow_through_ok(normalized, flow),
        }
        weights = {
            "breakout_structure": 35.0,
            "absorption_context": 25.0,
            "flow_confirmation": 20.0,
            "execution_risk": 20.0,
        }
        score_components = _rule_score_components(
            conditions=conditions,
            components={
                "breakout_structure": ["micro_breakout", "close_near_high"],
                "absorption_context": ["prior_absorption", "range_compression"],
                "flow_confirmation": ["flow_ok", "recent_move_ok", "not_overheated_move", "range_expansion_ok", "edge_ok"],
                "execution_risk": [
                    "candle_window_ready",
                    "risk_allowed",
                    "spread_ok",
                    "data_fresh",
                    "micro_roundtrip_cost_ok",
                    "failed_follow_through_ok",
                ],
            },
            weights=weights,
        )
        return _build_rule_evaluation(
            symbol=symbol,
            strategy_name=self.strategy_name,
            strategy_version=self.strategy_version,
            parameter_set_id=self.parameter_set_id,
            entry_mode=self.entry_mode,
            min_score=settings.strategy_micro_absorption_breakout_min_score,
            conditions=conditions,
            score_components=score_components,
            score_weights=weights,
            indicators=indicators,
            flow=flow,
            risk_preview=risk_preview,
            pattern_status=patterns,
        )


class LiquidityPullbackReclaimEngine:
    strategy_name = "Liquidity Pullback Reclaim"
    strategy_version = "1.0.0"
    parameter_set_id = "liquidity-pullback-reclaim-v1"
    entry_mode = "liquidity_pullback_reclaim"

    def evaluate(self, *, symbol: str, candles: list[dict], risk_preview: dict | None = None) -> RealtimeVolumeEvaluation:
        settings = get_settings()
        normalized, indicators, flow, base = _scalp_strategy_context(symbol, candles, risk_preview)
        patterns = _liquidity_pullback_reclaim_patterns(normalized, indicators, flow)
        conditions = {
            **base,
            "tight_liquidity": patterns["tight_liquidity"],
            "recent_move_ok": patterns["recent_move_ok"],
            "not_overheated_move": patterns["not_overheated_move"],
            "first_pullback": patterns["first_pullback"],
            "pullback_depth_ok": patterns["pullback_depth_ok"],
            "support_held": patterns["support_held"],
            "support_reclaim": patterns["support_reclaim"],
            "reclaim_on_volume": patterns["volume_ratio"] >= settings.strategy_liquidity_pullback_min_volume_ratio,
            "flow_ok": _scalp_flow_ok(
                flow,
                min_trade_strength=settings.strategy_liquidity_pullback_min_trade_strength,
                max_sell_pressure=settings.strategy_liquidity_pullback_max_sell_pressure,
            ),
            "imbalance_ok": patterns["imbalance_ok"],
            "sell_pressure_decreasing": patterns["sell_pressure_decreasing"],
            "bb_dead_zone_clear": patterns["bb_dead_zone_clear"],
            "not_chasing": patterns["not_chasing"],
            "range_expansion_ok": patterns["range_fraction"] >= settings.strategy_liquidity_pullback_min_range_pct,
            "roundtrip_cost_ok": patterns["roundtrip_cost_ok"],
            "failed_follow_through_ok": _failed_follow_through_ok(normalized, flow),
        }
        weights = {
            "liquidity_context": 25.0,
            "pullback_structure": 30.0,
            "reclaim_flow": 25.0,
            "execution_risk": 20.0,
        }
        score_components = _rule_score_components(
            conditions=conditions,
            components={
                "liquidity_context": ["tight_liquidity", "recent_move_ok", "not_overheated_move", "range_expansion_ok"],
                "pullback_structure": ["first_pullback", "pullback_depth_ok", "support_held", "bb_dead_zone_clear", "not_chasing"],
                "reclaim_flow": ["support_reclaim", "reclaim_on_volume", "flow_ok", "imbalance_ok", "sell_pressure_decreasing"],
                "execution_risk": [
                    "candle_window_ready",
                    "risk_allowed",
                    "spread_ok",
                    "data_fresh",
                    "roundtrip_cost_ok",
                    "failed_follow_through_ok",
                ],
            },
            weights=weights,
        )
        return _build_rule_evaluation(
            symbol=symbol,
            strategy_name=self.strategy_name,
            strategy_version=self.strategy_version,
            parameter_set_id=self.parameter_set_id,
            entry_mode=self.entry_mode,
            min_score=settings.strategy_liquidity_pullback_reclaim_min_score,
            conditions=conditions,
            score_components=score_components,
            score_weights=weights,
            indicators=indicators,
            flow=flow,
            risk_preview=risk_preview,
            pattern_status=patterns,
        )


class EntryPatternEngine:
    strategy_name = "Entry Pattern Router"

    def evaluate(self, *, symbol: str, candles: list[dict], risk_preview: dict | None = None) -> RealtimeVolumeEvaluation:
        evaluations = self.evaluate_all(symbol=symbol, candles=candles, risk_preview=risk_preview, allowed_only=False)
        if not evaluations:
            evaluation = SurgePullbackReclaimEngine().evaluate(
                symbol=symbol,
                candles=candles,
                risk_preview=risk_preview,
            )
            evaluation.passed = False
            evaluation.entry_allowed = False
            evaluation.watch_only = False
            evaluation.reject_reason = "활성화된 진입 패턴이 없습니다."
            evaluation.failed_conditions = ["활성화된 진입 패턴이 없습니다."]
            return evaluation
        allowed = [evaluation for evaluation in evaluations if evaluation.entry_allowed]
        if allowed:
            allowed.sort(key=lambda item: item.final_score, reverse=True)
            return allowed[0]
        evaluations.sort(key=lambda item: item.final_score, reverse=True)
        return evaluations[0]

    def evaluate_all(
        self,
        *,
        symbol: str,
        candles: list[dict],
        risk_preview: dict | None = None,
        allowed_only: bool = True,
    ) -> list[RealtimeVolumeEvaluation]:
        settings = get_settings()
        evaluations: list[RealtimeVolumeEvaluation] = []
        if settings.strategy_surge_pullback_enabled:
            evaluations.append(
                SurgePullbackReclaimEngine().evaluate(
                    symbol=symbol,
                    candles=candles,
                    risk_preview=risk_preview,
                )
            )
        if settings.strategy_volume_shock_pullback_enabled:
            evaluations.append(
                FirstPullbackAfterVolumeShockEngine().evaluate(
                    symbol=symbol,
                    candles=candles,
                    risk_preview=risk_preview,
                )
            )
        if settings.strategy_liquidity_sweep_reclaim_enabled:
            evaluations.append(
                LiquiditySweepReclaimEngine().evaluate(
                    symbol=symbol,
                    candles=candles,
                    risk_preview=risk_preview,
                )
            )
        if settings.strategy_micro_absorption_breakout_enabled:
            evaluations.append(
                MicroBreakoutWithAbsorptionEngine().evaluate(
                    symbol=symbol,
                    candles=candles,
                    risk_preview=risk_preview,
                )
            )
        if settings.strategy_liquidity_pullback_reclaim_enabled:
            evaluations.append(
                LiquidityPullbackReclaimEngine().evaluate(
                    symbol=symbol,
                    candles=candles,
                    risk_preview=risk_preview,
                )
            )
        evaluations.sort(key=lambda item: item.final_score, reverse=True)
        if allowed_only:
            return [evaluation for evaluation in evaluations if evaluation.entry_allowed]
        return evaluations


def _normalize_candles(candles: list[dict]) -> list[dict]:
    rows = []
    for candle in candles:
        close = _to_float(candle.get("close"))
        high = _to_float(candle.get("high"))
        low = _to_float(candle.get("low"))
        open_ = _to_float(candle.get("open"))
        volume = _to_float(candle.get("volume")) or 0.0
        if close is None or high is None or low is None or open_ is None:
            continue
        rows.append({**candle, "open": open_, "high": high, "low": low, "close": close, "volume": volume})
    return sorted(rows, key=lambda row: (str(row.get("market_date") or ""), str(row.get("market_time") or "")))


def _indicator_snapshot(candles: list[dict]) -> IndicatorSnapshot:
    closes = [row["close"] for row in candles]
    highs = [row["high"] for row in candles]
    lows = [row["low"] for row in candles]
    bb_mid = _sma(closes[-20:]) if len(closes) >= 20 else None
    std = _stddev(closes[-20:]) if len(closes) >= 20 else None
    bb_upper = bb_mid + 2 * std if bb_mid is not None and std is not None else None
    bb_lower = bb_mid - 2 * std if bb_mid is not None and std is not None else None
    ema9 = _ema_last(closes, 9)
    ema20 = _ema_last(closes, 20)
    atr20 = _atr(highs, lows, closes, 20)
    close = closes[-1] if closes else None
    vwap = _vwap(candles)
    macd_line = _macd_line(closes)
    macd_signal_series = _ema_series([value for value in macd_line if value is not None], 9)
    macd = next((value for value in reversed(macd_line) if value is not None), None)
    macd_signal = macd_signal_series[-1] if macd_signal_series else None
    histogram = macd - macd_signal if macd is not None and macd_signal is not None else None
    prev_histogram = None
    if len(macd_signal_series) >= 2:
        macd_values = [value for value in macd_line if value is not None]
        prev_histogram = macd_values[-2] - macd_signal_series[-2]
    return IndicatorSnapshot(
        close=close,
        vwap=vwap,
        ema9=ema9,
        ema20=ema20,
        atr20=atr20,
        atr_pct=(atr20 / close * 100) if atr20 and close else None,
        bb_upper=bb_upper,
        bb_mid=bb_mid,
        bb_lower=bb_lower,
        macd=macd,
        macd_signal=macd_signal,
        macd_histogram=histogram,
        macd_histogram_delta=(histogram - prev_histogram) if histogram is not None and prev_histogram is not None else None,
        vwap_distance_atr=((close - vwap) / atr20) if close is not None and vwap is not None and atr20 else None,
    )


def _lower_band_reclaim_state(candles: list[dict]) -> tuple[bool, bool, int | None]:
    if len(candles) < 23:
        return False, False, None
    breach_index = None
    for offset in range(1, min(3, len(candles)) + 1):
        index = len(candles) - offset
        window = candles[max(0, index - 19) : index + 1]
        if len(window) < 20:
            continue
        closes = [row["close"] for row in window]
        mid = _sma(closes)
        std = _stddev(closes)
        lower = mid - 2 * std if mid is not None and std is not None else None
        if lower is not None and (candles[index]["low"] < lower or candles[index]["close"] < lower):
            breach_index = index
            break
    if breach_index is None:
        return False, False, None
    latest = candles[-1]
    latest_window = candles[-20:]
    latest_mid = _sma([row["close"] for row in latest_window])
    latest_std = _stddev([row["close"] for row in latest_window])
    latest_lower = latest_mid - 2 * latest_std if latest_mid is not None and latest_std is not None else None
    reclaimed = latest_lower is not None and latest["close"] >= latest_lower
    return True, reclaimed, len(candles) - 1 - breach_index


def _volume_pullback_patterns(candles: list[dict], indicators: IndicatorSnapshot) -> dict:
    if len(candles) < 10 or indicators.close is None:
        return {
            "vwap_pullback_reclaim": False,
            "ema9_reclaim": False,
            "micro_breakout": False,
            "high_failure_count": 0,
        }
    latest = candles[-1]
    previous = candles[-2] if len(candles) >= 2 else latest
    recent = candles[-6:]
    recent_lows = [row["low"] for row in recent]
    recent_highs = [row["high"] for row in recent[:-1]]
    close = latest["close"]
    vwap_pullback = bool(
        indicators.vwap is not None
        and min(recent_lows) <= indicators.vwap * 1.003
        and close >= indicators.vwap
    )
    ema_reclaim = bool(
        indicators.ema9 is not None
        and min(recent_lows) <= indicators.ema9 * 1.003
        and close >= indicators.ema9
        and previous["close"] <= indicators.ema9 * 1.002
    )
    micro_breakout = bool(recent_highs and close >= max(recent_highs))
    high_failure_count = _high_failure_count(candles)
    return {
        "vwap_pullback_reclaim": vwap_pullback,
        "ema9_reclaim": ema_reclaim,
        "micro_breakout": micro_breakout,
        "high_failure_count": high_failure_count,
    }


def _surge_pullback_patterns(candles: list[dict], indicators: IndicatorSnapshot) -> dict:
    settings = get_settings()
    if len(candles) < 20 or indicators.close is None:
        return {
            "surge_detected": False,
            "pullback_seen": False,
            "support_confirmed": False,
            "reclaim_confirmed": False,
            "not_upper_chase": False,
            "structure_low_held": False,
        }
    window = candles[-min(40, len(candles)) :]
    lows = [row["low"] for row in window]
    highs = [row["high"] for row in window]
    surge_low = min(lows)
    peak_index = max(range(len(window)), key=lambda idx: window[idx]["high"])
    peak_high = highs[peak_index]
    after_peak = window[peak_index + 1 :] or [window[-1]]
    pullback_low = min(row["low"] for row in after_peak)
    latest = window[-1]
    previous = window[-2] if len(window) >= 2 else latest
    surge_pct = (peak_high - surge_low) / surge_low if surge_low > 0 else 0.0
    pullback_pct = (peak_high - pullback_low) / peak_high if peak_high > 0 else 0.0
    bars_since_peak = len(window) - 1 - peak_index

    support_levels = {
        "vwap": indicators.vwap,
        "ema9": indicators.ema9,
        "ema20": indicators.ema20,
        "bb_mid": indicators.bb_mid,
        "bb_lower": indicators.bb_lower,
    }
    touched_supports = {
        key: bool(value is not None and pullback_low <= value * 1.012 and latest["close"] >= value * 0.995)
        for key, value in support_levels.items()
    }
    support_zone = next((key for key, passed in touched_supports.items() if passed), None)
    support_confirmed = bool(support_zone)

    recent_lows = [row["low"] for row in window[-max(3, settings.strategy_surge_reclaim_lookback_bars) :]]
    structure_low_held = bool(
        len(recent_lows) >= 2
        and latest["low"] >= min(recent_lows[:-1]) * 0.995
        and latest["close"] >= pullback_low * 1.005
    )
    recent_highs = [
        row["high"]
        for row in window[-max(3, settings.strategy_surge_reclaim_lookback_bars) : -1]
    ]
    reclaim_confirmed = bool(
        latest["close"] > latest["open"]
        and (
            (indicators.ema9 is not None and latest["close"] >= indicators.ema9 and previous["close"] <= indicators.ema9 * 1.004)
            or (indicators.vwap is not None and latest["close"] >= indicators.vwap and pullback_low <= indicators.vwap * 1.012)
            or (recent_highs and latest["close"] >= max(recent_highs))
            or _latest_close_near_high(candles)
        )
    )
    bb_ratio = _bb_position_ratio(indicators)
    not_upper_chase = bool(
        indicators.bb_upper is None
        or latest["close"] < indicators.bb_upper
        and (bb_ratio is None or bb_ratio <= settings.strategy_surge_pullback_max_bb_position)
    )
    pullback_seen = (
        settings.strategy_surge_min_pullback_pct <= pullback_pct <= settings.strategy_surge_max_pullback_pct
        and bars_since_peak >= 1
    )
    return {
        "surge_detected": surge_pct >= settings.strategy_surge_min_move_pct,
        "surge_pct": surge_pct,
        "surge_low": surge_low,
        "peak_high": peak_high,
        "peak_index": peak_index,
        "bars_since_peak": bars_since_peak,
        "pullback_seen": pullback_seen,
        "pullback_pct": pullback_pct,
        "pullback_low": pullback_low,
        "support_confirmed": support_confirmed,
        "support_zone": support_zone,
        "touched_supports": touched_supports,
        "reclaim_confirmed": reclaim_confirmed,
        "not_upper_chase": not_upper_chase,
        "bb_position_ratio": bb_ratio,
        "structure_low_held": structure_low_held,
    }


def _macd_recovery_status(candles: list[dict], *, lookback: int = 3) -> dict:
    normalized = _normalize_candles(candles)
    if len(normalized) < 35:
        return {
            "histogram_recovering_from_negative": False,
            "histogram_fading_above_zero": False,
            "histogram_above_zero": False,
            "both_below_zero": False,
            "reason": "insufficient_candles",
        }
    lookback = max(2, min(int(lookback or 3), 6))
    snapshots = [
        _indicator_snapshot(normalized[:idx])
        for idx in range(len(normalized) - lookback + 1, len(normalized) + 1)
        if idx >= 30
    ]
    hist_values = [
        snapshot.macd_histogram
        for snapshot in snapshots
        if snapshot.macd_histogram is not None
    ]
    latest = snapshots[-1] if snapshots else _indicator_snapshot(normalized)
    histogram_above_zero = bool(latest.macd_histogram is not None and latest.macd_histogram >= 0)
    both_below_zero = bool(
        latest.macd is not None
        and latest.macd_signal is not None
        and latest.macd < 0
        and latest.macd_signal < 0
    )
    recovering = False
    fading = False
    if len(hist_values) >= lookback:
        recent = hist_values[-lookback:]
        recovering = (
            all(value < 0 for value in recent)
            and all(right > left for left, right in zip(recent, recent[1:]))
        )
        fading = (
            all(value > 0 for value in recent)
            and all(right < left for left, right in zip(recent, recent[1:]))
        )
    return {
        "histogram_recovering_from_negative": recovering,
        "histogram_fading_above_zero": fading,
        "histogram_above_zero": histogram_above_zero,
        "both_below_zero": both_below_zero,
        "macd": latest.macd,
        "macd_signal": latest.macd_signal,
        "histogram": latest.macd_histogram,
        "histogram_delta": latest.macd_histogram_delta,
        "histogram_recent": hist_values[-lookback:],
    }


def _directional_confirmation(candles: list[dict], indicators: IndicatorSnapshot, patterns: dict) -> bool:
    if not candles:
        return False
    latest = candles[-1]
    close = _to_float(latest.get("close"))
    if close is None:
        return False
    if patterns.get("micro_breakout") or patterns.get("ema9_reclaim") or patterns.get("vwap_pullback_reclaim"):
        return True
    if indicators.ema9 is not None and close >= indicators.ema9 and _latest_close_near_high(candles):
        return True
    if indicators.vwap is not None and close >= indicators.vwap and _latest_candle_green(candles):
        return True
    if _strong_momentum_without_vwap(candles, {}):
        return True
    return False


def _volume_pullback_score(
    *,
    candles: list[dict],
    indicators: IndicatorSnapshot,
    flow: dict,
    patterns: dict,
    lower_band_status: dict,
) -> dict[str, float]:
    settings = get_settings()
    weights = _score_weights(settings)
    volume_60s = _to_float(flow.get("volume_60s")) or (candles[-1]["volume"] if candles else 0.0)
    volume_velocity = _to_float(flow.get("volume_velocity_10s"))
    trade_strength = _to_float(flow.get("trade_strength"))
    sell_pressure = _sell_pressure_fraction(flow.get("sell_pressure"))
    bid_ask_imbalance = _to_float(flow.get("bid_ask_imbalance"))
    latest_price = _to_float((flow.get("trade") or {}).get("last")) or (indicators.close or 0.0)
    notional_60s = volume_60s * latest_price if latest_price and volume_60s else 0.0
    liquidity_score = 0.0
    if volume_60s >= settings.strategy_min_volume_60s:
        liquidity_score += 12.0
    liquidity_score += min(12.0, max(0.0, volume_60s / max(settings.strategy_min_volume_60s, 1.0) * 3.0))
    if volume_velocity is not None and volume_velocity >= settings.strategy_min_volume_velocity_10s:
        liquidity_score += min(10.0, max(4.0, volume_velocity * 2.0))
    if settings.scanner_min_1m_notional_usd > 0 and notional_60s >= settings.scanner_min_1m_notional_usd:
        liquidity_score += 4.0
    if trade_strength is not None and trade_strength >= 52:
        liquidity_score += 2.0
    if trade_strength is not None and trade_strength < settings.strategy_min_trade_strength_for_entry:
        liquidity_score -= min(8.0, (settings.strategy_min_trade_strength_for_entry - trade_strength) / 5.0)
    if sell_pressure is not None and sell_pressure > 0.5:
        liquidity_score -= min(10.0, (sell_pressure - 0.5) * 40.0)
    if bid_ask_imbalance is not None and bid_ask_imbalance < 0.25:
        liquidity_score -= min(6.0, (0.25 - bid_ask_imbalance) * 24.0)
    liquidity_score = max(0.0, liquidity_score)
    liquidity_ratio = min(40.0, liquidity_score) / 40.0

    acceleration_score = 0.0
    if patterns.get("micro_breakout"):
        acceleration_score += 9.0
    if _latest_candle_green(candles):
        acceleration_score += 6.0
    if _latest_close_near_high(candles):
        acceleration_score += 5.0
    if len(candles) >= 2 and candles[-1]["close"] > candles[-2]["close"]:
        acceleration_score += 4.0
    if indicators.macd_histogram_delta is None or indicators.macd_histogram_delta >= 0:
        acceleration_score += 1.0
    acceleration_ratio = min(25.0, acceleration_score) / 25.0

    bb_score = 0.0
    bb_ratio = _to_float(lower_band_status.get("bb_position_ratio"))
    if lower_band_status.get("lower_band_reclaimed"):
        bb_score += 6.0
    if lower_band_status.get("bb_position") == "lower_to_mid":
        bb_score += 12.0
    elif (
        lower_band_status.get("bb_position") == "mid_to_upper"
        and bb_ratio is not None
        and bb_ratio < settings.strategy_upper_band_caution_position
    ):
        bb_score += 8.0
    if not lower_band_status.get("bb_overheated"):
        bb_score += 7.0
    bb_ratio_score = min(25.0, bb_score) / 25.0

    price_action_ratio = _price_action_score(candles) / 15.0
    return {
        "liquidity_impulse": round(liquidity_ratio * weights["liquidity_impulse"], 2),
        "price_acceleration": round(acceleration_ratio * weights["price_acceleration"], 2),
        "bollinger_context": round(bb_ratio_score * weights["bollinger_context"], 2),
        "price_action": round(price_action_ratio * weights["price_action"], 2),
    }


def _surge_pullback_score_components(
    *,
    candles: list[dict],
    indicators: IndicatorSnapshot,
    flow: dict,
    patterns: dict,
) -> dict[str, float]:
    settings = get_settings()
    volume_60s = _to_float(flow.get("volume_60s")) or (candles[-1]["volume"] if candles else 0.0)
    volume_velocity = _to_float(flow.get("volume_velocity_10s"))
    trade_strength = _to_float(flow.get("trade_strength"))
    sell_pressure = _sell_pressure_fraction(flow.get("sell_pressure"))
    surge_pct = _to_float(patterns.get("surge_pct")) or 0.0
    pullback_pct = _to_float(patterns.get("pullback_pct")) or 0.0
    macd_status = patterns.get("macd") if isinstance(patterns.get("macd"), dict) else {}

    surge_context = 0.0
    if patterns.get("surge_detected"):
        surge_context += 16.0
    surge_context += min(9.0, max(0.0, surge_pct / max(settings.strategy_surge_min_move_pct, 0.001) * 4.0))

    pullback_support = 0.0
    if patterns.get("pullback_seen"):
        pullback_support += 8.0
    if patterns.get("support_confirmed"):
        pullback_support += 12.0
    if patterns.get("structure_low_held"):
        pullback_support += 7.0
    if settings.strategy_surge_min_pullback_pct <= pullback_pct <= settings.strategy_surge_max_pullback_pct * 0.75:
        pullback_support += 3.0

    reclaim_confirmation = 0.0
    if patterns.get("reclaim_confirmed"):
        reclaim_confirmation += 12.0
    if macd_status.get("histogram_recovering_from_negative"):
        reclaim_confirmation += 5.0
    elif macd_status.get("histogram_above_zero"):
        reclaim_confirmation += 3.0
    if macd_status.get("both_below_zero"):
        reclaim_confirmation -= 5.0
    if _latest_candle_green(candles):
        reclaim_confirmation += 5.0
    if _latest_close_near_high(candles):
        reclaim_confirmation += 4.0
    if indicators.ema9 is not None and indicators.close is not None and indicators.close >= indicators.ema9:
        reclaim_confirmation += 2.0
    if indicators.vwap is not None and indicators.close is not None and indicators.close >= indicators.vwap:
        reclaim_confirmation += 2.0

    chase_avoidance = 0.0
    if patterns.get("not_upper_chase"):
        chase_avoidance += 7.0
    bb_ratio = _to_float(patterns.get("bb_position_ratio"))
    if bb_ratio is not None and bb_ratio <= settings.strategy_surge_pullback_max_bb_position * 0.9:
        chase_avoidance += 3.0

    liquidity_reacceleration = 0.0
    if volume_60s >= settings.strategy_min_volume_60s:
        liquidity_reacceleration += 3.0
    if volume_velocity is not None and volume_velocity >= settings.strategy_min_volume_velocity_10s:
        liquidity_reacceleration += 3.0
    if trade_strength is None or trade_strength >= settings.strategy_min_trade_strength_for_entry:
        liquidity_reacceleration += 2.0
    if sell_pressure is None or sell_pressure <= settings.strategy_max_sell_pressure_for_entry:
        liquidity_reacceleration += 2.0

    return {
        "surge_context": round(min(25.0, surge_context), 2),
        "pullback_support": round(min(30.0, pullback_support), 2),
        "reclaim_confirmation": round(min(25.0, reclaim_confirmation), 2),
        "chase_avoidance": round(min(10.0, chase_avoidance), 2),
        "liquidity_reacceleration": round(min(10.0, liquidity_reacceleration), 2),
    }


def _scalp_strategy_context(symbol: str, candles: list[dict], risk_preview: dict | None) -> tuple[list[dict], IndicatorSnapshot, dict, dict]:
    settings = get_settings()
    normalized = _normalize_candles(candles)
    indicators = _indicator_snapshot(normalized)
    flow = get_market_data_service().provider.order_flow_snapshot().get(symbol.upper(), {})
    required_count = (
        settings.strategy_live_tick_min_candles
        if settings.strategy_prefer_live_tick_candles
        else settings.strategy_official_min_candles
    )
    volume_60s = _to_float(flow.get("volume_60s")) or (normalized[-1]["volume"] if normalized else 0.0)
    notional_1m = _latest_notional_1m(normalized, flow)
    spread_pct = _to_float(flow.get("spread_pct"))
    base = {
        "candle_window_ready": len(normalized) >= required_count,
        "risk_allowed": bool((risk_preview or {}).get("allowed", False)),
        "liquidity_ok": _volume_60s_ok(volume_60s) and _notional_1m_ok(notional_1m),
        "data_fresh": not _flow_stale_blocked(flow),
        "spread_ok": spread_pct is None or spread_pct <= _max_spread_pct_for_flow(flow),
        "price_available": bool(normalized or flow.get("trade")),
    }
    return normalized, indicators, flow, base


def _scalp_flow_ok(
    flow: dict,
    *,
    min_trade_strength: float | None = None,
    max_sell_pressure: float | None = None,
) -> bool:
    settings = get_settings()
    min_strength = settings.strategy_min_trade_strength_for_entry if min_trade_strength is None else min_trade_strength
    max_pressure = settings.strategy_max_sell_pressure_for_entry if max_sell_pressure is None else max_sell_pressure
    trade_strength = _to_float(flow.get("trade_strength"))
    sell_pressure = _sell_pressure_fraction(flow.get("sell_pressure"))
    strength_ok = trade_strength is None or trade_strength >= min_strength
    sell_ok = sell_pressure is None or sell_pressure <= max_pressure
    return strength_ok and sell_ok


def _scalp_expected_edge_ok(candles: list[dict], flow: dict, min_change: float) -> bool:
    """Cost/momentum EDGE floor -- not a probability-weighted expected value.

    Requires the recent 10-bar move to clear round-trip cost x1.4. It has no
    P(win) and no downside/stop term, so a pass does not imply positive
    expectancy; it only screens out setups whose recent range cannot even cover
    costs. (The live engine has no reachable-upside-vs-target gate; that
    one-sided check lives only in the replay script's entry_reachability_ok.)
    """
    if len(candles) < 10:
        return False
    recent_change = abs(_recent_close_change_fraction(candles, lookback=10) or 0.0)
    spread_pct = _to_float(flow.get("spread_pct"))
    spread_fraction = max(0.0, (spread_pct or 0.0) / 100.0)
    # Round-trip cost matching the replay model: entry slippage 0.0005 + exit slippage
    # 0.0008 + commission 0.1% per side (0.002) + SEC fee (~0.00003) ≈ 0.00333.
    estimated_cost = spread_fraction + 0.0033
    return recent_change >= max(min_change, estimated_cost * 1.4)


def _volume_ratio(candles: list[dict], *, lookback: int = 20) -> float:
    if len(candles) < 2:
        return 0.0
    latest_volume = _to_float(candles[-1].get("volume")) or 0.0
    prior = candles[-min(lookback + 1, len(candles)) : -1]
    baseline = sum((_to_float(row.get("volume")) or 0.0) for row in prior) / max(1, len(prior))
    return latest_volume / max(baseline, 1.0)


def _roundtrip_cost_fraction(flow: dict) -> float:
    spread_pct = _to_float(flow.get("spread_pct"))
    spread_fraction = max(0.0, (spread_pct or 0.0) / 100.0)
    # Replay-compatible estimate: spread + entry/exit slippage + commissions/SEC.
    return spread_fraction + 0.0033


def _latest_range_fraction(candles: list[dict]) -> float:
    if not candles:
        return 0.0
    latest = candles[-1]
    high = _to_float(latest.get("high"))
    low = _to_float(latest.get("low"))
    close = _to_float(latest.get("close"))
    if high is None or low is None or close is None or close <= 0:
        return 0.0
    return max(0.0, (high - low) / close)


def _entry_dynamic_take_profit_fraction(candles: list[dict], flow: dict, strategy_name: str) -> float:
    settings = get_settings()
    spread_pct = _to_float(flow.get("spread_pct"))
    spread_fraction = max(0.0, (spread_pct or 0.0) / 100.0)
    cost = _roundtrip_cost_fraction(flow)
    recent_change = _recent_close_change_fraction(candles, lookback=10)
    recent_move = abs(recent_change) if recent_change is not None else 0.0
    volatility = max(recent_move, _latest_range_fraction(candles) * 0.35)
    edge = settings.paper_min_net_take_profit_pct
    min_net = settings.paper_min_net_take_profit_pct
    if "Runner" in strategy_name or "Continuation" in strategy_name or "EMA9 Ride" in strategy_name:
        return max(0.006, cost + edge, spread_fraction * 2.0 + edge, min(0.06, volatility * 0.80))
    if "Order Flow" in strategy_name or "Liquidity" in strategy_name:
        return max(0.0035, cost + edge, spread_fraction * 1.8 + edge, volatility * 0.45)
    momentum_bonus = min(0.018, volatility * 0.45) if ("Surge" in strategy_name or "Absorption" in strategy_name) else 0.0
    return max(min_net, cost + edge, spread_fraction * 1.8 + edge + momentum_bonus)


def _lower_wick_ratio(row: dict) -> float:
    high = _to_float(row.get("high"))
    low = _to_float(row.get("low"))
    open_ = _to_float(row.get("open"))
    close = _to_float(row.get("close"))
    if high is None or low is None or open_ is None or close is None or high <= low:
        return 0.0
    body_low = min(open_, close)
    return max(0.0, (body_low - low) / (high - low))


def _volume_shock_pullback_patterns(candles: list[dict], indicators: IndicatorSnapshot, flow: dict) -> dict:
    settings = get_settings()
    if len(candles) < 12:
        # Must carry every key the caller reads unconditionally (e.g. volume_ratio,
        # pullback_pct); omitting them raised KeyError whenever this engine ran on a
        # symbol with fewer than 12 candles.
        return {
            "volume_shock": False,
            "first_pullback": False,
            "support_held": False,
            "reclaim_confirmed": False,
            "recent_10bar_change": None,
            "volume_ratio": 0.0,
            "pullback_pct": 0.0,
            "peak_high": None,
            "pullback_low": None,
        }
    latest = candles[-1]
    previous = candles[-2]
    window = candles[-min(10, len(candles)) :]
    peak_index = max(range(len(window)), key=lambda idx: window[idx]["high"])
    peak_high = window[peak_index]["high"]
    after_peak = window[peak_index + 1 :] or [window[-1]]
    pullback_low = min(row["low"] for row in after_peak)
    pullback_pct = (peak_high - pullback_low) / peak_high if peak_high > 0 else 0.0
    recent_change = _recent_close_change_fraction(candles, lookback=10) or 0.0
    volume_ratio = _volume_ratio(candles)
    volume_shock = (
        recent_change >= settings.strategy_volume_shock_min_10bar_change_pct
        or volume_ratio >= 1.6
    )
    support_levels = [indicators.ema9, indicators.ema20, indicators.vwap, indicators.bb_mid]
    support_held = any(level is not None and pullback_low <= level * 1.015 and latest["close"] >= level * 0.995 for level in support_levels)
    first_pullback = 1 <= len(after_peak) <= 5 and 0.004 <= pullback_pct <= 0.09
    reclaim_confirmed = bool(
        latest["close"] > latest["open"]
        and latest["close"] >= previous["close"]
        # Reclaim must arrive on real participation, not a thin-volume drift that
        # then fails (replay-tuned gate that fixed choppy-name whipsaw).
        and volume_ratio >= settings.strategy_volume_shock_reclaim_min_volume_ratio
        and (
            _latest_close_near_high(candles)
            or (indicators.ema9 is not None and latest["close"] >= indicators.ema9)
        )
    )
    return {
        "volume_shock": volume_shock,
        "first_pullback": first_pullback,
        "support_held": support_held,
        "reclaim_confirmed": reclaim_confirmed,
        "recent_10bar_change": recent_change,
        "volume_ratio": volume_ratio,
        "pullback_pct": pullback_pct,
        "peak_high": peak_high,
        "pullback_low": pullback_low,
    }


def _liquidity_sweep_patterns(candles: list[dict], indicators: IndicatorSnapshot, flow: dict) -> dict:
    settings = get_settings()
    if len(candles) < 8:
        return {
            "liquidity_sweep": False,
            "reclaimed_sweep_level": False,
            "lower_wick_absorption": False,
            "sell_pressure_relief": False,
        }
    latest = candles[-1]
    prior = candles[-7:-1]
    prior_low = min(row["low"] for row in prior)
    sweep_low = latest["low"] < prior_low * 0.997
    reclaim_pct = (latest["close"] - prior_low) / prior_low if prior_low > 0 else 0.0
    reclaimed = latest["close"] >= prior_low * (1 + settings.strategy_liquidity_sweep_min_reclaim_pct)
    lower_wick = _lower_wick_ratio(latest) >= 0.35
    sell_pressure = _sell_pressure_fraction(flow.get("sell_pressure"))
    trade_strength = _to_float(flow.get("trade_strength"))
    sell_pressure_relief = (
        sell_pressure is None
        or sell_pressure <= settings.strategy_max_sell_pressure_for_entry
        or (trade_strength is not None and trade_strength >= settings.strategy_min_trade_strength_for_entry + 10)
    )
    support_reclaim = (
        indicators.ema9 is None
        or latest["close"] >= indicators.ema9
        or (indicators.vwap is not None and latest["close"] >= indicators.vwap * 0.995)
    )
    return {
        "liquidity_sweep": sweep_low,
        "reclaimed_sweep_level": reclaimed and support_reclaim,
        "lower_wick_absorption": lower_wick,
        "sell_pressure_relief": sell_pressure_relief,
        "prior_low": prior_low,
        "sweep_low": latest["low"],
        "reclaim_pct": reclaim_pct,
    }


def _micro_breakout_absorption_patterns(candles: list[dict], indicators: IndicatorSnapshot, flow: dict) -> dict:
    settings = get_settings()
    lookback = max(4, int(settings.strategy_micro_breakout_lookback_bars or 8))
    if len(candles) < lookback + 2:
        return {
            "micro_breakout": False,
            "prior_absorption": False,
            "range_compression": False,
            "range_fraction": 0.0,
        }
    latest = candles[-1]
    prior = candles[-lookback - 1:-1]
    prior_high = max(row["high"] for row in prior)
    ranges = [max(0.0, row["high"] - row["low"]) for row in prior]
    avg_range = sum(ranges) / max(1, len(ranges))
    compression = avg_range > 0 and (max(row["high"] for row in prior) - min(row["low"] for row in prior)) <= avg_range * 4.0
    prior_absorption = any(
        _lower_wick_ratio(row) >= 0.35
        or (indicators.ema9 is not None and row["low"] <= indicators.ema9 * 1.015 and row["close"] >= indicators.ema9 * 0.995)
        for row in prior[-5:]
    )
    volume_ratio = _volume_ratio(candles)
    range_fraction = _latest_range_fraction(candles)
    # A breakout on near-average volume is low-conviction and failed often;
    # require real participation (replay-tuned 1.3x vs the prior 1.05x).
    micro_breakout = latest["close"] >= prior_high and volume_ratio >= settings.strategy_micro_breakout_min_volume_ratio
    return {
        "micro_breakout": micro_breakout,
        "prior_absorption": prior_absorption,
        "range_compression": compression,
        "range_fraction": range_fraction,
        "prior_high": prior_high,
        "volume_ratio": volume_ratio,
        "volume_velocity_10s": flow.get("volume_velocity_10s"),
    }


def _liquidity_pullback_reclaim_patterns(candles: list[dict], indicators: IndicatorSnapshot, flow: dict) -> dict:
    settings = get_settings()
    empty = {
        "tight_liquidity": False,
        "recent_move_ok": False,
        "not_overheated_move": False,
        "first_pullback": False,
        "pullback_depth_ok": False,
        "support_held": False,
        "support_reclaim": False,
        "volume_ratio": 0.0,
        "imbalance_ok": True,
        "sell_pressure_decreasing": True,
        "bb_dead_zone_clear": True,
        "not_chasing": False,
        "roundtrip_cost_ok": False,
        "recent_10bar_change": None,
        "pullback_pct": None,
        "range_fraction": 0.0,
        "roundtrip_cost_pct": None,
    }
    if len(candles) < 12:
        return empty

    latest = candles[-1]
    previous = candles[-2]
    window = candles[-min(11, len(candles)) :]
    peak_index = max(range(len(window)), key=lambda idx: window[idx]["high"])
    peak_high = window[peak_index]["high"]
    after_peak = window[peak_index + 1 :] or [window[-1]]
    pullback_low = min(row["low"] for row in after_peak)
    pullback_pct = (peak_high - pullback_low) / peak_high if peak_high > 0 else 0.0
    recent_change = _recent_close_change_fraction(candles, lookback=10) or 0.0
    volume_ratio = _volume_ratio(candles)
    range_fraction = _latest_range_fraction(candles)
    roundtrip_cost = _roundtrip_cost_fraction(flow)
    notional_1m = _latest_notional_1m(candles, flow)
    quote_count = _to_float(flow.get("quote_count")) or _to_float(latest.get("quote_count"))
    imbalance = _to_float(flow.get("bid_ask_imbalance"))
    if imbalance is not None and imbalance > 1.0:
        imbalance = imbalance / 100.0
    support_levels = [indicators.ema9, indicators.ema20, indicators.bb_mid, indicators.vwap]
    support_held = any(
        level is not None and pullback_low <= level * 1.015 and latest["close"] >= level * 0.995
        for level in support_levels
    )
    vwap_reclaim = (
        indicators.vwap is None
        or (latest["low"] <= indicators.vwap * 1.012 and latest["close"] >= indicators.vwap * 0.998)
    )
    ema_reclaim = (
        indicators.ema9 is None
        or (latest["low"] <= indicators.ema9 * 1.015 and latest["close"] >= indicators.ema9 * 0.997)
    )
    support_reclaim = latest["close"] >= previous["close"] and latest["close"] >= latest["open"] and (vwap_reclaim or ema_reclaim)
    ema9_extension = 0.0
    if indicators.ema9 and indicators.ema9 > 0 and indicators.close is not None:
        ema9_extension = max(0.0, (indicators.close - indicators.ema9) / indicators.ema9)
    not_chasing = ema9_extension <= 0.055 and latest["close"] <= peak_high * 1.005
    bb_position = _bb_position_ratio(indicators)
    dead_min = settings.strategy_liquidity_pullback_avoid_bb_dead_zone_min
    dead_max = settings.strategy_liquidity_pullback_avoid_bb_dead_zone_max
    bb_dead_zone_clear = (
        bb_position is None
        or dead_min <= 0
        or dead_max <= dead_min
        or not (dead_min <= bb_position <= dead_max)
    )

    return {
        "tight_liquidity": (
            notional_1m is not None
            and notional_1m >= settings.strategy_liquidity_pullback_min_notional_1m_usd
            and (quote_count is None or quote_count >= 8)
        ),
        "recent_move_ok": recent_change >= settings.strategy_liquidity_pullback_min_10bar_change_pct,
        "not_overheated_move": recent_change <= settings.strategy_liquidity_pullback_max_10bar_change_pct,
        "first_pullback": 1 <= len(after_peak) <= 6,
        "pullback_depth_ok": 0.006 <= pullback_pct <= 0.075,
        "support_held": support_held,
        "support_reclaim": support_reclaim,
        "volume_ratio": volume_ratio,
        "imbalance_ok": imbalance is None or imbalance >= 0.50,
        "sell_pressure_decreasing": _sell_pressure_decreasing(candles, flow),
        "bb_dead_zone_clear": bb_dead_zone_clear,
        "not_chasing": not_chasing,
        "roundtrip_cost_ok": roundtrip_cost <= settings.strategy_liquidity_pullback_max_roundtrip_cost_pct,
        "recent_10bar_change": recent_change,
        "pullback_pct": pullback_pct,
        "range_fraction": range_fraction,
        "roundtrip_cost_pct": roundtrip_cost * 100.0,
        "notional_1m": notional_1m,
        "quote_count": quote_count,
        "ema9_extension": ema9_extension,
        "bb_position": bb_position,
        "peak_high": peak_high,
        "pullback_low": pullback_low,
    }


def _failed_follow_through_ok(candles: list[dict], flow: dict) -> bool:
    settings = get_settings()
    if not settings.strategy_failed_follow_through_filter_enabled or len(candles) < 3:
        return True
    latest = candles[-1]
    previous = candles[-2]
    trade_strength = _to_float(flow.get("trade_strength"))
    sell_pressure = _sell_pressure_fraction(flow.get("sell_pressure"))
    no_price_follow = latest["close"] < previous["close"] and latest["high"] <= previous["high"] * 1.002
    volume_not_following = latest["volume"] <= previous["volume"] * 0.85
    high_failures = _high_failure_count(candles, lookback=3) >= 2
    flow_failed = (
        trade_strength is not None
        and trade_strength < settings.strategy_min_trade_strength_for_entry
        and sell_pressure is not None
        and sell_pressure > settings.strategy_max_sell_pressure_for_entry
    )
    return not (high_failures or (no_price_follow and volume_not_following and flow_failed))


def _build_rule_evaluation(
    *,
    symbol: str,
    strategy_name: str,
    strategy_version: str,
    parameter_set_id: str,
    entry_mode: str,
    min_score: float,
    conditions: dict[str, bool],
    score_components: dict[str, float],
    score_weights: dict[str, float],
    indicators: IndicatorSnapshot,
    flow: dict,
    risk_preview: dict | None,
    pattern_status: dict,
) -> RealtimeVolumeEvaluation:
    final_score = round(sum(score_components.values()), 2)
    passed_conditions = [name for name, passed in conditions.items() if passed]
    failed_conditions = [name for name, passed in conditions.items() if not passed]
    # Boolean AND (replay-style): enter only when EVERY condition is True. The
    # weighted score / min_score are kept purely for display and monitoring — they
    # no longer gate entry, so behaviour matches the replay's hard AND of conditions.
    entry_allowed = not failed_conditions
    lower_band_status = {
        "lower_band_breached": pattern_status.get("lower_touch", False),
        "lower_band_reclaimed": pattern_status.get("reclaimed_inside_band", False),
        "bb_position": _bb_position(indicators),
        "bb_position_ratio": _bb_position_ratio(indicators),
        "entry_role": strategy_name,
    }
    evaluation = RealtimeVolumeEvaluation(
        symbol=symbol.upper(),
        strategy_name=strategy_name,
        strategy_version=strategy_version,
        parameter_set_id=parameter_set_id,
        passed=entry_allowed,
        final_score=final_score,
        entry_allowed=entry_allowed,
        watch_only=False,
        passed_conditions=passed_conditions,
        failed_conditions=failed_conditions,
        reject_reason=None if entry_allowed else ", ".join(failed_conditions[:4]),
        indicators=indicators,
        order_flow=flow,
        score_components=score_components,
        score_weights=score_weights,
        gate_status=conditions,
        pattern_status=pattern_status,
        lower_band_status=lower_band_status,
        risk_preview=risk_preview,
        entry_mode=entry_mode,
    )
    record_event(
        level="INFO",
        event_type="strategy.signal_evaluation",
        message=f"{strategy_name} 평가 완료" if entry_allowed else f"{strategy_name} 진입 차단",
        severity=StatusLevel.NORMAL if entry_allowed else StatusLevel.CAUTION,
        symbol=symbol.upper(),
        payload=evaluation.model_dump(),
    )
    return evaluation


def _rule_score_components(
    *,
    conditions: dict[str, bool],
    components: dict[str, list[str]],
    weights: dict[str, float],
) -> dict[str, float]:
    output: dict[str, float] = {}
    for component, names in components.items():
        if not names:
            output[component] = 0.0
            continue
        passed = sum(1 for name in names if conditions.get(name))
        output[component] = round((passed / len(names)) * float(weights.get(component, 0.0)), 2)
    return output


def _strong_momentum_without_vwap(candles: list[dict], flow: dict) -> bool:
    settings = get_settings()
    if len(candles) < 10:
        return False
    change = _recent_close_change_fraction(candles, lookback=10)
    trade_strength = _to_float(flow.get("trade_strength"))
    sell_pressure = _sell_pressure_fraction(flow.get("sell_pressure"))
    latest = candles[-1]
    previous = candles[-2] if len(candles) >= 2 else latest
    flow_ok = (
        (trade_strength is None or trade_strength >= 58)
        and (sell_pressure is None or sell_pressure <= 0.50)
    )
    return bool(
        change is not None
        and change >= settings.strategy_strong_momentum_min_10bar_change_pct
        and latest["close"] >= previous["close"]
        and _latest_close_near_high(candles)
        and flow_ok
    )


def _recent_close_change_fraction(candles: list[dict], *, lookback: int = 10) -> float | None:
    normalized = _normalize_candles(candles)
    window = normalized[-min(lookback, len(normalized)) :]
    if len(window) < 2:
        return None
    first = _to_float(window[0].get("close"))
    last = _to_float(window[-1].get("close"))
    if first is None or first <= 0 or last is None:
        return None
    return (last - first) / first


def _sell_pressure_fraction(value: str | int | float | None) -> float | None:
    pressure = _to_float(value)
    if pressure is None:
        return None
    return pressure / 100.0 if pressure > 1.0 else pressure


def _bid_ask_imbalance_fraction(flow: dict) -> float | None:
    imbalance = _to_float(flow.get("bid_ask_imbalance"))
    if imbalance is None:
        return None
    return imbalance / 100.0 if imbalance > 1.0 else imbalance


def _sell_pressure_decreasing(candles: list[dict], flow: dict) -> bool:
    current = _sell_pressure_fraction(flow.get("sell_pressure"))
    previous = _sell_pressure_fraction(candles[-2].get("sell_pressure")) if len(candles) >= 2 else None
    if current is None or previous is None:
        return True
    return current <= previous


def _score_weights(settings) -> dict[str, float]:
    raw = {
        "liquidity_impulse": max(0.0, float(settings.strategy_weight_liquidity_impulse)),
        "price_acceleration": max(0.0, float(settings.strategy_weight_price_acceleration)),
        "bollinger_context": max(0.0, float(settings.strategy_weight_bollinger_context)),
        "price_action": max(0.0, float(settings.strategy_weight_price_action)),
    }
    total = sum(raw.values())
    if total <= 0:
        return {
            "liquidity_impulse": 45.0,
            "price_acceleration": 25.0,
            "bollinger_context": 15.0,
            "price_action": 15.0,
        }
    return {key: round(value / total * 100.0, 4) for key, value in raw.items()}


def _price_action_score(candles: list[dict]) -> float:
    if len(candles) < 3:
        return 0.0
    latest = candles[-1]
    previous = candles[-2]
    score = 0.0
    candle_range = latest["high"] - latest["low"]
    if latest["close"] > latest["open"]:
        score += 5.0
    if candle_range > 0 and (latest["high"] - latest["close"]) / candle_range <= 0.35:
        score += 4.0
    if latest["high"] > previous["high"]:
        score += 3.0
    if latest["low"] >= previous["low"]:
        score += 3.0
    return min(15.0, score)


def _latest_candle_green(candles: list[dict]) -> bool:
    if not candles:
        return False
    latest = candles[-1]
    return latest["close"] > latest["open"]


def _latest_close_near_high(candles: list[dict]) -> bool:
    if not candles:
        return False
    latest = candles[-1]
    candle_range = latest["high"] - latest["low"]
    if candle_range <= 0:
        return False
    return (latest["high"] - latest["close"]) / candle_range <= 0.35


def _bb_position(indicators: IndicatorSnapshot) -> str:
    if indicators.close is None or indicators.bb_lower is None or indicators.bb_mid is None or indicators.bb_upper is None:
        return "unknown"
    if indicators.close < indicators.bb_lower:
        return "below_lower"
    if indicators.close < indicators.bb_mid:
        return "lower_to_mid"
    if indicators.close <= indicators.bb_upper:
        return "mid_to_upper"
    return "above_upper"


def _bb_position_ratio(indicators: IndicatorSnapshot) -> float | None:
    if indicators.close is None or indicators.bb_lower is None or indicators.bb_upper is None:
        return None
    band_width = indicators.bb_upper - indicators.bb_lower
    if band_width <= 0:
        return None
    return (indicators.close - indicators.bb_lower) / band_width


def _bb_upper_entry_blocked(indicators: IndicatorSnapshot, block_position: float) -> bool:
    if indicators.close is None or indicators.bb_upper is None:
        return False
    if indicators.close >= indicators.bb_upper:
        return True
    ratio = _bb_position_ratio(indicators)
    return ratio is not None and ratio >= block_position


def _bb_overheated(indicators: IndicatorSnapshot, max_over_upper_atr: float) -> bool:
    if indicators.close is None or indicators.bb_upper is None:
        return False
    if indicators.close <= indicators.bb_upper:
        return False
    if not indicators.atr20:
        return True
    return (indicators.close - indicators.bb_upper) / indicators.atr20 > max_over_upper_atr


def _flow_stale_blocked(flow: dict) -> bool:
    settings = get_settings()
    if not settings.strategy_gate_tick_stale_enabled:
        return False
    age = _to_float(flow.get("last_update_age_sec"))
    return age is not None and age > settings.strategy_tick_stale_block_sec


def _volume_60s_ok(volume_60s: float) -> bool:
    settings = get_settings()
    if not settings.strategy_gate_min_volume_60s_enabled:
        return True
    return volume_60s >= settings.strategy_min_volume_60s


def _latest_notional_1m(candles: list[dict], flow: dict) -> float | None:
    flow_notional = _to_float(flow.get("notional_1m")) or _to_float(flow.get("notional_60s"))
    if flow_notional is not None:
        return flow_notional
    if not candles:
        return None
    latest = candles[-1]
    candle_notional = _to_float(latest.get("notional")) or _to_float(latest.get("notional_usd"))
    if candle_notional is not None:
        return candle_notional
    close = _to_float(latest.get("close"))
    volume = _to_float(latest.get("volume"))
    if close is None or volume is None:
        return None
    return close * volume


def _notional_1m_ok(notional_1m: float | None) -> bool:
    minimum = get_settings().strategy_min_notional_1m_usd
    if minimum <= 0:
        return True
    return notional_1m is not None and notional_1m >= minimum


def _high_failure_count(candles: list[dict], *, lookback: int = 3) -> int:
    if len(candles) < lookback + 2:
        return 0
    recent = candles[-lookback:]
    prior_high = max(row["high"] for row in candles[-lookback - 3:-lookback] or candles[:-lookback])
    return sum(1 for row in recent if row["high"] < prior_high and row["close"] < row["open"])


def _max_spread_pct_for_flow(flow: dict) -> float:
    # Match the replay's price-aware spread cap exactly (this is the validated
    # behaviour the strategy P&L was tuned against, see prefill_entry_ok in
    # replay_tc_shadow_strategies.py). On a low-priced stock a single tick is
    # already a large %, so a flat tight cap unfairly blocks them:
    #   price <  $2  -> allow up to 1.25%
    #   price >= $2  -> allow up to 0.85%
    # Below this hard cap, spread still acts as a cost that raises the required
    # take-profit / entry-expectancy (handled in the score/edge checks).
    last_price = (
        _to_float((flow.get("trade") or {}).get("last"))
        or _to_float(flow.get("last_price"))
        or _to_float(flow.get("last"))
        or 0.0
    )
    return 1.25 if 0.0 < last_price < 2.0 else 0.85


def _macd_line(closes: list[float]) -> list[float | None]:
    ema12 = _ema_series(closes, 12)
    ema26 = _ema_series(closes, 26)
    output = []
    offset = len(ema12) - len(ema26)
    for index, slow in enumerate(ema26):
        fast = ema12[index + offset]
        output.append(fast - slow)
    return [None] * (len(closes) - len(output)) + output


def _ema_last(values: list[float], period: int) -> float | None:
    series = _ema_series(values, period)
    return series[-1] if series else None


def _ema_series(values: list[float], period: int) -> list[float]:
    if len(values) < period:
        return []
    multiplier = 2 / (period + 1)
    ema = sum(values[:period]) / period
    output = [ema]
    for value in values[period:]:
        ema = (value - ema) * multiplier + ema
        output.append(ema)
    return output


def _atr(highs: list[float], lows: list[float], closes: list[float], period: int) -> float | None:
    if len(closes) < period + 1:
        return None
    true_ranges = []
    for index in range(1, len(closes)):
        true_ranges.append(
            max(
                highs[index] - lows[index],
                abs(highs[index] - closes[index - 1]),
                abs(lows[index] - closes[index - 1]),
            )
        )
    return _sma(true_ranges[-period:])


def _vwap(candles: list[dict]) -> float | None:
    total_volume = sum(row["volume"] for row in candles)
    if total_volume <= 0:
        return None
    total = sum(((row["high"] + row["low"] + row["close"]) / 3) * row["volume"] for row in candles)
    return total / total_volume


def _sma(values: list[float]) -> float | None:
    if not values:
        return None
    return sum(values) / len(values)


def _stddev(values: list[float]) -> float | None:
    if not values:
        return None
    mean = sum(values) / len(values)
    return (sum((value - mean) ** 2 for value in values) / len(values)) ** 0.5


def _to_float(value: str | int | float | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        return None
