@echo off
setlocal
cd /d "%~dp0"

echo [1/3] Starting PostgreSQL
call scripts\start-postgres.cmd
if errorlevel 1 (
  echo.
  echo PostgreSQL failed to start.
  pause
  exit /b %errorlevel%
)

echo.
echo [2/3] Applying database migrations
call scripts\migrate-db.cmd
if errorlevel 1 (
  echo.
  echo Database migration failed.
  pause
  exit /b %errorlevel%
)

echo.
echo [3/3] Starting backend and web
call scripts\start-dev-vscode.cmd

echo.
echo Started inside the current VSCode terminal session.
echo Logs:
if exist ".runtime\backend-log.txt" (
  set /p BACKEND_LOG=<".runtime\backend-log.txt"
) else (
  set BACKEND_LOG=logs\backend.log
)
if exist ".runtime\web-log.txt" (
  set /p WEB_LOG=<".runtime\web-log.txt"
) else (
  set WEB_LOG=logs\web.log
)
echo   %BACKEND_LOG%
if exist ".runtime\worker-log.txt" (
  set /p WORKER_LOG=<".runtime\worker-log.txt"
) else (
  set WORKER_LOG=logs\worker.log
)
echo   %WORKER_LOG%
if exist ".runtime\realtime-worker-log.txt" (
  set /p REALTIME_WORKER_LOG=<".runtime\realtime-worker-log.txt"
) else (
  set REALTIME_WORKER_LOG=logs\realtime-worker.log
)
echo   %REALTIME_WORKER_LOG%
echo   %WEB_LOG%
echo.
echo Stop with:
echo   stop-dev.bat
exit /b 0
