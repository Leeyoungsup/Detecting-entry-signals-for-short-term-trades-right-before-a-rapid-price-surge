from datetime import datetime, timezone

from app.adapters.market_data.base import MarketDataUnavailableError
from app.core.config import Settings


class ExternalMarketDataStub:
    provider_name = "external_stub"

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def status(self) -> dict:
        configured = bool(
            self.settings.external_market_data_enabled
            and self.settings.external_market_data_api_key
            and self.settings.external_market_data_base_url
        )
        return {
            "provider": self.provider_name,
            "provider_display_name": self.settings.external_market_data_provider_name,
            "configured": configured,
            "status": "configured" if configured else "not_configured",
            "message": (
                "외부 실시간 market data provider가 설정되었습니다."
                if configured
                else "외부 실시간 market data provider adapter가 아직 연결되지 않았습니다."
            ),
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }

    def scanner_rankings(self, exchange: str = "NAS") -> dict:
        del exchange
        return {"trade_volume": {"output2": []}, "volume_surge": {"output2": []}, "trade_strength": {"output2": []}}

    async def start_realtime(
        self,
        *,
        symbols: list[str],
        exchange: str = "NAS",
        key_mode: str = "regular",
        subscribe_quotes: bool = True,
        subscribe_trades: bool = True,
    ) -> dict:
        del symbols, exchange, key_mode, subscribe_quotes, subscribe_trades
        return self.realtime_status()

    async def stop_realtime(self) -> dict:
        return self.realtime_status()

    def realtime_status(self) -> dict:
        return {
            "status": "not_configured",
            "environment": "external",
            "provider": self.provider_name,
            "subscription_count": 0,
            "last_message_at": None,
            "last_realtime_at": None,
            "last_error": "TODO_EXTERNAL_MARKET_DATA: 실시간 차트/tick provider adapter 연결 필요",
            "latest_quote_symbols": [],
            "latest_trade_symbols": [],
        }

    def realtime_snapshot(self) -> dict:
        return {"status": self.realtime_status(), "quotes": {}, "trades": {}, "recent_events": []}

    def subscribed_symbols(self) -> set[str]:
        return set()

    def order_flow_snapshot(self) -> dict[str, dict]:
        return {}

    def recent_events(self, limit: int = 100) -> list[dict]:
        del limit
        return []

    def price(self, symbol: str, exchange: str = "NAS") -> dict:
        raise self._not_configured(symbol, exchange)

    def quote(self, symbol: str, exchange: str = "NAS") -> dict:
        raise self._not_configured(symbol, exchange)

    def minute_bars(self, symbol: str, exchange: str = "NAS", interval: str = "1", limit: int = 120) -> dict:
        raise self._not_configured(symbol, exchange)

    def minute_bars_history(
        self,
        symbol: str,
        exchange: str = "NAS",
        interval: str = "1",
        target_date: str | None = None,
        max_pages: int = 20,
    ) -> dict:
        raise self._not_configured(symbol, exchange)

    def daily_bars(
        self,
        symbol: str,
        exchange: str = "NAS",
        period: str = "0",
        bymd: str = "",
        adjusted: bool = True,
        max_pages: int = 5,
    ) -> dict:
        raise self._not_configured(symbol, exchange)

    def _not_configured(self, symbol: str, exchange: str) -> MarketDataUnavailableError:
        return MarketDataUnavailableError(
            f"TODO_EXTERNAL_MARKET_DATA: {exchange}:{symbol} 실시간/차트 데이터 provider가 아직 설정되지 않았습니다."
        )
