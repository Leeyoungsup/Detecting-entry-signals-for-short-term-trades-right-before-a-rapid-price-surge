from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from app.db.base import Base
from app.db import models  # noqa: F401
from app.db.repositories.orders import PaperOrderRepository
from app.domain.enums import OrderState
from app.domain.models import Fill, OrderEvent, OrderRequest


def test_paper_order_repository_records_order_event_fill_and_closed_trade() -> None:
    engine = create_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)

    db = Session()
    try:
        request = OrderRequest(
            symbol="AAPL",
            side="buy",
            quantity=10,
            limit_price=10.0,
            mode="internal_paper",
        )
        event = OrderEvent(
            order_id="paper-1",
            previous_state=OrderState.ACKNOWLEDGED,
            new_state=OrderState.FILLED,
            source="paper_fill_model",
            message="filled",
        )
        fill = Fill(order_id="paper-1", symbol="AAPL", quantity=10, price=10.0)

        PaperOrderRepository(db).record_order_lifecycle(
            client_order_id="paper-1",
            request=request,
            final_state="FILLED",
            events=[event],
            fill=fill,
            market_snapshot={"risk_preview": {"allowed": True}},
            closed_trades=[
                {
                    "position_key": "AAPL::test",
                    "symbol": "AAPL",
                    "quantity": 10,
                    "entry_price": 9.5,
                    "exit_price": 10.0,
                    "gross_pnl_usd": 5,
                    "net_pnl_usd": 4.5,
                    "fees_usd": 0.5,
                    "mode": "internal_paper",
                    "entry_snapshot": {"score": 80},
                    "exit_snapshot": {"reason": "take_profit"},
                }
            ],
        )

        assert db.execute(text("select count(*) from orders")).scalar_one() == 1
        assert db.execute(text("select count(*) from order_events")).scalar_one() == 1
        assert db.execute(text("select count(*) from fills")).scalar_one() == 1
        assert db.execute(text("select count(*) from closed_trades")).scalar_one() == 1
    finally:
        db.close()
