from app.services.logging_service import redact_payload


def test_redact_payload_masks_nested_secrets_and_tokens() -> None:
    payload = {
        "Authorization": "Bearer abc",
        "nested": {
            "client_secret": "secret",
            "safe": "visible",
            "items": [{"access_token": "token"}, {"value": 1}],
        },
    }

    redacted = redact_payload(payload)

    assert redacted["Authorization"] == "***REDACTED***"
    assert redacted["nested"]["client_secret"] == "***REDACTED***"
    assert redacted["nested"]["items"][0]["access_token"] == "***REDACTED***"
    assert redacted["nested"]["safe"] == "visible"
    assert redacted["nested"]["items"][1]["value"] == 1
