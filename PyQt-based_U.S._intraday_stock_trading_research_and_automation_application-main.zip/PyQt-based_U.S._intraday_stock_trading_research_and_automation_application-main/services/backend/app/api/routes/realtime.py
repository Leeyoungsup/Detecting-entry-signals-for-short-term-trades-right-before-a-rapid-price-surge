import asyncio
from datetime import datetime, timezone
from time import monotonic
from uuid import uuid4

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketDisconnect as StarletteWebSocketDisconnect

from app.domain.enums import RealtimeEventType, StatusLevel
from app.domain.models import RealtimeEnvelope
from app.services import shared_state
from app.services.event_bus import event_bus

router = APIRouter()

RUNTIME_SYSTEM_STATUS_KEY = "trading_lab:runtime:system_status"
LEGACY_RUNTIME_SYSTEM_STATUS_KEY = "kis:runtime:system_status"
WEBSOCKET_STATUS_HEARTBEAT_SEC = 5.0
WEBSOCKET_STATUS_PUSH_SEC = 2.0


@router.get("/schema")
def realtime_schema() -> dict:
    return {
        "envelope": {
            "event_id": "uuid",
            "event_type": [event.value for event in RealtimeEventType],
            "occurred_at": "iso8601",
            "mode": "research|backtest|internal_paper|kis_mock|live",
            "status_level": [level.value for level in StatusLevel],
            "correlation_id": "optional",
            "symbol": "optional",
            "payload": "event-specific object",
        }
    }


@router.get("/history")
def realtime_history() -> dict:
    return {"events": [event.model_dump(mode="json") for event in event_bus.history()]}


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket) -> None:
    await websocket.accept()
    queue = event_bus.subscribe()
    try:
        event = event_bus.publish(
            RealtimeEventType.SYSTEM_STATUS,
            {"message": "Realtime stream connected.", "live_enabled": False},
            status_level=StatusLevel.NORMAL,
        )
        await websocket.send_json(event.model_dump(mode="json"))
        for historical_event in event_bus.history()[-20:]:
            if historical_event.event_id != event.event_id:
                await websocket.send_json(historical_event.model_dump(mode="json"))
        last_status_push = monotonic()
        while True:
            try:
                next_event = await asyncio.wait_for(queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                next_event = _shared_system_status_event()
                last_status_push = monotonic()
            await websocket.send_json(next_event.model_dump(mode="json"))
            if monotonic() - last_status_push >= WEBSOCKET_STATUS_PUSH_SEC:
                await websocket.send_json(_shared_system_status_event().model_dump(mode="json"))
                last_status_push = monotonic()
    except (WebSocketDisconnect, StarletteWebSocketDisconnect, RuntimeError):
        return
    finally:
        event_bus.unsubscribe(queue)


def _shared_system_status_event() -> RealtimeEnvelope:
    payload = shared_state.get_json_any(RUNTIME_SYSTEM_STATUS_KEY, LEGACY_RUNTIME_SYSTEM_STATUS_KEY)
    if not isinstance(payload, dict):
        payload = {"message": "Realtime stream heartbeat.", "live_enabled": False}
    status_level = _status_level(payload.get("status_level"))
    return RealtimeEnvelope(
        event_id=str(uuid4()),
        event_type=RealtimeEventType.SYSTEM_STATUS,
        occurred_at=datetime.now(timezone.utc),
        mode=str(payload.get("trading_mode") or payload.get("mode") or "internal_paper"),
        status_level=status_level,
        payload=payload,
    )


def _status_level(value: object) -> StatusLevel:
    try:
        return StatusLevel(str(value or StatusLevel.NORMAL.value))
    except ValueError:
        return StatusLevel.NORMAL
