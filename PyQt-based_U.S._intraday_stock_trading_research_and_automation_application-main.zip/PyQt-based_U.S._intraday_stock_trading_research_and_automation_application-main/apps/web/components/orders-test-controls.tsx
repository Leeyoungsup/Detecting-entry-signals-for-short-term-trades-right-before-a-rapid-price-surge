"use client";

import { useState, useTransition } from "react";
import { Play, RefreshCw, RotateCcw, XCircle } from "lucide-react";
import { API_BASE_URL } from "@/lib/api";

type Props = {
  firstPositionSymbol?: string;
  onChanged?: () => void | Promise<void>;
};

export function OrdersTestControls({ firstPositionSymbol, onChanged }: Props) {
  const [symbol, setSymbol] = useState("AAPL");
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  async function submit(side: "buy" | "sell") {
    const targetSymbol = side === "sell" ? firstPositionSymbol : symbol.trim().toUpperCase();
    if (!targetSymbol) {
      setMessage("청산할 테스트 포지션이 없습니다.");
      return;
    }
    setMessage("시뮬레이션 주문 생성 중...");
    try {
      const res = await fetch(
        `${API_BASE_URL}/api/orders/paper/dev-simulate?symbol=${encodeURIComponent(targetSymbol)}&side=${side}`,
        { method: "POST" },
      );
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        setMessage(body?.detail?.message ?? "시뮬레이션 주문 생성 실패");
        return;
      }
      setMessage(`${targetSymbol} ${side === "buy" ? "테스트 매수" : "테스트 매도"} 생성 완료`);
      startTransition(() => {
        void onChanged?.();
      });
    } catch {
      setMessage("backend API 호출 실패");
    }
  }

  async function resetPaper() {
    setMessage("시뮬레이션 상태 초기화 중...");
    try {
      const res = await fetch(`${API_BASE_URL}/api/orders/paper/reset`, { method: "POST" });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        setMessage(body?.detail?.message ?? "시뮬레이션 초기화 실패");
        return;
      }
      setMessage("시뮬레이션 주문/포지션/타임라인 초기화 완료");
      startTransition(() => {
        void onChanged?.();
      });
    } catch {
      setMessage("backend API 호출 실패");
    }
  }

  return (
    <div className="flex flex-wrap items-end gap-3 border-b border-line bg-white px-6 py-4">
      <label className="grid gap-1 text-sm">
        <span className="text-xs font-medium text-zinc-500">테스트 종목</span>
        <input
          className="h-10 w-32 rounded border border-line px-3 text-sm font-semibold uppercase"
          value={symbol}
          onChange={(event) => setSymbol(event.target.value)}
        />
      </label>
      <button
        className="inline-flex h-10 items-center gap-2 rounded bg-zinc-950 px-4 text-sm font-semibold text-white disabled:opacity-50"
        disabled={isPending}
        onClick={() => submit("buy")}
      >
        <Play className="h-4 w-4" />
        테스트 매수
      </button>
      <button
        className="inline-flex h-10 items-center gap-2 rounded border border-line bg-white px-4 text-sm font-semibold text-zinc-900 disabled:opacity-50"
        disabled={isPending || !firstPositionSymbol}
        onClick={() => submit("sell")}
      >
        <XCircle className="h-4 w-4" />
        보유 종목 청산
      </button>
      <button
        className="inline-flex h-10 items-center gap-2 rounded border border-line bg-white px-4 text-sm font-semibold text-zinc-900"
        onClick={() => void onChanged?.()}
      >
        <RefreshCw className="h-4 w-4" />
        새로고침
      </button>
      <button
        className="inline-flex h-10 items-center gap-2 rounded border border-red-200 bg-red-50 px-4 text-sm font-semibold text-red-700"
        disabled={isPending}
        onClick={resetPaper}
      >
        <RotateCcw className="h-4 w-4" />
        시뮬레이션 초기화
      </button>
      <p className="min-h-5 text-sm text-zinc-600">{message || "실제 주문 없이 시뮬레이션 타임라인만 생성합니다."}</p>
    </div>
  );
}
