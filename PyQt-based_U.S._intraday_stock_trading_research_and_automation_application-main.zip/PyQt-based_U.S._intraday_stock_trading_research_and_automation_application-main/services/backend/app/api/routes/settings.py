from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.core.config import get_settings
from app.domain.enums import StatusLevel
from app.services.event_log import record_event

router = APIRouter()

EDITABLE_SETTINGS: dict[str, dict[str, Any]] = {
    "scanner": {
        "label": "스캐너",
        "fields": {
            "scanner_min_price_usd": {"label": "최소 주가 USD", "type": "float", "min": 0, "max": 100, "step": 0.1},
            "scanner_auto_start_enabled": {"label": "스캐너 자동 시작", "type": "bool"},
            "scanner_max_websocket_symbols": {"label": "최대 Toss polling 감시 종목", "type": "int", "min": 1, "max": 100, "step": 1},
            "scanner_subscription_refresh_sec": {"label": "구독 갱신 주기 초", "type": "int", "min": 5, "max": 300, "step": 5},
            "scanner_fallback_symbols": {"label": "비상 fallback 종목", "type": "text"},
            "scanner_use_fallback_when_no_rankings": {"label": "후보 없을 때 fallback 표시", "type": "bool"},
            "scanner_allow_ranking_only_for_ws": {"label": "랭킹-only Toss 감시 후보 허용", "type": "bool"},
            "scanner_min_ranking_daily_volume": {"label": "랭킹-only 최소 일일 거래량", "type": "float", "min": 0, "max": 5000000000, "step": 1000000},
            "scanner_max_price_usd": {"label": "최대 주가 USD 미만", "type": "float", "min": 0, "max": 1000, "step": 1},
            "scanner_min_1m_volume": {"label": "최소 1분 거래량", "type": "float", "min": 0, "max": 10000000, "step": 100},
            "scanner_min_1m_notional_usd": {"label": "1분 거래대금 기준 비활성 권장", "type": "float", "min": 0, "max": 10000000, "step": 1000},
            "scanner_min_10m_volume": {"label": "최소 10분 거래량", "type": "float", "min": 0, "max": 100000000, "step": 1000},
            "scanner_min_10m_notional_usd": {"label": "최소 10분 거래대금 USD", "type": "float", "min": 0, "max": 100000000, "step": 5000},
            "scanner_min_trade_count": {"label": "최소 체결 수", "type": "float", "min": 0, "max": 10000000, "step": 100},
            "scanner_max_latest_bar_age_sec": {"label": "공식 1분봉 최대 지연 초", "type": "int", "min": 0, "max": 3600, "step": 30},
            "scanner_exclude_fund_like_symbols": {"label": "ETF/ETN/레버리지 제외", "type": "bool"},
            "scanner_excluded_symbols": {"label": "제외 심볼", "type": "text"},
        },
    },
    "session": {
        "label": "미국장 세션",
        "fields": {
            "scanner_regular_session_only": {"label": "정규장만 감시", "type": "bool"},
            "scanner_allow_premarket": {"label": "프리마켓 감시", "type": "bool"},
            "scanner_allow_afterhours": {"label": "애프터마켓 감시", "type": "bool"},
            "scanner_allow_daymarket": {"label": "데이마켓 감시", "type": "bool"},
            "scanner_stop_realtime_when_session_closed": {"label": "장마감 Toss polling 중지", "type": "bool"},
        },
    },
    "candles": {
        "label": "분봉 갱신",
        "fields": {
            "scanner_seed_minute_bars_enabled": {"label": "공식 1분봉 seed 사용", "type": "bool"},
            "scanner_seed_minute_bars_max_symbols": {"label": "분봉 갱신 최대 종목", "type": "int", "min": 1, "max": 50, "step": 1},
            "scanner_seed_minute_bars_interval_sec": {"label": "분봉 갱신 주기 초", "type": "int", "min": 5, "max": 600, "step": 5},
            "scanner_seed_minute_bars_align_wait_sec": {"label": "분봉 00초 정렬 대기 초", "type": "int", "min": 0, "max": 30, "step": 1},
            "chart_live_merge_max_gap_minutes": {"label": "차트 병합 허용 공백 분", "type": "int", "min": 0, "max": 60, "step": 1},
        },
    },
    "paper_test": {
        "label": "Paper 테스트",
        "fields": {
            "paper_test_orders_enabled": {"label": "테스트 주문 허용", "type": "bool"},
            "paper_test_relaxed_order_flow_only": {"label": "완화 테스트 주문", "type": "bool"},
            "paper_test_max_orders_per_call": {"label": "한 번에 최대 테스트 주문", "type": "int", "min": 1, "max": 5, "step": 1},
            "paper_max_open_positions": {"label": "최대 보유 포지션", "type": "int", "min": 1, "max": 20, "step": 1},
            "paper_max_total_exposure_pct": {"label": "최대 총 노출 %", "type": "pct", "min": 1, "max": 100, "step": 1},
            "paper_test_min_realtime_volume_60s": {"label": "테스트 최소 60초 거래량", "type": "float", "min": 0, "max": 1000000, "step": 1},
            "paper_exit_cooldown_seconds": {"label": "청산 판단 최소 간격 초", "type": "int", "min": 1, "max": 60, "step": 1},
            "toss_position_quote_monitor_enabled": {"label": "보유종목 Toss 호가 감시", "type": "bool"},
            "toss_position_quote_interval_sec": {"label": "Toss 호가 감시 주기 초", "type": "float", "min": 0.5, "max": 10, "step": 0.5},
            "toss_position_quote_cache_sec": {"label": "Toss 호가 캐시 초", "type": "float", "min": 0, "max": 5, "step": 0.1},
            "toss_position_quote_max_symbols_per_tick": {"label": "초당 Toss 호가 감시 최대 종목", "type": "int", "min": 1, "max": 10, "step": 1},
        },
    },
    "costs": {
        "label": "비용 모델",
        "fields": {
            "paper_fee_model_enabled": {"label": "수수료 모델 사용", "type": "bool"},
            "paper_commission_pct": {"label": "거래 수수료 %", "type": "pct", "min": 0, "max": 5, "step": 0.01},
            "paper_commission_per_share": {"label": "주당 수수료 USD", "type": "float", "min": 0, "max": 1, "step": 0.001},
            "paper_min_commission_usd": {"label": "최소 수수료 USD", "type": "float", "min": 0, "max": 20, "step": 0.01},
            "paper_sec_fee_pct": {"label": "SEC fee %", "type": "pct", "min": 0, "max": 1, "step": 0.001},
            "paper_taf_fee_per_share": {"label": "TAF 주당 USD", "type": "float", "min": 0, "max": 1, "step": 0.0001},
            "paper_taf_fee_cap_usd": {"label": "TAF 상한 USD", "type": "float", "min": 0, "max": 50, "step": 0.1},
        },
    },
}


class SettingsPatch(BaseModel):
    values: dict[str, Any]


@router.get("")
def runtime_settings() -> dict:
    settings = get_settings()
    return {
        "runtime_only": True,
        "read_only": {
            "trading_mode": settings.trading_mode,
            "live_enabled": settings.live_enabled,
            "market_data_provider": settings.market_data_provider,
            "execution_provider": settings.execution_provider,
            "market_data_feed": "openapi_polling" if settings.market_data_provider == "toss" else settings.alpaca_feed,
            "toss_environment": settings.toss_environment,
        },
        "groups": _settings_groups(settings),
    }


@router.patch("")
def update_runtime_settings(patch: SettingsPatch) -> dict:
    settings = get_settings()
    field_meta = _field_meta_by_key()
    changed: dict[str, dict[str, Any]] = {}
    for key, raw_value in patch.values.items():
        meta = field_meta.get(key)
        if not meta:
            raise HTTPException(status_code=400, detail=f"수정할 수 없는 설정입니다: {key}")
        old_value = getattr(settings, key)
        new_value = _coerce_value(key, raw_value, meta)
        setattr(settings, key, new_value)
        changed[key] = {"old": old_value, "new": new_value}
    if changed:
        record_event(
            level="INFO",
            event_type="settings.runtime_updated",
            message="운영 설정이 수정되었습니다.",
            severity=StatusLevel.CAUTION,
            payload={"changed": changed, "runtime_only": True},
        )
    return {"runtime_only": True, "groups": _settings_groups(settings), "changed": changed}


def _settings_groups(settings) -> list[dict[str, Any]]:
    groups = []
    for group_key, group in EDITABLE_SETTINGS.items():
        fields = []
        for key, meta in group["fields"].items():
            raw = getattr(settings, key)
            value = raw * 100 if meta["type"] == "pct" else raw
            fields.append({"key": key, "value": value, **meta})
        groups.append({"key": group_key, "label": group["label"], "fields": fields})
    return groups


def _field_meta_by_key() -> dict[str, dict[str, Any]]:
    output = {}
    for group in EDITABLE_SETTINGS.values():
        output.update(group["fields"])
    return output


def _coerce_value(key: str, value: Any, meta: dict[str, Any]) -> Any:
    setting_type = meta["type"]
    if setting_type == "bool":
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            lowered = value.strip().lower()
            if lowered in {"true", "1", "yes", "on"}:
                return True
            if lowered in {"false", "0", "no", "off"}:
                return False
        raise HTTPException(status_code=400, detail=f"{key} 값은 true/false여야 합니다.")
    if setting_type == "text":
        return str(value)
    try:
        numeric = float(value)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=f"{key} 값은 숫자여야 합니다.") from exc
    min_value = meta.get("min")
    max_value = meta.get("max")
    if min_value is not None and numeric < float(min_value):
        raise HTTPException(status_code=400, detail=f"{key} 값은 {min_value} 이상이어야 합니다.")
    if max_value is not None and numeric > float(max_value):
        raise HTTPException(status_code=400, detail=f"{key} 값은 {max_value} 이하여야 합니다.")
    if setting_type == "pct":
        numeric = numeric / 100
    if setting_type == "int":
        return int(round(numeric))
    return numeric
