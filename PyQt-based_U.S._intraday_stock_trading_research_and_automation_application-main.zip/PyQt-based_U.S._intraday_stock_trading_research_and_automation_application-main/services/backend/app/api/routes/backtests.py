from fastapi import APIRouter
from fastapi import HTTPException
from pydantic import BaseModel

from app.domain.models import BacktestRunRequest
from app.services.backtest import ConservativeFillModel
from app.services.strategy_replay_api import StrategyReplayError
from app.services.strategy_replay_api import run_strategy_replay

router = APIRouter()


class StrategyReplayRequest(BaseModel):
    symbol: str
    date_kst: str
    start_time_kst: str
    end_time_kst: str
    end_date_kst: str | None = None


@router.get("/defaults")
def backtest_defaults() -> dict:
    return {
        "initial_equity_usd": 2000.0,
        "mode": "backtest",
        "strategy_name": "lower_band_reclaim",
        "conservative_same_bar_exit": True,
        "cost_model": {
            "commission_enabled": True,
            "sec_fee_enabled": True,
            "taf_fee_enabled": True,
            "spread_cost_enabled": True,
            "slippage_enabled": True,
            "default_slippage_bps": 5,
            "stop_slippage_bps": 10,
        },
    }


@router.post("/preview")
def preview_backtest(request: BacktestRunRequest) -> dict:
    decision = ConservativeFillModel().decide_exit(
        candle_high=101.0,
        candle_low=99.0,
        stop_loss=99.5,
        take_profit=100.8,
    )
    return {
        "accepted": True,
        "request": request.model_dump(),
        "status": "queued_stub",
        "live_trading_called": False,
        "sample_conservative_fill_decision": decision.__dict__ if decision else None,
        "message": "Historical data loader and execution accounting are the next implementation step.",
    }


@router.post("/strategy-replay")
def strategy_replay(request: StrategyReplayRequest) -> dict:
    try:
        return run_strategy_replay(
            symbol=request.symbol,
            date_kst=request.date_kst,
            start_time_kst=request.start_time_kst,
            end_time_kst=request.end_time_kst,
            end_date_kst=request.end_date_kst,
        )
    except StrategyReplayError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
