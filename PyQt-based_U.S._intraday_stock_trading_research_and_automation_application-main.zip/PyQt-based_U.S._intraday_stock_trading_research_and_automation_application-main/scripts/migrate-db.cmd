@echo off
setlocal

cd /d "%~dp0..\services\backend"

call ..\..\scripts\load-env.cmd

set CONDA_ENV_DIR=%USERPROFILE%\.conda\envs\kis-trading-research
if not exist "%CONDA_ENV_DIR%\python.exe" set CONDA_ENV_DIR=C:\ProgramData\anaconda3\envs\kis-trading-research
set PATH=%CONDA_ENV_DIR%;%CONDA_ENV_DIR%\Library\bin;%CONDA_ENV_DIR%\Scripts;%PATH%

if "%DATABASE_URL%"=="" set DATABASE_URL=postgresql+psycopg://kis_app:change_me@127.0.0.1:5432/kis_trading_research

echo Applying Alembic migrations
python -m alembic upgrade head
if errorlevel 1 exit /b %errorlevel%
exit /b 0
