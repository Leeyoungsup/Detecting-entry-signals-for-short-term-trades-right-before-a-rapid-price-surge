"use client";

import {
  Activity,
  AlertTriangle,
  Database,
  DollarSign,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  Wallet,
  Zap,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { PageTitle } from "@/components/page-title";
import { StatusPill } from "@/components/status-pill";
import { API_BASE_URL } from "@/lib/api";

type CommandCenter = {
  status_level: string;
  trading_mode: string;
  live_enabled: boolean;
  market_data_provider?: string;
  market_data_status?: string;
  market_data_message?: string;
  execution_provider?: string;
  execution_status?: string;
  runtime_supervisor?: {
    running: boolean;
    last_tick_at?: string | null;
    last_error?: string | null;
    position_quote_monitor?: {
      running?: boolean;
      last_tick_at?: string | null;
      last_error?: string | null;
      last_result?: {
        checked?: number;
        positions?: number;
        blocked?: { symbol?: string; error?: string; retry_after?: string }[];
        skipped?: string;
        unique_symbols_quoted?: number;
        max_symbols_per_tick?: number;
      } | null;
    };
  };
  data_freshness?: {
    last_ws_message_at?: string | null;
    last_realtime_at?: string | null;
    last_trade_at?: string | null;
    last_quote_at?: string | null;
    state?: string | null;
    trade_state?: string | null;
    quote_state?: string | null;
  };
  session?: {
    state?: string | null;
    market_timezone?: string | null;
    local_timezone?: string | null;
    now_market?: string | null;
    now_local?: string | null;
  };
  account: {
    initial_equity_usd: number;
    equity_usd: number;
    cash_buying_power_usd?: number | null;
    realized_pnl_usd: number;
    unrealized_pnl_usd: number;
    daily_loss_limit_used_pct: number;
    daily_loss_limit_enabled?: boolean;
    total_exposure_pct: number;
    risk_hard_caps_enabled?: boolean;
  };
  counts: { open_positions: number; open_orders: number; trades_today: number };
  performance: { win_rate_today: number | null; profit_factor_today: number | null };
  recent_warnings: string[];
};

const fallback: CommandCenter = {
  status_level: "CAUTION",
  trading_mode: "live",
  live_enabled: true,
  market_data_provider: "checking",
  market_data_status: "waiting",
  market_data_message: "백엔드 상태 응답 대기 중",
  execution_provider: "toss",
  execution_status: "waiting",
  runtime_supervisor: { running: false, last_tick_at: null, last_error: null },
  data_freshness: { last_ws_message_at: null, last_realtime_at: null, last_trade_at: null, last_quote_at: null, state: "CAUTION" },
  session: { state: "unknown", now_market: null, now_local: null },
  account: {
    initial_equity_usd: 2000,
    equity_usd: 2000,
    realized_pnl_usd: 0,
    unrealized_pnl_usd: 0,
    daily_loss_limit_used_pct: 0,
    daily_loss_limit_enabled: false,
    total_exposure_pct: 0,
    risk_hard_caps_enabled: false,
  },
  counts: { open_positions: 0, open_orders: 0, trades_today: 0 },
  performance: { win_rate_today: null, profit_factor_today: null },
  recent_warnings: ["백엔드 상태 응답을 기다리는 중입니다."],
};

const commandCenterRefreshEvents = new Set([
  "live.order_candidate",
  "live.order_blocked",
  "paper.order_event",
  "paper.exit_signal",
  "paper.exit_blocked",
  "paper.order_blocked",
  "paper.position_quote_failed",
  "paper.reset",
  "runtime.supervisor_started",
  "runtime.supervisor_stopped",
  "runtime.supervisor_tick_failed",
  "runtime.position_quote_tick_failed",
  "scanner.realtime_start",
  "scanner.realtime_paused",
  "settings.runtime_updated",
]);

function realtimeUrl() {
  return `${API_BASE_URL.replace(/^http/, "ws").replace(/\/$/, "")}/api/realtime/ws`;
}

export default function CommandCenterPage() {
  const [data, setData] = useState<CommandCenter>(fallback);
  const [connected, setConnected] = useState(false);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const refreshTimerRef = useRef<number | null>(null);
  const fallbackTimerRef = useRef<number | null>(null);
  const watchdogTimerRef = useRef<number | null>(null);
  const lastEventMsRef = useRef(0);
  const commandAbortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    void loadCommandCenter();
  }, []);

  useEffect(() => {
    let closed = false;
    let socket: WebSocket | null = null;

    function scheduleLoad() {
      if (document.visibilityState !== "visible") return;
      if (refreshTimerRef.current !== null) return;
      refreshTimerRef.current = window.setTimeout(() => {
        refreshTimerRef.current = null;
        void loadCommandCenter();
      }, 250);
    }

    function connect() {
      if (closed) return;
      socket = new WebSocket(realtimeUrl());
      socket.onopen = () => {
        const now = Date.now();
        lastEventMsRef.current = now;
        setConnected(true);
        setUpdatedAt(new Date(now));
        void loadCommandCenter();
      };
      socket.onerror = () => setConnected(false);
      socket.onclose = () => {
        setConnected(false);
        if (!closed) window.setTimeout(connect, 3000);
      };
      socket.onmessage = (message) => {
        try {
          const now = Date.now();
          lastEventMsRef.current = now;
          const event = JSON.parse(message.data) as {
            event_type?: string;
            payload?: {
              event_type?: string;
              runtime_supervisor?: CommandCenter["runtime_supervisor"];
              data_freshness?: CommandCenter["data_freshness"];
              session?: CommandCenter["session"];
            };
          };
          if (event.event_type === "system.status") {
            setData((current) => ({
              ...current,
              runtime_supervisor: event.payload?.runtime_supervisor ?? current.runtime_supervisor,
              data_freshness: event.payload?.data_freshness ?? current.data_freshness,
              session: event.payload?.session ?? current.session,
            }));
            setUpdatedAt(new Date(now));
            return;
          }
          const logEventType = event.payload?.event_type;
          if (event.event_type === "log.event" && logEventType && commandCenterRefreshEvents.has(logEventType)) {
            scheduleLoad();
          }
        } catch {
          return;
        }
      };
    }

    function watchdog() {
      if (closed) return;
      const idleMs = Date.now() - lastEventMsRef.current;
      if (lastEventMsRef.current > 0 && idleMs > 15000) {
        setConnected(false);
        socket?.close();
      }
      watchdogTimerRef.current = window.setTimeout(watchdog, 5000);
    }

    connect();
    watchdog();
    fallbackTimerRef.current = window.setInterval(() => {
      if (document.visibilityState === "visible") {
        void loadCommandCenter();
      }
    }, 10000);
    return () => {
      closed = true;
      commandAbortRef.current?.abort();
      socket?.close();
      if (refreshTimerRef.current !== null) window.clearTimeout(refreshTimerRef.current);
      if (fallbackTimerRef.current !== null) window.clearInterval(fallbackTimerRef.current);
      if (watchdogTimerRef.current !== null) window.clearTimeout(watchdogTimerRef.current);
    };
  }, []);

  async function loadCommandCenter() {
    commandAbortRef.current?.abort();
    const controller = new AbortController();
    commandAbortRef.current = controller;
    try {
      const response = await fetch(`${API_BASE_URL}/api/command-center`, { cache: "no-store", signal: controller.signal });
      if (!response.ok) return;
      setData((await response.json()) as CommandCenter);
      setUpdatedAt(new Date());
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      return;
    }
  }

  const initialEquity = data.account.initial_equity_usd ?? data.account.equity_usd ?? 0;
  const totalPnl = data.account.realized_pnl_usd + data.account.unrealized_pnl_usd;
  const pnlPct = initialEquity > 0 ? (totalPnl / initialEquity) * 100 : 0;
  const dataState = data.data_freshness?.state ?? data.status_level;
  const warnings = data.recent_warnings.filter(Boolean);

  return (
    <>
      <PageTitle
        title="운영 센터"
        description="실시간 데이터, 페이퍼 계좌, 자동화 루프, 리스크 상태를 한 화면에서 감시합니다."
        icon={<Activity className="h-5 w-5" aria-hidden />}
        action={<CommandLiveStatus connected={connected} updatedAt={updatedAt} />}
      />

      <section className="space-y-5 p-6">
        <div className={statusPanelClass(data.status_level)}>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-3">
                <StatusPill status={data.status_level} />
                <span className="text-sm font-semibold text-ink">{modeLabel(data.trading_mode)}</span>
                <span className="rounded border border-line bg-white px-2 py-1 text-xs font-medium text-zinc-600">
                  실전매매 {data.live_enabled ? "활성" : "비활성"}
                </span>
              </div>
              <div>
                <div className="text-2xl font-bold tracking-normal text-ink">{statusHeadline(data.status_level)}</div>
                <div className="mt-1 text-sm text-zinc-600">{data.market_data_message || "운영 상태를 확인 중입니다."}</div>
              </div>
            </div>
            <div className="grid gap-2 sm:grid-cols-3 lg:min-w-[520px]">
              <StatusChip icon={<Database className="h-4 w-4" />} label="Market Data" value={`${data.market_data_provider ?? "-"} / ${data.market_data_status ?? "-"}`} status={data.market_data_status} />
              <StatusChip icon={<Zap className="h-4 w-4" />} label="실행 Gateway" value={`${data.execution_provider ?? "-"} / ${data.execution_status ?? "-"}`} status={data.execution_status} />
              <StatusChip icon={<Activity className="h-4 w-4" />} label="감시 루프" value={data.runtime_supervisor?.running ? "실행 중" : "중지"} status={data.runtime_supervisor?.running ? "NORMAL" : "BLOCKED"} />
            </div>
          </div>
        </div>

        <div className="grid gap-4 xl:grid-cols-[1.25fr_0.75fr]">
          <section className="rounded border border-line bg-white">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <div>
                <h2 className="text-base font-semibold text-ink">페이퍼 계좌</h2>
                <p className="mt-1 text-xs text-zinc-500">수수료 반영 후 실현손익 기준</p>
              </div>
              <Wallet className="h-5 w-5 text-info" aria-hidden />
            </div>
            <div className="grid gap-px bg-line md:grid-cols-4">
              <MoneyTile label="현재 평가금액" value={data.account.equity_usd} accent="info" />
              <MoneyTile label="총 손익" value={totalPnl} detail={`${formatSignedPercent(pnlPct)} / 기준 $${data.account.initial_equity_usd.toFixed(0)}`} accent={totalPnl >= 0 ? "ok" : "block"} signed />
              <MoneyTile label="실현손익" value={data.account.realized_pnl_usd} accent={data.account.realized_pnl_usd >= 0 ? "ok" : "block"} signed />
              <MoneyTile label="미실현손익" value={data.account.unrealized_pnl_usd} accent={data.account.unrealized_pnl_usd >= 0 ? "ok" : "block"} signed />
            </div>
          </section>

          <section className="rounded border border-line bg-white">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <div>
                <h2 className="text-base font-semibold text-ink">계좌 사용 현황</h2>
                <p className="mt-1 text-xs text-zinc-500">신규 진입 차단에는 사용하지 않음</p>
              </div>
              <ShieldCheck className="h-5 w-5 text-ok" aria-hidden />
            </div>
            <div className="space-y-4 p-5">
              <ProgressMetric label="일일 손실 참고값" value={data.account.daily_loss_limit_used_pct} limitLabel="2% 기준 / 차단 미적용" tone="info" />
              <ProgressMetric label="총 노출 참고값" value={data.account.total_exposure_pct} limitLabel="계좌 대비 / 차단 미적용" tone="info" />
            </div>
          </section>
        </div>

        <section className="rounded border border-line bg-white">
          <div className="flex items-center justify-between border-b border-line px-5 py-3">
            <h2 className="text-sm font-semibold text-ink">시스템 진단</h2>
            <span className="text-xs text-zinc-400">실시간 데이터 · 시장 세션 · 자동화 루프</span>
          </div>
          <div className="grid gap-px bg-line sm:grid-cols-2 lg:grid-cols-4">
            <DiagItem label="데이터 상태" value={stateLabel(dataState)} status={dataState} />
            <DiagItem label="시장 세션" value={sessionLabel(data.session?.state)} />
            <DiagItem label="미국장 시간" value={data.session?.now_market ?? "-"} />
            <DiagItem label="한국 시간" value={data.session?.now_local ?? "-"} />
            <DiagItem label="최근 trade tick" value={formatKstDateTime(data.data_freshness?.last_trade_at)} />
            <DiagItem label="최근 quote tick" value={formatKstDateTime(data.data_freshness?.last_quote_at)} />
            <DiagItem label="최근 loop tick" value={formatKstTime(data.runtime_supervisor?.last_tick_at)} />
            <DiagItem label="보유종목 호가" value={positionQuoteLabel(data.runtime_supervisor?.position_quote_monitor)} />
          </div>
        </section>

        <div className="grid gap-4 xl:grid-cols-[0.8fr_1.2fr]">
          <section className="rounded border border-line bg-white">
            <div className="border-b border-line px-5 py-4">
              <h2 className="text-base font-semibold text-ink">오늘 요약</h2>
            </div>
            <div className="grid gap-px bg-line sm:grid-cols-2">
              <CountTile icon={<Activity className="h-4 w-4" />} label="거래 수" value={data.counts.trades_today} />
              <CountTile icon={<TrendingUp className="h-4 w-4" />} label="승률" value={formatOptionalPercent(data.performance.win_rate_today)} />
              <CountTile icon={<DollarSign className="h-4 w-4" />} label="Profit Factor" value={formatOptionalNumber(data.performance.profit_factor_today)} />
              <CountTile icon={<TrendingDown className="h-4 w-4" />} label="미체결 주문" value={data.counts.open_orders} />
              <CountTile icon={<Wallet className="h-4 w-4" />} label="보유 포지션" value={data.counts.open_positions} />
            </div>
          </section>

          <section className="rounded border border-line bg-white">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <h2 className="text-base font-semibold text-ink">최근 경고와 상태 메시지</h2>
              <AlertTriangle className="h-5 w-5 text-warn" aria-hidden />
            </div>
            <div className="divide-y divide-line">
              {(warnings.length ? warnings : ["표시할 경고가 없습니다."]).slice(0, 6).map((warning, index) => (
                <div key={`${warning}-${index}`} className="flex gap-3 px-5 py-3">
                  <span className={warningToneClass(warning)}>{warningToneLabel(warning)}</span>
                  <p className="min-w-0 flex-1 text-sm leading-6 text-zinc-700">{warning}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </section>
    </>
  );
}

function StatusChip({ icon, label, value, status }: { icon: React.ReactNode; label: string; value: string; status?: string | null }) {
  return (
    <div className="rounded border border-line bg-white px-3 py-2">
      <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
        {icon}
        {label}
      </div>
      <div className="mt-1 flex items-center gap-2">
        <span className={dotClass(status)} />
        <span className="truncate text-sm font-semibold text-ink">{value}</span>
      </div>
    </div>
  );
}

function MoneyTile({
  label,
  value,
  detail,
  accent,
  signed,
}: {
  label: string;
  value: number;
  detail?: string;
  accent: "ok" | "warn" | "block" | "info";
  signed?: boolean;
}) {
  return (
    <div className="bg-white p-4">
      <div className="text-xs font-medium text-zinc-500">{label}</div>
      <div className={`mt-2 text-2xl font-bold ${accentTextClass(accent)}`}>{signed ? formatSignedMoney(value) : formatMoney(value)}</div>
      {detail ? <div className="mt-2 text-xs text-zinc-500">{detail}</div> : null}
    </div>
  );
}

function ProgressMetric({ label, value, limitLabel, tone }: { label: string; value: number; limitLabel: string; tone: "ok" | "warn" | "block" | "info" }) {
  const bounded = Math.max(0, Math.min(100, value));
  return (
    <div>
      <div className="flex items-end justify-between gap-3">
        <div>
          <div className="text-sm font-semibold text-ink">{label}</div>
          <div className="mt-1 text-xs text-zinc-500">{limitLabel}</div>
        </div>
        <div className={`text-xl font-bold ${accentTextClass(tone)}`}>{value.toFixed(1)}%</div>
      </div>
      <div className="mt-3 h-2 rounded bg-zinc-100">
        <div className={`h-2 rounded ${accentBgClass(tone)}`} style={{ width: `${bounded}%` }} />
      </div>
    </div>
  );
}

function DiagItem({ label, value, status }: { label: string; value: string; status?: string | null }) {
  return (
    <div className="bg-white px-4 py-3">
      <div className="text-xs font-medium text-zinc-500">{label}</div>
      <div className="mt-1 flex items-center gap-2">
        {status !== undefined ? <span className={dotClass(status)} /> : null}
        <span className="truncate text-sm font-semibold text-ink">{value}</span>
      </div>
    </div>
  );
}

function CountTile({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="bg-white p-4">
      <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
        {icon}
        {label}
      </div>
      <div className="mt-2 text-xl font-bold text-ink">{value}</div>
    </div>
  );
}

function CommandLiveStatus({ connected, updatedAt }: { connected: boolean; updatedAt: Date | null }) {
  return (
    <div className="inline-flex items-center gap-2 rounded border border-line bg-white px-3 py-2 text-xs font-semibold text-zinc-600">
      <span className={connected ? "h-2 w-2 rounded-full bg-ok" : "h-2 w-2 rounded-full bg-warn"} />
      <span>{connected ? "부분 업데이트 연결" : "자동 갱신 대기"}</span>
      <span className="text-zinc-400">{updatedAt ? updatedAt.toLocaleTimeString("ko-KR", { hour12: false }) : "-"}</span>
    </div>
  );
}

function statusPanelClass(status: string) {
  if (status === "NORMAL") return "rounded border border-emerald-200 bg-emerald-50 p-5";
  if (status === "CAUTION") return "rounded border border-amber-200 bg-amber-50 p-5";
  if (status === "EMERGENCY") return "rounded border border-red-300 bg-red-50 p-5";
  return "rounded border border-red-200 bg-red-50 p-5";
}

function statusHeadline(status: string) {
  const labels: Record<string, string> = {
    NORMAL: "시스템 정상, 전략 감시 중",
    CAUTION: "주의 상태, 데이터와 주문 조건 확인 필요",
    BLOCKED: "신규 진입 차단 상태",
    EMERGENCY: "긴급 대응 필요",
  };
  return labels[status] ?? "운영 상태 확인 중";
}

function modeLabel(value: string) {
  const labels: Record<string, string> = {
    research: "리서치 모드",
    backtest: "백테스트 모드",
    internal_paper: "시뮬레이션 모드",
    kis_mock: "KIS 모의투자 모드",
    live: "실전 모드",
  };
  return labels[value] ?? value;
}

function sessionLabel(value?: string | null) {
  const labels: Record<string, string> = {
    regular: "정규장",
    premarket: "프리마켓",
    afterhours: "애프터마켓",
    daymarket: "데이마켓",
    closed: "장마감",
    unknown: "확인 중",
  };
  return value ? labels[value] ?? value : "-";
}

function stateLabel(value?: string | null) {
  const labels: Record<string, string> = {
    NORMAL: "정상",
    CAUTION: "주의",
    BLOCKED: "차단",
    EMERGENCY: "긴급",
    PAUSED: "일시중지",
  };
  return value ? labels[value] ?? value : "-";
}

function dotClass(status?: string | null) {
  const normalized = (status ?? "").toUpperCase();
  if (["NORMAL", "ONLINE", "CONFIGURED", "CONNECTED", "RUNNING"].includes(normalized)) return "h-2 w-2 rounded-full bg-ok";
  if (["CAUTION", "WARNING", "EXECUTION_ONLY", "PAUSED"].includes(normalized)) return "h-2 w-2 rounded-full bg-warn";
  return "h-2 w-2 rounded-full bg-block";
}

function accentTextClass(tone: "ok" | "warn" | "block" | "info") {
  return {
    ok: "text-ok",
    warn: "text-warn",
    block: "text-block",
    info: "text-info",
  }[tone];
}

function accentBgClass(tone: "ok" | "warn" | "block" | "info") {
  return {
    ok: "bg-ok",
    warn: "bg-warn",
    block: "bg-block",
    info: "bg-info",
  }[tone];
}

function warningToneLabel(value: string) {
  if (value.includes("실시간") || value.includes("실행 중")) return "정보";
  if (value.includes("중지") || value.includes("실패") || value.includes("오류")) return "주의";
  if (value.includes("실전매매")) return "잠금";
  return "확인";
}

function warningToneClass(value: string) {
  const label = warningToneLabel(value);
  if (label === "정보") return "mt-0.5 inline-flex h-6 shrink-0 items-center rounded bg-blue-50 px-2 text-xs font-semibold text-info ring-1 ring-blue-100";
  if (label === "잠금") return "mt-0.5 inline-flex h-6 shrink-0 items-center rounded bg-red-50 px-2 text-xs font-semibold text-block ring-1 ring-red-100";
  return "mt-0.5 inline-flex h-6 shrink-0 items-center rounded bg-amber-50 px-2 text-xs font-semibold text-warn ring-1 ring-amber-100";
}

function formatMoney(value: number) {
  return `$${value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatSignedMoney(value: number) {
  const sign = value > 0 ? "+" : "";
  return `${sign}${formatMoney(value)}`;
}

function formatSignedPercent(value: number) {
  const sign = value > 0 ? "+" : "";
  return `${sign}${value.toFixed(2)}%`;
}

function formatOptionalPercent(value: number | null) {
  return value == null ? "-" : `${value.toFixed(1)}%`;
}

function formatOptionalNumber(value: number | null) {
  if (value == null) return "-";
  if (value >= 999) return "∞";
  return value.toFixed(2);
}

function positionQuoteLabel(monitor?: CommandCenter["runtime_supervisor"] extends infer Runtime ? Runtime extends { position_quote_monitor?: infer Monitor } ? Monitor : never : never) {
  if (!monitor?.running) return "중지";
  const result = monitor.last_result;
  if (result?.skipped) return `중지 (${result.skipped})`;
  const checked = result?.checked ?? 0;
  const positions = result?.positions ?? 0;
  const blocked = result?.blocked?.length ?? 0;
  const maxSymbols = result?.max_symbols_per_tick ?? "-";
  if (positions > 0 && checked === 0 && blocked > 0) {
    return `호가 실패 ${blocked}/${positions}개, 쿨다운`;
  }
  if (blocked > 0) {
    return `${checked}/${positions}개 확인, 실패 ${blocked}개`;
  }
  return `${checked}/${positions}개 확인, 최대 ${maxSymbols}/초`;
}

function formatKstTime(value?: string | null) {
  if (!value) return "-";
  const date = parseRealtimeDate(value);
  if (!date) return "-";
  return date.toLocaleTimeString("ko-KR", {
    timeZone: "Asia/Seoul",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function formatKstDateTime(value?: string | null) {
  if (!value) return "-";
  const date = parseRealtimeDate(value);
  if (!date) return "-";
  return date.toLocaleString("ko-KR", {
    timeZone: "Asia/Seoul",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function parseRealtimeDate(value: string) {
  let normalized = value;
  if (normalized.endsWith("Z")) normalized = `${normalized.slice(0, -1)}+00:00`;
  normalized = normalized.replace(/\.(\d{3,6})\d+([+-]\d{2}:?\d{2})$/, ".$1$2");
  normalized = normalized.replace(/\.(\d{3,6})\d+$/, ".$1");
  const date = /[+-]\d{2}:?\d{2}$/.test(normalized) ? new Date(normalized) : new Date(`${normalized}Z`);
  return Number.isNaN(date.getTime()) ? null : date;
}
