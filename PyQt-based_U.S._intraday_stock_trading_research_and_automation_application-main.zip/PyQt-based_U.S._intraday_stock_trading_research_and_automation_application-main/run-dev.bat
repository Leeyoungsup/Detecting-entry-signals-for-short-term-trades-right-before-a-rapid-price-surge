@echo off
setlocal
cd /d "%~dp0"
call scripts\run-dev.cmd
echo.
echo Dev server windows have been opened.
pause
