import asyncio
from datetime import datetime
from uuid import uuid4

from app.domain.enums import RealtimeEventType, StatusLevel
from app.domain.models import RealtimeEnvelope
from app.services import shared_state

REALTIME_CHANNEL = "trading_lab:realtime:events"
REALTIME_HISTORY_KEY = "trading_lab:realtime:history"
LEGACY_REALTIME_HISTORY_KEY = "kis:realtime:history"


class InMemoryEventBus:
    """Small local bus for skeleton realtime delivery; Redis Pub/Sub can replace this boundary."""

    def __init__(self) -> None:
        self._history: list[RealtimeEnvelope] = []
        self._subscribers: set[asyncio.Queue[RealtimeEnvelope]] = set()
        self._redis_task: asyncio.Task | None = None

    def publish(
        self,
        event_type: RealtimeEventType,
        payload: dict,
        *,
        mode: str = "internal_paper",
        status_level: StatusLevel = StatusLevel.NORMAL,
        symbol: str | None = None,
        correlation_id: str | None = None,
    ) -> RealtimeEnvelope:
        event = RealtimeEnvelope(
            event_id=str(uuid4()),
            event_type=event_type,
            occurred_at=datetime.utcnow(),
            mode=mode,
            status_level=status_level,
            correlation_id=correlation_id,
            symbol=symbol,
            payload=payload,
        )
        self._history.append(event)
        self._history = self._history[-500:]
        stale_subscribers: list[asyncio.Queue[RealtimeEnvelope]] = []
        for subscriber in self._subscribers:
            try:
                subscriber.put_nowait(event)
            except asyncio.QueueFull:
                stale_subscribers.append(subscriber)
        for subscriber in stale_subscribers:
            self._subscribers.discard(subscriber)
        event_json = event.model_dump(mode="json")
        envelope = {"origin": shared_state.PROCESS_ID, "event": event_json}
        shared_state.push_json(REALTIME_HISTORY_KEY, event_json, max_items=500)
        shared_state.publish_json(REALTIME_CHANNEL, envelope)
        return event

    def history(self) -> list[RealtimeEnvelope]:
        shared = shared_state.list_json_any(REALTIME_HISTORY_KEY, LEGACY_REALTIME_HISTORY_KEY, limit=500)
        if shared:
            events: list[RealtimeEnvelope] = []
            for row in shared:
                try:
                    events.append(RealtimeEnvelope.model_validate(row))
                except Exception:
                    continue
            if events:
                self._history = events[-500:]
        return list(self._history)

    def subscribe(self) -> asyncio.Queue[RealtimeEnvelope]:
        self._ensure_redis_listener()
        queue: asyncio.Queue[RealtimeEnvelope] = asyncio.Queue(maxsize=100)
        self._subscribers.add(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue[RealtimeEnvelope]) -> None:
        self._subscribers.discard(queue)

    def _ensure_redis_listener(self) -> None:
        if self._redis_task and not self._redis_task.done():
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        self._redis_task = loop.create_task(self._listen_redis(), name="redis-realtime-event-listener")

    async def _listen_redis(self) -> None:
        async def handle(message: dict) -> None:
            if message.get("origin") == shared_state.PROCESS_ID:
                return
            raw_event = message.get("event")
            if not isinstance(raw_event, dict):
                return
            try:
                event = RealtimeEnvelope.model_validate(raw_event)
            except Exception:
                return
            self._history.append(event)
            self._history = self._history[-500:]
            stale_subscribers: list[asyncio.Queue[RealtimeEnvelope]] = []
            for subscriber in self._subscribers:
                try:
                    subscriber.put_nowait(event)
                except asyncio.QueueFull:
                    stale_subscribers.append(subscriber)
            for subscriber in stale_subscribers:
                self._subscribers.discard(subscriber)

        while True:
            try:
                await shared_state.subscribe_json(REALTIME_CHANNEL, handle)
            except asyncio.CancelledError:
                raise
            except Exception:
                await asyncio.sleep(2.0)


event_bus = InMemoryEventBus()
