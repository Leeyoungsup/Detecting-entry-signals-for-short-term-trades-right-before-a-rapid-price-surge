"use client";

import Link from "next/link";
import { LineChart } from "lucide-react";
import { LiveStatus } from "@/components/live-status";
import { PageTitle } from "@/components/page-title";
import { useLiveResource, type RealtimeEnvelope } from "@/lib/use-live-resource";

type ScannerData = {
  realtime?: {
    subscribed_symbols: string[];
    symbols_with_quote: string[];
    symbols_with_trade: string[];
    last_realtime_at: string | null;
  };
  candidates: Candidate[];
};

type Candidate = {
  symbol: string;
  company_name: string | null;
  last_price?: number | null;
  prev_close_price?: number | null;
  day_change_pct?: number | null;
  rank_total: number | null;
  scanner_score: number | null;
  trade_notional_rank?: number | null;
  realtime_liquidity_rank?: number | null;
  realtime_volume_rank: number | null;
  volume_1m: number | null;
  notional_1m?: number | null;
  notional_10m?: number | null;
  daily_volume?: number | null;
  trade_count?: number | null;
  volume_source: string | null;
  volume_velocity_10s: number | null;
  trade_strength: number | null;
  spread_pct: number | null;
  selected_for_ws: boolean;
  selected_for_strategy: boolean;
  reject_reason: string | null;
  order_flow_notes?: string[];
};

const fallback: ScannerData = { candidates: [] };

export default function SymbolsPage() {
  const { data, connected, eventAt, updatedAt } = useLiveResource<ScannerData>({
    path: "/scanner/funnel",
    fallback,
    shouldReload: symbolsShouldReload,
    minIntervalMs: 2500,
  });
  const subscribed = new Set(data.realtime?.subscribed_symbols ?? []);
  const candidateSymbols = new Set(data.candidates.map((candidate) => candidate.symbol.toUpperCase()).filter(Boolean));
  const subscribedOutsideCandidates = [...subscribed].filter((symbol) => !candidateSymbols.has(symbol)).length;

  return (
    <>
      <PageTitle
        title="종목 목록"
        description="실시간 후보 종목을 한눈에 보고, 종목을 눌러 상세 판단 근거로 이동합니다."
        icon={<LineChart className="h-5 w-5" aria-hidden />}
        action={<LiveStatus connected={connected} eventAt={eventAt} updatedAt={updatedAt} />}
      />
      <section className="space-y-6 p-6">
        <div className="grid gap-3 md:grid-cols-3">
          <SummaryCard label="후보 종목" value={data.candidates.length} detail="최종 후보 테이블 표시 수" />
          <SummaryCard label="관찰 구독" value={subscribed.size} detail={`coarse 랭킹 WS 관찰 · 후보 외 ${subscribedOutsideCandidates}개`} />
          <SummaryCard label="마지막 실시간 tick" value={formatKstDateTime(data.realtime?.last_realtime_at)} detail={formatSymbolList([...subscribed])} />
        </div>
        <div className="overflow-hidden rounded border border-line bg-white">
          <div className="border-b border-line px-4 py-3 text-sm font-semibold text-ink">후보 목록</div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="bg-zinc-50 text-xs uppercase text-zinc-500">
                <tr>
                  <th className="px-3 py-2">종목</th>
                  <th className="px-3 py-2">종목명</th>
                  <th className="px-3 py-2 text-right">현재가</th>
                  <th className="px-3 py-2 text-right">등락률</th>
                  <th className="px-3 py-2 text-right">스프레드</th>
                  <th className="px-3 py-2">상태</th>
                </tr>
              </thead>
              <tbody>
                {data.candidates.map((candidate) => {
                  const dayChange = candidateDayChangePct(candidate);
                  return (
                    <tr key={candidate.symbol} className="border-t border-line">
                      <td className="px-3 py-2">
                        <Link href={`/symbols/${candidate.symbol}`} prefetch={false} className="font-semibold text-info hover:underline">
                          {candidate.symbol}
                        </Link>
                      </td>
                      <td className="px-3 py-2 text-zinc-700">{candidate.company_name ?? "-"}</td>
                      <td className="px-3 py-2 text-right font-semibold text-zinc-700">{formatPrice(candidate.last_price)}</td>
                      <td className={`px-3 py-2 text-right font-semibold ${percentTone(dayChange)}`}>{formatSignedPercent(dayChange)}</td>
                      <td className="px-3 py-2 text-right text-zinc-700">{formatPercent(candidate.spread_pct)}</td>
                      <td className="px-3 py-2">
                        <WatchBadge strategy={candidate.selected_for_strategy} subscribed={candidate.selected_for_ws} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </>
  );
}

function symbolsShouldReload(event: RealtimeEnvelope) {
  if (event.event_type !== "log.event") return false;
  return [
    "scanner.snapshot",
    "scanner.realtime_start",
    "scanner.realtime_paused",
    "scanner.minute_seed",
    "strategy.signal_evaluation",
    "risk.decision",
    "paper.order_event",
  ].includes(String(event.payload?.event_type ?? ""));
}

function WatchBadge({ strategy, subscribed }: { strategy: boolean; subscribed: boolean }) {
  if (strategy) {
    return <span className="inline-flex rounded bg-emerald-50 px-2 py-1 text-xs font-semibold text-ok ring-1 ring-emerald-100">전략 감시</span>;
  }
  if (subscribed) {
    return <span className="inline-flex rounded bg-blue-50 px-2 py-1 text-xs font-semibold text-info ring-1 ring-blue-100">실시간 구독</span>;
  }
  return <span className="inline-flex rounded bg-zinc-50 px-2 py-1 text-xs font-semibold text-zinc-500 ring-1 ring-zinc-200">랭킹</span>;
}

function SummaryCard({ label, value, detail }: { label: string; value: string | number; detail?: string }) {
  return (
    <div className="rounded border border-line bg-white p-4">
      <div className="text-xs font-semibold text-zinc-500">{label}</div>
      <div className="mt-2 text-xl font-semibold text-ink">{value}</div>
      {detail ? <div className="mt-2 truncate text-xs text-zinc-500">{detail}</div> : null}
    </div>
  );
}

function formatSymbolList(symbols: string[]) {
  if (!symbols.length) return "-";
  return symbols.slice(0, 8).join(", ") + (symbols.length > 8 ? ` 외 ${symbols.length - 8}` : "");
}

function formatPrice(value: number | null | undefined) {
  const number = toNumber(value);
  if (number == null) return "-";
  return number.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 4 });
}

function formatPercent(value: number | null) {
  if (value == null) {
    return "-";
  }
  return `${Number(value).toFixed(3)}%`;
}

function formatSignedPercent(value: number | null) {
  if (value == null) return "-";
  const sign = value > 0 ? "+" : "";
  return `${sign}${value.toFixed(2)}%`;
}

function percentTone(value: number | null) {
  if (value == null) return "text-zinc-500";
  if (value > 0) return "text-red-600";
  if (value < 0) return "text-blue-600";
  return "text-zinc-500";
}

// Live day change from the polling price vs the prior-day close, falling back to the ranking
// snapshot's change rate when the close is unavailable.
function candidateDayChangePct(candidate: Candidate): number | null {
  const last = toNumber(candidate.last_price);
  const prevClose = toNumber(candidate.prev_close_price);
  if (last != null && prevClose != null && prevClose !== 0) {
    return ((last - prevClose) / prevClose) * 100;
  }
  return toNumber(candidate.day_change_pct);
}

function toNumber(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value.replace(/,/g, ""));
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function formatKstDateTime(value?: string | null) {
  if (!value) return "-";
  const date = parseRealtimeDate(value);
  if (!date) return "-";
  return date.toLocaleString("ko-KR", {
    timeZone: "Asia/Seoul",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function parseRealtimeDate(value: string) {
  let normalized = value;
  if (normalized.endsWith("Z")) normalized = `${normalized.slice(0, -1)}+00:00`;
  normalized = normalized.replace(/\.(\d{3,6})\d+([+-]\d{2}:?\d{2})$/, ".$1$2");
  normalized = normalized.replace(/\.(\d{3,6})\d+$/, ".$1");
  const date = /[+-]\d{2}:?\d{2}$/.test(normalized) ? new Date(normalized) : new Date(`${normalized}Z`);
  return Number.isNaN(date.getTime()) ? null : date;
}
