"use client";

import Link from "next/link";
import { use, useCallback } from "react";
import {
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  Clock3,
  Layers3,
  LineChart,
  RadioTower,
  ShieldCheck,
  Wallet,
} from "lucide-react";
import { InteractivePriceChart } from "@/components/interactive-price-chart";
import { LiveStatus } from "@/components/live-status";
import { PageTitle } from "@/components/page-title";
import { StatusPill } from "@/components/status-pill";
import { SymbolRefreshControls } from "@/components/symbol-refresh-controls";
import { useLiveResource, type RealtimeEnvelope } from "@/lib/use-live-resource";

type Candle = {
  market_date?: string | null;
  market_time?: string | null;
  korea_date?: string | null;
  korea_time?: string | null;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number | null;
  volume: number | null;
  notional?: number | null;
  source?: string | null;
  is_live?: boolean | null;
};

type SymbolDetail = {
  symbol: string;
  company_name?: string | null;
  data_source?: string;
  rest_source_used?: boolean;
  price: Record<string, string | number | null>;
  chart: {
    interval: string;
    date?: string | null;
    source?: string | null;
    source_detail?: string | null;
    freshness?: Freshness | null;
    realtime_freshness?: Freshness | null;
    data_gap_blocked?: boolean;
    strategy_candle_mode?: string | null;
    message: string;
    overlays: string[];
    candles: Candle[];
    indicators: Record<string, number | null>;
  };
  order_flow: Record<string, number | string | null | unknown[]>;
  order_book: Record<string, number | string | null | Record<string, unknown>>;
  signal_explanation: {
    strategy_name?: string;
    passed_conditions: string[];
    failed_conditions: string[];
    reject_reason: string | null;
    entry_allowed: boolean;
    entry_mode?: string | null;
    strategy_candle_mode?: string | null;
    lower_band_status?: Record<string, unknown>;
    pattern_status?: Record<string, unknown>;
  };
  risk_preview: Record<string, number | string | boolean | null>;
};

type Freshness = {
  latest_market_at?: string | null;
  latest_korea_at?: string | null;
  age_sec?: number | null;
  is_stale?: boolean | null;
  is_caution?: boolean | null;
  source?: string | null;
};

type ScannerData = {
  realtime?: { subscribed_symbols: string[] };
  candidates: {
    symbol: string;
    company_name: string | null;
    selected_for_ws: boolean;
    selected_for_strategy: boolean;
    rank_total: number | null;
    realtime_volume_rank?: number | null;
  }[];
};

const fallbackSymbol: SymbolDetail = {
  symbol: "-",
  company_name: null,
  price: {},
  chart: { interval: "1m", message: "백엔드에 연결할 수 없습니다.", overlays: [], candles: [], indicators: {} },
  order_flow: {},
  order_book: {},
  signal_explanation: {
    passed_conditions: [],
    failed_conditions: ["backend_unavailable"],
    reject_reason: "backend_unavailable",
    entry_allowed: false,
  },
  risk_preview: {},
};

const fallbackScanner: ScannerData = { candidates: [] };

export default function SymbolPage({
  params,
  searchParams,
}: {
  params: Promise<{ symbol: string }>;
  searchParams: Promise<{ timeframe?: string; date?: string }>;
}) {
  const { symbol } = use(params);
  const { timeframe = "1m", date } = use(searchParams);
  const query = new URLSearchParams({ timeframe });
  if (date) query.set("date", date);

  const shouldReloadSymbol = useCallback((event: RealtimeEnvelope) => symbolShouldReload(event, symbol), [symbol]);
  const { data, connected, eventAt, updatedAt } = useLiveResource<SymbolDetail>({
    path: `/symbols/${symbol}?${query.toString()}`,
    fallback: { ...fallbackSymbol, symbol },
    shouldReload: shouldReloadSymbol,
    minIntervalMs: 3000,
    fallbackIntervalMs: 30000,
  });
  const { data: scanner } = useLiveResource<ScannerData>({
    path: "/scanner/funnel",
    fallback: fallbackScanner,
    shouldReload: scannerShouldReload,
    minIntervalMs: 2500,
    fallbackIntervalMs: 30000,
  });

  const latestCandle = lastValidCandle(data.chart.candles);
  const firstCandle = firstValidCandle(data.chart.candles);
  const currentPrice = toNumber(data.price.last) ?? toNumber(latestCandle?.close);
  const referencePrice = toNumber(firstCandle?.open);
  const change = currentPrice != null && referencePrice != null ? currentPrice - referencePrice : null;
  const changePct = change != null && referencePrice ? (change / referencePrice) * 100 : null;
  const subscribed = new Set(scanner.realtime?.subscribed_symbols ?? []);
  const activeCandidate = scanner.candidates.find((candidate) => candidate.symbol === data.symbol);

  return (
    <>
      <PageTitle
        title="종목 상세"
        description="차트, 호가, 체결 흐름, 진입 조건, 리스크를 한 화면에서 확인합니다."
        icon={<LineChart className="h-5 w-5" aria-hidden />}
        action={<LiveStatus connected={connected} eventAt={eventAt} updatedAt={updatedAt} />}
      />

      <section className="space-y-5 p-6">
        <QuoteBoard
          data={data}
          price={currentPrice}
          change={change}
          changePct={changePct}
          activeCandidate={activeCandidate}
          subscribed={subscribed.has(data.symbol)}
        />

        <div className="rounded border border-line bg-white px-4 py-3">
          <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
            <SymbolRefreshControls activeTimeframe={data.chart.interval} activeDate={date ?? ""} />
            <CandidateStrip candidates={scanner.candidates} activeSymbol={data.symbol} subscribed={subscribed} />
          </div>
        </div>

        <div className="grid gap-5 xl:grid-cols-[minmax(0,1.55fr)_420px]">
          <section className="min-w-0">
            <InteractivePriceChart candles={data.chart.candles} indicators={data.chart.indicators} message={data.chart.message} />
          </section>
          <aside className="space-y-5">
            <DecisionPanel signal={data.signal_explanation} />
            <RiskTicket risk={data.risk_preview} price={currentPrice} />
          </aside>
        </div>

        <div className="grid gap-5 xl:grid-cols-2">
          <OrderBookPanel orderBook={data.order_book} />
          <IndicatorPanel indicators={data.chart.indicators} />
        </div>

        <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_420px]">
          <CandleTable candles={data.chart.candles.slice(-24).reverse()} />
          <DataStatusPanel data={data} />
        </div>
      </section>
    </>
  );
}

function symbolShouldReload(event: RealtimeEnvelope, symbol: string) {
  const eventSymbol = String(event.symbol ?? event.payload?.symbol ?? "").toUpperCase();
  const currentSymbol = symbol.toUpperCase();
  if (event.event_type === "symbol.detail") {
    return !eventSymbol || eventSymbol === currentSymbol;
  }
  if (event.event_type !== "log.event") return false;
  const payloadSymbol = String(event.payload?.symbol ?? "").toUpperCase();
  if (payloadSymbol && payloadSymbol !== currentSymbol) return false;
  // strategy.signal_evaluation is NOT included: the symbol route itself publishes it on every load,
  // which would create a feedback loop (load → event → load → ...). Only real-time action events trigger reload.
  return [
    "risk.decision",
    "live.order_candidate",
    "live.order_blocked",
    "paper.order_event",
    "paper.exit_signal",
    "paper.exit_blocked",
  ].includes(String(event.payload?.event_type ?? ""));
}

function scannerShouldReload(event: RealtimeEnvelope) {
  if (event.event_type !== "log.event") return false;
  return [
    "scanner.snapshot",
    "scanner.realtime_start",
    "scanner.realtime_paused",
    "scanner.minute_seed",
    "strategy.signal_evaluation",
    "live.order_candidate",
    "live.order_blocked",
    "paper.order_event",
  ].includes(String(event.payload?.event_type ?? ""));
}

function QuoteBoard({
  data,
  price,
  change,
  changePct,
  activeCandidate,
  subscribed,
}: {
  data: SymbolDetail;
  price: number | null;
  change: number | null;
  changePct: number | null;
  activeCandidate?: ScannerData["candidates"][number];
  subscribed: boolean;
}) {
  const positive = (change ?? 0) >= 0;
  const tone = positive ? "text-ok" : "text-block";
  return (
    <section className="rounded border border-line bg-white">
      <div className="flex flex-col gap-5 border-b border-line px-5 py-4 xl:flex-row xl:items-end xl:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-3xl font-bold tracking-normal text-ink">{data.symbol}</h1>
            <span className="truncate text-base font-medium text-zinc-500">{data.company_name ?? "종목명 미확인"}</span>
            <StatusPill status={data.signal_explanation.entry_allowed ? "NORMAL" : "CAUTION"} />
          </div>
          <div className="mt-3 flex flex-wrap items-end gap-x-4 gap-y-2">
            <div className="text-5xl font-bold tracking-normal text-ink">{formatPrice(price)}</div>
            <div className={`pb-1 text-lg font-bold ${tone}`}>
              {formatSignedPrice(change)} {formatSignedPercent(changePct)}
            </div>
          </div>
        </div>
        <div className="grid gap-2 sm:grid-cols-4 xl:min-w-[620px]">
          <QuoteStat label="실시간 구독" value={subscribed ? "구독 중" : "미구독"} tone={subscribed ? "ok" : "warn"} />
          <QuoteStat label="후보 순위" value={formatNumber(activeCandidate?.realtime_volume_rank ?? activeCandidate?.rank_total)} tone="info" />
          <QuoteStat label="차트 기준" value={data.chart.source_detail ?? formatDataSource(data.chart.source ?? data.data_source)} tone="info" />
          <QuoteStat label="전략 기준" value={formatStrategyCandleMode(data.signal_explanation.strategy_candle_mode ?? data.chart.strategy_candle_mode)} tone="ok" />
        </div>
      </div>
      <div className="grid gap-px bg-line sm:grid-cols-2 xl:grid-cols-4">
        <MarketMini label="최신 candle" value={formatFreshness(data.chart.freshness)} icon={<Clock3 className="h-4 w-4" />} />
        <MarketMini label="실시간 tick" value={formatFreshness(data.chart.realtime_freshness)} icon={<RadioTower className="h-4 w-4" />} />
        <MarketMini label="공백 보호" value={data.chart.data_gap_blocked ? "병합 보류" : "정상"} icon={<ShieldCheck className="h-4 w-4" />} />
        <MarketMini label="캔들 수" value={`${data.chart.candles.length}개`} icon={<BarChart3 className="h-4 w-4" />} />
      </div>
    </section>
  );
}

function QuoteStat({ label, value, tone }: { label: string; value: string; tone: "ok" | "warn" | "block" | "info" }) {
  return (
    <div className="rounded border border-line bg-zinc-50 px-3 py-2">
      <div className="text-xs font-medium text-zinc-500">{label}</div>
      <div className={`mt-1 truncate text-sm font-bold ${toneText(tone)}`}>{value || "-"}</div>
    </div>
  );
}

function MarketMini({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) {
  return (
    <div className="bg-white px-5 py-3">
      <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
        <span className="text-info">{icon}</span>
        {label}
      </div>
      <div className="mt-1 truncate text-sm font-semibold text-ink">{value}</div>
    </div>
  );
}

function CandidateStrip({
  candidates,
  activeSymbol,
  subscribed,
}: {
  candidates: ScannerData["candidates"];
  activeSymbol: string;
  subscribed: Set<string>;
}) {
  if (!candidates.length) {
    return <div className="text-sm text-zinc-500">현재 스캐너 후보가 없습니다. 장중에 자동으로 표시됩니다.</div>;
  }
  return (
    <div className="flex min-w-0 flex-1 items-center gap-2 overflow-x-auto pb-1 xl:justify-end">
      {candidates.slice(0, 24).map((candidate) => {
        const active = candidate.symbol === activeSymbol;
        return (
          <Link
            key={candidate.symbol}
            href={`/symbols/${candidate.symbol}`}
            className={[
              "inline-flex h-10 shrink-0 items-center gap-2 rounded border px-3 text-sm font-semibold",
              active ? "border-ink bg-ink text-white" : "border-line bg-white text-ink hover:bg-zinc-50",
            ].join(" ")}
          >
            <span>{candidate.symbol}</span>
            <span className={active ? "text-zinc-200" : subscribed.has(candidate.symbol) ? "text-info" : "text-zinc-400"}>
              {candidate.realtime_volume_rank ?? candidate.rank_total ?? "-"}
            </span>
          </Link>
        );
      })}
    </div>
  );
}

function DecisionPanel({ signal }: { signal: SymbolDetail["signal_explanation"] }) {
  const allowed = signal.entry_allowed;
  const passed = signal.passed_conditions.length;
  const total = passed + signal.failed_conditions.length;
  return (
    <section className="rounded border border-line bg-white">
      <div className="flex items-center justify-between border-b border-line px-5 py-4">
        <div>
          <h2 className="text-base font-semibold text-ink">매매 판단</h2>
          {signal.strategy_name ? <p className="mt-1 text-xs text-zinc-500">{signal.strategy_name}</p> : null}
        </div>
        <StatusPill status={allowed ? "NORMAL" : "CAUTION"} />
      </div>
      <div className="p-5">
        <div className="flex items-end justify-between gap-4">
          <div>
            <div className="text-xs font-medium text-zinc-500">진입 조건 통과</div>
            <div className={allowed ? "mt-1 text-5xl font-bold text-ok" : "mt-1 text-5xl font-bold text-warn"}>
              {passed}
              <span className="text-2xl font-semibold text-zinc-400">/{total || "-"}</span>
            </div>
            <div className="mt-1 text-xs text-zinc-500">모든 조건 통과 시에만 진입 (AND)</div>
          </div>
          <div className={allowed ? "rounded bg-emerald-50 px-3 py-2 text-sm font-bold text-ok ring-1 ring-emerald-100" : "rounded bg-amber-50 px-3 py-2 text-sm font-bold text-warn ring-1 ring-amber-100"}>
            {allowed ? "진입 가능" : "대기"}
          </div>
        </div>
        <div className="mt-4 h-2 rounded bg-zinc-100">
          <div className={allowed ? "h-2 rounded bg-ok" : "h-2 rounded bg-warn"} style={{ width: `${total ? (passed / total) * 100 : 0}%` }} />
        </div>
        <div className="mt-4 rounded bg-zinc-50 px-3 py-2 text-sm leading-6 text-zinc-700">
          {signal.reject_reason ?? "진입 조건을 통과했습니다. 현재 주문 모드 기준으로 처리됩니다."}
        </div>
        <ConditionList title="통과" items={signal.passed_conditions} tone="ok" />
        <ConditionList title="보류/실패" items={signal.failed_conditions} tone="warn" />
      </div>
    </section>
  );
}

function ConditionList({ title, items, tone }: { title: string; items: string[]; tone: "ok" | "warn" }) {
  return (
    <div className="mt-4">
      <div className="text-xs font-semibold text-zinc-500">{title}</div>
      <div className="mt-2 flex flex-wrap gap-2">
        {(items.length ? items : ["-"]).slice(0, 8).map((item) => (
          <span
            key={item}
            className={tone === "ok" ? "rounded bg-emerald-50 px-2 py-1 text-xs font-medium text-ok ring-1 ring-emerald-100" : "rounded bg-amber-50 px-2 py-1 text-xs font-medium text-warn ring-1 ring-amber-100"}
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}

function RiskTicket({ risk, price }: { risk: SymbolDetail["risk_preview"]; price: number | null }) {
  const quantity = toNumber(risk.quantity);
  const notional = quantity != null && price != null ? quantity * price : null;
  return (
    <section className="rounded border border-line bg-white">
      <div className="flex items-center justify-between border-b border-line px-5 py-4">
        <div>
          <h2 className="text-base font-semibold text-ink">주문 프리뷰</h2>
          <p className="mt-1 text-xs text-zinc-500">현재 주문 모드 기준</p>
        </div>
        <Wallet className="h-5 w-5 text-info" aria-hidden />
      </div>
      <div className="divide-y divide-line">
        <KeyRow label="허용 여부" value={risk.allowed ? "허용" : "차단"} strong tone={risk.allowed ? "ok" : "block"} />
        <KeyRow label="예상 진입가" value={formatPrice(price)} />
        <KeyRow label="예상 수량" value={formatNumber(quantity)} />
        <KeyRow label="예상 주문금액" value={formatUsd(notional ?? risk.max_notional_usd)} />
        <KeyRow label="손절가" value={formatPrice(risk.stop_loss_price)} tone="block" />
        <KeyRow label="거래 리스크" value={formatUsd(risk.risk_amount_usd)} />
        <KeyRow label="차단 사유" value={String(risk.reason ?? "-")} />
      </div>
    </section>
  );
}

function OrderBookPanel({ orderBook }: { orderBook: SymbolDetail["order_book"] }) {
  const bid = toNumber(orderBook.bid);
  const ask = toNumber(orderBook.ask);
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="호가" icon={<Layers3 className="h-5 w-5 text-info" />} />
      <div className="grid grid-cols-2 gap-px bg-line">
        <QuoteSide label="매수 Bid" price={bid} depth={toNumber(orderBook.bid_depth)} tone="ok" />
        <QuoteSide label="매도 Ask" price={ask} depth={toNumber(orderBook.ask_depth)} tone="block" />
      </div>
      <div className="divide-y divide-line">
        <KeyRow label="스프레드" value={formatPercent(orderBook.spread_pct)} />
        <KeyRow label="호가 불균형" value={formatNumber(orderBook.bid_ask_imbalance)} />
      </div>
    </section>
  );
}

function QuoteSide({ label, price, depth, tone }: { label: string; price: number | null; depth: number | null; tone: "ok" | "block" }) {
  return (
    <div className="bg-white p-4">
      <div className="text-xs font-medium text-zinc-500">{label}</div>
      <div className={`mt-2 text-2xl font-bold ${toneText(tone)}`}>{formatPrice(price)}</div>
      <div className="mt-1 text-xs text-zinc-500">잔량 {formatNumber(depth)}</div>
    </div>
  );
}

function IndicatorPanel({ indicators }: { indicators: Record<string, number | null> }) {
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="주요 지표" icon={<LineChart className="h-5 w-5 text-info" />} />
      <div className="divide-y divide-line">
        <KeyRow label="VWAP" value={formatPrice(indicators.vwap)} />
        <KeyRow label="EMA9 / EMA20" value={`${formatPrice(indicators.ema9)} / ${formatPrice(indicators.ema20)}`} />
        <KeyRow label="BB 상단" value={formatPrice(indicators.bb_upper)} />
        <KeyRow label="BB 중앙" value={formatPrice(indicators.bb_mid)} />
        <KeyRow label="BB 하단" value={formatPrice(indicators.bb_lower)} />
        <KeyRow label="ATR20 / ATR%" value={`${formatNumber(indicators.atr20)} / ${formatPercent(indicators.atr_pct)}`} />
        <KeyRow label="MACD Hist Δ" value={formatNumber(indicators.macd_histogram_delta)} />
      </div>
    </section>
  );
}

function CandleTable({ candles }: { candles: Candle[] }) {
  return (
    <section className="overflow-hidden rounded border border-line bg-white">
      <PanelHeader title="최근 1분봉" icon={<BarChart3 className="h-5 w-5 text-info" />} />
      <div className="max-h-[420px] overflow-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="sticky top-0 bg-zinc-50 text-xs text-zinc-500">
            <tr>
              <th className="px-4 py-3 font-semibold">시간(KST)</th>
              <th className="px-4 py-3 text-right font-semibold">시가</th>
              <th className="px-4 py-3 text-right font-semibold">고가</th>
              <th className="px-4 py-3 text-right font-semibold">저가</th>
              <th className="px-4 py-3 text-right font-semibold">종가</th>
              <th className="px-4 py-3 text-right font-semibold">거래량</th>
            </tr>
          </thead>
          <tbody>
            {candles.map((candle, index) => (
              <tr key={`${candle.market_date}-${candle.market_time}-${index}`} className="border-t border-line">
                <td className="whitespace-nowrap px-4 py-3 text-zinc-600">{formatCandleDateTime(candle)}</td>
                <td className="whitespace-nowrap px-4 py-3 text-right text-zinc-700">{formatPrice(candle.open)}</td>
                <td className="whitespace-nowrap px-4 py-3 text-right text-ok">{formatPrice(candle.high)}</td>
                <td className="whitespace-nowrap px-4 py-3 text-right text-block">{formatPrice(candle.low)}</td>
                <td className="whitespace-nowrap px-4 py-3 text-right font-semibold text-ink">{formatPrice(candle.close)}</td>
                <td className="whitespace-nowrap px-4 py-3 text-right text-zinc-700">{formatNumber(candle.volume)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function DataStatusPanel({ data }: { data: SymbolDetail }) {
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="데이터 상태" icon={<AlertTriangle className="h-5 w-5 text-warn" />} />
      <div className="divide-y divide-line">
        <KeyRow label="차트 소스" value={data.chart.source_detail ?? formatDataSource(data.chart.source)} />
        <KeyRow label="REST 조회" value={data.rest_source_used ? "사용" : "캐시/실시간"} />
        <KeyRow label="최신 candle" value={formatFreshness(data.chart.freshness)} />
        <KeyRow label="실시간 tick" value={formatFreshness(data.chart.realtime_freshness)} />
        <KeyRow label="차트 공백 보호" value={data.chart.data_gap_blocked ? "병합 보류" : "정상"} />
      </div>
    </section>
  );
}

function PanelHeader({ title, icon }: { title: string; icon: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-line px-5 py-4">
      <h2 className="text-base font-semibold text-ink">{title}</h2>
      {icon}
    </div>
  );
}

function KeyRow({ label, value, strong = false, tone }: { label: string; value: string; strong?: boolean; tone?: "ok" | "warn" | "block" | "info" }) {
  return (
    <div className="flex items-center justify-between gap-4 px-5 py-3 text-sm">
      <span className="text-zinc-500">{label}</span>
      <span className={`text-right ${strong ? "text-base font-bold" : "font-semibold"} ${tone ? toneText(tone) : "text-ink"}`}>{value}</span>
    </div>
  );
}

function lastValidCandle(candles: Candle[]) {
  return [...candles].reverse().find((candle) => candle.close != null);
}

function firstValidCandle(candles: Candle[]) {
  return candles.find((candle) => candle.open != null);
}

function toneText(tone: "ok" | "warn" | "block" | "info") {
  return {
    ok: "text-ok",
    warn: "text-warn",
    block: "text-block",
    info: "text-info",
  }[tone];
}

function formatDataSource(value: string | null | undefined) {
  if (value === "toss_position_quote_1m_window") {
    return "보유 종목 Toss 호가 기준 1분봉";
  }
  const labels: Record<string, string> = {
    kis_rest_minute: "KIS REST 공식 1분봉",
    kis_rest_minute_history: "KIS REST 공식 과거 1분봉",
    kis_rest_daily: "KIS REST 공식 일봉",
    provider_ws_tick_fallback: "Toss polling tick 임시 fallback",
    provider_ws_tick_1m_window: "Toss polling tick-built 최신 1분봉",
    provider_ws_tick_warming: "Toss polling tick-built 1분봉 생성 중",
    provider_minute: "Primary market data 공식 1분봉",
    toss_minute: "Toss OpenAPI 공식 1분봉",
    toss_minute_history: "Toss OpenAPI 공식 과거 1분봉",
    toss_daily: "Toss OpenAPI 공식 일봉",
    provider_minute_scanner_seed: "스캐너 seed 공식 1분봉",
    provider_minute_plus_ws_tick: "공식 1분봉 + Toss polling tick",
    provider_daily: "Primary market data 공식 일봉",
    external_market_data_unconfigured: "외부 market data 미설정",
  };
  return value ? labels[value] ?? value : "-";
}

function formatStrategyCandleMode(value?: string | null) {
  const labels: Record<string, string> = {
    live_tick: "Toss polling 1분봉",
    live_tick_fallback: "Toss polling 1분봉 fallback",
    live_tick_warming: "Toss polling 1분봉 생성 중",
    official: "공식 1분봉",
    official_latest: "공식 최신 1분봉",
    official_warming: "공식 1분봉 확보 중",
    official_gap_fallback: "공식 1분봉 fallback",
  };
  return value ? labels[value] ?? value : "-";
}

function formatFreshness(value?: Freshness | null) {
  if (!value?.latest_korea_at) return "-";
  const age = value.age_sec == null ? "" : ` / ${formatAge(value.age_sec)}`;
  const state = value.is_stale ? " 지연" : value.is_caution ? " 주의" : "";
  return `${value.latest_korea_at}${age}${state}`;
}

function formatAge(seconds: number) {
  if (seconds < 60) return `${Math.round(seconds)}초 전`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}분 전`;
  return `${(seconds / 3600).toFixed(1)}시간 전`;
}

function formatDateTime(date?: string | null, time?: string | null) {
  const t = formatTime(time);
  if (!date || date.length !== 8) return t;
  return `${date.slice(4, 6)}/${date.slice(6, 8)} ${t}`;
}

function formatCandleDateTime(candle: Candle) {
  return formatDateTime(candle.korea_date ?? candle.market_date, candle.korea_time ?? candle.market_time);
}

function formatTime(value?: string | null) {
  if (!value) return "-";
  const padded = value.padStart(6, "0");
  return `${padded.slice(0, 2)}:${padded.slice(2, 4)}`;
}

function formatPrice(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "-";
  return number.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 4 });
}

function formatSignedPrice(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "-";
  return `${number > 0 ? "+" : ""}${formatPrice(number)}`;
}

function formatUsd(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "-";
  return `$${number.toLocaleString("en-US", { maximumFractionDigits: 2 })}`;
}

function formatNumber(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "-";
  return number.toLocaleString("en-US", { maximumFractionDigits: 4 });
}

function formatPercent(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "-";
  return `${number.toFixed(3)}%`;
}

function formatSignedPercent(value: unknown) {
  const number = toNumber(value);
  if (number == null) return "";
  return `(${number > 0 ? "+" : ""}${number.toFixed(2)}%)`;
}

function toNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value.replace(/,/g, ""));
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
