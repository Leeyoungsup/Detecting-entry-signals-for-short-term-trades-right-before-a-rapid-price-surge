from enum import StrEnum


class StatusLevel(StrEnum):
    NORMAL = "NORMAL"
    CAUTION = "CAUTION"
    BLOCKED = "BLOCKED"
    EMERGENCY = "EMERGENCY"


class TradingMode(StrEnum):
    RESEARCH = "research"
    BACKTEST = "backtest"
    INTERNAL_PAPER = "internal_paper"
    KIS_MOCK = "kis_mock"
    LIVE = "live"


class OrderState(StrEnum):
    CREATED = "CREATED"
    RISK_CHECKED = "RISK_CHECKED"
    SUBMITTED = "SUBMITTED"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    CANCELLED = "CANCELLED"
    REPLACE_REQUESTED = "REPLACE_REQUESTED"
    REPLACED = "REPLACED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"
    ERROR = "ERROR"
    UNKNOWN_RECONCILE_REQUIRED = "UNKNOWN_RECONCILE_REQUIRED"


class RealtimeEventType(StrEnum):
    SYSTEM_STATUS = "system.status"
    SCANNER_SNAPSHOT = "scanner.snapshot"
    SYMBOL_DETAIL = "symbol.detail"
    STRATEGY_SIGNAL = "strategy.signal"
    ORDER_EVENT = "order.event"
    FILL_EVENT = "fill.event"
    LOG_EVENT = "log.event"
    ALERT_EVENT = "alert.event"
