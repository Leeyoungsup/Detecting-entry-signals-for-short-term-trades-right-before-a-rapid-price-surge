from __future__ import annotations

from datetime import datetime, timezone
from threading import RLock
from uuid import uuid4

from app.adapters.toss.client import TossApiError, TossExecutionClient
from app.core.config import Settings, get_settings
from app.domain.enums import OrderState, StatusLevel
from app.domain.models import Fill, OrderEvent, OrderRequest, Position
from app.services import shared_state
from app.services.event_log import record_event
from app.services.fee_model import toss_fee_breakdown

LIVE_STATE_KEY = "trading_lab:live:state"
LIVE_ORDER_LOCK_KEY = "trading_lab:live:order_lock"

_orders: dict[str, dict] = {}
_positions: dict[str, Position] = {}
_timeline: list[OrderEvent] = []
_fills: list[Fill] = []
_closed_trades: list[dict] = []
_health: dict[str, object] = {"consecutive_errors": 0}
_emergency_stop = False
_shared_state_updated_at: str | None = None
_state_lock = RLock()

LIVE_OPEN_ORDER_STATES = {
    OrderState.CREATED,
    OrderState.RISK_CHECKED,
    OrderState.SUBMITTED,
    OrderState.ACKNOWLEDGED,
    OrderState.PARTIALLY_FILLED,
    OrderState.CANCEL_REQUESTED,
    OrderState.REPLACE_REQUESTED,
    OrderState.UNKNOWN_RECONCILE_REQUIRED,
}


class LiveBroker:
    """Toss live order ledger and reconciliation manager.

    This service only tracks orders submitted by this app. The command center can still
    read Toss holdings directly, but strategy duplicate-order checks use this ledger so
    replay/runtime and live execution have an auditable path.
    """

    def __init__(
        self,
        *,
        settings: Settings | None = None,
        client: TossExecutionClient | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        self.client = client or TossExecutionClient(self.settings)

    def state(self) -> dict:
        with _state_lock:
            _hydrate_state()
            return {
                "mode": "live",
                "paper_enabled": False,
                "auto_trade_enabled": bool(self.settings.toss_live_auto_trade_enabled),
                "emergency_stop": _emergency_stop,
                "health": dict(_health),
                "orders": [{**order, "state": str(order["state"])} for order in _orders.values()],
                "positions": [position.model_dump(mode="json") for position in _positions.values()],
                "timeline": [event.model_dump(mode="json") for event in _timeline[-300:]],
                "fills": [fill.model_dump(mode="json") for fill in _fills[-300:]],
                "closed_trades": _closed_trades[-300:],
                "updated_at": _shared_state_updated_at,
            }

    def reset(self) -> dict:
        with _state_lock:
            _hydrate_state()
            cleared = {
                "orders": len(_orders),
                "positions": len(_positions),
                "timeline": len(_timeline),
                "fills": len(_fills),
                "closed_trades": len(_closed_trades),
            }
            _orders.clear()
            _positions.clear()
            _timeline.clear()
            _fills.clear()
            _closed_trades.clear()
            _health.clear()
            _health.update({"consecutive_errors": 0})
            global _emergency_stop
            _emergency_stop = False
            _persist_state()
            record_event(
                level="WARNING",
                event_type="live.reset",
                message="Live order ledger was reset locally. Toss account state was not modified.",
                severity=StatusLevel.CAUTION,
                payload={"cleared": cleared},
            )
            return {"cleared": cleared}

    def has_exposure(self, symbol: str, parameter_set_id: str | None = None) -> bool:
        with _state_lock:
            _hydrate_state()
            symbol = symbol.upper()
            position_key = _position_key(symbol, parameter_set_id) if parameter_set_id else None
            if position_key and position_key in _positions and _positions[position_key].quantity > 0:
                return True
            if not position_key and any(position.symbol.upper() == symbol and position.quantity > 0 for position in _positions.values()):
                return True
            return any(
                str((order.get("request") or {}).get("symbol") or "").upper() == symbol
                and (not parameter_set_id or _order_parameter_set_id(order) == parameter_set_id)
                and order.get("state") in LIVE_OPEN_ORDER_STATES
                for order in _orders.values()
            )

    def position(self, symbol: str, position_key: str | None = None, parameter_set_id: str | None = None) -> Position | None:
        with _state_lock:
            _hydrate_state()
            if position_key:
                return _positions.get(position_key)
            if parameter_set_id:
                return _positions.get(_position_key(symbol, parameter_set_id))
            return next((position for position in _positions.values() if position.symbol.upper() == symbol.upper()), None)

    def positions_for_symbol(self, symbol: str) -> list[Position]:
        with _state_lock:
            _hydrate_state()
            return [position for position in _positions.values() if position.symbol.upper() == symbol.upper() and position.quantity > 0]

    def update_position(self, position: Position) -> None:
        with _state_lock:
            _hydrate_state()
            key = position.position_key or _position_key(position.symbol, position.parameter_set_id)
            if position.quantity <= 0:
                _positions.pop(key, None)
            else:
                position.position_key = key
                _positions[key] = position
            _persist_state()

    def submit_entry_order(
        self,
        *,
        symbol: str,
        quantity: float,
        market_snapshot: dict,
        strategy_signal_id: str | None = None,
    ) -> dict:
        return self._submit_live_order(
            symbol=symbol,
            side="buy",
            quantity=quantity,
            market_snapshot=market_snapshot,
            strategy_signal_id=strategy_signal_id,
            order_role="entry",
        )

    def submit_exit_order(
        self,
        *,
        position: Position,
        quantity: float,
        reason: str,
        market_snapshot: dict,
        strategy_signal_id: str | None = None,
    ) -> dict:
        market_snapshot = {
            **market_snapshot,
            "position_key": position.position_key,
            "exit_reason": reason,
            "strategy_name": position.strategy_name,
            "parameter_set_id": position.parameter_set_id,
            "entry_mode": position.entry_mode,
        }
        return self._submit_live_order(
            symbol=position.symbol,
            side="sell",
            quantity=min(quantity, position.quantity),
            market_snapshot=market_snapshot,
            strategy_signal_id=strategy_signal_id or f"live-exit-{reason}-{position.position_key}",
            order_role="exit",
            position_key=position.position_key,
            exit_reason=reason,
            allow_when_emergency_stopped=True,
        )

    def reconcile_open_orders(self, *, max_orders: int | None = None) -> dict:
        with _state_lock:
            _hydrate_state()
            order_ids = [
                order_id
                for order_id, order in _orders.items()
                if order.get("state") in LIVE_OPEN_ORDER_STATES
            ]
        limit = max_orders or int(self.settings.toss_live_reconcile_max_orders_per_tick or 20)
        checked = 0
        failed: list[dict] = []
        for order_id in order_ids[: max(1, limit)]:
            try:
                self.reconcile_order(order_id)
                checked += 1
            except TossApiError as exc:
                failed.append({"order_id": order_id, "error": str(exc), "status_code": exc.status_code})
                self._note_failure("reconcile_order", exc, order_id=order_id)
            except Exception as exc:
                failed.append({"order_id": order_id, "error": str(exc)})
                self._note_failure("reconcile_order", exc, order_id=order_id)
        return {
            "checked": checked,
            "failed": failed,
            "open_orders_before": len(order_ids),
            "updated_at": _utc_now().isoformat(),
        }

    def reconcile_order(self, order_id: str) -> dict:
        with _state_lock:
            _hydrate_state()
            order = _orders.get(order_id)
        if not order:
            raise TossApiError(f"Live order is not in the local ledger: {order_id}")
        detail = self.client.order_detail(order_id=order_id)
        with _state_lock:
            _hydrate_state()
            order = _orders.get(order_id)
            if not order:
                raise TossApiError(f"Live order disappeared from ledger during reconcile: {order_id}")
            previous_state = order.get("state")
            provider_status = str(detail.get("status") or "").upper()
            new_state = _state_from_provider_status(provider_status)
            _apply_execution_delta(order_id, order, detail)
            order["provider_status"] = provider_status
            order["provider_detail"] = detail
            order["filled_quantity"] = _execution_filled_quantity(detail)
            order["average_fill_price"] = _execution_average_price(detail)
            order["updated_at"] = _utc_now().isoformat()
            if previous_state != new_state:
                order["state"] = new_state
                _append_event(
                    order_id=order_id,
                    previous_state=previous_state,
                    new_state=new_state,
                    source="toss_reconcile",
                    message=f"Toss live order reconciled as {provider_status or new_state}.",
                    payload={"provider_status": provider_status, "detail": _compact_order_detail(detail)},
                )
            if self.settings.toss_live_cancel_stale_orders_enabled:
                self._cancel_stale_order_if_needed(order_id, order, provider_status)
            _note_success()
            _persist_state()
            return {**order, "state": str(order["state"])}

    def cancel_open_orders(self, *, reason: str = "manual_cancel") -> dict:
        with _state_lock:
            _hydrate_state()
            order_ids = [
                order_id
                for order_id, order in _orders.items()
                if order.get("state") in LIVE_OPEN_ORDER_STATES
            ]
        cancelled: list[str] = []
        failed: list[dict] = []
        for order_id in order_ids:
            try:
                self.cancel_order(order_id, reason=reason)
                cancelled.append(order_id)
            except TossApiError as exc:
                failed.append({"order_id": order_id, "error": str(exc), "status_code": exc.status_code})
                self._note_failure("cancel_order", exc, order_id=order_id)
        return {"requested": len(order_ids), "cancelled": cancelled, "failed": failed}

    def cancel_order(self, order_id: str, *, reason: str = "manual_cancel") -> dict:
        with _state_lock:
            _hydrate_state()
            order = _orders.get(order_id)
            previous_state = order.get("state") if order else None
            if order:
                order["state"] = OrderState.CANCEL_REQUESTED
                order["cancel_reason"] = reason
                order["updated_at"] = _utc_now().isoformat()
                _append_event(
                    order_id=order_id,
                    previous_state=previous_state,
                    new_state=OrderState.CANCEL_REQUESTED,
                    source="live_broker",
                    message=f"Live order cancel requested: {reason}",
                    payload={"reason": reason},
                )
                _persist_state()
        result = self.client.cancel_order(order_id=order_id)
        self.reconcile_order(order_id)
        return result

    def activate_emergency_stop(self, *, reason: str, liquidate: bool = False) -> dict:
        global _emergency_stop
        with _state_lock:
            _hydrate_state()
            _emergency_stop = True
            _health["emergency_reason"] = reason
            _health["emergency_at"] = _utc_now().isoformat()
            _persist_state()
        cancel_result = self.cancel_open_orders(reason=f"emergency_stop:{reason}")
        record_event(
            level="ERROR",
            event_type="live.emergency_stop",
            message="Live emergency stop activated. New entries are blocked and open orders were sent cancel requests.",
            severity=StatusLevel.EMERGENCY,
            payload={"reason": reason, "liquidate": liquidate, "cancel_result": cancel_result},
        )
        liquidation_result = None
        if liquidate:
            liquidation_result = self._liquidate_positions(reason=reason)
        return {
            "emergency_stop": True,
            "reason": reason,
            "cancel_result": cancel_result,
            "liquidation_result": liquidation_result,
        }

    def clear_emergency_stop(self) -> dict:
        global _emergency_stop
        with _state_lock:
            _hydrate_state()
            _emergency_stop = False
            _health["consecutive_errors"] = 0
            _health.pop("emergency_reason", None)
            _health.pop("emergency_at", None)
            _persist_state()
        record_event(
            level="WARNING",
            event_type="live.emergency_stop_cleared",
            message="Live emergency stop was cleared manually.",
            severity=StatusLevel.CAUTION,
        )
        return {"emergency_stop": False}

    def _submit_live_order(
        self,
        *,
        symbol: str,
        side: str,
        quantity: float,
        market_snapshot: dict,
        strategy_signal_id: str | None,
        order_role: str,
        position_key: str | None = None,
        exit_reason: str | None = None,
        allow_when_emergency_stopped: bool = False,
    ) -> dict:
        symbol = symbol.upper()
        side = side.lower()
        quantity = float(quantity or 0.0)
        parameter_set_id = str(market_snapshot.get("parameter_set_id") or _entry_parameter_set_id(market_snapshot) or "manual")
        if quantity <= 0:
            return self._blocked(symbol, side, "quantity_not_positive", market_snapshot)
        if side == "buy" and not self.settings.toss_live_auto_trade_enabled:
            return self._blocked(symbol, side, "live_auto_trade_disabled", market_snapshot)
        if not self.client.live_order_enabled():
            return self._blocked(symbol, side, "toss_live_order_disabled", market_snapshot)
        with _state_lock:
            _hydrate_state()
            if _emergency_stop and side == "buy" and not allow_when_emergency_stopped:
                return self._blocked(symbol, side, "emergency_stop_active", market_snapshot)
            if side == "buy" and self.has_exposure(symbol, parameter_set_id=parameter_set_id):
                return self._blocked(symbol, side, "duplicate_symbol_strategy_exposure", market_snapshot)
            risk_reject = _live_risk_reject_payload(
                settings=self.settings,
                symbol=symbol,
                side=side,
                quantity=quantity,
                market_snapshot=market_snapshot,
                parameter_set_id=parameter_set_id,
            )
            if risk_reject:
                return self._blocked(symbol, side, risk_reject["reason"], {**market_snapshot, "risk_reject": risk_reject})
        lock_key = f"{LIVE_ORDER_LOCK_KEY}:{symbol}:{side}:{parameter_set_id}"
        lock_id = shared_state.acquire_lock(lock_key, ttl_sec=10)
        if lock_id is None:
            return self._blocked(symbol, side, "live_order_lock_busy", market_snapshot)
        try:
            if side == "sell":
                sellable_reject = self._sellable_reject(symbol=symbol, quantity=quantity)
                if sellable_reject:
                    return self._blocked(symbol, side, sellable_reject["reason"], {**market_snapshot, "sellable_reject": sellable_reject})
            client_order_id = _client_order_id(symbol=symbol, side=side)
            request = OrderRequest(
                symbol=symbol,
                side=side,
                order_type="market",
                quantity=quantity,
                mode="live",
                strategy_signal_id=strategy_signal_id,
            )
            result = self.client.create_order(
                symbol=symbol,
                side=side,
                order_type="MARKET",
                quantity=quantity,
                client_order_id=client_order_id,
            )
            order_id = str(result.get("orderId") or client_order_id)
            now = _utc_now().isoformat()
            order = {
                "order_id": order_id,
                "client_order_id": client_order_id,
                "provider_order_id": result.get("orderId"),
                "request": request.model_dump(),
                "state": OrderState.ACKNOWLEDGED,
                "order_role": order_role,
                "position_key": position_key,
                "exit_reason": exit_reason,
                "market_snapshot": market_snapshot,
                "provider_response": result,
                "filled_quantity": 0.0,
                "filled_quantity_applied": 0.0,
                "filled_notional_applied": 0.0,
                "fees_applied_usd": 0.0,
                "created_at": now,
                "updated_at": now,
            }
            with _state_lock:
                _hydrate_state()
                _orders[order_id] = order
                for previous_state, new_state, source, message in (
                    (None, OrderState.CREATED, "live_broker", "Live order created locally."),
                    (OrderState.CREATED, OrderState.RISK_CHECKED, "risk_manager", "Live risk caps passed."),
                    (OrderState.RISK_CHECKED, OrderState.SUBMITTED, "toss_execution_gateway", "Live order submitted to Toss."),
                    (OrderState.SUBMITTED, OrderState.ACKNOWLEDGED, "toss_execution_gateway", "Toss acknowledged the live order."),
                ):
                    _append_event(
                        order_id=order_id,
                        previous_state=previous_state,
                        new_state=new_state,
                        source=source,
                        message=message,
                        payload={"request": request.model_dump(), "provider_response": result},
                    )
                _persist_state()
            record_event(
                level="WARNING",
                event_type="live.order_submitted",
                message=f"Live {side.upper()} order submitted to Toss.",
                severity=StatusLevel.CAUTION,
                symbol=symbol,
                order_id=order_id,
                payload={
                    "side": side,
                    "quantity": quantity,
                    "client_order_id": client_order_id,
                    "order_role": order_role,
                    "strategy_signal_id": strategy_signal_id,
                    "market_snapshot": _compact_market_snapshot(market_snapshot),
                },
            )
            try:
                return self.reconcile_order(order_id)
            except TossApiError as exc:
                self._note_failure("initial_reconcile", exc, order_id=order_id)
                return {**order, "state": str(order["state"]), "initial_reconcile_error": str(exc)}
        except TossApiError as exc:
            self._note_failure("submit_live_order", exc, symbol=symbol)
            raise
        finally:
            shared_state.release_lock(lock_key, lock_id)

    def _blocked(self, symbol: str, side: str, reason: str, payload: dict) -> dict:
        record_event(
            level="INFO",
            event_type="live.order_blocked",
            message=f"Live {side.upper()} order blocked: {reason}",
            severity=StatusLevel.BLOCKED,
            symbol=symbol,
            payload={"reason": reason, **_compact_market_snapshot(payload)},
        )
        return {"blocked": True, "reason": reason, "symbol": symbol, "side": side}

    def _sellable_reject(self, *, symbol: str, quantity: float) -> dict | None:
        try:
            payload = self.client.sellable_quantity(symbol=symbol)
        except TossApiError as exc:
            return {"reason": "sellable_quantity_unavailable", "error": str(exc), "status_code": exc.status_code}
        sellable = _extract_sellable_quantity(payload)
        if sellable is not None and sellable < quantity:
            return {"reason": "sellable_quantity_too_low", "sellable_quantity": sellable, "requested_quantity": quantity}
        return None

    def _cancel_stale_order_if_needed(self, order_id: str, order: dict, provider_status: str) -> None:
        if provider_status not in {"PENDING", "PARTIAL_FILLED"}:
            return
        max_age = float(self.settings.toss_live_pending_cancel_after_sec or 0.0)
        if max_age <= 0:
            return
        created_at = _parse_dt(order.get("created_at"))
        if created_at is None:
            return
        age = (_utc_now() - created_at).total_seconds()
        if age < max_age:
            return
        try:
            self.client.cancel_order(order_id=order_id)
            previous_state = order.get("state")
            order["state"] = OrderState.CANCEL_REQUESTED
            _append_event(
                order_id=order_id,
                previous_state=previous_state,
                new_state=OrderState.CANCEL_REQUESTED,
                source="live_broker",
                message="Stale live order cancel requested.",
                payload={"age_seconds": age, "provider_status": provider_status},
            )
        except TossApiError as exc:
            self._note_failure("cancel_stale_order", exc, order_id=order_id)

    def _liquidate_positions(self, *, reason: str) -> dict:
        with _state_lock:
            _hydrate_state()
            positions = [position for position in _positions.values() if position.quantity > 0]
        submitted: list[dict] = []
        failed: list[dict] = []
        for position in positions:
            try:
                submitted.append(
                    self.submit_exit_order(
                        position=position,
                        quantity=position.quantity,
                        reason=f"emergency_stop:{reason}",
                        market_snapshot={"source": "live_emergency_stop", "position_key": position.position_key},
                    )
                )
            except Exception as exc:
                failed.append({"position_key": position.position_key, "symbol": position.symbol, "error": str(exc)})
                self._note_failure("emergency_liquidation", exc, symbol=position.symbol)
        return {"submitted": submitted, "failed": failed}

    def _note_failure(self, operation: str, exc: Exception, *, symbol: str | None = None, order_id: str | None = None) -> None:
        with _state_lock:
            _hydrate_state()
            consecutive = int(_health.get("consecutive_errors") or 0) + 1
            _health["consecutive_errors"] = consecutive
            _health["last_error"] = str(exc)[:500]
            _health["last_error_operation"] = operation
            _health["last_error_at"] = _utc_now().isoformat()
            _persist_state()
        record_event(
            level="ERROR",
            event_type="live.reconcile_failed" if "reconcile" in operation else "live.order_error",
            message=f"Live broker operation failed: {operation}",
            severity=StatusLevel.EMERGENCY if consecutive >= self.settings.toss_live_emergency_stop_error_threshold else StatusLevel.BLOCKED,
            symbol=symbol,
            order_id=order_id,
            payload={"operation": operation, "error": str(exc)[:500], "consecutive_errors": consecutive},
        )
        if self.settings.toss_live_emergency_stop_enabled and consecutive >= self.settings.toss_live_emergency_stop_error_threshold:
            self.activate_emergency_stop(reason=f"{operation}_errors")


def _apply_execution_delta(order_id: str, order: dict, detail: dict) -> None:
    filled_quantity = _execution_filled_quantity(detail)
    average_price = _execution_average_price(detail)
    if filled_quantity <= 0 or average_price is None or average_price <= 0:
        return
    already_applied = float(order.get("filled_quantity_applied") or 0.0)
    delta_quantity = filled_quantity - already_applied
    if delta_quantity <= 1e-9:
        return
    cumulative_notional = filled_quantity * average_price
    already_notional = float(order.get("filled_notional_applied") or 0.0)
    delta_notional = max(0.0, cumulative_notional - already_notional)
    delta_price = delta_notional / delta_quantity if delta_quantity > 0 and delta_notional > 0 else average_price
    cumulative_fees = _execution_fees(detail)
    fees_applied = float(order.get("fees_applied_usd") or 0.0)
    delta_fees = max(0.0, cumulative_fees - fees_applied)
    if delta_fees <= 0:
        fee_breakdown = toss_fee_breakdown(
            side=str((order.get("request") or {}).get("side") or "buy"),
            quantity=delta_quantity,
            price=delta_price,
        )
        delta_fees = float(fee_breakdown["total_fees_usd"])
    else:
        fee_breakdown = {
            "notional_usd": delta_notional,
            "commission_usd": _execution_commission(detail),
            "regulatory_fee_usd": _execution_tax(detail),
            "total_fees_usd": delta_fees,
            "model": "toss_reported_delta",
        }
    request = OrderRequest.model_validate(order["request"])
    fill = Fill(
        order_id=order_id,
        symbol=request.symbol,
        side=request.side.lower(),
        quantity=delta_quantity,
        price=delta_price,
        broker_fill_id=f"toss-{order_id[:8]}-{filled_quantity:g}",
    )
    _fills.append(fill)
    _apply_fill(fill, request=request, market_snapshot=order.get("market_snapshot") or {}, fee_breakdown=fee_breakdown)
    order["filled_quantity_applied"] = filled_quantity
    order["filled_notional_applied"] = cumulative_notional
    order["fees_applied_usd"] = fees_applied + delta_fees
    _append_event(
        order_id=order_id,
        previous_state=order.get("state"),
        new_state=OrderState.PARTIALLY_FILLED if str(detail.get("status") or "").upper() == "PARTIAL_FILLED" else OrderState.FILLED,
        source="toss_fill_reconcile",
        message="Toss live fill applied to the local ledger.",
        payload={
            "fill": fill.model_dump(),
            "fee_breakdown": fee_breakdown,
            "provider_status": detail.get("status"),
        },
    )
    record_event(
        level="WARNING",
        event_type="live.fill",
        message=f"Live {request.side.upper()} fill reconciled.",
        severity=StatusLevel.CAUTION,
        symbol=request.symbol,
        order_id=order_id,
        payload={"fill": fill.model_dump(), "fee_breakdown": fee_breakdown, "detail": _compact_order_detail(detail)},
    )


def _apply_fill(fill: Fill, *, request: OrderRequest, market_snapshot: dict, fee_breakdown: dict) -> None:
    if fill.side == "sell":
        position_key = _market_position_key(fill.symbol, market_snapshot)
        existing = _positions.get(position_key)
        if not existing:
            return
        remaining = existing.quantity - fill.quantity
        close_ratio = min(1.0, fill.quantity / existing.quantity) if existing.quantity > 0 else 1.0
        gross_pnl = (fill.price - existing.average_price) * fill.quantity
        allocated_entry_fees = existing.entry_fees_usd * close_ratio
        exit_fees = float(fee_breakdown.get("total_fees_usd") or 0.0)
        net_pnl = gross_pnl - allocated_entry_fees - exit_fees
        _closed_trades.append(
            {
                "symbol": fill.symbol,
                "position_key": existing.position_key,
                "strategy_name": existing.strategy_name,
                "parameter_set_id": existing.parameter_set_id,
                "entry_mode": existing.entry_mode,
                "quantity": fill.quantity,
                "entry_price": existing.average_price,
                "exit_price": fill.price,
                "gross_pnl_usd": gross_pnl,
                "entry_fees_usd": allocated_entry_fees,
                "exit_fees_usd": exit_fees,
                "fees_usd": allocated_entry_fees + exit_fees,
                "net_pnl_usd": net_pnl,
                "fee_breakdown": {"entry_allocated_usd": allocated_entry_fees, "exit": fee_breakdown},
                "exit_reason": market_snapshot.get("exit_reason") or request.strategy_signal_id,
                "entry_snapshot": existing.entry_snapshot,
                "exit_snapshot": _compact_exit_snapshot(market_snapshot),
                "closed_at": _utc_now().isoformat(),
                "mode": "live",
            }
        )
        if remaining <= 0:
            _positions.pop(position_key, None)
        else:
            _positions[position_key] = existing.model_copy(
                update={
                    "quantity": remaining,
                    "entry_fees_usd": max(0.0, existing.entry_fees_usd - allocated_entry_fees),
                }
            )
        record_event(
            level="WARNING",
            event_type="live.position_closed" if remaining <= 0 else "live.position_reduced",
            message="Live position was updated by a sell fill.",
            severity=StatusLevel.CAUTION,
            symbol=fill.symbol,
            order_id=fill.order_id,
            payload={"position_key": position_key, "remaining_quantity": max(0.0, remaining), "closed_trade": _closed_trades[-1]},
        )
        return

    exit_plan = market_snapshot.get("exit_plan") if isinstance(market_snapshot.get("exit_plan"), dict) else {}
    stop_loss_price = _to_float(exit_plan.get("stop_loss_price")) or fill.price * 0.995
    take_profit_price = _to_float(exit_plan.get("take_profit_price")) or fill.price * 1.008
    dynamic_take_profit_price = _to_float(exit_plan.get("dynamic_take_profit_price")) or take_profit_price
    partial_take_profit_price = _to_float(exit_plan.get("partial_take_profit_price")) or fill.price * 1.004
    trailing_activation_price = _to_float(exit_plan.get("trailing_activation_price")) or fill.price * 1.003
    trailing_stop_price = _to_float(exit_plan.get("trailing_stop_price"))
    entry_snapshot = _compact_entry_snapshot(market_snapshot)
    parameter_set_id = entry_snapshot.get("parameter_set_id") or request.strategy_signal_id or "manual"
    position_key = _position_key(fill.symbol, str(parameter_set_id))
    entry_fees = float(fee_breakdown.get("total_fees_usd") or 0.0)
    existing = _positions.get(position_key)
    if not existing:
        _positions[position_key] = Position(
            position_key=position_key,
            symbol=fill.symbol,
            strategy_name=entry_snapshot.get("strategy_name"),
            parameter_set_id=str(parameter_set_id),
            entry_mode=entry_snapshot.get("entry_mode"),
            quantity=fill.quantity,
            average_price=fill.price,
            entry_fees_usd=entry_fees,
            mode="live",
            opened_at=_utc_now(),
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            dynamic_take_profit_price=dynamic_take_profit_price,
            dynamic_take_profit_reason="entry_plan",
            dynamic_take_profit_updated_at=_utc_now(),
            partial_take_profit_price=partial_take_profit_price,
            trailing_stop_price=trailing_stop_price,
            trailing_activation_price=trailing_activation_price,
            high_watermark=fill.price,
            exit_plan=exit_plan,
            entry_snapshot=entry_snapshot,
        )
    else:
        total_quantity = existing.quantity + fill.quantity
        average_price = ((existing.average_price * existing.quantity) + (fill.price * fill.quantity)) / total_quantity
        _positions[position_key] = existing.model_copy(
            update={
                "quantity": total_quantity,
                "average_price": average_price,
                "entry_fees_usd": existing.entry_fees_usd + entry_fees,
                "stop_loss_price": min(existing.stop_loss_price or stop_loss_price, stop_loss_price),
                "take_profit_price": max(existing.take_profit_price or take_profit_price, take_profit_price),
                "dynamic_take_profit_price": max(existing.dynamic_take_profit_price or dynamic_take_profit_price, dynamic_take_profit_price),
                "high_watermark": max(existing.high_watermark or average_price, fill.price),
            }
        )
    record_event(
        level="WARNING",
        event_type="live.position_opened",
        message="Live position was opened or increased by a buy fill.",
        severity=StatusLevel.CAUTION,
        symbol=fill.symbol,
        order_id=fill.order_id,
        payload={"position": _positions[position_key].model_dump(mode="json"), "fee_breakdown": fee_breakdown},
    )


def _live_risk_reject_payload(
    *,
    settings: Settings,
    symbol: str,
    side: str,
    quantity: float,
    market_snapshot: dict,
    parameter_set_id: str,
) -> dict | None:
    if side != "buy":
        return None
    price = _order_reference_price(market_snapshot)
    notional = max(0.0, quantity) * max(0.0, price)
    if quantity > float(settings.toss_live_max_quantity or 0.0):
        return {"reason": "max_quantity_exceeded", "quantity": quantity, "max_quantity": settings.toss_live_max_quantity}
    if settings.toss_live_max_order_notional_usd > 0 and notional > settings.toss_live_max_order_notional_usd:
        return {
            "reason": "max_order_notional_exceeded",
            "notional_usd": notional,
            "max_order_notional_usd": settings.toss_live_max_order_notional_usd,
        }
    position_key = _position_key(symbol, parameter_set_id)
    creates_new_position = position_key not in _positions or _positions[position_key].quantity <= 0
    open_positions = [position for position in _positions.values() if position.quantity > 0]
    if creates_new_position and len(open_positions) >= int(settings.toss_live_max_open_positions or 1):
        return {
            "reason": "max_open_positions_exceeded",
            "open_positions": len(open_positions),
            "max_open_positions": settings.toss_live_max_open_positions,
        }
    current_exposure = _total_exposure_usd(open_positions) + _open_buy_order_exposure_usd()
    projected_exposure = current_exposure + notional
    if settings.toss_live_max_total_exposure_usd > 0 and projected_exposure > settings.toss_live_max_total_exposure_usd:
        return {
            "reason": "max_total_exposure_exceeded",
            "current_exposure_usd": round(current_exposure, 4),
            "order_notional_usd": round(notional, 4),
            "projected_exposure_usd": round(projected_exposure, 4),
            "max_total_exposure_usd": settings.toss_live_max_total_exposure_usd,
        }
    return None


def _append_event(
    *,
    order_id: str,
    previous_state: OrderState | None,
    new_state: OrderState,
    source: str,
    message: str,
    payload: dict | None = None,
) -> None:
    event = OrderEvent(
        order_id=order_id,
        previous_state=previous_state,
        new_state=new_state,
        source=source,
        message=message,
        payload=payload or {},
    )
    _timeline.append(event)
    request = (_orders.get(order_id) or {}).get("request") or {}
    symbol = request.get("symbol")
    record_event(
        level="INFO",
        event_type="live.order_event",
        message=message,
        severity=StatusLevel.BLOCKED if new_state in {OrderState.REJECTED, OrderState.ERROR} else StatusLevel.NORMAL,
        symbol=symbol,
        order_id=order_id,
        payload=event.model_dump(mode="json"),
    )


def _state_from_provider_status(status: str) -> OrderState:
    status = status.upper()
    if status == "PENDING":
        return OrderState.ACKNOWLEDGED
    if status == "PARTIAL_FILLED":
        return OrderState.PARTIALLY_FILLED
    if status == "PENDING_CANCEL":
        return OrderState.CANCEL_REQUESTED
    if status == "PENDING_REPLACE":
        return OrderState.REPLACE_REQUESTED
    if status == "FILLED":
        return OrderState.FILLED
    if status == "CANCELED":
        return OrderState.CANCELLED
    if status == "REJECTED":
        return OrderState.REJECTED
    if status == "REPLACED":
        return OrderState.REPLACED
    if status in {"CANCEL_REJECTED", "REPLACE_REJECTED"}:
        return OrderState.UNKNOWN_RECONCILE_REQUIRED
    return OrderState.UNKNOWN_RECONCILE_REQUIRED


def _execution(detail: dict) -> dict:
    execution = detail.get("execution")
    return execution if isinstance(execution, dict) else detail


def _execution_filled_quantity(detail: dict) -> float:
    return _to_float(_execution(detail).get("filledQuantity") or detail.get("filledQuantity")) or 0.0


def _execution_average_price(detail: dict) -> float | None:
    return _to_float(_execution(detail).get("averageFilledPrice") or detail.get("averageFilledPrice"))


def _execution_commission(detail: dict) -> float:
    return _to_float(_execution(detail).get("commission") or detail.get("commission")) or 0.0


def _execution_tax(detail: dict) -> float:
    return _to_float(_execution(detail).get("tax") or detail.get("tax")) or 0.0


def _execution_fees(detail: dict) -> float:
    return _execution_commission(detail) + _execution_tax(detail)


def _extract_sellable_quantity(payload: object) -> float | None:
    if isinstance(payload, dict):
        for key in ("sellableQuantity", "quantity", "availableQuantity", "qty"):
            value = _to_float(payload.get(key))
            if value is not None:
                return value
        rows = payload.get("items") or payload.get("stocks") or payload.get("holdings")
        if isinstance(rows, list) and rows:
            return _extract_sellable_quantity(rows[0])
    return None


def _position_key(symbol: str, parameter_set_id: str | None) -> str:
    return f"{symbol.upper()}::{str(parameter_set_id or 'manual').strip() or 'manual'}"


def _market_position_key(symbol: str, market_snapshot: dict) -> str:
    key = market_snapshot.get("position_key")
    if key:
        return str(key)
    parameter_set_id = market_snapshot.get("parameter_set_id") or _entry_parameter_set_id(market_snapshot)
    return _position_key(symbol, str(parameter_set_id or "manual"))


def _entry_parameter_set_id(market_snapshot: dict) -> str | None:
    entry_snapshot = market_snapshot.get("entry_snapshot")
    if isinstance(entry_snapshot, dict) and entry_snapshot.get("parameter_set_id"):
        return str(entry_snapshot.get("parameter_set_id"))
    return None


def _order_parameter_set_id(order: dict) -> str | None:
    market_snapshot = order.get("market_snapshot") or {}
    if market_snapshot.get("parameter_set_id"):
        return str(market_snapshot.get("parameter_set_id"))
    return _entry_parameter_set_id(market_snapshot)


def _order_reference_price(market_snapshot: dict) -> float:
    return (
        _to_float(market_snapshot.get("ask"))
        or _to_float(market_snapshot.get("last"))
        or _to_float(market_snapshot.get("bid"))
        or _to_float(market_snapshot.get("strategy_reference_price"))
        or _to_float(market_snapshot.get("execution_price"))
        or 0.0
    )


def _total_exposure_usd(positions: list[Position]) -> float:
    return sum(max(0.0, position.quantity) * max(0.0, position.average_price) for position in positions)


def _open_buy_order_exposure_usd() -> float:
    total = 0.0
    for order in _orders.values():
        if order.get("state") not in LIVE_OPEN_ORDER_STATES:
            continue
        request = order.get("request") or {}
        if str(request.get("side") or "").lower() != "buy":
            continue
        remaining = max(0.0, float(request.get("quantity") or 0.0) - float(order.get("filled_quantity_applied") or 0.0))
        total += remaining * _order_reference_price(order.get("market_snapshot") or {})
    return total


def _client_order_id(*, symbol: str, side: str) -> str:
    return f"la-{side[:1]}-{symbol[:6]}-{uuid4().hex[:20]}"


def _compact_market_snapshot(snapshot: dict) -> dict:
    keep = {
        "bucket",
        "symbol",
        "bid",
        "ask",
        "last",
        "spread_pct",
        "source",
        "strategy_name",
        "parameter_set_id",
        "entry_mode",
        "execution_price",
        "strategy_reference_price",
        "exit_reason",
        "risk_reject",
        "sellable_reject",
    }
    return {key: snapshot.get(key) for key in keep if key in snapshot}


def _compact_order_detail(detail: dict) -> dict:
    execution = _execution(detail)
    return {
        "orderId": detail.get("orderId"),
        "symbol": detail.get("symbol"),
        "side": detail.get("side"),
        "status": detail.get("status"),
        "quantity": detail.get("quantity"),
        "orderedAt": detail.get("orderedAt"),
        "canceledAt": detail.get("canceledAt"),
        "execution": {
            "filledQuantity": execution.get("filledQuantity"),
            "averageFilledPrice": execution.get("averageFilledPrice"),
            "filledAmount": execution.get("filledAmount"),
            "commission": execution.get("commission"),
            "tax": execution.get("tax"),
            "filledAt": execution.get("filledAt"),
            "settlementDate": execution.get("settlementDate"),
        },
    }


def _compact_entry_snapshot(market_snapshot: dict) -> dict:
    snapshot = market_snapshot.get("entry_snapshot")
    if isinstance(snapshot, dict):
        return snapshot
    return {
        "strategy_name": market_snapshot.get("strategy_name"),
        "parameter_set_id": market_snapshot.get("parameter_set_id"),
        "entry_mode": market_snapshot.get("entry_mode"),
        "price": market_snapshot.get("strategy_reference_price") or market_snapshot.get("last"),
        "execution_price_source": market_snapshot.get("execution_price_source") or market_snapshot.get("source"),
        "bid": market_snapshot.get("bid"),
        "ask": market_snapshot.get("ask"),
        "spread_pct": market_snapshot.get("spread_pct"),
        "risk_preview": market_snapshot.get("risk_preview"),
        "exit_plan": market_snapshot.get("exit_plan"),
    }


def _compact_exit_snapshot(market_snapshot: dict) -> dict:
    snapshot = market_snapshot.get("exit_snapshot")
    if isinstance(snapshot, dict):
        return snapshot
    return {
        "reason": market_snapshot.get("exit_reason"),
        "price": market_snapshot.get("strategy_reference_last") or market_snapshot.get("last"),
        "bid": market_snapshot.get("strategy_reference_bid") or market_snapshot.get("bid"),
        "ask": market_snapshot.get("strategy_reference_ask") or market_snapshot.get("ask"),
        "spread_pct": market_snapshot.get("strategy_reference_spread_pct") or market_snapshot.get("spread_pct"),
        "execution_price_source": market_snapshot.get("execution_price_source") or market_snapshot.get("source"),
        "indicators": market_snapshot.get("exit_indicators"),
    }


def _to_float(value: object) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_dt(value: object) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _note_success() -> None:
    _health["consecutive_errors"] = 0
    _health["last_success_at"] = _utc_now().isoformat()


def _persist_state() -> None:
    global _shared_state_updated_at
    _shared_state_updated_at = _utc_now().isoformat()
    shared_state.set_json(
        LIVE_STATE_KEY,
        {
            "updated_at": _shared_state_updated_at,
            "emergency_stop": _emergency_stop,
            "health": dict(_health),
            "orders": [{**order, "state": str(order["state"])} for order in _orders.values()],
            "positions": [position.model_dump(mode="json") for position in _positions.values()],
            "timeline": [event.model_dump(mode="json") for event in _timeline[-500:]],
            "fills": [fill.model_dump(mode="json") for fill in _fills[-500:]],
            "closed_trades": _closed_trades[-500:],
        },
        ex=86400,
    )


def _hydrate_state() -> None:
    global _shared_state_updated_at, _emergency_stop
    payload = shared_state.get_json(LIVE_STATE_KEY)
    if not isinstance(payload, dict):
        return
    updated_at = str(payload.get("updated_at") or "")
    if updated_at and updated_at == _shared_state_updated_at:
        return
    if not updated_at and (_orders or _positions or _timeline or _fills or _closed_trades):
        return
    _orders.clear()
    _positions.clear()
    _timeline.clear()
    _fills.clear()
    _closed_trades.clear()
    for row in payload.get("orders") or []:
        if not isinstance(row, dict) or not row.get("order_id"):
            continue
        try:
            row["state"] = OrderState(str(row.get("state")))
        except Exception:
            row["state"] = OrderState.UNKNOWN_RECONCILE_REQUIRED
        _orders[str(row["order_id"])] = row
    for row in payload.get("positions") or []:
        try:
            position = Position.model_validate(row)
        except Exception:
            continue
        key = position.position_key or _position_key(position.symbol, position.parameter_set_id)
        position.position_key = key
        _positions[key] = position
    for row in payload.get("timeline") or []:
        try:
            _timeline.append(OrderEvent.model_validate(row))
        except Exception:
            continue
    for row in payload.get("fills") or []:
        try:
            _fills.append(Fill.model_validate(row))
        except Exception:
            continue
    for row in payload.get("closed_trades") or []:
        if isinstance(row, dict):
            _closed_trades.append(row)
    _health.clear()
    _health.update(payload.get("health") if isinstance(payload.get("health"), dict) else {"consecutive_errors": 0})
    _emergency_stop = bool(payload.get("emergency_stop"))
    _shared_state_updated_at = updated_at or _shared_state_updated_at
