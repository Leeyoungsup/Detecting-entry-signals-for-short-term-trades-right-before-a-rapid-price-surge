"use client";

import {
  AlertTriangle,
  BarChart3,
  ClipboardList,
  FileText,
  FlaskConical,
  Gauge,
  LineChart,
  ListFilter,
  Moon,
  Settings,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";

const nav = [
  { href: "/", label: "운영 센터", icon: Gauge },
  { href: "/scanner", label: "스캐너 퍼널", icon: ListFilter },
  { href: "/symbols", label: "종목 목록", icon: LineChart },
  { href: "/strategies", label: "전략 모니터", icon: BarChart3 },
  { href: "/backtests", label: "전략 테스트", icon: FlaskConical },
  { href: "/orders", label: "주문 타임라인", icon: ClipboardList },
  { href: "/logs", label: "로그 탐색기", icon: FileText },
  { href: "/settings", label: "설정", icon: Settings },
];

function isActive(pathname: string, href: string) {
  return href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname() ?? "/";
  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 hidden w-[17rem] overflow-hidden border-r border-slate-800 bg-gradient-to-b from-[#1c2647] via-[#111a30] to-[#070b16] text-slate-200 shadow-soft lg:block">
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-56 bg-[radial-gradient(70%_80%_at_28%_0%,rgba(99,102,241,0.22),transparent_70%)]"
          aria-hidden
        />
        <div className="relative flex h-20 items-center gap-3 border-b border-white/10 px-5">
          <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-to-br from-indigo-500/25 to-blue-500/10 text-indigo-200 ring-1 ring-indigo-400/25">
            <Moon className="h-5 w-5" aria-hidden />
          </div>
          <div>
            <div className="text-base font-bold tracking-tight text-white">Nocturne</div>
            <div className="mt-0.5 text-xs text-slate-400">US Intraday Desk</div>
          </div>
        </div>
        <nav className="relative space-y-1 p-3">
          {nav.map((item) => {
            const Icon = item.icon;
            const active = isActive(pathname, item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                prefetch={false}
                aria-current={active ? "page" : undefined}
                className={`group relative flex items-center gap-3 rounded px-3 py-2.5 text-sm font-medium transition ${
                  active ? "bg-white/10 text-white" : "text-slate-300 hover:bg-white/5 hover:text-white"
                }`}
              >
                {active ? <span className="absolute inset-y-1.5 left-0 w-0.5 rounded-full bg-indigo-400" aria-hidden /> : null}
                <span
                  className={`grid h-8 w-8 place-items-center rounded ring-1 transition ${
                    active
                      ? "bg-indigo-500/20 text-indigo-200 ring-indigo-400/30"
                      : "bg-white/5 text-slate-400 ring-white/5 group-hover:bg-blue-500/15 group-hover:text-blue-200 group-hover:ring-blue-400/25"
                  }`}
                >
                  <Icon className="h-4 w-4" aria-hidden />
                </span>
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="absolute bottom-0 left-0 right-0 border-t border-white/10 p-4 text-xs text-slate-400">
          <div className="rounded border border-amber-400/25 bg-amber-500/10 p-3">
            <div className="flex items-center gap-2 font-semibold text-amber-100">
              <AlertTriangle className="h-4 w-4" aria-hidden />
              Live 자동 주문 활성
            </div>
            <div className="mt-2 leading-5 text-slate-400">Toss live 계좌 기준, cap/emergency stop 적용</div>
          </div>
        </div>
      </aside>
      <div className="lg:pl-[17rem]">
        <header className="sticky top-0 z-20 border-b border-line bg-white/90 px-4 py-3 backdrop-blur lg:hidden">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-indigo-100 to-blue-50 text-indigo-600 ring-1 ring-indigo-100">
              <Moon className="h-5 w-5" aria-hidden />
            </div>
            <div>
              <div className="text-sm font-bold tracking-tight text-ink">Nocturne</div>
              <div className="text-xs text-zinc-500">US Intraday Desk</div>
            </div>
          </div>
          <nav className="mt-3 flex gap-2 overflow-x-auto pb-1">
            {nav.map((item) => {
              const Icon = item.icon;
              const active = isActive(pathname, item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  prefetch={false}
                  aria-current={active ? "page" : undefined}
                  className={`inline-flex h-9 shrink-0 items-center gap-2 rounded border px-3 text-xs font-semibold transition ${
                    active
                      ? "border-indigo-200 bg-indigo-50 text-indigo-700"
                      : "border-line bg-white text-zinc-700 hover:bg-zinc-50"
                  }`}
                >
                  <Icon className="h-4 w-4" aria-hidden />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </header>
        <main>{children}</main>
      </div>
    </div>
  );
}
