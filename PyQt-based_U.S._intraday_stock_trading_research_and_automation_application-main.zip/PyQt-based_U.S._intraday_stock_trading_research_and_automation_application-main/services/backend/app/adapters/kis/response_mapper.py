def map_kis_response(_: dict) -> dict:
    return {
        "TODO_KIS_VERIFY": (
            "Map only after official KIS response fields are verified. Raw responses must stay inside adapter."
        )
    }
