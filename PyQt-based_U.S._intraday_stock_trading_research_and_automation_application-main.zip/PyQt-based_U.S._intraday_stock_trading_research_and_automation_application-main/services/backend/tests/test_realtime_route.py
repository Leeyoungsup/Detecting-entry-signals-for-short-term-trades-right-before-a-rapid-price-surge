from app.api.routes import realtime
from app.domain.enums import RealtimeEventType, StatusLevel


def test_shared_system_status_event_uses_runtime_payload(monkeypatch) -> None:
    payload = {
        "status_level": "CAUTION",
        "trading_mode": "internal_paper",
        "message": "watching data freshness",
    }
    monkeypatch.setattr(realtime.shared_state, "get_json_any", lambda *keys: payload)

    event = realtime._shared_system_status_event()

    assert event.event_type == RealtimeEventType.SYSTEM_STATUS
    assert event.status_level == StatusLevel.CAUTION
    assert event.mode == "internal_paper"
    assert event.payload == payload


def test_shared_system_status_event_falls_back_to_heartbeat(monkeypatch) -> None:
    monkeypatch.setattr(realtime.shared_state, "get_json_any", lambda *keys: None)

    event = realtime._shared_system_status_event()

    assert event.event_type == RealtimeEventType.SYSTEM_STATUS
    assert event.status_level == StatusLevel.NORMAL
    assert event.payload["message"] == "Realtime stream heartbeat."
