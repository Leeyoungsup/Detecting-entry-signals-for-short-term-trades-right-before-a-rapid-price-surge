import clsx from "clsx";

type Status = "NORMAL" | "CAUTION" | "BLOCKED" | "EMERGENCY" | string;

const statusLabels: Record<string, string> = {
  NORMAL: "정상",
  CAUTION: "주의",
  BLOCKED: "차단",
  EMERGENCY: "긴급",
};

export function StatusPill({ status }: { status: Status }) {
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1.5 rounded px-2.5 py-1 text-xs font-semibold",
        status === "NORMAL" && "bg-emerald-50 text-ok ring-1 ring-emerald-200",
        status === "CAUTION" && "bg-amber-50 text-warn ring-1 ring-amber-200",
        status === "BLOCKED" && "bg-red-50 text-block ring-1 ring-red-200",
        status === "EMERGENCY" && "bg-red-100 text-block ring-2 ring-red-300",
        !["NORMAL", "CAUTION", "BLOCKED", "EMERGENCY"].includes(status) &&
          "bg-zinc-100 text-zinc-700 ring-1 ring-zinc-200",
      )}
    >
      <span
        className={clsx(
          "h-1.5 w-1.5 rounded-full",
          status === "NORMAL" && "bg-ok",
          status === "CAUTION" && "bg-warn",
          status === "BLOCKED" && "bg-block",
          status === "EMERGENCY" && "bg-block",
          !["NORMAL", "CAUTION", "BLOCKED", "EMERGENCY"].includes(status) && "bg-zinc-400",
        )}
      />
      {statusLabels[status] ?? status}
    </span>
  );
}
