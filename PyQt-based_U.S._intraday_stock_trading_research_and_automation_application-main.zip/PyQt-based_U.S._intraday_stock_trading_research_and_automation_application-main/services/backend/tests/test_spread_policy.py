from app.services import scanner
from app.services import strategy_engine
from app.services import strategy_runtime


def test_scanner_dynamic_spread_limit_expands_with_liquidity() -> None:
    low_liquidity = {
        "notional_1m": 2_000,
        "notional_10m": 9_000,
        "volume_velocity_10s": 1.0,
        "change_1m_pct": 0.1,
        "change_10m_pct": 0.2,
    }
    high_liquidity = {
        "notional_1m": 75_000,
        "notional_10m": 300_000,
        "volume_velocity_10s": 2.1,
        "change_1m_pct": 0.9,
        "change_10m_pct": 2.2,
    }

    assert scanner._dynamic_spread_limit(low_liquidity) <= 0.60
    assert scanner._dynamic_spread_limit(high_liquidity) == 1.20


def test_scanner_toss_spread_over_limit_is_warning_not_strategy_block(monkeypatch) -> None:
    def fake_quote(symbol: str, *, max_cache_age_sec: float = 0.5) -> dict:
        return {"symbol": symbol, "bid": 9.95, "ask": 10.05, "spread_pct": 1.30, "source": "test"}

    monkeypatch.setattr(scanner, "execution_quote_snapshot", fake_quote)
    data = {
        "symbol": "WIDE",
        "spread_pct": 1.00,
        "notional_1m": 75_000,
        "notional_10m": 300_000,
        "volume_velocity_10s": 2.1,
        "change_1m_pct": 0.9,
        "change_10m_pct": 2.2,
    }

    passed, note = scanner._apply_toss_spread_verification(data)

    assert passed is True
    assert "경고" in str(note)
    assert data["spread_pct"] == 1.30
    assert data["execution_spread_source"] == "toss_orderbook_quote"


def test_entry_spread_limit_expands_to_one_point_two_with_liquidity() -> None:
    flow = {
        "notional_1m": 75_000,
        "notional_10m": 300_000,
        "volume_velocity_10s": 2.1,
        "trade_strength": 82.0,
        "sell_pressure": 0.30,
    }

    limit = strategy_runtime._liquidity_adjusted_entry_spread_limit(base=0.60, flow=flow, final_score=86.0)

    assert limit == 1.20


def test_strategy_spread_gate_is_price_aware_matching_replay() -> None:
    # Replay-aligned price-aware cap: 1.25% under $2, 0.85% at/above $2. A single
    # tick on a low-priced stock is a large %, so the low-priced cap is looser.
    assert strategy_engine._max_spread_pct_for_flow({"last_price": 1.50}) == 1.25
    assert strategy_engine._max_spread_pct_for_flow({"last_price": 8.00}) == 0.85
    assert strategy_engine._max_spread_pct_for_flow({"trade": {"last": 1.20}}) == 1.25
    # Runtime order-submission gate uses the same price-aware cap.
    assert strategy_runtime._max_entry_spread_pct(last_price=1.19) == 1.25
    assert strategy_runtime._max_entry_spread_pct(last_price=12.26) == 0.85
