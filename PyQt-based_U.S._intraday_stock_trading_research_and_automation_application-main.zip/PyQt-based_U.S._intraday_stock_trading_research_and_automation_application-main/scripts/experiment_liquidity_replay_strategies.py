"""Replay-only experiment for liquidity-led intraday strategies.

This script does not change the active replay/runtime strategy set. It imports
the existing conservative replay engine, swaps in experimental liquidity
strategies, and writes separate experiment artifacts.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ENGINE_PATH = PROJECT_ROOT / "scripts" / "replay_tc_shadow_strategies.py"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "exports" / "strategy_replay" / "liquidity_experiment"

FILENAME_RE = re.compile(
    r"^(?P<symbol>[a-z0-9]+)_(?P<date>\d{4}-\d{2}-\d{2})_(?P<timerange>\d{4}-\d{4})_kst_(?P<hash>[0-9a-f]+)_enriched\.csv$"
)


def load_engine():
    spec = importlib.util.spec_from_file_location("tc_replay_engine_liquidity", ENGINE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


engine = load_engine()


def _f(value: object) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _notional(row: dict) -> float:
    explicit = _f(row.get("notional_usd")) or _f(row.get("notional"))
    if explicit is not None:
        return explicit
    return max(0.0, (_f(row.get("close")) or 0.0) * (_f(row.get("volume")) or 0.0))


def _volume_ratio(row: dict) -> float:
    return (_f(row.get("volume")) or 0.0) / max(_f(row.get("volume_ma20")) or 0.0, 1.0)


def _imbalance(row: dict) -> float | None:
    value = _f(row.get("bid_ask_imbalance"))
    if value is None:
        return None
    return value / 100.0 if value > 1.0 else value


def _quote_count_ok(row: dict, minimum: float = 8.0) -> bool:
    quote_count = _f(row.get("quote_count"))
    return quote_count is None or quote_count >= minimum


def _spread_cap(row: dict, high_liquidity: bool = False) -> float:
    close = _f(row.get("close")) or 0.0
    if close < 2.0:
        return 0.010 if high_liquidity else 0.0125
    return 0.006 if high_liquidity else 0.0085


def _tight_liquidity_ok(row: dict, *, min_notional: float = 60_000.0, high_liquidity: bool = False) -> bool:
    return (
        _notional(row) >= min_notional
        and engine.spread_fraction(row) <= _spread_cap(row, high_liquidity=high_liquidity)
        and _quote_count_ok(row)
    )


def _flow_ok(
    row: dict,
    *,
    min_strength: float = 52.0,
    max_sell_pressure: float = 55.0,
    min_imbalance: float | None = 0.50,
) -> bool:
    trade_strength = _f(row.get("trade_strength"))
    sell_pressure = _f(row.get("sell_pressure"))
    imbalance = _imbalance(row)
    strength_ok = trade_strength is None or trade_strength >= min_strength
    sell_ok = sell_pressure is None or sell_pressure <= max_sell_pressure
    imbalance_ok = min_imbalance is None or imbalance is None or imbalance >= min_imbalance
    return strength_ok and sell_ok and imbalance_ok


def _support_reclaim(row: dict, previous: dict) -> bool:
    vwap = row.get("session_vwap")
    ema9 = row.get("ema9")
    vwap_reclaim = vwap is None or (row["low"] <= vwap * 1.012 and row["close"] >= vwap * 0.998)
    ema_reclaim = ema9 is None or (row["low"] <= ema9 * 1.015 and row["close"] >= ema9 * 0.997)
    price_reclaim = row["close"] >= previous["close"] and row["close"] >= row["open"]
    return price_reclaim and (vwap_reclaim or ema_reclaim)


def signal_liquidity_absorption_reclaim(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 25:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    recent = rows[max(0, index - 5) : index + 1]
    absorption = any(
        engine.lower_wick_support(item)
        or (_flow_ok(item, min_strength=50.0, max_sell_pressure=58.0, min_imbalance=0.55) and item["close"] >= item["open"])
        for item in recent[-4:]
    )
    if (
        engine.common_entry_ok(rows, index, "Liquidity Absorption Reclaim")
        and _tight_liquidity_ok(row, min_notional=60_000.0)
        and _flow_ok(row, min_strength=52.0, max_sell_pressure=55.0, min_imbalance=0.52)
        and absorption
        and _support_reclaim(row, previous)
        and engine.previous_low_holding(rows, index, 0.992)
        and engine.failed_follow_through_ok(rows, index)
        and not engine.spread_widening(rows, index)
    ):
        return True, "liquidity_absorption_support_reclaim"
    return False, ""


def signal_liquidity_compression_breakout(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 30:
        return False, ""
    row = rows[index]
    lookback = 8
    prior = rows[index - lookback : index]
    prior_high = max(item["high"] for item in prior)
    prior_low = min(item["low"] for item in prior)
    ranges = [max(0.0, item["high"] - item["low"]) for item in prior]
    avg_range = sum(ranges) / max(1, len(ranges))
    compression = avg_range > 0 and (prior_high - prior_low) <= avg_range * 3.6
    previous_spreads = [engine.spread_fraction(rows[i]) for i in range(max(0, index - 4), index)]
    spread_tightening = not previous_spreads or engine.spread_fraction(row) <= (sum(previous_spreads) / len(previous_spreads)) * 1.05
    if (
        engine.common_entry_ok(rows, index, "Liquidity Compression Breakout")
        and _tight_liquidity_ok(row, min_notional=90_000.0, high_liquidity=True)
        and compression
        and spread_tightening
        and row["close"] >= prior_high * 1.001
        and _volume_ratio(row) >= 1.3
        and _flow_ok(row, min_strength=55.0, max_sell_pressure=50.0, min_imbalance=0.55)
        and engine.close_near_high(row)
        and engine.failed_follow_through_ok(rows, index)
        and not engine.spread_widening(rows, index)
    ):
        return True, "tight_spread_liquidity_compression_breakout"
    return False, ""


def signal_liquidity_pullback_reclaim(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 30:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    window = rows[max(0, index - 10) : index + 1]
    peak_index = max(range(len(window)), key=lambda idx: window[idx]["high"])
    peak_high = window[peak_index]["high"]
    after_peak = window[peak_index + 1 :] or [window[-1]]
    pullback_low = min(item["low"] for item in after_peak)
    pullback_pct = (peak_high - pullback_low) / peak_high if peak_high > 0 else 0.0
    recent_move = engine.recent_10bar_change_fraction(rows, index) or 0.0
    support = any(
        level and pullback_low <= level * 1.015 and row["close"] >= level * 0.995
        for level in [row.get("ema9"), row.get("ema20"), row.get("bb_mid20"), row.get("session_vwap")]
    )
    not_chasing = engine.ema9_extension_fraction(row) <= 0.055 and row["close"] <= peak_high * 1.005
    if (
        engine.common_entry_ok(rows, index, "Liquidity Pullback Reclaim")
        and _tight_liquidity_ok(row, min_notional=75_000.0)
        and recent_move >= 0.018
        and 1 <= len(after_peak) <= 6
        and 0.006 <= pullback_pct <= 0.075
        and support
        and _support_reclaim(row, previous)
        and _volume_ratio(row) >= 1.1
        and _flow_ok(row, min_strength=50.0, max_sell_pressure=55.0, min_imbalance=0.50)
        and engine.sell_pressure_decreasing(rows, index)
        and not_chasing
        and engine.failed_follow_through_ok(rows, index)
        and not engine.spread_widening(rows, index)
    ):
        return True, f"liquidity_pullback_{pullback_pct:.1%}_support_reclaim"
    return False, ""


LIQUIDITY_STRATEGIES = {
    "Liquidity Absorption Reclaim": signal_liquidity_absorption_reclaim,
    "Liquidity Compression Breakout": signal_liquidity_compression_breakout,
    "Liquidity Pullback Reclaim": signal_liquidity_pullback_reclaim,
}


def parse_window_key(path_file: Path) -> tuple[str, str, str] | None:
    match = FILENAME_RE.match(path_file.name)
    if not match:
        return None
    return (match.group("symbol").upper(), match.group("date"), match.group("timerange"))


def dedup_windows(paths: list[Path]) -> dict[tuple[str, str, str], Path]:
    best: dict[tuple[str, str, str], Path] = {}
    for path_file in paths:
        key = parse_window_key(path_file)
        if key is None:
            continue
        current = best.get(key)
        if current is None or path_file.stat().st_mtime > current.stat().st_mtime:
            best[key] = path_file
    return best


def aggregate(summaries: list[dict]) -> dict:
    trades = sum(item["trades"] for item in summaries)
    wins = sum(item["wins"] for item in summaries)
    losses = sum(item["losses"] for item in summaries)
    net = round(sum(item["net_pnl_usd"] for item in summaries), 4)
    return {
        "trades": trades,
        "wins": wins,
        "losses": losses,
        "net_pnl": net,
        "return_pct": round(net / 2000.0 * 100, 4),
        "win_rate_pct": round(wins / trades * 100, 2) if trades else 0.0,
    }


def replay_window(path_file: Path) -> tuple[list[dict], list[dict]]:
    rows = engine.load_rows(path_file)
    portfolios = engine.replay(rows)
    summaries = [engine.summary_row(portfolio) for portfolio in portfolios.values()]
    trades = [
        {"source_file": path_file.name, **trade}
        for portfolio in portfolios.values()
        for trade in portfolio.trades
    ]
    return summaries, trades


def build_report(windows: dict[tuple[str, str, str], Path]) -> tuple[dict, list[dict]]:
    window_reports: list[dict] = []
    all_trades: list[dict] = []
    total_summaries: list[dict] = []
    by_strategy_summaries: dict[str, list[dict]] = defaultdict(list)
    by_symbol_summaries: dict[str, list[dict]] = defaultdict(list)

    for key in sorted(windows):
        symbol, date, timerange = key
        path_file = windows[key]
        summaries, trades = replay_window(path_file)
        all_trades.extend(trades)
        total_summaries.extend(summaries)
        for summary in summaries:
            by_strategy_summaries[summary["strategy"]].append(summary)
            by_symbol_summaries[symbol].append(summary)
        total = aggregate(summaries)
        window_reports.append(
            {
                "key": [symbol, date, timerange],
                "file": path_file.name,
                **total,
                "by_strategy": {item["strategy"]: item for item in summaries},
            }
        )

    by_strategy = {}
    for name, items in by_strategy_summaries.items():
        stat = aggregate(items)
        stat.pop("return_pct", None)
        by_strategy[name] = stat

    report = {
        "engine": str(ENGINE_PATH.relative_to(PROJECT_ROOT)),
        "strategy_names_active": list(engine.STRATEGIES.keys()),
        "dedup_windows": len(windows),
        "total": aggregate(total_summaries),
        "by_strategy": by_strategy,
        "by_symbol": {
            symbol: {
                "windows": sum(1 for item in window_reports if item["key"][0] == symbol),
                **aggregate(items),
            }
            for symbol, items in sorted(by_symbol_summaries.items())
        },
        "windows": window_reports,
    }
    return report, all_trades


def write_outputs(report: dict, trades: list[dict], output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / "liquidity_strategies_replay_summary.json"
    trades_path = output_dir / "liquidity_strategies_replay_trades.csv"
    summary_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if trades:
        fields = list(trades[0].keys())
        with trades_path.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader()
            writer.writerows(trades)
    return summary_path, trades_path


def print_console(report: dict) -> None:
    total = report["total"]
    print("=" * 86)
    print(f"Liquidity experiment strategies: {', '.join(report['strategy_names_active'])}")
    print(f"Windows replayed              : {report['dedup_windows']}")
    print(
        f"TOTAL                         : {total['trades']} trades | win {total['win_rate_pct']}% | "
        f"net ${total['net_pnl']} | return {total['return_pct']}% (on $2000/strategy)"
    )
    print("-" * 86)
    print(f"{'BY STRATEGY':<38}{'trades':>7}{'win%':>8}{'net$':>12}")
    for name, stat in sorted(report["by_strategy"].items(), key=lambda item: item[1]["net_pnl"], reverse=True):
        print(f"{name:<38}{stat['trades']:>7}{stat['win_rate_pct']:>8}{stat['net_pnl']:>12}")
    print("-" * 86)
    print(f"{'TOP SYMBOLS':<10}{'win':>5}{'trades':>8}{'win%':>8}{'net$':>12}{'ret%':>9}")
    for symbol, stat in sorted(report["by_symbol"].items(), key=lambda item: item[1]["net_pnl"], reverse=True)[:12]:
        print(f"{symbol:<10}{stat['windows']:>5}{stat['trades']:>8}{stat['win_rate_pct']:>8}{stat['net_pnl']:>12}{stat['return_pct']:>9}")
    print("=" * 86)


def main() -> None:
    parser = argparse.ArgumentParser(description="Replay experimental liquidity strategies over enriched replay windows.")
    parser.add_argument(
        "--dir",
        action="append",
        required=True,
        help="Folder containing *_enriched.csv windows. Pass multiple times to combine sessions.",
    )
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument(
        "--only",
        action="append",
        choices=sorted(LIQUIDITY_STRATEGIES.keys()),
        help="Run only the named liquidity strategy. Can be passed multiple times.",
    )
    args = parser.parse_args()

    selected = LIQUIDITY_STRATEGIES
    if args.only:
        selected = {name: LIQUIDITY_STRATEGIES[name] for name in args.only}
    engine.STRATEGIES = selected
    paths: list[Path] = []
    for raw_dir in args.dir:
        paths.extend(sorted(Path(raw_dir).resolve().glob("*_enriched.csv")))
    windows = dedup_windows(paths)
    report, trades = build_report(windows)
    summary_path, trades_path = write_outputs(report, trades, Path(args.output_dir).resolve())
    print_console(report)
    print(f"raw files: {len(paths)}  ->  dedup windows: {len(windows)}")
    print(f"summary : {summary_path.relative_to(PROJECT_ROOT)}")
    print(f"trades  : {trades_path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
