from app.adapters.kis.auth import KisAuthClient, mask_secret, now_iso
from app.adapters.kis.errors import KisAdapterError, KisApiResponseError, KisConfigurationError
from app.adapters.kis.overseas_stock_api import KisOverseasStockApi
from app.adapters.kis.rest_client import KisRestClient
from app.core.config import get_settings


class KisConnectionService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.auth_client = KisAuthClient(self.settings)
        self.rest_client = KisRestClient(self.settings, self.auth_client)
        self.overseas_stock = KisOverseasStockApi(self.rest_client)

    def status(self, *, ping: bool = False) -> dict:
        configured = bool(self.settings.kis_app_key and self.settings.kis_app_secret)
        base_url = (
            self.settings.kis_rest_base_url_live
            if self.settings.kis_environment == "live"
            else self.settings.kis_rest_base_url_mock
        )
        result = {
            "environment": self.settings.kis_environment,
            "configured": configured,
            "base_url": base_url,
            "app_key": mask_secret(self.settings.kis_app_key),
            "account_configured": bool(self.settings.kis_account_no),
            "hts_id_configured": bool(self.settings.kis_hts_id),
            "rest_status": "not_checked",
            "checked_at": now_iso(),
            "live_order_enabled": False,
        }
        if not configured:
            result["rest_status"] = "credentials_missing"
            result["message"] = "KIS_APP_KEY/KIS_APP_SECRET을 .env에 설정해야 합니다."
            return result
        if not ping:
            result["rest_status"] = "configured"
            result["message"] = "ping=true로 호출하면 토큰 발급까지 확인합니다."
            return result
        try:
            token = self.auth_client.issue_access_token_sync()
            result["rest_status"] = "connected"
            result["token_expires_at"] = token.expires_at
            result["message"] = "KIS OAuth 접근토큰 발급 성공"
            return result
        except KisConfigurationError as exc:
            result["rest_status"] = "credentials_missing"
            result["message"] = str(exc)
            return result
        except KisApiResponseError as exc:
            result["rest_status"] = "api_error"
            result["message"] = str(exc)
            result["kis_status_code"] = exc.status_code
            result["kis_error_code"] = exc.payload.get("msg_cd")
            return result
        except KisAdapterError as exc:
            result["rest_status"] = "adapter_error"
            result["message"] = str(exc)
            return result
        except Exception as exc:
            result["rest_status"] = "network_error"
            result["message"] = str(exc)
            return result

    def price(self, symbol: str, exchange: str = "NAS") -> dict:
        return self.overseas_stock.get_price_sync(symbol=symbol, exchange=exchange)

    def quote(self, symbol: str, exchange: str = "NAS") -> dict:
        return self.overseas_stock.get_quote_sync(symbol=symbol, exchange=exchange)

    def minute_bars(self, symbol: str, exchange: str = "NAS", interval: str = "1", limit: int = 120) -> dict:
        return self.overseas_stock.get_minute_bars_sync(
            symbol=symbol,
            exchange=exchange,
            interval=interval,
            limit=limit,
        )

    def minute_bars_history(
        self,
        symbol: str,
        exchange: str = "NAS",
        interval: str = "1",
        target_date: str | None = None,
        max_pages: int = 20,
    ) -> dict:
        return self.overseas_stock.get_minute_bars_history_sync(
            symbol=symbol,
            exchange=exchange,
            interval=interval,
            target_date=target_date,
            max_pages=max_pages,
        )

    def daily_bars(
        self,
        symbol: str,
        exchange: str = "NAS",
        period: str = "0",
        bymd: str = "",
        adjusted: bool = True,
        max_pages: int = 5,
    ) -> dict:
        return self.overseas_stock.get_daily_bars_sync(
            symbol=symbol,
            exchange=exchange,
            period=period,
            bymd=bymd,
            adjusted=adjusted,
            max_pages=max_pages,
        )

    def scanner_rankings(self, exchange: str = "NAS") -> dict:
        return {
            "trade_volume": self.overseas_stock.get_trade_volume_ranking_sync(exchange=exchange),
            "volume_surge": self.overseas_stock.get_volume_surge_ranking_sync(exchange=exchange),
            "trade_strength": self.overseas_stock.get_trade_strength_ranking_sync(exchange=exchange),
        }
