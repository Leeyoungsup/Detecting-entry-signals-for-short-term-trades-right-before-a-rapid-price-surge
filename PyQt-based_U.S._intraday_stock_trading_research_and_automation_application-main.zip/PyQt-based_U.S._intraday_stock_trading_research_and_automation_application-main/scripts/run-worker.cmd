@echo off
setlocal

cd /d "%~dp0.."

call scripts\load-env.cmd

set APP_PROCESS_ROLE=worker
set CONDA_ENV_DIR=%USERPROFILE%\.conda\envs\kis-trading-research
if not exist "%CONDA_ENV_DIR%\python.exe" set CONDA_ENV_DIR=C:\ProgramData\anaconda3\envs\kis-trading-research
set PATH=%CONDA_ENV_DIR%;%CONDA_ENV_DIR%\Library\bin;%CONDA_ENV_DIR%\Scripts;%PATH%

if "%DATABASE_URL%"=="" set DATABASE_URL=postgresql+psycopg://kis_app:change_me@127.0.0.1:5432/kis_trading_research
if "%REDIS_URL%"=="" set REDIS_URL=redis://127.0.0.1:6379/0
if /I "%REDIS_URL%"=="redis://redis:6379/0" set REDIS_URL=redis://127.0.0.1:6379/0

echo Starting worker process
echo Process role: %APP_PROCESS_ROLE%
cd services\backend
python -m app.worker
