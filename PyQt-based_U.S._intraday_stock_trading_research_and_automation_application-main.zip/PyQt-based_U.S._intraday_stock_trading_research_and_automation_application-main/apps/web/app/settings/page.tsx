import {
  Database,
  Lock,
  RadioTower,
  Settings2,
  ShieldCheck,
  Wallet,
} from "lucide-react";
import { RuntimeSettingsEditor } from "@/components/runtime-settings-editor";
import { PageTitle } from "@/components/page-title";
import { apiGet } from "@/lib/api";

type SettingsField = {
  key: string;
  label: string;
  type: string;
  value: number | boolean | string;
  min?: number;
  max?: number;
  step?: number;
};

type SettingsGroup = {
  key: string;
  label: string;
  fields: SettingsField[];
};

type SettingsData = {
  runtime_only: boolean;
  read_only: Record<string, string | number | boolean | null>;
  groups: SettingsGroup[];
};

const fallback: SettingsData = {
  runtime_only: true,
  read_only: {},
  groups: [],
};

export default async function SettingsPage() {
  const data = await apiGet<SettingsData>("/settings", fallback);

  return (
    <>
      <PageTitle
        title="설정"
        description="전략을 제외한 운영, 스캐너, 세션, 시뮬레이션 테스트, 비용 모델 설정을 조정합니다."
        icon={<Settings2 className="h-5 w-5" aria-hidden />}
      />
      <section className="space-y-5 p-6">
        <div className="rounded border border-amber-200 bg-amber-50 px-5 py-4">
          <div className="flex items-start gap-3">
            <Lock className="mt-0.5 h-5 w-5 shrink-0 text-warn" aria-hidden />
            <div>
              <div className="text-sm font-semibold text-ink">런타임 설정</div>
              <p className="mt-1 text-sm leading-6 text-zinc-700">
                이 화면에서 바꾸는 값은 현재 실행 중인 백엔드에만 적용됩니다. 재시작하면 `.env` 값으로 돌아갑니다.
                API 키, 시크릿, 실전매매 전환 설정은 보안상 화면에서 수정하지 않습니다.
              </p>
            </div>
          </div>
        </div>

        <div className="grid gap-3 md:grid-cols-3 xl:grid-cols-6">
          <ReadOnlyCard icon={<ShieldCheck className="h-5 w-5" />} label="운영 모드" value={data.read_only.trading_mode} />
          <ReadOnlyCard icon={<Lock className="h-5 w-5" />} label="실전매매" value={data.read_only.live_enabled ? "활성" : "비활성"} />
          <ReadOnlyCard icon={<Database className="h-5 w-5" />} label="Market Data" value={data.read_only.market_data_provider} />
          <ReadOnlyCard icon={<RadioTower className="h-5 w-5" />} label="Feed" value={data.read_only.market_data_feed} />
          <ReadOnlyCard icon={<Wallet className="h-5 w-5" />} label="실행 Gateway" value={data.read_only.execution_provider} />
          <ReadOnlyCard icon={<Settings2 className="h-5 w-5" />} label="Toss 환경" value={data.read_only.toss_environment} />
        </div>

        <RuntimeSettingsEditor groups={data.groups} />
      </section>
    </>
  );
}

function ReadOnlyCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: unknown }) {
  return (
    <div className="rounded border border-line bg-white p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="text-xs font-medium text-zinc-500">{label}</div>
        <span className="text-info">{icon}</span>
      </div>
      <div className="mt-3 truncate text-lg font-bold text-ink">{String(value ?? "-")}</div>
    </div>
  );
}
