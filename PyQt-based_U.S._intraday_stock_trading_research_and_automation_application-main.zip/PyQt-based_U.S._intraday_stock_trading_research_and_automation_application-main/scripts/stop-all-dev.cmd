@echo off
setlocal

cd /d "%~dp0.."

echo Stopping managed backend ports 8001-8010 and 18001-18006
for %%R in (1 2 3 4 5) do (
  for %%A in (8000 8001 8002 8003 8004 8005 8006 8007 8008 8009 8010 18001 18002 18003 18004 18005 18006) do (
    for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":%%A .*LISTENING"') do (
      echo Stopping port %%A PID %%P
      taskkill /PID %%P /T /F > nul 2> nul
    )
  )
  ping -n 2 127.0.0.1 > nul
)

echo Stopping managed worker processes
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { ($_.CommandLine -like '*app.worker*' -or $_.CommandLine -like '*run-worker.cmd*' -or $_.CommandLine -like '*app.realtime_worker*' -or $_.CommandLine -like '*run-realtime-worker.cmd*') -and $_.ProcessId -ne $PID } | ForEach-Object { Write-Output ('Stopping worker PID ' + $_.ProcessId); Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"

echo Stopping managed web ports 3000-3003 and 18000-18013
for %%R in (1 2 3 4 5) do (
  for %%A in (3000 3001 3002 3003 18000 18004 18008 18012) do (
    for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":%%A .*LISTENING"') do (
      echo Stopping port %%A PID %%P
      taskkill /PID %%P /T /F > nul 2> nul
    )
  )
  ping -n 2 127.0.0.1 > nul
)

echo All managed dev ports stopped.
exit /b 0
