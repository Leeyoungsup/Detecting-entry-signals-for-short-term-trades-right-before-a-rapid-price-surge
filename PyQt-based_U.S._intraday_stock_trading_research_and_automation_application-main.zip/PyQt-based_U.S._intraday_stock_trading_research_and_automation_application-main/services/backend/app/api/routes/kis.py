from typing import Literal

from fastapi import APIRouter, HTTPException, Query

from app.adapters.kis.errors import KisAdapterError, KisApiResponseError, KisConfigurationError
from app.services.kis_connection import KisConnectionService
from app.services.kis_ws_manager import kis_ws_client

router = APIRouter()
kis_service = KisConnectionService()


@router.get("/status")
def kis_status(ping: bool = Query(default=False)) -> dict:
    return kis_service.status(ping=ping)


@router.get("/price/{symbol}")
def kis_price(symbol: str, exchange: str = Query(default="NAS")) -> dict:
    try:
        return kis_service.price(symbol=symbol, exchange=exchange)
    except KisApiResponseError as exc:
        raise _kis_http_error(exc) from exc
    except (KisAdapterError, KisConfigurationError) as exc:
        raise HTTPException(status_code=503, detail={"message": str(exc)}) from exc


@router.get("/quote/{symbol}")
def kis_quote(symbol: str, exchange: str = Query(default="NAS")) -> dict:
    try:
        return kis_service.quote(symbol=symbol, exchange=exchange)
    except KisApiResponseError as exc:
        raise _kis_http_error(exc) from exc
    except (KisAdapterError, KisConfigurationError) as exc:
        raise HTTPException(status_code=503, detail={"message": str(exc)}) from exc


@router.get("/minute-bars/{symbol}")
def kis_minute_bars(
    symbol: str,
    exchange: str = Query(default="NAS"),
    interval: str = Query(default="1"),
    limit: int = Query(default=120, ge=1, le=120),
) -> dict:
    try:
        return kis_service.minute_bars(
            symbol=symbol,
            exchange=exchange,
            interval=interval,
            limit=limit,
        )
    except KisApiResponseError as exc:
        raise _kis_http_error(exc) from exc
    except (KisAdapterError, KisConfigurationError) as exc:
        raise HTTPException(status_code=503, detail={"message": str(exc)}) from exc


@router.get("/scanner-rankings")
def kis_scanner_rankings(exchange: str = Query(default="NAS")) -> dict:
    try:
        return kis_service.scanner_rankings(exchange=exchange)
    except KisApiResponseError as exc:
        raise _kis_http_error(exc) from exc
    except (KisAdapterError, KisConfigurationError) as exc:
        raise HTTPException(status_code=503, detail={"message": str(exc)}) from exc


@router.post("/ws/start")
async def kis_ws_start(
    symbols: str = Query(default="AAPL"),
    exchange: str = Query(default="NAS"),
    key_mode: Literal["regular", "daytime"] = Query(default="regular"),
    quotes: bool = Query(default=True),
    trades: bool = Query(default=True),
) -> dict:
    symbol_list = [symbol.strip().upper() for symbol in symbols.split(",") if symbol.strip()]
    try:
        return await kis_ws_client.start(
            symbols=symbol_list,
            exchange=exchange,
            key_mode=key_mode,
            subscribe_quotes=quotes,
            subscribe_trades=trades,
        )
    except (KisAdapterError, KisConfigurationError) as exc:
        raise HTTPException(status_code=503, detail={"message": str(exc)}) from exc


@router.post("/ws/stop")
async def kis_ws_stop() -> dict:
    return await kis_ws_client.stop()


@router.get("/ws/status")
def kis_ws_status() -> dict:
    return kis_ws_client.status()


@router.get("/ws/events")
def kis_ws_events(limit: int = Query(default=100, ge=1, le=1000)) -> dict:
    return {"events": kis_ws_client.recent_events(limit)}


@router.get("/ws/snapshot")
def kis_ws_snapshot() -> dict:
    return kis_ws_client.snapshot()


def _kis_http_error(exc: KisApiResponseError) -> HTTPException:
    return HTTPException(
        status_code=502,
        detail={
            "message": str(exc),
            "kis_status_code": exc.status_code,
            "kis_error_code": exc.payload.get("msg_cd"),
        },
    )
