from datetime import datetime, timedelta, timezone

from app.services import strategy_runtime as strategy_runtime_module


class FakeBroker:
    def __init__(self, closed_trades: list[dict]) -> None:
        self._closed_trades = closed_trades

    def state(self) -> dict:
        return {"closed_trades": self._closed_trades}


def _closed_loss(symbol: str, *, seconds_ago: int, net_pnl_usd: float = -1.0) -> dict:
    closed_at = datetime.now(timezone.utc) - timedelta(seconds=seconds_ago)
    return {
        "symbol": symbol,
        "net_pnl_usd": net_pnl_usd,
        "closed_at": closed_at.isoformat(),
    }


def test_symbol_loss_guard_blocks_recent_same_symbol_loss(monkeypatch) -> None:
    settings = strategy_runtime_module.get_settings()
    monkeypatch.setattr(settings, "paper_symbol_any_strategy_loss_cooldown_seconds", 600)
    monkeypatch.setattr(settings, "paper_symbol_loss_cluster_cooldown_seconds", 1800)
    monkeypatch.setattr(settings, "paper_symbol_loss_cluster_lookback_seconds", 3600)
    monkeypatch.setattr(settings, "paper_symbol_loss_cluster_max_losses", 2)

    broker = FakeBroker([_closed_loss("TC", seconds_ago=120)])

    guard = strategy_runtime_module._symbol_loss_guard("TC", broker)

    assert 0 < guard["remaining_sec"] <= 600
    assert guard["reason"] == "symbol_recent_loss"


def test_symbol_loss_guard_blocks_loss_cluster(monkeypatch) -> None:
    settings = strategy_runtime_module.get_settings()
    monkeypatch.setattr(settings, "paper_symbol_any_strategy_loss_cooldown_seconds", 0)
    monkeypatch.setattr(settings, "paper_symbol_loss_cluster_cooldown_seconds", 1800)
    monkeypatch.setattr(settings, "paper_symbol_loss_cluster_lookback_seconds", 3600)
    monkeypatch.setattr(settings, "paper_symbol_loss_cluster_max_losses", 2)

    broker = FakeBroker(
        [
            _closed_loss("TC", seconds_ago=1500),
            _closed_loss("TC", seconds_ago=120),
            _closed_loss("BYAH", seconds_ago=30),
        ]
    )

    guard = strategy_runtime_module._symbol_loss_guard("TC", broker)

    assert 0 < guard["remaining_sec"] <= 1800
    assert guard["reason"] == "symbol_loss_cluster"
    assert guard["recent_loss_count"] == 2
