from datetime import datetime, timedelta, timezone

from app.api.routes.symbols import _merge_live_candles_if_continuous


def _candle_at(moment: datetime, *, is_live: bool = False) -> dict:
    return {
        "symbol": "AAPL",
        "market_date": moment.strftime("%Y%m%d"),
        "market_time": moment.strftime("%H%M%S"),
        "korea_date": (moment + timedelta(hours=9)).strftime("%Y%m%d"),
        "korea_time": (moment + timedelta(hours=9)).strftime("%H%M%S"),
        "open": 10.0,
        "high": 10.0,
        "low": 10.0,
        "close": 10.0,
        "volume": 1.0,
        "source": "toss_polling_tick" if is_live else "toss_minute",
        "is_live": is_live,
        "is_tick_built": is_live,
    }


def test_live_candle_merge_ignores_future_tick_bucket() -> None:
    now_floor = datetime.now(timezone.utc).replace(second=0, microsecond=0)
    base = [_candle_at(now_floor - timedelta(minutes=1))]
    future_live = [_candle_at(now_floor + timedelta(minutes=5), is_live=True)]

    result = _merge_live_candles_if_continuous(base, future_live)

    assert result["merged"] is False
    assert result["candles"] == base


def test_live_candle_merge_allows_next_minute_close_time_label() -> None:
    now_floor = datetime.now(timezone.utc).replace(second=0, microsecond=0)
    base = [_candle_at(now_floor)]
    close_time_live = [_candle_at(now_floor + timedelta(minutes=1), is_live=True)]

    result = _merge_live_candles_if_continuous(base, close_time_live)

    assert result["merged"] is True
    assert result["candles"][-1]["market_time"] == close_time_live[0]["market_time"]
