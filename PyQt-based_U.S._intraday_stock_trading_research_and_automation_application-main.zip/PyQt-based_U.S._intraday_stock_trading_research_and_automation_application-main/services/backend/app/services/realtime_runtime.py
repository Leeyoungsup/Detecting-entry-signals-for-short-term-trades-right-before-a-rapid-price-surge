import asyncio
from contextlib import suppress

from app.core.config import get_settings
from app.domain.enums import StatusLevel
from app.services import realtime_state
from app.services import toss_flow_recorder
from app.services.event_log import record_event
from app.services.market_data import get_market_data_service
from app.services.market_session import realtime_session_allowed, us_equity_session


class RealtimeRuntime:
    def __init__(self) -> None:
        self._task: asyncio.Task | None = None
        self._last_symbols: list[str] = []

    def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._task = asyncio.create_task(self._run(), name="market-data-realtime-runtime")
        record_event(
            level="INFO",
            event_type="runtime.realtime_started",
            message="Market-data realtime worker started.",
            severity=StatusLevel.NORMAL,
        )

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            with suppress(asyncio.CancelledError):
                await self._task
            self._task = None
        with suppress(Exception):
            await get_market_data_service().provider.stop_realtime()
        record_event(
            level="INFO",
            event_type="runtime.realtime_stopped",
            message="Market-data realtime worker stopped.",
            severity=StatusLevel.NORMAL,
        )

    async def _run(self) -> None:
        provider = get_market_data_service().provider
        while True:
            try:
                settings = get_settings()
                desired = realtime_state.desired_subscriptions()
                symbols = desired.get("symbols") or []
                session = us_equity_session()
                status = provider.realtime_status()
                if not realtime_session_allowed(settings, session):
                    if status.get("status") in ("starting", "connected"):
                        status = await provider.stop_realtime()
                    self._last_symbols = []
                elif symbols:
                    current = sorted(provider.subscribed_symbols())
                    if status.get("status") not in ("starting", "connected"):
                        status = await provider.start_realtime(
                            symbols=symbols,
                            exchange=desired.get("exchange") or settings.scanner_websocket_exchange,
                            key_mode=desired.get("key_mode") or settings.scanner_websocket_key_mode,
                            subscribe_quotes=True,
                            subscribe_trades=True,
                        )
                    elif current != sorted(symbols):
                        status = await provider.update_realtime(
                            symbols=symbols,
                            exchange=desired.get("exchange") or settings.scanner_websocket_exchange,
                            key_mode=desired.get("key_mode") or settings.scanner_websocket_key_mode,
                            subscribe_quotes=True,
                            subscribe_trades=True,
                        )
                    self._last_symbols = list(symbols)
                elif status.get("status") in ("starting", "connected"):
                    status = await provider.stop_realtime()
                    self._last_symbols = []
                latest_prices = provider.latest_prices() if hasattr(provider, "latest_prices") else None
                flow_snapshot = provider.order_flow_snapshot()
                realtime_state.publish_realtime_runtime(status, flow_snapshot, latest_prices)
                # Record Toss's own per-minute flow so we can re-tune thresholds to the Toss
                # scale (replay CSVs are Alpaca; live is Toss -- the flow scales differ).
                toss_flow_recorder.record_flow(flow_snapshot, latest_prices)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                record_event(
                    level="INFO",
                    event_type="runtime.realtime_tick_failed",
                    message="Market-data realtime worker tick failed.",
                    severity=StatusLevel.CAUTION,
                    payload={"reason": str(exc)[:300]},
                )
            await asyncio.sleep(1.0)


realtime_runtime = RealtimeRuntime()
