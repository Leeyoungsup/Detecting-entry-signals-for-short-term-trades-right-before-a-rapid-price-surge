from __future__ import annotations

import os
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / ".runtime"


def read_runtime_path(name: str, fallback: str) -> Path:
    path_file = RUNTIME / name
    if path_file.exists():
        value = path_file.read_text(encoding="utf-8", errors="ignore").strip()
        if value:
            return ROOT / value
    return ROOT / fallback


def print_new(path: Path, offsets: dict[Path, int]) -> None:
    if not path.exists():
        return
    with path.open("r", encoding="utf-8", errors="replace") as file:
        file.seek(offsets.get(path, 0))
        chunk = file.read()
        offsets[path] = file.tell()
    if chunk:
        label = path.relative_to(ROOT)
        for line in chunk.rstrip().splitlines():
            print(f"[{label}] {line}", flush=True)


def main() -> None:
    backend = read_runtime_path("backend-log.txt", "logs/backend-8010.log")
    web = read_runtime_path("web-log.txt", "logs/web-3000.log")
    paths = [backend, web]
    offsets = {path: 0 for path in paths}

    print("Following logs. Press Ctrl+C to stop.", flush=True)
    print(f"Backend log: {backend}", flush=True)
    print(f"Web log:     {web}", flush=True)

    try:
        while True:
            for path in paths:
                print_new(path, offsets)
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopped following logs.", flush=True)


if __name__ == "__main__":
    main()
