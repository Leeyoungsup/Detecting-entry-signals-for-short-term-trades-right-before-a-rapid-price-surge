"use client";

import { RotateCcw, ZoomIn, ZoomOut } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

type Candle = {
  market_date?: string | null;
  market_time?: string | null;
  korea_date?: string | null;
  korea_time?: string | null;
  open: number | null;
  high: number | null;
  low: number | null;
  close: number | null;
  volume: number | null;
  notional?: number | null;
  source?: string | null;
  is_live?: boolean | null;
};

type OverlayPoint = {
  bbUpper: number | null;
  bbMid: number | null;
  bbLower: number | null;
  vwap: number | null;
  ema9: number | null;
  ema20: number | null;
};

export function InteractivePriceChart({
  candles,
  indicators,
  message,
}: {
  candles: Candle[];
  indicators: Record<string, number | null>;
  message: string;
}) {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [visibleCount, setVisibleCount] = useState(80);
  const validCandles = useMemo(
    () => candles.filter((candle) => candle.close != null && candle.high != null && candle.low != null),
    [candles],
  );
  const visible = useMemo(
    () => validCandles.slice(-Math.min(visibleCount, validCandles.length)),
    [validCandles, visibleCount],
  );
  useEffect(() => {
    setVisibleCount((current) => Math.min(Math.max(current, 20), Math.max(validCandles.length, 20)));
  }, [validCandles.length]);
  const width = 920;
  const height = 340;
  const padding = { top: 18, right: 58, bottom: 28, left: 12 };
  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;
  const series = useMemo(() => buildOverlaySeries(visible), [visible]);
  const priceValues = [
    ...visible.flatMap((candle) => [toNumber(candle.high), toNumber(candle.low)]),
    ...series.map((point) => point.bbUpper),
    ...series.map((point) => point.bbMid),
    ...series.map((point) => point.bbLower),
    ...series.map((point) => point.vwap),
    ...series.map((point) => point.ema9),
    ...series.map((point) => point.ema20),
  ].filter((value): value is number => value != null && Number.isFinite(value));
  const min = Math.min(...priceValues);
  const max = Math.max(...priceValues);
  const rangePad = Number.isFinite(max - min) ? Math.max((max - min) * 0.08, max * 0.0005) : 1;
  const scaledMin = min - rangePad;
  const scaledMax = max + rangePad;
  const candleGap = visible.length > 1 ? plotWidth / visible.length : plotWidth;
  const candleWidth = Math.max(3, Math.min(10, candleGap * 0.58));
  const xAt = (index: number) => padding.left + candleGap * index + candleGap / 2;
  const yAt = (value: number) => padding.top + (1 - normalize(value, scaledMin, scaledMax)) * plotHeight;
  const gridValues = Array.from({ length: 5 }, (_, index) => scaledMin + ((scaledMax - scaledMin) * index) / 4).reverse();
  const verticalGrid = Array.from({ length: 6 }, (_, index) => padding.left + (plotWidth * index) / 5);
  const bbArea = areaPath(series.map((point) => point.bbUpper), series.map((point) => point.bbLower), xAt, yAt);
  const hovered = hoverIndex == null ? null : visible[hoverIndex];
  const hoveredOverlay = hoverIndex == null ? null : series[hoverIndex];
  const hoverX = hoverIndex == null ? null : xAt(hoverIndex);
  const tooltipX = hoverX == null ? 0 : Math.min(Math.max(hoverX + 12, 20), width - 220);

  function onMouseMove(event: React.MouseEvent<SVGSVGElement>) {
    if (visible.length === 0) {
      return;
    }
    const rect = event.currentTarget.getBoundingClientRect();
    const relativeX = ((event.clientX - rect.left) / rect.width) * width;
    const index = Math.round((relativeX - padding.left - candleGap / 2) / candleGap);
    setHoverIndex(Math.min(Math.max(index, 0), visible.length - 1));
  }

  function zoomIn() {
    setVisibleCount((current) => Math.max(20, Math.floor(current * 0.7)));
  }

  function zoomOut() {
    setVisibleCount((current) => Math.min(Math.max(validCandles.length, 20), Math.ceil(current * 1.35)));
  }

  function resetZoom() {
    setVisibleCount(Math.min(80, Math.max(validCandles.length, 20)));
  }

  return (
    <div className="rounded border border-line bg-white">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-4 py-3">
        <div className="text-sm font-semibold text-ink">차트</div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex items-center rounded border border-line bg-white">
            <button
              type="button"
              onClick={zoomIn}
              className="grid h-8 w-8 place-items-center border-r border-line text-ink hover:bg-zinc-50"
              title="확대"
              aria-label="차트 확대"
            >
              <ZoomIn className="h-4 w-4" aria-hidden />
            </button>
            <button
              type="button"
              onClick={zoomOut}
              className="grid h-8 w-8 place-items-center border-r border-line text-ink hover:bg-zinc-50"
              title="축소"
              aria-label="차트 축소"
            >
              <ZoomOut className="h-4 w-4" aria-hidden />
            </button>
            <button
              type="button"
              onClick={resetZoom}
              className="grid h-8 w-8 place-items-center text-ink hover:bg-zinc-50"
              title="초기화"
              aria-label="차트 확대 축소 초기화"
            >
              <RotateCcw className="h-4 w-4" aria-hidden />
            </button>
          </div>
          <div className="text-xs text-zinc-500">{message}</div>
        </div>
      </div>
      <div className="p-4">
        {visible.length > 1 ? (
          <svg
            className="h-96 w-full"
            viewBox={`0 0 ${width} ${height}`}
            role="img"
            aria-label="캔들 차트"
            onMouseMove={onMouseMove}
            onMouseLeave={() => setHoverIndex(null)}
          >
            <rect x="0" y="0" width={width} height={height} fill="#f8fafc" />
            {gridValues.map((value) => {
              const y = yAt(value);
              return (
                <g key={`h-${value}`}>
                  <line x1={padding.left} x2={width - padding.right} y1={y} y2={y} stroke="#e5e7eb" strokeWidth="1" />
                  <text x={width - padding.right + 8} y={y + 4} fill="#64748b" fontSize="11">
                    {formatPrice(value)}
                  </text>
                </g>
              );
            })}
            {verticalGrid.map((x, index) => (
              <line key={`v-${index}`} x1={x} x2={x} y1={padding.top} y2={height - padding.bottom} stroke="#eef2f7" strokeWidth="1" />
            ))}
            {bbArea ? <path d={bbArea} fill="#dbeafe" opacity="0.45" /> : null}
            <path d={linePath(series.map((point) => point.bbUpper), xAt, yAt)} fill="none" stroke="#60a5fa" strokeWidth="1.4" strokeDasharray="4 4" />
            <path d={linePath(series.map((point) => point.bbMid), xAt, yAt)} fill="none" stroke="#93c5fd" strokeWidth="1.2" />
            <path d={linePath(series.map((point) => point.bbLower), xAt, yAt)} fill="none" stroke="#60a5fa" strokeWidth="1.4" strokeDasharray="4 4" />
            <path d={linePath(series.map((point) => point.vwap), xAt, yAt)} fill="none" stroke="#7c3aed" strokeWidth="1.7" />
            <path d={linePath(series.map((point) => point.ema9), xAt, yAt)} fill="none" stroke="#f59e0b" strokeWidth="1.5" />
            <path d={linePath(series.map((point) => point.ema20), xAt, yAt)} fill="none" stroke="#10b981" strokeWidth="1.5" />
            {visible.map((candle, index) => {
              const open = toNumber(candle.open) ?? toNumber(candle.close) ?? 0;
              const close = toNumber(candle.close) ?? open;
              const high = toNumber(candle.high) ?? Math.max(open, close);
              const low = toNumber(candle.low) ?? Math.min(open, close);
              const x = xAt(index);
              const yOpen = yAt(open);
              const yClose = yAt(close);
              const up = close >= open;
              const color = up ? "#dc2626" : "#2563eb";
              const bodyY = Math.min(yOpen, yClose);
              const bodyHeight = Math.max(Math.abs(yOpen - yClose), 2);
              return (
                <g key={`${candle.market_date}-${candle.market_time}-${index}`}>
                  <line x1={x} x2={x} y1={yAt(high)} y2={yAt(low)} stroke={color} strokeWidth="1.2" />
                  <rect
                    x={x - candleWidth / 2}
                    y={bodyY}
                    width={candleWidth}
                    height={bodyHeight}
                    fill={up ? "#d1fae5" : "#fee2e2"}
                    stroke={color}
                    strokeWidth={hoverIndex === index ? "2" : "1"}
                  />
                </g>
              );
            })}
            {hovered && hoveredOverlay && hoverX != null ? (
              <g>
                <line x1={hoverX} x2={hoverX} y1={padding.top} y2={height - padding.bottom} stroke="#0f172a" strokeWidth="1" strokeDasharray="3 3" />
                <rect x={tooltipX} y="28" width="204" height="154" rx="4" fill="#ffffff" stroke="#cbd5e1" />
                <TooltipText x={tooltipX + 10} y={48} label={`${formatDate(displayDate(hovered))} ${formatTime(displayTime(hovered))} KST`} bold />
                <TooltipText x={tooltipX + 10} y={68} label={`O ${formatPrice(hovered.open)}  H ${formatPrice(hovered.high)}`} />
                <TooltipText x={tooltipX + 10} y={88} label={`L ${formatPrice(hovered.low)}  C ${formatPrice(hovered.close)}`} />
                <TooltipText x={tooltipX + 10} y={108} label={`Vol ${formatNumber(hovered.volume)}`} />
                <TooltipText x={tooltipX + 10} y={128} label={`BB ${formatPrice(hoveredOverlay.bbLower)} / ${formatPrice(hoveredOverlay.bbMid)} / ${formatPrice(hoveredOverlay.bbUpper)}`} />
                <TooltipText x={tooltipX + 10} y={148} label={`VWAP ${formatPrice(hoveredOverlay.vwap)}`} />
                <TooltipText x={tooltipX + 10} y={168} label={`EMA9 ${formatPrice(hoveredOverlay.ema9)}  EMA20 ${formatPrice(hoveredOverlay.ema20)}`} />
              </g>
            ) : null}
            <g transform={`translate(${padding.left}, ${height - 9})`} fill="#64748b" fontSize="11">
              <text x="0" y="0">{formatTime(displayTime(visible[0]))}</text>
              <text x={plotWidth / 2 - 18} y="0">{formatTime(displayTime(visible[Math.floor(visible.length / 2)]))}</text>
              <text x={plotWidth - 38} y="0">{formatTime(displayTime(visible[visible.length - 1]))}</text>
            </g>
          </svg>
        ) : (
          <div className="flex h-80 items-center justify-center text-sm text-zinc-500">표시할 candle 데이터가 없습니다.</div>
        )}
        <div className="mt-3 flex flex-wrap gap-3 text-xs text-zinc-600">
          <Legend color="#dc2626" label="상승 캔들" />
          <Legend color="#2563eb" label="하락 캔들" />
          <Legend color="#60a5fa" label="Bollinger Band" dashed />
          <Legend color="#7c3aed" label="VWAP" />
          <Legend color="#f59e0b" label="EMA9" />
          <Legend color="#10b981" label="EMA20" />
        </div>
        <div className="mt-3 grid gap-2 text-xs text-zinc-600 sm:grid-cols-3">
          <span>BB 하단: {formatPrice(indicators.bb_lower)}</span>
          <span>VWAP: {formatPrice(indicators.vwap)}</span>
          <span>EMA9 / EMA20: {formatPrice(indicators.ema9)} / {formatPrice(indicators.ema20)}</span>
        </div>
      </div>
    </div>
  );
}

function TooltipText({ x, y, label, bold = false }: { x: number; y: number; label: string; bold?: boolean }) {
  return (
    <text x={x} y={y} fill="#0f172a" fontSize="11" fontWeight={bold ? "700" : "500"}>
      {label}
    </text>
  );
}

function Legend({ color, label, dashed = false }: { color: string; label: string; dashed?: boolean }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span
        className="inline-block h-0 w-6 border-t-2"
        style={{ borderColor: color, borderTopStyle: dashed ? "dashed" : "solid" }}
      />
      {label}
    </span>
  );
}

function buildOverlaySeries(candles: Candle[]): OverlayPoint[] {
  const closes = candles.map((candle) => toNumber(candle.close));
  const ema9 = emaSeries(closes, 9);
  const ema20 = emaSeries(closes, 20);
  const vwap = vwapSeries(candles);
  return candles.map((_, index) => {
    const window = closes.slice(Math.max(0, index - 19), index + 1).filter((value): value is number => value != null);
    if (window.length < 20) {
      return { bbUpper: null, bbMid: null, bbLower: null, vwap: vwap[index], ema9: ema9[index], ema20: ema20[index] };
    }
    const mid = average(window);
    const std = standardDeviation(window, mid);
    return {
      bbUpper: mid + 2 * std,
      bbMid: mid,
      bbLower: mid - 2 * std,
      vwap: vwap[index],
      ema9: ema9[index],
      ema20: ema20[index],
    };
  });
}

function emaSeries(values: (number | null)[], period: number) {
  const output: (number | null)[] = Array(values.length).fill(null);
  const clean: number[] = [];
  const multiplier = 2 / (period + 1);
  let ema: number | null = null;
  for (let index = 0; index < values.length; index += 1) {
    const value = values[index];
    if (value == null) {
      continue;
    }
    clean.push(value);
    if (clean.length < period) {
      continue;
    }
    if (clean.length === period) {
      ema = average(clean);
    } else if (ema != null) {
      ema = (value - ema) * multiplier + ema;
    }
    output[index] = ema;
  }
  return output;
}

function vwapSeries(candles: Candle[]) {
  const output: (number | null)[] = [];
  let totalVolume = 0;
  let totalNotional = 0;
  for (const candle of candles) {
    const high = toNumber(candle.high);
    const low = toNumber(candle.low);
    const close = toNumber(candle.close);
    const volume = toNumber(candle.volume) ?? 0;
    if (high == null || low == null || close == null || volume <= 0) {
      output.push(output[output.length - 1] ?? null);
      continue;
    }
    totalVolume += volume;
    totalNotional += ((high + low + close) / 3) * volume;
    output.push(totalVolume > 0 ? totalNotional / totalVolume : null);
  }
  return output;
}

function linePath(series: (number | null)[], xAt: (index: number) => number, yAt: (value: number) => number) {
  let path = "";
  let open = false;
  series.forEach((value, index) => {
    if (value == null) {
      open = false;
      return;
    }
    path += `${open ? "L" : "M"}${xAt(index).toFixed(1)} ${yAt(value).toFixed(1)} `;
    open = true;
  });
  return path.trim();
}

function areaPath(
  upper: (number | null)[],
  lower: (number | null)[],
  xAt: (index: number) => number,
  yAt: (value: number) => number,
) {
  const points = upper
    .map((value, index) => ({ index, upper: value, lower: lower[index] }))
    .filter((point): point is { index: number; upper: number; lower: number } => point.upper != null && point.lower != null);
  if (points.length < 2) {
    return "";
  }
  const top = points.map((point, index) => `${index === 0 ? "M" : "L"}${xAt(point.index).toFixed(1)} ${yAt(point.upper).toFixed(1)}`);
  const bottom = [...points].reverse().map((point) => `L${xAt(point.index).toFixed(1)} ${yAt(point.lower).toFixed(1)}`);
  return `${top.join(" ")} ${bottom.join(" ")} Z`;
}

function average(values: number[]) {
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function standardDeviation(values: number[], mean: number) {
  return Math.sqrt(values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / values.length);
}

function normalize(value: number, min: number, max: number) {
  if (!Number.isFinite(min) || !Number.isFinite(max) || max === min) {
    return 0.5;
  }
  return (value - min) / (max - min);
}

function formatDate(value: string | null | undefined) {
  if (!value || value.length !== 8) {
    return "-";
  }
  return `${value.slice(0, 4)}-${value.slice(4, 6)}-${value.slice(6, 8)}`;
}

function formatTime(value: string | null | undefined) {
  if (!value) {
    return "-";
  }
  const padded = value.padStart(6, "0");
  return `${padded.slice(0, 2)}:${padded.slice(2, 4)}`;
}

function displayDate(candle: Candle | null | undefined) {
  return candle?.korea_date ?? candle?.market_date;
}

function displayTime(candle: Candle | null | undefined) {
  return candle?.korea_time ?? candle?.market_time;
}

function formatPrice(value: unknown) {
  const number = toNumber(value);
  if (number == null) {
    return "-";
  }
  return number.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 4 });
}

function formatNumber(value: unknown) {
  const number = toNumber(value);
  if (number == null) {
    return "-";
  }
  return number.toLocaleString("en-US", { maximumFractionDigits: 4 });
}

function toNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value.replace(/,/g, ""));
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}
