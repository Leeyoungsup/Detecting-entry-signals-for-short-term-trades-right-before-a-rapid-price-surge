from datetime import datetime, timedelta, timezone

from app.core.config import Settings
from app.services import scanner
from app.domain.models import ScannerSnapshot


def test_daily_mover_passes_directional_impulse_during_pullback() -> None:
    row = {
        "change_1m_pct": -0.05,
        "change_10m_pct": -0.20,
        "mover_change_pct": 3.25,
    }

    assert scanner._passes_candidate_directional_impulse(row) is True


def test_non_mover_without_short_term_impulse_is_rejected() -> None:
    row = {
        "change_1m_pct": 0.05,
        "change_10m_pct": 0.20,
        "mover_change_pct": 2.95,
    }

    assert scanner._passes_candidate_directional_impulse(row) is False


def test_daily_mover_avoids_slow_large_cap_penalty() -> None:
    base = {
        "last": 10.0,
        "volume_1m": 50_000,
        "notional_1m": 500_000,
        "notional_10m": 50_000,
        "change_1m_pct": 0.05,
        "change_10m_pct": 0.20,
    }

    non_mover_score = scanner._liquidity_first_score({**base, "mover_change_pct": 2.0})
    mover_score = scanner._liquidity_first_score({**base, "mover_change_pct": 3.0})

    assert mover_score - non_mover_score == 20.0


def test_unsubscribed_candidate_stays_in_candidate_pool() -> None:
    candidate = ScannerSnapshot(
        symbol="TEST",
        company_name="Test Corp",
        scanner_score=42.0,
        reclaim_state="waiting_for_realtime_bars",
        selected_for_ws=False,
        selected_for_strategy=False,
    )

    merged = scanner._merge_realtime(candidate, None, subscribed_symbols=set())

    assert merged.selected_for_ws is False
    assert merged.selected_for_strategy is False
    assert merged.scanner_score == 42.0
    assert merged.reclaim_state == "waiting_for_subscription"
    assert merged.reject_reason is not None
    assert "후보" in merged.reject_reason

def test_websocket_stale_handles_alpaca_nanosecond_timestamps() -> None:
    fresh = datetime.now(timezone.utc).isoformat().replace("+00:00", "123Z")
    stale = (datetime.now(timezone.utc) - timedelta(seconds=120)).isoformat().replace("+00:00", "123Z")

    assert scanner._websocket_connection_stale({"status": "connected", "last_realtime_at": fresh}, max_age_sec=90) is False
    assert scanner._websocket_connection_stale({"status": "connected", "last_realtime_at": stale}, max_age_sec=90) is True


def test_websocket_starting_becomes_stale() -> None:
    started_at = (datetime.now(timezone.utc) - timedelta(seconds=120)).isoformat()

    assert scanner._websocket_connection_stale({"status": "starting", "started_at": started_at}, max_age_sec=90) is True


def test_subscription_pool_respects_paid_alpaca_capacity_above_twenty() -> None:
    rows = [
        {"symb": f"T{i:02d}", "scanner_score": 1.0}
        for i in range(35)
    ]

    symbols = scanner._symbols_from_ranking_rows(rows, top_n=30)

    assert len(symbols) == 30
    assert symbols[:3] == ["T00", "T01", "T02"]


def test_subscription_pool_ignores_strategy_reject_cooldown() -> None:
    symbol = "COOL"
    scanner._candidate_reject_cooldown_until[symbol] = datetime.now(timezone.utc) + timedelta(seconds=90)

    try:
        symbols = scanner._symbols_from_ranking_rows([{"symb": symbol, "scanner_score": 1.0}], top_n=1)
    finally:
        scanner._candidate_reject_cooldown_until.pop(symbol, None)

    assert symbols == [symbol]


def test_combined_rows_keep_mover_abs_rank_order_without_notional_rerank() -> None:
    rankings = {
        "trade_volume": {
            "output2": [
                {
                    "symb": "AAA",
                    "rank": 1,
                    "scanner_score": 100,
                    "mover_change_pct": -20.0,
                    "mover_abs_rank": 1,
                    "volume_1m": 500,
                    "volume_10m": 2_000,
                    "notional_10m": 1_000,
                    "last": 10.0,
                },
                {
                    "symb": "BBB",
                    "rank": 2,
                    "scanner_score": 99,
                    "mover_change_pct": 15.0,
                    "mover_abs_rank": 2,
                    "volume_1m": 10_000,
                    "volume_10m": 50_000,
                    "notional_10m": 500_000,
                    "last": 10.0,
                },
            ]
        }
    }

    scanner._candidate_pool_rows.clear()
    try:
        rows = scanner._combined_ranking_rows(rankings, top_n=2)
    finally:
        scanner._candidate_pool_rows.clear()

    assert [row["symb"] for row in rows] == ["AAA", "BBB"]


def test_scanner_price_filter_is_exclusive_at_twenty(monkeypatch) -> None:
    monkeypatch.setattr(
        scanner,
        "get_settings",
        lambda: Settings(scanner_min_price_usd=0.5, scanner_max_price_usd=20.0),
    )

    assert scanner._outside_scanner_price_range({"last": 19.99}) is False
    assert scanner._outside_scanner_price_range({"last": 20.0}) is True
    assert scanner._outside_scanner_price_range({"last": 20.01}) is True


def test_combined_rows_overfetch_keeps_under_twenty_candidates(monkeypatch) -> None:
    monkeypatch.setattr(
        scanner,
        "get_settings",
        lambda: Settings(
            scanner_min_price_usd=0.5,
            scanner_max_price_usd=20.0,
            scanner_min_candidate_score=0.0,
            scanner_candidate_universe_size=100,
        ),
    )
    high_price_rows = [
        {
            "symb": f"BIG{i:02d}",
            "rank": i + 1,
            "toss_wts_rank": i + 1,
            "screener_source": "toss_rankings_api",
            "scanner_score": 100 - i,
            "last": 20.0 + i,
        }
        for i in range(10)
    ]
    low_price_rows = [
        {
            "symb": f"LOW{i:02d}",
            "rank": i + 11,
            "toss_wts_rank": i + 11,
            "screener_source": "toss_rankings_api",
            "scanner_score": 90 - i,
            "last": 19.99 - (i * 0.01),
        }
        for i in range(35)
    ]

    scanner._candidate_pool_rows.clear()
    try:
        rows = scanner._combined_ranking_rows(
            {"trade_volume": {"output2": [*high_price_rows, *low_price_rows]}},
            top_n=30,
        )
    finally:
        scanner._candidate_pool_rows.clear()

    assert len(rows) == 30
    assert all(row["symb"].startswith("LOW") for row in rows)
    assert all(float(row["last"]) < 20.0 for row in rows)


def test_active_paper_position_is_included_on_candidate_refresh(monkeypatch) -> None:
    rows = [
        {"symb": f"M{i:02d}", "scanner_score": 100 - i}
        for i in range(30)
    ]

    monkeypatch.setattr(scanner, "_load_manual_candidates", lambda: None)
    monkeypatch.setattr(scanner, "_active_paper_symbols", lambda: ["HOLD"])
    monkeypatch.setattr(scanner, "_hydrate_manual_candidate_row", lambda row, symbol: row)
    scanner._manual_candidates.clear()

    merged = scanner._with_manual_candidate_rows(rows)

    assert len(merged) == 30
    assert merged[0]["symb"] == "HOLD"
    assert merged[0]["active_paper_position"] is True
    assert "M29" not in {row["symb"] for row in merged}


def test_realtime_subscription_matches_refreshed_candidate_batch_with_position(monkeypatch) -> None:
    ranking_rows = [
        {
            "symb": f"M{i:02d}",
            "scanner_score": 100 - i,
            "rank": i + 1,
            "toss_wts_rank": i + 1,
            "screener_source": "toss_wts_biggest_total_amount",
        }
        for i in range(30)
    ]
    monkeypatch.setattr(scanner, "_get_rankings_for_realtime", lambda exchange: {"trade_volume": {"output2": ranking_rows}})
    monkeypatch.setattr(scanner, "_ranking_rows_or_fallback", lambda rows, top_n: rows)
    monkeypatch.setattr(scanner, "_active_paper_symbols", lambda: ["HOLD"])
    monkeypatch.setattr(scanner, "_load_manual_candidates", lambda: None)
    scanner._manual_candidates.clear()

    symbols = scanner._requested_realtime_symbols(exchange="NAS", top_n=30)

    assert len(symbols) == 30
    assert symbols[0] == "HOLD"
    assert "M28" in symbols
    assert "M29" not in symbols
