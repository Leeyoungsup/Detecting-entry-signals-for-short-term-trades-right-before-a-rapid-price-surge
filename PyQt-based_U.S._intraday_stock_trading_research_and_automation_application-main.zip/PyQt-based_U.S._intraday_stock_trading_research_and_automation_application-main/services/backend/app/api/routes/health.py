from fastapi import APIRouter

from app.core.config import get_settings
from app.services.execution_gateway import ExecutionGatewayService
from app.services.market_data import get_market_data_service

router = APIRouter()


@router.get("/health")
def health() -> dict:
    settings = get_settings()
    market_data = get_market_data_service()
    execution_status = ExecutionGatewayService().status()
    return {
        "status": "ok",
        "trading_mode": settings.trading_mode,
        "live_enabled": settings.live_enabled,
        "live_order_enabled": execution_status.get("live_order_enabled", False),
        "kis_live_enabled": settings.kis_live_enabled,
        "legacy_kis_live_enabled": settings.kis_live_enabled,
        "market_data_provider": market_data.provider_name,
        "configured_market_data_provider": settings.market_data_provider,
        "external_market_data_enabled": settings.external_market_data_enabled,
        "execution_provider": execution_status.get("provider"),
        "execution_status": execution_status.get("status"),
        "execution_role": "toss_account_preview_or_legacy_debug",
        "kis_role": "legacy_fallback_debug",
        "legacy_kis_role": "fallback_debug_only",
        "strategy_validated": settings.strategy_validated,
    }
