from app.adapters.market_data import alpaca as alpaca_module
from app.adapters.market_data.alpaca import AlpacaMarketDataProvider
from app.adapters.toss import wts_ranking
from app.adapters.toss.wts_ranking import TossWtsRankingClient
from app.core.config import Settings


def test_toss_wts_ranking_rows_normalize_symbols_and_rank_order(monkeypatch) -> None:
    settings = Settings()
    client = TossWtsRankingClient(settings)

    monkeypatch.setattr(
        client,
        "_crawl_rendered_rows",
        lambda: [
            {
                "productCode": "US:ZCMD",
                "companyName": "Zhongchao",
                "industry": "Education",
                "marketCapUsd": 1_000_000,
                "tossSecuritiesAmount": 500_000_000,
                "tossSecuritiesBuy": 60,
                "tossSecuritiesSell": 40,
            },
            {"productCode": "CWD.US", "companyName": "CaliberCos"},
        ],
    )

    rows = client.biggest_total_amount_rows(limit=10)

    assert [row["symb"] for row in rows] == ["ZCMD", "CWD"]
    assert rows[0]["toss_wts_rank"] == 1
    assert rows[0]["screener_source"] == "toss_wts_biggest_total_amount"
    assert rows[0]["industry"] == "Education"
    assert rows[0]["market_cap_usd"] == 1_000_000
    assert rows[0]["toss_trade_amount_krw"] == 500_000_000
    assert rows[0]["toss_buy_ratio_pct"] == 60.0
    assert rows[1]["company_name"] == "CaliberCos"


def test_toss_wts_anchor_rows_extract_stock_links_once() -> None:
    rows = wts_ranking._extract_anchor_rows(
        [
            {
                "href": "https://www.tossinvest.com/stocks/NAS0240124005/order",
                "text": "1\nSU \uadf8\ub8f9 \ud640\ub529\uc2a4",
                "section": "\ud1a0\uc2a4\uc99d\uad8c \uac70\ub798\ub300\uae08",
            },
            {
                "href": "https://www.tossinvest.com/stocks/US20100311002/order",
                "text": "2\nSOXL",
                "section": "\ud1a0\uc2a4\uc99d\uad8c \uac70\ub798\ub300\uae08",
            },
            {
                "href": "https://www.tossinvest.com/stocks/US20100311002/order",
                "text": "1,562\uc6d0",
                "section": "\ud1a0\uc2a4\uc99d\uad8c \uac70\ub798\ub300\uae08",
            },
            {
                "href": "https://www.tossinvest.com/stocks/AMX0260127004/order",
                "text": "9\nSNXX",
                "section": "\ud1a0\uc2a4\uc99d\uad8c \uac70\ub798\ub300\uae08",
            },
            {"href": "https://www.tossinvest.com/stocks/US20100311002/order", "text": "duplicate"},
            {"href": "https://www.tossinvest.com/investment-disclaimers", "text": "investment notice"},
        ],
        stock_info_by_code={
            "NAS0240124005": {"symbol": "SUGP", "companyName": "SU Group", "currency": "USD"},
            "US20100311002": {"symbol": "SOXL", "companyName": "SOXL", "currency": "USD"},
            "AMX0260127004": {"symbol": "SNXX", "companyName": "SNXX", "currency": "USD"},
        },
    )

    assert [row["productCode"] for row in rows] == ["SUGP", "SOXL", "SNXX"]
    assert rows[0]["companyName"] == "SU Group"
    assert rows[0]["rank"] == 1


def test_toss_wts_anchor_rows_do_not_guess_internal_product_codes() -> None:
    rows = wts_ranking._extract_anchor_rows(
        [
            {
                "href": "https://www.tossinvest.com/stocks/NAS0240124005/order",
                "text": "1\nSU \uadf8\ub8f9 \ud640\ub529\uc2a4",
                "section": "\ud1a0\uc2a4\uc99d\uad8c \uac70\ub798\ub300\uae08",
            }
        ]
    )

    assert rows == []


def test_alpaca_scanner_uses_toss_seed_as_primary_order(monkeypatch) -> None:
    provider = AlpacaMarketDataProvider(
        Settings(
            alpaca_key="key",
            alpaca_secret="secret",
            scanner_candidate_source="toss_biggest_total_amount",
            scanner_max_websocket_symbols=3,
            scanner_candidate_universe_size=3,
        )
    )

    monkeypatch.setattr(
        alpaca_module.TossWtsRankingClient,
        "biggest_total_amount_rows",
        lambda self, limit=30: [
            {
                "symb": "ZCMD",
                "rank": 1,
                "toss_wts_rank": 1,
                "scanner_score": 100,
                "screener_source": "toss_wts_biggest_total_amount",
            },
            {
                "symb": "CWD",
                "rank": 2,
                "toss_wts_rank": 2,
                "scanner_score": 99,
                "screener_source": "toss_wts_biggest_total_amount",
            },
            {
                "symb": "YRD",
                "rank": 3,
                "toss_wts_rank": 3,
                "scanner_score": 98,
                "screener_source": "toss_wts_biggest_total_amount",
            },
        ],
    )
    monkeypatch.setattr(provider, "_mover_symbols", lambda limit=100: [])
    monkeypatch.setattr(
        provider,
        "_assets_for_symbols",
        lambda symbols: {
            symbol: {"class": "us_equity", "status": "active", "name": f"{symbol} Inc.", "tradable": True}
            for symbol in symbols
        },
    )
    monkeypatch.setattr(provider, "_snapshots", lambda symbols: {})
    monkeypatch.setattr(
        provider,
        "_recent_minute_bars",
        lambda symbols, limit=10: {
            symbol: [{"t": "2026-07-07T12:00:00Z", "o": 10.0, "h": 10.2, "l": 9.9, "c": 10.1, "v": 2000}]
            for symbol in symbols
        },
    )

    rows = provider.scanner_rankings()["trade_volume"]["output2"]

    assert [row["symb"] for row in rows] == ["ZCMD", "CWD", "YRD"]
    assert {row["screener_source"] for row in rows} == {"toss_wts_biggest_total_amount"}
