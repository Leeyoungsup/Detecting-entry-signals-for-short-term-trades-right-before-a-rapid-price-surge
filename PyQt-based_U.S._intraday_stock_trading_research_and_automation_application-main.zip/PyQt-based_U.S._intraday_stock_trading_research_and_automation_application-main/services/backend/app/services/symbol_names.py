NAME_FIELD_CANDIDATES = (
    "company_name",
    "name",
    "item_name",
    "symbol_name",
    "ovrs_item_name",
    "ovrs_pdno_name",
    "prdt_name",
    "prod_name",
    "hts_kor_isnm",
    "kor_isnm",
    "korea_name",
    "Korea name",
    "eng_name",
    "english_name",
    "English name",
    "hts_eng_isnm",
)

COMMON_SYMBOL_NAMES: dict[str, str] = {
    "AAPL": "Apple Inc.",
    "MSFT": "Microsoft Corp.",
    "NVDA": "NVIDIA Corp.",
    "TSLA": "Tesla Inc.",
    "AMZN": "Amazon.com Inc.",
    "GOOGL": "Alphabet Inc. Class A",
    "GOOG": "Alphabet Inc. Class C",
    "META": "Meta Platforms Inc.",
    "AVGO": "Broadcom Inc.",
    "AMD": "Advanced Micro Devices Inc.",
    "MU": "Micron Technology Inc.",
    "SMCI": "Super Micro Computer Inc.",
    "PLTR": "Palantir Technologies Inc.",
    "NFLX": "Netflix Inc.",
    "QQQ": "Invesco QQQ Trust",
    "SPY": "SPDR S&P 500 ETF Trust",
    "IWM": "iShares Russell 2000 ETF",
    "TQQQ": "ProShares UltraPro QQQ",
    "SQQQ": "ProShares UltraPro Short QQQ",
    "SOXL": "Direxion Daily Semiconductor Bull 3X Shares",
    "SOXS": "Direxion Daily Semiconductor Bear 3X Shares",
    "BCRX": "BioCryst Pharmaceuticals Inc.",
}


def extract_symbol_name(row: dict | None) -> str | None:
    if not row:
        return None
    for key in NAME_FIELD_CANDIDATES:
        value = row.get(key)
        if value is None:
            continue
        name = str(value).strip()
        if name and name not in {"-", "0", "None", "null"}:
            return name
    return None


def resolve_symbol_name(symbol: str, row: dict | None = None) -> str | None:
    raw_name = extract_symbol_name(row)
    if raw_name:
        return raw_name
    return COMMON_SYMBOL_NAMES.get(symbol.upper())
