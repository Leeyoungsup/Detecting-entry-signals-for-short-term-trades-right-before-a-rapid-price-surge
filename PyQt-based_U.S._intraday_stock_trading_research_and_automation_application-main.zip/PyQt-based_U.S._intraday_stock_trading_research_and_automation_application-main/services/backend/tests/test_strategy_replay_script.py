import importlib.util
import sys
from pathlib import Path

import pytest


def _load_replay_module():
    root = Path(__file__).resolve().parents[3]
    path = root / "scripts" / "replay_tc_shadow_strategies.py"
    spec = importlib.util.spec_from_file_location("replay_tc_shadow_strategies_test", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["replay_tc_shadow_strategies_test"] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_replay_uses_10bar_close_change_not_average_range_for_expectancy() -> None:
    replay = _load_replay_module()
    rows = []
    for index in range(10):
        close = 10.0 + (index * 0.1)
        rows.append(
            {
                "timestamp_kst": f"2026-01-02 09:{30 + index:02d}:00",
                "open": close,
                "high": close + 0.01,
                "low": close - 0.01,
                "close": close,
                "volume": 10_000,
                "volume_ma20": 8_000,
                "range_pct": 0.2,
            }
        )

    change = replay.recent_10bar_change_fraction(rows, 9)
    expected = replay.conservative_expected_upside_fraction(rows, 9)

    assert round(change, 4) == 0.09
    assert expected > 0.03


def test_trailing_stop_fill_uses_runtime_like_current_bid_cap() -> None:
    replay = _load_replay_module()
    row = {
        "first_bid": 9.0,
        "last_bid": 9.0,
        "avg_bid": 9.0,
        "min_bid": 8.0,
        "avg_spread_pct": 0.5,
    }

    price = replay.execution_price(10.0, row, "sell", reason="intrabar_trailing_stop_after_profit")

    assert price == pytest.approx(10.0 * (1 - replay.STOP_SLIPPAGE_CAP_PCT))


def test_structure_stop_fill_is_capped_by_slippage_guard() -> None:
    replay = _load_replay_module()
    # min_bid gapped far below the stop trigger; without the guard the fill would
    # be 8.0 * (1 - 0.0015) = 7.988. The guard floors it at trigger*(1-cap).
    row = {
        "first_bid": 9.0,
        "last_bid": 9.0,
        "avg_bid": 9.0,
        "min_bid": 8.0,
        "avg_spread_pct": 0.5,
    }

    price = replay.execution_price(10.0, row, "sell", reason="structure_or_final_stop")

    assert price == pytest.approx(10.0 * (1 - replay.STOP_SLIPPAGE_CAP_PCT))


def test_prefill_spread_guard_applies_to_surge_pullback() -> None:
    replay = _load_replay_module()
    rows = [{"first_bid": 4.68, "first_ask": 7.0}]
    signal = {
        "strategy": "Surge Pullback Reclaim",
        "signal_close": 6.95,
    }

    assert replay.prefill_entry_ok(rows, 0, signal) is False
    assert signal["reject_at_fill"] == "prefill_first_spread_too_wide"


def test_replay_vwap_gate_allows_strong_10bar_momentum_below_vwap() -> None:
    replay = _load_replay_module()
    rows = []
    for index in range(10):
        close = 10.0 + (index * 0.06)
        rows.append(
                {
                    "timestamp_kst": f"2026-01-02 09:{30 + index:02d}:00",
                    "open": close - 0.01,
                    "high": close + 0.005,
                    "low": close - 0.02,
                "close": close,
                "volume": 20_000,
                "volume_ma20": 10_000,
                "session_vwap": 11.0,
                "trade_strength": 75.0,
                "sell_pressure": 30.0,
            }
        )

    assert replay.above_vwap(rows[-1]) is False
    assert replay.vwap_or_strong_momentum(rows, 9) is True


def test_replay_blocks_strategy_reentry_after_loss() -> None:
    replay = _load_replay_module()
    portfolio = replay.Portfolio(strategy="Surge Pullback Reclaim")
    portfolio.last_exit_index = 20
    portfolio.last_exit_net_pnl = -1.0

    assert replay.strategy_reentry_allowed(portfolio, 25, portfolio.strategy) is False
    assert replay.strategy_reentry_allowed(portfolio, 31, portfolio.strategy) is True


def test_replay_registers_current_scalp_strategy_set() -> None:
    replay = _load_replay_module()

    assert list(replay.STRATEGIES) == [
        "First Pullback After Volume Shock",
        "Micro Breakout With Absorption",
    ]
    assert replay.ARCHIVED_STRATEGIES == {
        "Liquidity Sweep Reclaim": replay.signal_liquidity_sweep_reclaim,
        "Surge Pullback Reclaim": replay.signal_surge_pullback,
    }


def test_replay_blocks_symbol_reentry_after_loss_cluster() -> None:
    replay = _load_replay_module()
    latest_loss_index = 30
    portfolios = {
        "a": replay.Portfolio(strategy="a", last_exit_index=20, last_exit_net_pnl=-1.0),
        "b": replay.Portfolio(strategy="b", last_exit_index=latest_loss_index, last_exit_net_pnl=-1.0),
        "c": replay.Portfolio(strategy="c", last_exit_index=5, last_exit_net_pnl=2.0),
    }

    # Still within the per-symbol loss re-entry cooldown after the latest loss -> blocked.
    within_cooldown = latest_loss_index + replay.SYMBOL_LOSS_REENTRY_COOLDOWN_BARS - 1
    assert replay.symbol_reentry_allowed(portfolios, within_cooldown) is False
    # Well past the symbol cooldown, the cluster lookback and the cluster cooldown -> allowed.
    past_all = (
        latest_loss_index
        + max(replay.SYMBOL_LOSS_REENTRY_COOLDOWN_BARS, replay.LOSS_CLUSTER_LOOKBACK_BARS)
        + replay.LOSS_CLUSTER_COOLDOWN_BARS
        + 1
    )
    assert replay.symbol_reentry_allowed(portfolios, past_all) is True


def test_stop_price_can_ignore_current_entry_bar_structure() -> None:
    replay = _load_replay_module()
    rows = [
        {"low": 9.95},
        {"low": 9.96},
        {"low": 9.70},
    ]

    completed_only_stop = replay.stop_price(rows, 2, 10.0, include_current=False)
    current_bar_peek_stop = replay.stop_price(rows, 2, 10.0, include_current=True)

    assert completed_only_stop == pytest.approx(9.95 * (1 - replay.STRUCTURE_STOP_BUFFER))
    assert current_bar_peek_stop == pytest.approx(9.70 * (1 - replay.STRUCTURE_STOP_BUFFER))


def test_synthetic_low_first_path_exits_structure_stop_before_reclaim_high() -> None:
    replay = _load_replay_module()
    rows = [
        {"timestamp_kst": "2026-01-02 09:30:00", "open": 10.0, "high": 10.0, "low": 10.0, "close": 10.0},
        {"timestamp_kst": "2026-01-02 09:31:00", "open": 10.0, "high": 10.5, "low": 9.8, "close": 10.4},
    ]
    portfolio = replay.Portfolio(
        strategy="Liquidity Pullback Reclaim",
        position=replay.Position(
            strategy="Liquidity Pullback Reclaim",
            entry_index=0,
            entry_time="2026-01-02 09:30:00",
            entry_price=10.0,
            quantity=10,
            reason="test",
            indicators={},
            stop_price=9.9,
            high_watermark=10.0,
        ),
    )

    assert replay.apply_synthetic_tick_path(rows, 1, portfolio, "low_first") is True
    assert portfolio.position is None
    assert portfolio.trades[-1]["exit_reason"] == "stop_loss_confirmed"


def test_synthetic_high_first_path_holds_trailing_without_runtime_weakness() -> None:
    replay = _load_replay_module()
    rows = [
        {"timestamp_kst": "2026-01-02 09:30:00", "open": 10.0, "high": 10.0, "low": 10.0, "close": 10.0},
        {"timestamp_kst": "2026-01-02 09:31:00", "open": 10.0, "high": 10.2, "low": 9.8, "close": 10.0},
    ]
    portfolio = replay.Portfolio(
        strategy="Liquidity Pullback Reclaim",
        position=replay.Position(
            strategy="Liquidity Pullback Reclaim",
            entry_index=0,
            entry_time="2026-01-02 09:30:00",
            entry_price=10.0,
            quantity=10,
            reason="test",
            indicators={},
            stop_price=9.5,
            high_watermark=10.0,
        ),
    )

    assert replay.apply_synthetic_tick_path(rows, 1, portfolio, "high_first") is False
    assert portfolio.position is not None
    assert portfolio.trades == []
