from datetime import datetime, timezone, timedelta

from app.adapters.toss.client import TossApiError, TossExecutionClient
from app.core.config import get_settings
from app.domain.enums import RealtimeEventType, StatusLevel
from app.domain.models import OrderRequest
from app.services.candle_builder import candle_builder
from app.services.event_log import record_event
from app.services.event_bus import event_bus
from app.services.execution_pricing import ExecutionPricingError, execution_market_snapshot, execution_quote_snapshot
from app.services.fee_model import toss_fee_breakdown
from app.services import live_decision_log
from app.services.live_broker import LiveBroker
from app.services.market_session import us_equity_session
from app.services.market_data import get_market_data_service
from app.services.paper_broker import InternalPaperBroker
from app.services.risk_manager import RiskManager
from app.services.short_runtime import short_track_runtime
from app.services.strategy_decision import (
    DynamicTakeProfitConfig,
    EMERGENCY_EXIT_REASONS,
    EntryFillGateConfig,
    ExitDecisionConfig,
    ExitDecisionIndicators,
    ExitDecisionPosition,
    advance_trailing_stop,
    bounded_stop_exit_price,
    choose_dynamic_trailing_pct,
    evaluate_exit_decision,
    evaluate_entry_fill_gate,
    is_profit_exit_reason,
    update_dynamic_take_profit_target,
)
from app.services.strategy_engine import (
    _high_failure_count,
    _indicator_snapshot,
    _macd_recovery_status,
    _normalize_candles,
)


class StrategyRuntime:
    def __init__(self) -> None:
        self._last_evaluated_bucket: dict[str, str] = {}
        self._last_ordered_bucket: dict[str, str] = {}
        self._last_wait_log_at: dict[str, datetime] = {}
        self._last_gap_log_at: dict[str, datetime] = {}
        self._macd_fading_since: dict[str, datetime] = {}
        self._position_quote_blocked_until: dict[str, datetime] = {}
        self._position_quote_cursor = 0

    def on_trade(self, event: dict, candle: dict | None) -> None:
        if not candle:
            return
        symbol = str(event.get("symbol") or "").upper()
        bucket = _bucket(candle)
        if not symbol or not bucket:
            return
        settings = get_settings()
        if not (settings.execution_provider == "toss" and settings.toss_position_quote_monitor_enabled):
            self._monitor_exit(symbol, event, candle)
        if self._last_evaluated_bucket.get(symbol) == bucket and not candle.get("is_live"):
            return
        self._last_evaluated_bucket[symbol] = bucket

        candles, candle_mode = _strategy_candle_window(symbol)
        if len(candles) < _required_candle_count(candle_mode):
            self._record_waiting_for_candles(symbol, len(candles), candle_mode)
            return
        if candle_mode == "official_gap_fallback" and _gap_minutes(candles[-1], candle) > get_settings().strategy_max_candle_gap_minutes:
            self._record_candle_gap(symbol, candles[-1], candle)
            return
        # Short track (extreme-fade) evaluates on the completed candle window,
        # independent of the long entry path (which is disabled). Self-gated by
        # strategy_short_track_enabled + internal_paper; never raises.
        # Long entry generation removed 2026-07-20 (short-only track). The runtime
        # no longer evaluates long strategies; short_track_runtime handles entries.
        short_track_runtime.on_completed_candle(symbol, bucket, candles)

    def _record_live_strategy_candidate(
        self,
        symbol: str,
        bucket: str,
        entry_price: float,
        candles: list[dict],
        evaluation: dict,
        shared_market_snapshot: dict | None = None,
    ) -> None:
        settings = get_settings()
        parameter_set_id = str(evaluation.get("parameter_set_id") or "entry-pattern")
        order_memory_key = f"{symbol}::{parameter_set_id}::live"
        if self._last_ordered_bucket.get(order_memory_key) == bucket:
            return
        market_snapshot = shared_market_snapshot or execution_market_snapshot(symbol, side="buy")
        entry_ref_price = _to_float(market_snapshot.get("ask")) or _to_float(market_snapshot.get("last"))
        entry_gate = evaluate_entry_fill_gate(
            bid=_to_float(market_snapshot.get("bid")),
            ask=_to_float(market_snapshot.get("ask")),
            last=_to_float(market_snapshot.get("last")),
            spread_pct=_to_float(market_snapshot.get("spread_pct")),
            max_spread_pct=_max_entry_spread_pct(evaluation, last_price=entry_ref_price),
            signal_close=_to_float((evaluation.get("indicators") or {}).get("close")),
            strategy_name=str(evaluation.get("strategy_name") or ""),
            config=EntryFillGateConfig(
                entry_slippage_pct=settings.paper_entry_slippage_pct,
                max_chase_pct=settings.paper_entry_max_chase_pct,
                min_price_usd=settings.scanner_min_price_usd,
                runner_negative_chase_pct=settings.paper_entry_max_chase_pct,
            ),
        )
        if not entry_gate.allowed or entry_gate.execution_price is None:
            record_event(
                level="WARNING" if entry_gate.reason in {"spread_too_wide", "missing_ask_or_last"} else "INFO",
                event_type="live.order_blocked",
                message=f"Live strategy candidate blocked by entry fill gate: {entry_gate.reason}",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={
                    "bucket": bucket,
                    "provider": "toss",
                    "strategy_name": evaluation.get("strategy_name"),
                    "parameter_set_id": parameter_set_id,
                    "entry_gate_reason": entry_gate.reason,
                    "live_order_called": False,
                    **entry_gate.payload,
                },
            )
            return

        execution_price = entry_gate.execution_price
        execution_risk = RiskManager().preview_long_entry(
            account_equity_usd=settings.paper_initial_equity_usd,
            entry_price=execution_price,
            stop_loss_price=_dynamic_stop_loss_price(
                execution_price,
                candles,
                market_snapshot=market_snapshot,
                evaluation=evaluation,
            ),
        )
        risk_quantity = float(execution_risk.quantity or 0.0)
        capped_quantity = min(risk_quantity, float(settings.toss_live_max_quantity or 0.0))
        if execution_price > 0 and settings.toss_live_max_order_notional_usd > 0:
            capped_quantity = min(capped_quantity, int(settings.toss_live_max_order_notional_usd / execution_price))
        if capped_quantity <= 0:
            record_event(
                level="INFO",
                event_type="live.order_blocked",
                message="Live strategy candidate blocked by live quantity/notional caps.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={
                    "bucket": bucket,
                    "strategy_name": evaluation.get("strategy_name"),
                    "parameter_set_id": parameter_set_id,
                    "execution_price": execution_price,
                    "risk_quantity": risk_quantity,
                    "max_quantity": settings.toss_live_max_quantity,
                    "max_notional_usd": settings.toss_live_max_order_notional_usd,
                    "live_order_called": False,
                },
            )
            self._last_ordered_bucket[order_memory_key] = bucket
            return

        client = TossExecutionClient(settings)
        live_order_enabled = client.live_order_enabled()
        preview = market_snapshot.get("toss_preview") if isinstance(market_snapshot.get("toss_preview"), dict) else None
        try:
            if preview is None:
                preview = client.execution_preview(symbol=symbol, side="buy", currency="USD")
        except TossApiError as exc:
            record_event(
                level="WARNING",
                event_type="live.order_blocked",
                message="Toss live preview failed; live strategy order was not submitted.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={
                    "bucket": bucket,
                    "strategy_name": evaluation.get("strategy_name"),
                    "parameter_set_id": parameter_set_id,
                    "error": str(exc),
                    "status_code": exc.status_code,
                    "payload": exc.payload,
                    "live_order_called": False,
                },
            )
            self._last_ordered_bucket[order_memory_key] = bucket
            return

        market_snapshot["strategy_reference_price"] = entry_price
        market_snapshot["execution_price"] = execution_price
        market_snapshot["execution_price_source"] = market_snapshot.get("source")
        market_snapshot["strategy_name"] = evaluation.get("strategy_name")
        market_snapshot["parameter_set_id"] = evaluation.get("parameter_set_id")
        market_snapshot["entry_mode"] = evaluation.get("entry_mode")
        market_snapshot["risk_preview"] = execution_risk.model_dump()
        market_snapshot["toss_preview"] = preview
        exit_plan = _entry_exit_plan(
            execution_price,
            candles,
            quantity=capped_quantity,
            market_snapshot=market_snapshot,
            evaluation=evaluation,
        )
        if exit_plan.get("entry_viable") is False:
            record_event(
                level="INFO",
                event_type="live.order_blocked",
                message="Live buy blocked because expected upside does not clear estimated round-trip cost and edge floor.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={
                    "bucket": bucket,
                    "provider": "toss",
                    "strategy_name": evaluation.get("strategy_name"),
                    "parameter_set_id": parameter_set_id,
                    "execution_price": execution_price,
                    "required_profit_pct": exit_plan.get("required_profit_pct"),
                    "estimated_roundtrip_cost_pct": exit_plan.get("estimated_roundtrip_cost_pct"),
                    "expected_upside_pct": (exit_plan.get("expected_upside") or {}).get("expected_upside_pct"),
                    "entry_viability_reason": exit_plan.get("entry_viability_reason"),
                    "live_order_called": False,
                },
            )
            self._last_ordered_bucket[order_memory_key] = bucket
            return
        market_snapshot["exit_plan"] = exit_plan
        market_snapshot["entry_snapshot"] = _entry_chart_snapshot(
            symbol=symbol,
            bucket=bucket,
            entry_price=entry_price,
            execution_price=execution_price,
            candles=candles,
            evaluation=evaluation,
            execution_market=market_snapshot,
        )
        live_order_called = bool(live_order_enabled and settings.toss_live_auto_trade_enabled)
        record_event(
            level="WARNING" if live_order_called else "INFO",
            event_type="live.order_candidate",
            message="Live mode strategy signal passed.",
            severity=StatusLevel.CAUTION if live_order_called else StatusLevel.BLOCKED,
            symbol=symbol,
            payload={
                "bucket": bucket,
                "provider": "toss",
                "strategy_name": evaluation.get("strategy_name"),
                "parameter_set_id": parameter_set_id,
                "entry_mode": evaluation.get("entry_mode"),
                "final_score": evaluation.get("final_score"),
                "reference_price": entry_price,
                "execution_price": execution_price,
                "risk_quantity": risk_quantity,
                "capped_quantity": capped_quantity,
                "estimated_notional_usd": round(execution_price * capped_quantity, 4),
                "max_quantity": settings.toss_live_max_quantity,
                "max_notional_usd": settings.toss_live_max_order_notional_usd,
                "max_open_positions": settings.toss_live_max_open_positions,
                "max_total_exposure_usd": settings.toss_live_max_total_exposure_usd,
                "live_order_enabled": live_order_enabled,
                "live_auto_trade_enabled": settings.toss_live_auto_trade_enabled,
                "live_order_called": live_order_called,
                "preview": preview,
                "risk_preview": execution_risk.model_dump(),
                "evaluation": evaluation,
            },
        )
        _log_live_decision(
            side="buy",
            symbol=symbol,
            strategy=evaluation.get("strategy_name"),
            parameter_set_id=parameter_set_id,
            bucket=bucket,
            reason=evaluation.get("entry_mode"),
            price=execution_price,
            quantity=capped_quantity,
            candles=candles,
            market_snapshot=market_snapshot,
        )
        try:
            LiveBroker(settings=settings, client=client).submit_entry_order(
                symbol=symbol,
                quantity=capped_quantity,
                market_snapshot=market_snapshot,
                strategy_signal_id=f"{parameter_set_id}-{symbol}-{bucket}",
            )
        except TossApiError as exc:
            record_event(
                level="ERROR",
                event_type="live.order_error",
                message="Toss live strategy order submission failed.",
                severity=StatusLevel.EMERGENCY,
                symbol=symbol,
                payload={
                    "bucket": bucket,
                    "strategy_name": evaluation.get("strategy_name"),
                    "parameter_set_id": parameter_set_id,
                    "error": str(exc),
                    "status_code": exc.status_code,
                    "payload": exc.payload,
                },
            )
        self._last_ordered_bucket[order_memory_key] = bucket

    def _submit_internal_paper_order(
        self,
        symbol: str,
        bucket: str,
        entry_price: float,
        candles: list[dict],
        risk: dict,
        evaluation: dict,
        shared_market_snapshot: dict | None = None,
    ) -> None:
        settings = get_settings()
        parameter_set_id = str(evaluation.get("parameter_set_id") or "entry-pattern")
        order_memory_key = f"{symbol}::{parameter_set_id}"
        if settings.trading_mode != "internal_paper":
            record_event(
                level="INFO",
                event_type="paper.order_blocked",
                message="internal_paper 모드가 아니어서 시뮬레이션 주문을 생성하지 않았습니다.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={"trading_mode": settings.trading_mode},
            )
            return
        if self._last_ordered_bucket.get(order_memory_key) == bucket:
            return
        broker = InternalPaperBroker()
        if broker.has_exposure(symbol, parameter_set_id=parameter_set_id):
            record_event(
                level="INFO",
                event_type="paper.order_blocked",
                message="동일 종목/전략 포지션 또는 주문이 있어 시뮬레이션 주문을 차단했습니다.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={"bucket": bucket, "parameter_set_id": parameter_set_id, "strategy_name": evaluation.get("strategy_name")},
            )
            return
        cooldown_remaining_sec = _loss_cooldown_remaining_sec(symbol, broker, parameter_set_id=parameter_set_id)
        if cooldown_remaining_sec > 0:
            record_event(
                level="INFO",
                event_type="paper.order_blocked",
                message="손실 청산 후 동일 전략/종목 쿨다운 중이라 시뮬레이션 주문을 차단했습니다.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={
                    "bucket": bucket,
                    "strategy_name": evaluation.get("strategy_name"),
                    "parameter_set_id": parameter_set_id,
                    "cooldown_remaining_sec": round(cooldown_remaining_sec, 1),
                    "cooldown_total_sec": settings.paper_symbol_loss_cooldown_seconds,
                },
            )
            return
        symbol_cooldown = _symbol_loss_guard(symbol, broker)
        if symbol_cooldown["remaining_sec"] > 0:
            record_event(
                level="INFO",
                event_type="paper.order_blocked",
                message="Recent symbol losses triggered a paper reentry cooldown.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={
                    "bucket": bucket,
                    "strategy_name": evaluation.get("strategy_name"),
                    "parameter_set_id": parameter_set_id,
                    **symbol_cooldown,
                },
            )
            return
        market_snapshot = shared_market_snapshot or execution_market_snapshot(symbol, side="buy")

        entry_ref_price = _to_float(market_snapshot.get("ask")) or _to_float(market_snapshot.get("last"))
        entry_gate = evaluate_entry_fill_gate(
            bid=_to_float(market_snapshot.get("bid")),
            ask=_to_float(market_snapshot.get("ask")),
            last=_to_float(market_snapshot.get("last")),
            spread_pct=_to_float(market_snapshot.get("spread_pct")),
            max_spread_pct=_max_entry_spread_pct(evaluation, last_price=entry_ref_price),
            signal_close=_to_float((evaluation.get("indicators") or {}).get("close")),
            strategy_name=str(evaluation.get("strategy_name") or ""),
            config=EntryFillGateConfig(
                entry_slippage_pct=settings.paper_entry_slippage_pct,
                max_chase_pct=settings.paper_entry_max_chase_pct,
                min_price_usd=settings.scanner_min_price_usd,
                runner_negative_chase_pct=settings.paper_entry_max_chase_pct,
            ),
        )
        if not entry_gate.allowed:
            payload = {
                "bucket": bucket,
                "provider": "toss",
                "strategy_name": evaluation.get("strategy_name"),
                "parameter_set_id": parameter_set_id,
                "entry_gate_reason": entry_gate.reason,
                **entry_gate.payload,
            }
            if entry_gate.reason == "spread_too_wide":
                payload["session"] = us_equity_session().get("state")
            record_event(
                level="WARNING" if entry_gate.reason in {"spread_too_wide", "missing_ask_or_last"} else "INFO",
                event_type="paper.order_blocked",
                message=f"Paper buy blocked by shared entry fill gate: {entry_gate.reason}",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload=payload,
            )
            return

        _raw_ask = entry_gate.raw_ask
        execution_price = entry_gate.execution_price
        if execution_price is None:
            record_event(
                level="WARNING",
                event_type="paper.order_blocked",
                message="Toss ask/last 가격이 없어 paper 매수 주문을 차단했습니다.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={"bucket": bucket, "market_snapshot": market_snapshot},
            )
            return

        execution_risk = RiskManager().preview_long_entry(
            account_equity_usd=settings.paper_initial_equity_usd,
            entry_price=execution_price,
            stop_loss_price=_dynamic_stop_loss_price(execution_price, candles, market_snapshot=market_snapshot, evaluation=evaluation),
        )
        quantity = float(execution_risk.quantity or 0)
        if quantity <= 0:
            return
        market_snapshot["strategy_reference_price"] = entry_price
        market_snapshot["execution_price_source"] = market_snapshot.get("source")
        market_snapshot["strategy_name"] = evaluation.get("strategy_name")
        market_snapshot["parameter_set_id"] = evaluation.get("parameter_set_id")
        market_snapshot["entry_mode"] = evaluation.get("entry_mode")
        market_snapshot["risk_preview"] = execution_risk.model_dump()
        exit_plan = _entry_exit_plan(
            execution_price,
            candles,
            quantity=quantity,
            market_snapshot=market_snapshot,
            evaluation=evaluation,
        )
        if exit_plan.get("entry_viable") is False:
            record_event(
                level="INFO",
                event_type="paper.order_blocked",
                message="Paper buy blocked because expected upside does not clear estimated round-trip cost and edge floor.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={
                    "bucket": bucket,
                    "provider": "toss",
                    "strategy_name": evaluation.get("strategy_name"),
                    "parameter_set_id": parameter_set_id,
                    "execution_price": execution_price,
                    "required_profit_pct": exit_plan.get("required_profit_pct"),
                    "estimated_roundtrip_cost_pct": exit_plan.get("estimated_roundtrip_cost_pct"),
                    "expected_upside_pct": (exit_plan.get("expected_upside") or {}).get("expected_upside_pct"),
                    "entry_viability_reason": exit_plan.get("entry_viability_reason"),
                },
            )
            return
        request = OrderRequest(
            symbol=symbol,
            side="buy",
            order_type="marketable_limit",
            quantity=quantity,
            limit_price=execution_price * 1.001,
            mode="internal_paper",
            strategy_signal_id=f"{parameter_set_id}-{symbol}-{bucket}",
        )
        market_snapshot["exit_plan"] = exit_plan
        market_snapshot["entry_snapshot"] = _entry_chart_snapshot(
            symbol=symbol,
            bucket=bucket,
            entry_price=entry_price,
            execution_price=execution_price,
            candles=candles,
            evaluation=evaluation,
            execution_market=market_snapshot,
        )
        broker.submit_order(request, market_snapshot=market_snapshot)
        self._last_ordered_bucket[order_memory_key] = bucket

    def monitor_open_positions(self) -> dict:
        settings = get_settings()
        if (
            not settings.paper_exit_monitor_enabled
            or (not settings.toss_position_quote_monitor_enabled and settings.trading_mode != "live")
        ):
            return {"checked": 0, "skipped": "disabled"}
        reconcile = None
        if settings.trading_mode == "internal_paper":
            broker = InternalPaperBroker()
            event_prefix = "paper"
        elif settings.trading_mode == "live":
            broker = LiveBroker(settings=settings)
            event_prefix = "live"
            reconcile = broker.reconcile_open_orders()
        else:
            return {"checked": 0, "skipped": "disabled"}
        positions = [
            row
            for row in broker.state().get("positions", [])
            if (_to_float(row.get("quantity")) or 0.0) > 0
        ]
        max_symbols = max(1, int(settings.toss_position_quote_max_symbols_per_tick))
        checked = 0
        blocked: list[dict] = []
        quote_cache: dict[str, dict] = {}
        now = datetime.now(timezone.utc)
        positions_by_symbol = _positions_by_symbol(positions)
        selected_symbols = self._round_robin_symbol_batch(list(positions_by_symbol), max_symbols=max_symbols)
        for symbol in selected_symbols:
            if not symbol:
                continue
            blocked_until = self._position_quote_blocked_until.get(symbol)
            if blocked_until and blocked_until > now:
                blocked.append(
                    {
                        "symbol": symbol,
                        "error": "quote_failure_cooldown",
                        "retry_after": blocked_until.isoformat(),
                    }
                )
                continue
            try:
                if symbol not in quote_cache:
                    quote_cache[symbol] = execution_quote_snapshot(
                        symbol,
                        max_cache_age_sec=settings.toss_position_quote_cache_sec,
                    )
                execution_market = dict(quote_cache[symbol])
            except ExecutionPricingError as exc:
                blocked.append({"symbol": symbol, "error": str(exc)})
                record_event(
                    level="WARNING",
                    event_type=f"{event_prefix}.position_quote_failed",
                    message="보유종목 Toss 호가 조회 실패로 청산 판단을 건너뜁니다.",
                    severity=StatusLevel.CAUTION,
                    symbol=symbol,
                    payload={"error": str(exc), "payload": exc.payload},
                )
                self._position_quote_blocked_until[symbol] = now + timedelta(
                    seconds=max(1.0, float(settings.toss_position_quote_failure_cooldown_sec))
                )
                continue
            current_price = _to_float(execution_market.get("bid")) or _to_float(execution_market.get("last"))
            if current_price is None:
                blocked.append({"symbol": symbol, "error": "missing_bid_last"})
                self._position_quote_blocked_until[symbol] = now + timedelta(
                    seconds=max(1.0, float(settings.toss_position_quote_failure_cooldown_sec))
                )
                continue
            self._position_quote_blocked_until.pop(symbol, None)
            candle = _latest_exit_candle(symbol, current_price)
            event = {
                "event_type": "toss_position_quote",
                "symbol": symbol,
                "last": current_price,
                "trade_volume": 0,
                "bid": execution_market.get("bid"),
                "ask": execution_market.get("ask"),
                "spread_pct": execution_market.get("spread_pct"),
                "received_at": datetime.now(timezone.utc).isoformat(),
                "source": execution_market.get("source"),
                "raw": {
                    "bid": execution_market.get("bid"),
                    "ask": execution_market.get("ask"),
                    "spread_pct": execution_market.get("spread_pct"),
                    "source": execution_market.get("source"),
                },
            }
            candle_builder.on_trade(event, source="toss_position_quote")
            event_bus.publish(
                RealtimeEventType.SYMBOL_DETAIL,
                {"event_type": "market_data.toss_position_quote", "symbol": symbol, "source": execution_market.get("source")},
                status_level=StatusLevel.NORMAL,
                symbol=symbol,
            )
            for row in positions_by_symbol.get(symbol, []):
                self._monitor_exit(symbol, event, candle, execution_market=execution_market, position_key=row.get("position_key"))
                checked += 1
        return {
            "checked": checked,
            "positions": len(positions),
            "unique_symbols_quoted": len(quote_cache),
            "max_symbols_per_tick": max_symbols,
            "selected_symbols": selected_symbols,
            "blocked": blocked[:5],
            "reconcile": reconcile,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

    def _round_robin_symbol_batch(self, symbols: list[str], *, max_symbols: int) -> list[str]:
        if not symbols:
            self._position_quote_cursor = 0
            return []
        ordered = sorted({str(symbol or "").upper() for symbol in symbols if str(symbol or "").strip()})
        count = max(1, min(int(max_symbols), len(ordered)))
        if len(ordered) <= count:
            self._position_quote_cursor = 0
            return ordered
        start = self._position_quote_cursor % len(ordered)
        selected = [ordered[(start + offset) % len(ordered)] for offset in range(count)]
        self._position_quote_cursor = (start + count) % len(ordered)
        return selected

    def _monitor_exit(
        self,
        symbol: str,
        event: dict,
        candle: dict,
        *,
        execution_market: dict | None = None,
        position_key: str | None = None,
    ) -> None:
        settings = get_settings()
        if not settings.paper_exit_monitor_enabled:
            return
        if settings.trading_mode == "internal_paper":
            broker = InternalPaperBroker()
            event_prefix = "paper"
        elif settings.trading_mode == "live":
            broker = LiveBroker(settings=settings)
            event_prefix = "live"
        else:
            return
        position = broker.position(symbol, position_key=position_key)
        if not position or position.quantity <= 0:
            return
        now = datetime.utcnow()
        if position.last_exit_check_at and (now - _to_naive(position.last_exit_check_at)).total_seconds() < settings.paper_exit_cooldown_seconds:
            return

        current_price = (
            _to_float(execution_market.get("bid")) if execution_market else None
        ) or _to_float(event.get("last")) or _to_float(candle.get("close"))
        if current_price is None:
            return
        if execution_market:
            bid = _to_float(execution_market.get("bid"))
            ask = _to_float(execution_market.get("ask"))
            spread_pct = _to_float(execution_market.get("spread_pct"))
        else:
            flow = get_market_data_service().provider.order_flow_snapshot().get(symbol, {})
            quote = flow.get("quote") or {}
            bid = _to_float(quote.get("bid"))
            ask = _to_float(quote.get("ask"))
            spread_pct = _to_float(flow.get("spread_pct"))

        candles, _ = _strategy_candle_window(symbol, prefer_toss_position=True)
        indicators = _indicator_snapshot(_normalize_candles(candles))
        high_watermark_before = position.high_watermark or position.average_price
        high_watermark = max(high_watermark_before, current_price)
        momentum_state = _exit_momentum_state(
            symbol=symbol,
            current_price=current_price,
            position=position,
            indicators=indicators,
            high_watermark=high_watermark,
        )
        if isinstance(position.exit_plan, dict):
            momentum_state["dynamic_exit_profile"] = position.exit_plan.get("dynamic_exit_profile")
        momentum_state["execution_spread_pct"] = spread_pct
        momentum_state["spread_widened"] = _spread_widened_for_exit(spread_pct)
        momentum_state = self._apply_macd_fading_confirmation(
            symbol=symbol,
            position=position,
            current_price=current_price,
            momentum_state=momentum_state,
        )
        trailing_pct = (
            _dynamic_trailing_stop_pct(momentum_state)
            if current_price >= (position.trailing_activation_price or float("inf"))
            else settings.paper_trailing_stop_pct
        )
        trailing_state = advance_trailing_stop(
            entry_price=position.average_price,
            current_price=current_price,
            high_watermark=position.high_watermark,
            trailing_stop_price=position.trailing_stop_price,
            activation_price=position.trailing_activation_price or float("inf"),
            activation_pct=settings.paper_trailing_activation_pct,
            trailing_pct=trailing_pct,
            break_even_activation_pct=settings.paper_break_even_activation_pct,
            break_even_lock_pct=settings.paper_break_even_lock_pct,
        )
        high_watermark = trailing_state.high_watermark
        trailing_stop_price = trailing_state.trailing_stop_price
        dynamic_take_profit = _dynamic_take_profit_update(
            position=position,
            current_price=current_price,
            high_watermark=high_watermark,
            momentum_state=momentum_state,
            trailing_pct=trailing_pct,
        )
        if dynamic_take_profit:
            position.dynamic_take_profit_price = dynamic_take_profit["price"]
            position.dynamic_take_profit_reason = dynamic_take_profit["reason"]
            position.dynamic_take_profit_updated_at = datetime.now(timezone.utc)
            position.take_profit_price = dynamic_take_profit["price"]
            momentum_state["dynamic_take_profit"] = dynamic_take_profit

        reason, quantity = _exit_decision(
            current_price=current_price,
            position=position,
            indicators=indicators,
            high_watermark=high_watermark,
            trailing_stop_price=trailing_stop_price,
            momentum_state=momentum_state,
        )
        position.high_watermark = high_watermark
        position.trailing_stop_price = trailing_stop_price
        position.last_exit_check_at = now
        broker.update_position(position)
        if not reason or quantity <= 0:
            return

        bucket = _bucket(candle) or datetime.utcnow().strftime("%Y%m%d:%H%M%S")
        if execution_market is None:
            try:
                execution_market = execution_market_snapshot(symbol, side="sell")
            except ExecutionPricingError as exc:
                record_event(
                    level="WARNING",
                    event_type=f"{event_prefix}.exit_blocked",
                    message="Toss 기준 최종 매도 호가를 확인하지 못해 시뮬레이션 청산을 보류했습니다.",
                    severity=StatusLevel.BLOCKED,
                    symbol=symbol,
                    payload={"reason": reason, "error": str(exc), "provider": "toss"},
                )
                return
        exit_price = _to_float(execution_market.get("bid")) or _to_float(execution_market.get("last"))
        if exit_price is None:
            record_event(
                level="WARNING",
                event_type=f"{event_prefix}.exit_blocked",
                message="Toss bid/last 가격이 없어 시뮬레이션 청산을 보류했습니다.",
                severity=StatusLevel.BLOCKED,
                symbol=symbol,
                payload={"reason": reason, "market_snapshot": execution_market},
            )
            return
        if reason in _EMERGENCY_EXIT_REASONS and position.stop_loss_price:
            # Bound the stop fill near the stop level (mirrors replay STOP_SLIPPAGE_CAP): a
            # gap/spike between 1s bid polls would otherwise fill far below the stop and
            # overshoot the intended loss (e.g. -6% on a 3.5% stop).
            capped_exit_price = bounded_stop_exit_price(
                exit_price,
                trigger_price=position.stop_loss_price,
                reason=reason,
                stop_slippage_cap_pct=get_settings().paper_stop_slippage_cap_pct,
            )
            if capped_exit_price > exit_price:
                exit_price = capped_exit_price
                execution_market = {**execution_market, "bid": capped_exit_price}
        if _is_profit_exit(reason):
            estimated_net_pnl = _estimated_exit_net_pnl(position=position, quantity=quantity, exit_price=exit_price)
            if estimated_net_pnl <= 0:
                record_event(
                    level="INFO",
                    event_type=f"{event_prefix}.exit_blocked",
                    message="익절 계열 청산 신호였지만 Toss bid와 수수료 기준 예상 순손익이 음수라 보류했습니다.",
                    severity=StatusLevel.CAUTION,
                    symbol=symbol,
                    payload={
                        "reason": reason,
                        "quantity": quantity,
                        "entry_price": position.average_price,
                        "exit_price": exit_price,
                        "estimated_net_pnl": estimated_net_pnl,
                        "execution_market": execution_market,
                    },
                )
                return
        if reason in ("partial_take_profit", "bb_mid_partial_take_profit"):
            position.partial_exit_done = True
            broker.update_position(position)
        request = OrderRequest(
            symbol=symbol,
            side="sell",
            order_type="marketable_limit" if settings.trading_mode == "internal_paper" else "market",
            quantity=quantity,
            limit_price=_exit_limit_price(exit_price, reason) if settings.trading_mode == "internal_paper" else None,
            mode=settings.trading_mode,
            strategy_signal_id=f"exit-{reason}-{position.parameter_set_id or symbol}-{bucket}",
        )
        market_snapshot = {
            **execution_market,
            "position_key": position.position_key,
            "strategy_name": position.strategy_name,
            "parameter_set_id": position.parameter_set_id,
            "entry_mode": position.entry_mode,
            "strategy_reference_last": current_price,
            "strategy_reference_bid": bid,
            "strategy_reference_ask": ask,
            "strategy_reference_spread_pct": spread_pct,
            "execution_price_source": execution_market.get("source"),
            "exit_reason": reason,
            "exit_indicators": {
                "vwap": indicators.vwap,
                "ema9": indicators.ema9,
                "ema20": indicators.ema20,
                "current_price": current_price,
                "bid": bid,
                "ask": ask,
                "trailing_stop_price": trailing_stop_price,
                "trailing_stop_pct": trailing_pct,
                "dynamic_take_profit_price": position.dynamic_take_profit_price,
                "dynamic_take_profit_reason": position.dynamic_take_profit_reason,
                "high_watermark_before": high_watermark_before,
                "high_watermark_after": high_watermark,
                "momentum_state": momentum_state,
            },
            "exit_snapshot": _exit_chart_snapshot(
                symbol=symbol,
                bucket=bucket,
                reason=reason,
                current_price=current_price,
                quantity=quantity,
                position=position,
                candles=candles,
                indicators=indicators,
                execution_market=execution_market,
                momentum_state=momentum_state,
                trailing_stop_price=trailing_stop_price,
                high_watermark_before=high_watermark_before,
                high_watermark=high_watermark,
            ),
        }
        record_event(
            level="INFO",
            event_type=f"{event_prefix}.exit_signal",
            message=f"자동 청산 신호 발생: {reason}",
            severity=StatusLevel.NORMAL,
            symbol=symbol,
            payload={
                "reason": reason,
                "quantity": quantity,
                "current_price": current_price,
                "position": position.model_dump(mode="json"),
                "market_snapshot": market_snapshot,
            },
        )
        if settings.trading_mode == "internal_paper":
            broker.submit_order(request, market_snapshot=market_snapshot)
        else:
            _log_live_decision(
                side="sell",
                symbol=symbol,
                strategy=position.strategy_name,
                parameter_set_id=position.parameter_set_id,
                bucket=bucket,
                reason=reason,
                price=exit_price,
                quantity=quantity,
                candles=candles,
                market_snapshot=market_snapshot,
            )
            try:
                broker.submit_exit_order(
                    position=position,
                    quantity=quantity,
                    reason=reason,
                    market_snapshot=market_snapshot,
                    strategy_signal_id=request.strategy_signal_id,
                )
            except TossApiError as exc:
                record_event(
                    level="ERROR",
                    event_type="live.exit_error",
                    message="Toss live exit order submission failed.",
                    severity=StatusLevel.EMERGENCY,
                    symbol=symbol,
                    payload={
                        "reason": reason,
                        "quantity": quantity,
                        "error": str(exc),
                        "status_code": exc.status_code,
                        "payload": exc.payload,
                        "position": position.model_dump(mode="json"),
                    },
                )

    def _apply_macd_fading_confirmation(
        self,
        *,
        symbol: str,
        position,
        current_price: float,
        momentum_state: dict,
    ) -> dict:
        settings = get_settings()
        key = f"{symbol}:{getattr(position, 'position_key', None) or getattr(position, 'parameter_set_id', '') or 'default'}"
        macd_exit = momentum_state.get("macd_exit") if isinstance(momentum_state.get("macd_exit"), dict) else {}
        raw_fading = bool(momentum_state.get("macd_histogram_fading_raw"))
        profit_pct = (current_price - position.average_price) / position.average_price if position.average_price > 0 else 0.0

        recent = macd_exit.get("histogram_recent") if isinstance(macd_exit.get("histogram_recent"), list) else []
        drop_ratio = 0.0
        first = _to_float(recent[0]) if recent else None
        last = _to_float(recent[-1]) if recent else None
        if first is not None and last is not None and abs(first) > 1e-12:
            drop_ratio = max(0.0, (first - last) / abs(first))

        supporting_weakness = (
            bool(momentum_state.get("chart_profit_weakness"))
            or bool(momentum_state.get("flow_weak_confirmation"))
            or bool(momentum_state.get("volume_decay"))
            or int(momentum_state.get("high_failures") or 0) >= 1
            or bool(momentum_state.get("spread_widened"))
        )
        active = (
            settings.paper_macd_fading_exit_enabled
            and raw_fading
            and profit_pct >= settings.paper_macd_fading_min_profit_pct
            and drop_ratio >= settings.paper_macd_fading_min_hist_drop_ratio
        )
        now = datetime.utcnow()
        if active:
            self._macd_fading_since.setdefault(key, now)
        else:
            self._macd_fading_since.pop(key, None)
        elapsed = (now - self._macd_fading_since[key]).total_seconds() if active and key in self._macd_fading_since else 0.0
        chart_ok = supporting_weakness or not settings.paper_macd_fading_confirm_with_chart
        confirmed = bool(active and elapsed >= settings.paper_macd_fading_min_seconds and chart_ok)

        momentum_state["macd_fading_confirmation"] = {
            "raw": raw_fading,
            "confirmed": confirmed,
            "profit_pct": profit_pct,
            "min_profit_pct": settings.paper_macd_fading_min_profit_pct,
            "drop_ratio": drop_ratio,
            "min_drop_ratio": settings.paper_macd_fading_min_hist_drop_ratio,
            "elapsed_seconds": elapsed,
            "min_seconds": settings.paper_macd_fading_min_seconds,
            "supporting_weakness": supporting_weakness,
            "requires_chart_or_flow": settings.paper_macd_fading_confirm_with_chart,
        }
        momentum_state["macd_histogram_fading_confirmed"] = confirmed
        runner_full_exit_confirmed = bool(
            momentum_state.get("runner")
            and confirmed
            and bool(momentum_state.get("volume_decay"))
            and bool(momentum_state.get("below_ema9"))
            and int(momentum_state.get("high_failures") or 0) >= settings.paper_runner_full_exit_high_failures
        )
        momentum_state["runner_full_exit_confirmed"] = runner_full_exit_confirmed
        if confirmed:
            if not momentum_state.get("runner") or runner_full_exit_confirmed:
                momentum_state["chart_profit_weakness"] = True
                if profit_pct > 0:
                    momentum_state["weak"] = True
            momentum_state["macd_fading_reason"] = "confirmed_profit_chart_flow_fading"
        return momentum_state

    def status(self) -> dict:
        return {
            "last_evaluated_bucket": self._last_evaluated_bucket,
            "last_ordered_bucket": self._last_ordered_bucket,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

    def reset_order_memory(self) -> dict:
        cleared = {
            "last_evaluated_bucket": len(self._last_evaluated_bucket),
            "last_ordered_bucket": len(self._last_ordered_bucket),
            "macd_fading_since": len(self._macd_fading_since),
            "position_quote_cursor": self._position_quote_cursor,
        }
        self._last_evaluated_bucket.clear()
        self._last_ordered_bucket.clear()
        self._macd_fading_since.clear()
        self._position_quote_cursor = 0
        return {"cleared": cleared}

    def _record_waiting_for_candles(self, symbol: str, candle_count: int, candle_mode: str) -> None:
        now = datetime.now(timezone.utc)
        previous = self._last_wait_log_at.get(symbol)
        if previous and (now - previous).total_seconds() < 60:
            return
        self._last_wait_log_at[symbol] = now
        required = _required_candle_count(candle_mode)
        record_event(
            level="DEBUG",
            event_type="strategy.waiting_for_candles",
            message="전략 기준 1분봉 window가 부족해서 전략 평가를 대기합니다.",
            severity=StatusLevel.NORMAL,
            symbol=symbol,
            payload={"candle_mode": candle_mode, "candle_count": candle_count, "required": required, "throttle_sec": 60},
        )

    def _record_candle_gap(self, symbol: str, latest_closed: dict, live_candle: dict) -> None:
        now = datetime.now(timezone.utc)
        previous = self._last_gap_log_at.get(symbol)
        if previous and (now - previous).total_seconds() < 60:
            return
        self._last_gap_log_at[symbol] = now
        record_event(
            level="INFO",
            event_type="strategy.candle_gap_blocked",
            message="공식 1분봉과 live tick 사이 공백 때문에 전략 평가를 보류합니다.",
            severity=StatusLevel.CAUTION,
            symbol=symbol,
            payload={
                "latest_closed_bucket": _bucket(latest_closed),
                "live_bucket": _bucket(live_candle),
                "gap_minutes": _gap_minutes(latest_closed, live_candle),
                "max_gap_minutes": get_settings().strategy_max_candle_gap_minutes,
            },
        )


def _with_live_forming(official: list[dict], live_candles: list[dict]) -> list[dict]:
    """Hybrid entry window: completed official bars (history, no repaint) with the
    current forming/live minute appended as the current bar. Pattern checks on the
    current bar (breakout / reclaim / close-near-high) then react in real-time to
    the developing minute instead of waiting for it to close, while the historical
    context stays on completed bars. The trailing live candle repaints each tick,
    which is intended: entries fire while price is actually in the pattern, and the
    stop handles reversals. Exits are already tick-real-time."""
    window = list(official[-120:])
    forming = live_candles[-1] if live_candles else None
    if not forming or not forming.get("is_live"):
        return window
    if window:
        last_key = (window[-1].get("market_date"), window[-1].get("market_time"))
        forming_key = (forming.get("market_date"), forming.get("market_time"))
        if forming_key <= last_key:
            # the forming minute is already represented by a completed official bar
            return window
    window.append(forming)
    return window[-120:]


def _strategy_candle_window(symbol: str, *, prefer_toss_position: bool = False) -> tuple[list[dict], str]:
    settings = get_settings()
    sets = candle_builder.candle_sets(symbol, limit=120)
    official_candles = sets["official"]
    live_candles = sets["live_tick"]
    toss_candles = [row for row in live_candles if row.get("source") == "toss_position_quote"]
    if prefer_toss_position:
        if toss_candles:
            return toss_candles[-120:], "toss_position_quote"
        return [], "toss_position_quote_warming"
    if not settings.strategy_prefer_live_tick_candles:
        if len(official_candles) >= settings.strategy_official_min_candles:
            if settings.strategy_include_live_forming_candle:
                return _with_live_forming(official_candles, live_candles), "official_plus_live_forming"
            return official_candles[-120:], "official_latest"
        if official_candles:
            return official_candles, "official_warming"
        if len(live_candles) >= settings.strategy_live_tick_min_candles:
            return live_candles[-120:], "live_tick_fallback"
        return live_candles, "live_tick_warming"
    if settings.strategy_prefer_live_tick_candles:
        if len(live_candles) >= settings.strategy_live_tick_min_candles:
            return live_candles[-120:], "live_tick"
        if len(official_candles) >= settings.strategy_official_min_candles:
            return official_candles[-120:], "official_gap_fallback"
        return live_candles, "live_tick_warming"
    return official_candles, "official_latest"


def _positions_by_symbol(positions: list[dict]) -> dict[str, list[dict]]:
    grouped: dict[str, list[dict]] = {}
    for row in positions:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        grouped.setdefault(symbol, []).append(row)
    for rows in grouped.values():
        rows.sort(
            key=lambda row: (
                str(row.get("position_key") or ""),
                str(row.get("parameter_set_id") or ""),
            )
        )
    return dict(sorted(grouped.items()))


def _required_candle_count(candle_mode: str | None = None) -> int:
    settings = get_settings()
    if candle_mode in {"live_tick", "live_tick_fallback", "live_tick_warming"}:
        return settings.strategy_live_tick_min_candles
    return settings.strategy_official_min_candles


def _bucket(candle: dict) -> str | None:
    market_date = candle.get("market_date")
    market_time = candle.get("market_time")
    if not market_date or not market_time:
        return None
    return f"{market_date}:{market_time}"


def _gap_minutes(previous: dict, current: dict) -> float:
    previous_dt = _candle_datetime(previous)
    current_dt = _candle_datetime(current)
    if not previous_dt or not current_dt:
        return 0.0
    return max(0.0, (current_dt - previous_dt).total_seconds() / 60)


def _candle_datetime(candle: dict) -> datetime | None:
    market_date = candle.get("market_date")
    market_time = str(candle.get("market_time") or "").zfill(6)
    if not market_date or len(str(market_date)) != 8 or len(market_time) < 6:
        return None
    try:
        return datetime.strptime(f"{market_date}{market_time[:6]}", "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _latest_exit_candle(symbol: str, current_price: float) -> dict:
    sets = candle_builder.candle_sets(symbol, limit=1)
    toss_candles = [
        row for row in (sets.get("live_tick") or []) if row.get("source") == "toss_position_quote"
    ]
    if toss_candles:
        return toss_candles[-1]
    now = datetime.now(timezone.utc)
    return {
        "symbol": symbol,
        "market_date": now.strftime("%Y%m%d"),
        "market_time": now.strftime("%H%M%S"),
        "open": current_price,
        "high": current_price,
        "low": current_price,
        "close": current_price,
        "volume": 0,
        "source": "toss_position_quote_synthetic_candle",
    }


def _max_entry_spread_pct(evaluation: dict | None = None, *, last_price: float | None = None) -> float:
    # Match the replay's price-aware spread cap (1.25% under $2, 0.85% at/above $2),
    # so runtime entries pass the same spread gate the strategy P&L was tuned against.
    price = last_price
    if price is None and evaluation:
        flow = evaluation.get("order_flow") if isinstance(evaluation.get("order_flow"), dict) else {}
        price = (
            _to_float((flow.get("trade") or {}).get("last"))
            or _to_float(flow.get("last_price"))
            or _to_float(flow.get("last"))
        )
    price = price or 0.0
    return 1.25 if 0.0 < price < 2.0 else 0.85


def _liquidity_adjusted_entry_spread_limit(*, base: float, flow: dict, final_score: float = 0.0) -> float:
    volume_60s = _to_float(flow.get("volume_60s")) or 0.0
    last_price = (
        _to_float((flow.get("trade") or {}).get("last"))
        or _to_float(flow.get("last_price"))
        or _to_float(flow.get("last"))
        or 0.0
    )
    notional_1m = _to_float(flow.get("notional_1m")) or (volume_60s * last_price if last_price > 0 else 0.0)
    notional_10m = _to_float(flow.get("notional_10m")) or 0.0
    velocity = _to_float(flow.get("volume_velocity_10s")) or _to_float(flow.get("notional_velocity_10s")) or 0.0
    strength = _to_float(flow.get("trade_strength")) or 0.0
    sell_pressure = _to_float(flow.get("sell_pressure"))

    limit = base
    if (notional_10m >= 25_000 or notional_1m >= 8_000) and (
        final_score >= 65 or velocity >= 1.2 or strength >= 55
    ):
        limit = max(limit, 0.80)
    if (notional_10m >= 100_000 or notional_1m >= 25_000) and (
        final_score >= 75 or velocity >= 1.5 or strength >= 65
    ):
        limit = max(limit, 1.00)
    if (notional_10m >= 250_000 or notional_1m >= 60_000) and (
        final_score >= 85 or velocity >= 2.0 or strength >= 80
    ):
        limit = max(limit, 1.20)
    if sell_pressure is not None and sell_pressure > 0.70:
        limit = min(limit, max(base, 0.80))
    return min(limit, 1.20)


def _max_exit_spread_pct() -> float:
    entry_threshold = _max_entry_spread_pct()
    return max(entry_threshold * 1.25, entry_threshold + 0.05)


def _spread_widened_for_exit(spread_pct: float | None) -> bool:
    if spread_pct is None:
        return False
    return spread_pct > _max_exit_spread_pct()


def _loss_cooldown_remaining_sec(symbol: str, broker: InternalPaperBroker, *, parameter_set_id: str | None = None) -> float:
    settings = get_settings()
    cooldown_sec = max(0, int(settings.paper_symbol_loss_cooldown_seconds))
    if cooldown_sec <= 0:
        return 0.0
    now = datetime.now(timezone.utc)
    for trade in reversed(broker.state().get("closed_trades", [])):
        if str(trade.get("symbol") or "").upper() != symbol.upper():
            continue
        if parameter_set_id and str(trade.get("parameter_set_id") or "") != parameter_set_id:
            continue
        net_pnl = _to_float(trade.get("net_pnl_usd")) or 0.0
        if net_pnl >= 0:
            continue
        closed_at = _parse_datetime(trade.get("closed_at"))
        if closed_at is None:
            continue
        elapsed = (now - closed_at).total_seconds()
        return max(0.0, cooldown_sec - elapsed)
    return 0.0


def _symbol_loss_guard(symbol: str, broker: InternalPaperBroker) -> dict:
    settings = get_settings()
    any_loss_cooldown = max(0, int(settings.paper_symbol_any_strategy_loss_cooldown_seconds))
    cluster_cooldown = max(0, int(settings.paper_symbol_loss_cluster_cooldown_seconds))
    cluster_lookback = max(0, int(settings.paper_symbol_loss_cluster_lookback_seconds))
    cluster_max_losses = max(1, int(settings.paper_symbol_loss_cluster_max_losses))
    now = datetime.now(timezone.utc)
    losses: list[dict] = []
    for trade in reversed(broker.state().get("closed_trades", [])):
        if str(trade.get("symbol") or "").upper() != symbol.upper():
            continue
        net_pnl = _to_float(trade.get("net_pnl_usd")) or 0.0
        if net_pnl >= 0:
            continue
        closed_at = _parse_datetime(trade.get("closed_at"))
        if closed_at is None:
            continue
        elapsed = (now - closed_at).total_seconds()
        losses.append({"elapsed": elapsed, "trade": trade})

    latest_loss = losses[0] if losses else None
    latest_remaining = max(0.0, any_loss_cooldown - latest_loss["elapsed"]) if latest_loss and any_loss_cooldown > 0 else 0.0
    recent_losses = [loss for loss in losses if cluster_lookback <= 0 or loss["elapsed"] <= cluster_lookback]
    cluster_remaining = 0.0
    if cluster_cooldown > 0 and len(recent_losses) >= cluster_max_losses:
        cluster_remaining = max(0.0, cluster_cooldown - recent_losses[0]["elapsed"])
    remaining = max(latest_remaining, cluster_remaining)
    if remaining <= 0:
        return {"remaining_sec": 0.0}
    return {
        "remaining_sec": round(remaining, 1),
        "reason": "symbol_loss_cluster" if cluster_remaining >= latest_remaining and cluster_remaining > 0 else "symbol_recent_loss",
        "recent_loss_count": len(recent_losses),
        "cluster_max_losses": cluster_max_losses,
        "any_strategy_cooldown_sec": any_loss_cooldown,
        "cluster_cooldown_sec": cluster_cooldown,
        "cluster_lookback_sec": cluster_lookback,
    }


def _parse_datetime(value: object) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _entry_exit_plan(
    entry_price: float,
    candles: list[dict] | None = None,
    quantity: float | None = None,
    market_snapshot: dict | None = None,
    evaluation: dict | None = None,
) -> dict:
    settings = get_settings()
    normalized = _normalize_candles(candles or [])
    profile = _dynamic_exit_profile(
        entry_price=entry_price,
        candles=normalized,
        quantity=quantity,
        market_snapshot=market_snapshot,
        evaluation=evaluation,
    )
    stop_loss_price = _dynamic_stop_loss_price(
        entry_price,
        candles or [],
        market_snapshot=market_snapshot,
        evaluation=evaluation,
        profile=profile,
    )
    min_profit_price = entry_price * (1 + profile["min_profit_pct"])
    partial_take_profit_plan = _structure_aware_profit_price(
        entry_price=entry_price,
        target_pct=profile["partial_take_profit_pct"],
        quantity=quantity,
        candles=normalized,
        atr_multiplier=profile["partial_atr_multiplier"],
        min_price=min_profit_price,
    )
    take_profit_plan = _structure_aware_profit_price(
        entry_price=entry_price,
        target_pct=profile["take_profit_pct"],
        quantity=quantity,
        candles=normalized,
        atr_multiplier=profile["take_profit_atr_multiplier"],
        min_price=max(min_profit_price, partial_take_profit_plan["price"]),
    )
    take_profit_price = take_profit_plan["price"]
    partial_take_profit_price = partial_take_profit_plan["price"]
    trailing_activation_price = _fee_aware_profit_price(
        entry_price=entry_price,
        target_pct=profile["trailing_activation_pct"],
        quantity=quantity,
    )
    expected_upside = _expected_upside_profile(
        entry_price=entry_price,
        candles=normalized,
        profile=profile,
    )
    expected_upside_pct = _to_float(expected_upside.get("expected_upside_pct"))
    required_profit_pct = _to_float(profile.get("min_profit_pct")) or 0.0
    entry_viable = expected_upside_pct is None or expected_upside_pct >= required_profit_pct
    if expected_upside_pct is None:
        entry_viability_reason = "insufficient_chart_context"
    elif entry_viable:
        entry_viability_reason = "expected_upside_covers_cost_floor"
    else:
        entry_viability_reason = "expected_upside_below_cost_floor"
    return {
        "stop_loss_price": stop_loss_price,
        "stop_loss_pct": (entry_price - stop_loss_price) / entry_price if entry_price > 0 else settings.paper_stop_loss_pct,
        "stop_loss_model": "max(config_pct, atr, structure_floor, spread_floor)_liquidity_volatility_strategy_adjusted",
        "take_profit_price": take_profit_price,
        "dynamic_take_profit_price": take_profit_price,
        "take_profit_fee_adjusted": take_profit_price > entry_price * (1 + profile["take_profit_pct"]),
        "take_profit_model": "nearest(resistance, indicator, atr, fee_spread_floor)_liquidity_volatility_strategy_adjusted",
        "take_profit_reference": take_profit_plan,
        "partial_take_profit_price": partial_take_profit_price,
        "partial_take_profit_fee_adjusted": partial_take_profit_price > entry_price * (1 + profile["partial_take_profit_pct"]),
        "partial_take_profit_model": "nearest(resistance, indicator, atr, fee_spread_floor)_liquidity_volatility_strategy_adjusted",
        "partial_take_profit_reference": partial_take_profit_plan,
        "partial_exit_fraction": settings.paper_partial_exit_fraction,
        "time_exit_seconds": settings.paper_time_exit_seconds,
        "no_progress_exit_seconds": None,
        "no_progress_exit_enabled": False,
        "trailing_activation_price": trailing_activation_price,
        "trailing_activation_fee_adjusted": trailing_activation_price > entry_price * (1 + profile["trailing_activation_pct"]),
        "trailing_stop_price": None,
        "trailing_stop_pct": profile["trailing_stop_pct"],
        "trailing_stop_model": "spread_liquidity_volatility_strategy_adjusted_inactive_until_profit_activation",
        "dynamic_exit_profile": profile,
        "entry_viable": entry_viable,
        "entry_viability_reason": entry_viability_reason,
        "expected_upside": expected_upside,
        "required_profit_pct": required_profit_pct,
        "estimated_roundtrip_cost_pct": (_to_float(profile.get("fee_floor_pct")) or 0.0)
        + (_to_float(profile.get("spread_floor_pct")) or 0.0),
        "edge_floor_pct": _to_float(profile.get("edge_floor_pct")) or 0.0,
        "dynamic_take_profit_enabled": settings.paper_dynamic_take_profit_enabled,
        "take_profit_requires_weakness": settings.paper_take_profit_requires_weakness,
        "partial_exit_requires_weakness": settings.paper_partial_exit_requires_weakness,
        "dynamic_trailing": {
            "tight_pct": settings.paper_dynamic_trailing_tight_pct,
            "normal_pct": settings.paper_dynamic_trailing_normal_pct,
            "wide_pct": settings.paper_dynamic_trailing_wide_pct,
            "runner_profit_pct": settings.paper_runner_trailing_profit_pct,
        },
        "exit_on_vwap_ema_break": settings.paper_exit_on_vwap_ema_break,
    }


def _fee_aware_profit_price(*, entry_price: float, target_pct: float, quantity: float | None) -> float:
    settings = get_settings()
    base_price = entry_price * (1 + target_pct)
    if not settings.paper_fee_model_enabled or entry_price <= 0 or not quantity or quantity <= 0:
        return base_price
    entry_fees = _estimated_entry_fees(quantity=quantity, price=entry_price)
    min_net_profit = entry_price * quantity * max(0.0, settings.paper_min_net_take_profit_pct)
    required_price = base_price
    for _ in range(3):
        exit_fees = _estimated_exit_fees(quantity=quantity, price=required_price)
        required_price = (entry_price * quantity + entry_fees + exit_fees + min_net_profit) / quantity
        required_price = max(required_price, base_price)
    return required_price


def _expected_upside_profile(*, entry_price: float, candles: list[dict], profile: dict | None = None) -> dict:
    settings = get_settings()
    if entry_price <= 0:
        return {"expected_upside_pct": None, "reason": "invalid_entry_price"}
    normalized = _normalize_candles(candles)
    if not normalized:
        return {"expected_upside_pct": None, "reason": "missing_candles"}
    indicators = _indicator_snapshot(normalized)
    lookback = max(3, settings.paper_take_profit_lookback_bars)
    recent_highs = [
        high
        for high in (_to_float(row.get("high")) for row in normalized[-lookback:])
        if high is not None and high > entry_price
    ]
    nearest_recent_high_pct = None
    if recent_highs:
        nearest_recent_high_pct = (min(recent_highs) - entry_price) / entry_price

    indicator_levels = [
        level
        for level in [indicators.bb_mid, indicators.bb_upper, indicators.vwap, indicators.ema9, indicators.ema20]
        if level is not None and level > entry_price
    ]
    nearest_indicator_pct = None
    if indicator_levels:
        nearest_indicator_pct = (min(indicator_levels) - entry_price) / entry_price

    recent_10bar_change_pct = _recent_10bar_change_pct(normalized)
    recent_10bar_abs_change_pct = abs(recent_10bar_change_pct) if recent_10bar_change_pct is not None else None
    atr_pct = _to_float((profile or {}).get("atr_pct"))
    if atr_pct is None and indicators.atr20 is not None:
        atr_pct = indicators.atr20 / entry_price

    structure_candidates = [
        pct
        for pct in [nearest_recent_high_pct, nearest_indicator_pct]
        if pct is not None and pct > 0
    ]
    structure_ceiling_pct = min(structure_candidates) if structure_candidates else None
    volatility_budget_pct = max(
        [pct for pct in [(atr_pct or 0.0) * 1.15, (recent_10bar_abs_change_pct or 0.0) * 0.75] if pct > 0],
        default=None,
    )

    if structure_ceiling_pct is not None and volatility_budget_pct is not None:
        expected_upside_pct = min(structure_ceiling_pct, max(volatility_budget_pct, structure_ceiling_pct * 0.65))
        reason = "nearest_structure_capped_by_volatility"
    elif structure_ceiling_pct is not None:
        expected_upside_pct = structure_ceiling_pct
        reason = "nearest_structure"
    elif volatility_budget_pct is not None:
        expected_upside_pct = volatility_budget_pct
        reason = "recent_volatility_budget"
    else:
        expected_upside_pct = None
        reason = "insufficient_chart_context"

    return {
        "expected_upside_pct": expected_upside_pct,
        "nearest_recent_high_pct": nearest_recent_high_pct,
        "nearest_indicator_pct": nearest_indicator_pct,
        "recent_10bar_change_pct": recent_10bar_change_pct,
        "recent_10bar_abs_change_pct": recent_10bar_abs_change_pct,
        "atr_pct": atr_pct,
        "structure_ceiling_pct": structure_ceiling_pct,
        "volatility_budget_pct": volatility_budget_pct,
        "reason": reason,
        "model": "nearest_resistance_atr_10bar_change",
    }


def _recent_10bar_change_pct(candles: list[dict], *, lookback: int = 10) -> float | None:
    normalized = _normalize_candles(candles)
    window = normalized[-min(lookback, len(normalized)) :]
    if len(window) < 2:
        return None
    first_close = _to_float(window[0].get("close"))
    last_close = _to_float(window[-1].get("close"))
    if first_close is None or first_close <= 0 or last_close is None:
        return None
    return (last_close - first_close) / first_close


def _dynamic_exit_profile(
    *,
    entry_price: float,
    candles: list[dict],
    quantity: float | None,
    market_snapshot: dict | None,
    evaluation: dict | None,
) -> dict:
    settings = get_settings()
    indicators = _indicator_snapshot(_normalize_candles(candles))
    spread_pct = _to_float((market_snapshot or {}).get("spread_pct"))
    spread_fraction = max(0.0, (spread_pct or 0.0) / 100.0)
    atr_pct = max(0.0, (indicators.atr20 or 0.0) / entry_price) if entry_price > 0 else 0.0
    recent_10bar_change_pct = _recent_10bar_change_pct(candles)
    recent_10bar_abs_change_pct = abs(recent_10bar_change_pct) if recent_10bar_change_pct is not None else None

    flow = evaluation.get("order_flow") if isinstance((evaluation or {}).get("order_flow"), dict) else {}
    final_score = _to_float((evaluation or {}).get("final_score")) or 0.0
    velocity = _to_float(flow.get("volume_velocity_10s")) or _to_float(flow.get("notional_velocity_10s")) or 0.0
    trade_strength = _to_float(flow.get("trade_strength"))
    if trade_strength is not None and trade_strength <= 1:
        trade_strength *= 100
    sell_pressure = _to_float(flow.get("sell_pressure"))
    if sell_pressure is None:
        sell_pressure = _to_float(flow.get("aggressive_sell_ratio"))
    if sell_pressure is not None and sell_pressure > 1:
        sell_pressure /= 100

    strong_liquidity = velocity >= 1.5 or (trade_strength is not None and trade_strength >= 60)
    weak_liquidity = (velocity > 0 and velocity < 0.75) or (sell_pressure is not None and sell_pressure >= 0.62)
    strong_strategy = final_score >= 75
    weak_strategy = final_score > 0 and final_score < 55
    high_volatility = atr_pct >= 0.018 or (recent_10bar_abs_change_pct or 0.0) >= 0.018 or spread_fraction >= 0.0035

    target_multiplier = 1.0
    if strong_liquidity or strong_strategy:
        target_multiplier += 0.20
    if high_volatility:
        target_multiplier += 0.15
    if weak_liquidity or weak_strategy:
        target_multiplier -= 0.15
    target_multiplier = min(max(target_multiplier, 0.75), 1.45)

    stop_multiplier = 1.0
    if high_volatility:
        stop_multiplier += 0.25
    if spread_fraction >= 0.002:
        stop_multiplier += 0.15
    if weak_liquidity:
        stop_multiplier -= 0.10
    if strong_liquidity and strong_strategy:
        stop_multiplier += 0.10
    stop_multiplier = min(max(stop_multiplier, 0.85), 1.55)

    fee_floor_pct = _fee_floor_pct(entry_price=entry_price, quantity=quantity)
    spread_floor_pct = spread_fraction * 2.5
    edge_floor_pct = max(settings.paper_min_net_take_profit_pct, spread_fraction * 0.5)
    min_profit_pct = max(
        settings.paper_min_net_take_profit_pct,
        fee_floor_pct + spread_floor_pct + edge_floor_pct,
    )

    partial_pct = max(
        settings.paper_partial_take_profit_pct * target_multiplier,
        min_profit_pct * 0.85,
        spread_fraction * 3.0 + fee_floor_pct,
        atr_pct * (0.30 if weak_liquidity else 0.50 if strong_liquidity else 0.40),
        (recent_10bar_abs_change_pct or 0.0) * (0.25 if weak_liquidity else 0.50 if strong_liquidity else 0.35),
    )
    take_profit_pct = max(
        settings.paper_take_profit_pct * target_multiplier,
        min_profit_pct,
        partial_pct * 1.25,
        atr_pct * (0.85 if weak_liquidity else 1.35 if strong_liquidity else 1.10),
        (recent_10bar_abs_change_pct or 0.0) * (0.65 if weak_liquidity else 1.00 if strong_liquidity else 0.80),
    )
    trailing_activation_pct = max(
        settings.paper_trailing_activation_pct * min(max(target_multiplier, 0.9), 1.35),
        min_profit_pct * 0.90,
        atr_pct * (0.30 if weak_liquidity else 0.55 if strong_liquidity else 0.40),
    )
    trailing_stop_pct = max(
        settings.paper_trailing_stop_pct * (1.25 if strong_liquidity else 0.90 if weak_liquidity else 1.0),
        spread_fraction * 3.0,
        atr_pct * 0.45,
    )
    trailing_stop_pct = min(max(trailing_stop_pct, settings.paper_dynamic_trailing_tight_pct), settings.paper_dynamic_trailing_wide_pct * 1.5)

    return {
        "spread_pct": spread_pct,
        "spread_fraction": spread_fraction,
        "atr_pct": atr_pct,
        "fee_floor_pct": fee_floor_pct,
        "spread_floor_pct": spread_floor_pct,
        "edge_floor_pct": edge_floor_pct,
        "min_profit_pct": min_profit_pct,
        "recent_10bar_change_pct": recent_10bar_change_pct,
        "recent_10bar_abs_change_pct": recent_10bar_abs_change_pct,
        "target_multiplier": target_multiplier,
        "stop_multiplier": stop_multiplier,
        "partial_take_profit_pct": partial_pct,
        "take_profit_pct": take_profit_pct,
        "trailing_activation_pct": trailing_activation_pct,
        "trailing_stop_pct": trailing_stop_pct,
        "partial_atr_multiplier": settings.paper_partial_take_profit_atr_multiplier * max(0.85, min(target_multiplier, 1.35)),
        "take_profit_atr_multiplier": settings.paper_take_profit_atr_multiplier * max(0.85, min(target_multiplier, 1.45)),
        "strong_liquidity": strong_liquidity,
        "weak_liquidity": weak_liquidity,
        "strong_strategy": strong_strategy,
        "weak_strategy": weak_strategy,
        "high_volatility": high_volatility,
        "final_score": final_score,
        "volume_velocity_10s": velocity,
        "trade_strength": trade_strength,
        "sell_pressure": sell_pressure,
        "model": "spread_liquidity_volatility_strategy",
    }


def _fee_floor_pct(*, entry_price: float, quantity: float | None) -> float:
    if entry_price <= 0 or not quantity or quantity <= 0:
        return 0.0
    entry_fees = _estimated_entry_fees(quantity=quantity, price=entry_price)
    exit_fees = _estimated_exit_fees(quantity=quantity, price=entry_price)
    return (entry_fees + exit_fees) / max(entry_price * quantity, 0.000001)


def _structure_aware_profit_price(
    *,
    entry_price: float,
    target_pct: float,
    quantity: float | None,
    candles: list[dict],
    atr_multiplier: float,
    min_price: float | None = None,
) -> dict:
    settings = get_settings()
    if entry_price <= 0:
        return {
            "price": entry_price,
            "fee_adjusted_price": entry_price,
            "selected_reason": "invalid_entry_price",
            "candidate_prices": {},
        }

    fixed_pct_price = _fee_aware_profit_price(
        entry_price=entry_price,
        target_pct=target_pct,
        quantity=quantity,
    )
    min_profitable_price = _fee_aware_profit_price(
        entry_price=entry_price,
        target_pct=0.0,
        quantity=quantity,
    )
    normalized = _normalize_candles(candles)
    indicators = _indicator_snapshot(normalized)
    lookback = max(3, settings.paper_take_profit_lookback_bars)

    recent_highs = [
        high
        for high in (_to_float(row.get("high")) for row in normalized[-lookback:])
        if high is not None and high > entry_price
    ]
    indicator_levels = [
        level
        for level in [indicators.bb_mid, indicators.bb_upper, indicators.vwap, indicators.ema9, indicators.ema20]
        if level is not None and level > entry_price
    ]
    candidate_prices: dict[str, float] = {
        "min_profitable_floor": min_profitable_price,
        "fixed_pct_target": fixed_pct_price,
    }
    if recent_highs:
        candidate_prices["nearest_recent_high"] = min(recent_highs)
    if indicator_levels:
        candidate_prices["nearest_indicator_level"] = min(indicator_levels)
    if indicators.atr20 is not None and indicators.atr20 > 0 and atr_multiplier > 0:
        candidate_prices["atr_target"] = entry_price + (indicators.atr20 * atr_multiplier)

    floor_price = max(entry_price, min_price or entry_price, min_profitable_price, fixed_pct_price)
    valid_candidates = {
        reason: price
        for reason, price in candidate_prices.items()
        if reason not in {"min_profitable_floor", "fixed_pct_target"} and price is not None and price >= floor_price
    }
    if not valid_candidates:
        return {
            "price": floor_price,
            "fee_adjusted_price": fixed_pct_price,
            "min_profitable_price": min_profitable_price,
            "selected_reason": "activation_floor",
            "min_price": min_price,
            "candidate_prices": candidate_prices,
        }
    selected_reason, selected_price = min(valid_candidates.items(), key=lambda item: item[1])
    return {
        "price": selected_price,
        "fee_adjusted_price": fixed_pct_price,
        "min_profitable_price": min_profitable_price,
        "selected_reason": selected_reason,
        "min_price": min_price,
        "candidate_prices": candidate_prices,
    }


def _estimated_entry_fees(*, quantity: float, price: float) -> float:
    return float(toss_fee_breakdown(side="buy", quantity=quantity, price=price)["total_fees_usd"])


def _dynamic_stop_loss_price(
    entry_price: float,
    candles: list[dict],
    market_snapshot: dict | None = None,
    evaluation: dict | None = None,
    profile: dict | None = None,
) -> float:
    settings = get_settings()
    if entry_price <= 0:
        return entry_price
    normalized = _normalize_candles(candles)
    indicators = _indicator_snapshot(normalized)
    if profile is None and (market_snapshot or evaluation):
        profile = _dynamic_exit_profile(
            entry_price=entry_price,
            candles=normalized,
            quantity=None,
            market_snapshot=market_snapshot,
            evaluation=evaluation,
        )
    stop_pct = max(settings.paper_stop_loss_pct, settings.paper_min_stop_loss_pct)
    if indicators.atr20:
        stop_pct = max(stop_pct, (indicators.atr20 * settings.paper_stop_atr_multiplier) / entry_price)
    lookback = max(1, settings.paper_structure_stop_lookback_bars)
    recent_lows = [
        _to_float(row.get("low"))
        for row in normalized[-lookback:]
        if _to_float(row.get("low")) is not None
    ]
    if recent_lows:
        structure_pct = max(0.0, (entry_price - min(recent_lows)) / entry_price)
        if structure_pct > 0:
            stop_pct = max(stop_pct, structure_pct)
    profile_atr_pct = 0.0
    profile_recent_10bar_abs_change_pct = 0.0
    if profile:
        spread_fraction = _to_float(profile.get("spread_fraction")) or 0.0
        profile_atr_pct = _to_float(profile.get("atr_pct")) or 0.0
        profile_recent_10bar_abs_change_pct = _to_float(profile.get("recent_10bar_abs_change_pct")) or 0.0
        stop_multiplier = _to_float(profile.get("stop_multiplier")) or 1.0
        stop_pct = max(
            stop_pct * stop_multiplier,
            spread_fraction * 3.0,
            profile_atr_pct * 0.85,
            profile_recent_10bar_abs_change_pct * 0.70,
        )
    adaptive_cap = max(
        settings.paper_max_stop_loss_pct,
        min(
            settings.paper_adaptive_max_stop_loss_pct,
            max(stop_pct, profile_atr_pct * 1.35, profile_recent_10bar_abs_change_pct * 0.90),
        ),
    )
    stop_pct = min(max(stop_pct, settings.paper_min_stop_loss_pct), adaptive_cap)
    return entry_price * (1 - stop_pct)


def _entry_chart_snapshot(
    *,
    symbol: str,
    bucket: str,
    entry_price: float,
    execution_price: float,
    candles: list[dict],
    evaluation: dict,
    execution_market: dict,
) -> dict:
    normalized = _normalize_candles(candles)
    indicators = _indicator_snapshot(normalized)
    return {
        **_chart_context_snapshot(symbol=symbol, bucket=bucket, candles=normalized, indicators=indicators),
        "decision": "entry",
        "strategy_name": evaluation.get("strategy_name"),
        "strategy_version": evaluation.get("strategy_version"),
        "parameter_set_id": evaluation.get("parameter_set_id"),
        "final_score": evaluation.get("final_score"),
        "entry_mode": evaluation.get("entry_mode"),
        "entry_allowed": evaluation.get("entry_allowed"),
        "passed_conditions": evaluation.get("passed_conditions", [])[:8],
        "failed_conditions": evaluation.get("failed_conditions", [])[:8],
        "score_components": evaluation.get("score_components"),
        "score_weights": evaluation.get("score_weights"),
        "pattern_status": evaluation.get("pattern_status"),
        "lower_band_status": evaluation.get("lower_band_status"),
        "strategy_reference_price": entry_price,
        "execution_price": execution_price,
        "execution_market": _execution_market_summary(execution_market),
        "order_flow": _flow_summary(symbol, evaluation.get("order_flow")),
    }


def _exit_chart_snapshot(
    *,
    symbol: str,
    bucket: str,
    reason: str,
    current_price: float,
    quantity: float,
    position,
    candles: list[dict],
    indicators,
    execution_market: dict,
    momentum_state: dict,
    trailing_stop_price: float | None,
    high_watermark_before: float,
    high_watermark: float,
) -> dict:
    execution_summary = _execution_market_summary(execution_market)
    return {
        **_chart_context_snapshot(symbol=symbol, bucket=bucket, candles=_normalize_candles(candles), indicators=indicators),
        "decision": "exit",
        "reason": reason,
        "quantity": quantity,
        "current_price": current_price,
        "bid": execution_summary.get("bid"),
        "ask": execution_summary.get("ask"),
        "spread_pct": execution_summary.get("spread_pct"),
        "entry_price": position.average_price,
        "gross_pnl_estimate": (current_price - position.average_price) * quantity,
        "stop_loss_price": position.stop_loss_price,
        "take_profit_price": position.take_profit_price,
        "dynamic_take_profit_price": position.dynamic_take_profit_price,
        "dynamic_take_profit_reason": position.dynamic_take_profit_reason,
        "partial_take_profit_price": position.partial_take_profit_price,
        "trailing_stop_price": trailing_stop_price,
        "trailing_activation_price": position.trailing_activation_price,
        "high_watermark_before": high_watermark_before,
        "high_watermark_after": high_watermark,
        "momentum_state": momentum_state,
        "execution_market": execution_summary,
    }


def _log_live_decision(
    *,
    side: str,
    symbol: str,
    strategy: str | None,
    parameter_set_id: str | None,
    bucket: str,
    reason: str | None,
    price: float | None,
    quantity: float | None,
    candles: list[dict],
    market_snapshot: dict,
) -> None:
    """Append a live buy/sell decision + the full 120-candle window it saw, for the
    morning replay-vs-live review. Never raises (wraps the append helper's own guard)."""
    try:
        normalized = _normalize_candles(candles)
        window = [_compact_candle(row) for row in normalized[-120:]]
        indicators = _indicator_payload(_indicator_snapshot(normalized)) if normalized else {}
        live_decision_log.record(
            {
                "side": side,
                "symbol": symbol,
                "strategy": strategy,
                "parameter_set_id": parameter_set_id,
                "bucket": bucket,
                "reason": reason,
                "execution_price": price,
                "quantity": quantity,
                "bid": _to_float(market_snapshot.get("bid")),
                "ask": _to_float(market_snapshot.get("ask")),
                "spread_pct": _to_float(market_snapshot.get("spread_pct")),
                "candle_count": len(window),
                "indicators": indicators,
                "candle_window": window,
            }
        )
    except Exception:
        pass


def _chart_context_snapshot(*, symbol: str, bucket: str, candles: list[dict], indicators) -> dict:
    recent = [_compact_candle(row) for row in candles[-5:]]
    latest = recent[-1] if recent else {}
    return {
        "symbol": symbol,
        "bucket": bucket,
        "candle_count": len(candles),
        "latest_candle": latest,
        "recent_candles": recent,
        "indicators": _indicator_payload(indicators),
        "bb_context": _bb_context(indicators),
    }


def _indicator_payload(indicators) -> dict:
    return {
        "close": indicators.close,
        "vwap": indicators.vwap,
        "ema9": indicators.ema9,
        "ema20": indicators.ema20,
        "atr20": indicators.atr20,
        "atr_pct": indicators.atr_pct,
        "bb_upper": indicators.bb_upper,
        "bb_mid": indicators.bb_mid,
        "bb_lower": indicators.bb_lower,
        "macd": indicators.macd,
        "macd_signal": indicators.macd_signal,
        "macd_histogram": indicators.macd_histogram,
        "macd_histogram_delta": indicators.macd_histogram_delta,
        "vwap_distance_atr": indicators.vwap_distance_atr,
    }


def _compact_candle(row: dict) -> dict:
    return {
        "market_date": row.get("market_date"),
        "market_time": row.get("market_time"),
        "open": _to_float(row.get("open")),
        "high": _to_float(row.get("high")),
        "low": _to_float(row.get("low")),
        "close": _to_float(row.get("close")),
        "volume": _to_float(row.get("volume")),
        "source": row.get("source"),
        "is_live": row.get("is_live"),
    }


def _bb_context(indicators) -> dict:
    close = indicators.close
    upper = indicators.bb_upper
    lower = indicators.bb_lower
    mid = indicators.bb_mid
    ratio = None
    zone = "unknown"
    if close is not None and upper is not None and lower is not None and upper != lower:
        ratio = (close - lower) / (upper - lower)
        if ratio >= 0.9:
            zone = "near_upper"
        elif ratio >= 0.55:
            zone = "mid_to_upper"
        elif ratio >= 0.2:
            zone = "lower_to_mid"
        else:
            zone = "near_lower"
    return {
        "position_ratio": ratio,
        "zone": zone,
        "above_mid": bool(close is not None and mid is not None and close >= mid),
        "near_upper": bool(ratio is not None and ratio >= 0.9),
    }


def _flow_summary(symbol: str, flow: dict | None = None) -> dict:
    if not isinstance(flow, dict):
        flow = get_market_data_service().provider.order_flow_snapshot().get(symbol, {})
    quote = flow.get("quote") if isinstance(flow.get("quote"), dict) else {}
    trade = flow.get("trade") if isinstance(flow.get("trade"), dict) else {}
    return {
        "volume_10s": flow.get("volume_10s"),
        "volume_30s": flow.get("volume_30s"),
        "volume_60s": flow.get("volume_60s"),
        "volume_velocity_10s": flow.get("volume_velocity_10s"),
        "trade_strength": flow.get("trade_strength"),
        "sell_pressure": flow.get("sell_pressure"),
        "spread_pct": flow.get("spread_pct") if flow.get("spread_pct") is not None else quote.get("spread_pct"),
        "bid_ask_imbalance": flow.get("bid_ask_imbalance") if flow.get("bid_ask_imbalance") is not None else quote.get("bid_ask_imbalance"),
        "last_trade_price": trade.get("last"),
        "last_trade_volume": trade.get("trade_volume"),
        "last_update_age_sec": flow.get("last_update_age_sec"),
    }


def _execution_market_summary(market: dict) -> dict:
    return {
        "source": market.get("source"),
        "bid": market.get("bid"),
        "ask": market.get("ask"),
        "last": market.get("last"),
        "spread_pct": market.get("spread_pct"),
        "execution_price_source": market.get("execution_price_source"),
    }


def _dynamic_take_profit_update(
    *,
    position,
    current_price: float,
    high_watermark: float,
    momentum_state: dict,
    trailing_pct: float,
) -> dict | None:
    settings = get_settings()
    full_quantity = float(position.quantity)
    if full_quantity <= 0 or position.average_price <= 0:
        return None

    profit_floor = _position_min_profitable_exit_price(position=position, quantity=full_quantity)
    return update_dynamic_take_profit_target(
        average_price=position.average_price,
        quantity=full_quantity,
        current_price=current_price,
        high_watermark=high_watermark,
        take_profit_price=position.take_profit_price,
        previous_dynamic_take_profit_price=position.dynamic_take_profit_price,
        profit_floor=profit_floor,
        momentum_state=momentum_state,
        trailing_pct=trailing_pct,
        config=DynamicTakeProfitConfig(
            enabled=settings.paper_dynamic_take_profit_enabled,
            default_take_profit_pct=settings.paper_take_profit_pct,
            dynamic_trailing_normal_pct=settings.paper_dynamic_trailing_normal_pct,
            dynamic_trailing_wide_pct=settings.paper_dynamic_trailing_wide_pct,
            max_exit_spread_pct=_max_exit_spread_pct(),
        ),
    )


_EMERGENCY_EXIT_REASONS = EMERGENCY_EXIT_REASONS


def _exit_limit_price(exit_price: float, reason: str | None) -> float:
    settings = get_settings()
    if reason in _EMERGENCY_EXIT_REASONS:
        return exit_price * (1 - max(0.0, settings.paper_stop_loss_emergency_limit_buffer_pct))
    # Sell at the bid minus exit slippage, matching the replay execution model.
    return exit_price * (1 - settings.paper_exit_slippage_pct)


def _stop_loss_decision(
    *,
    current_price: float,
    position,
    momentum_state: dict,
    full_quantity: float,
) -> tuple[str | None, bool]:
    settings = get_settings()
    if position.stop_loss_price is None:
        _clear_stop_loss_hold(position)
        return None, False
    if current_price > position.stop_loss_price:
        _clear_stop_loss_hold(position)
        return None, False

    now = datetime.now(timezone.utc)
    if position.stop_loss_candidate_since is None:
        position.stop_loss_candidate_since = now

    loss_pct = (position.average_price - current_price) / position.average_price if position.average_price > 0 else 0.0
    hard_stop_price = position.average_price * (1 - settings.paper_max_stop_loss_pct)
    deep_break = current_price <= position.stop_loss_price * (1 - settings.paper_stop_loss_deep_break_pct)
    rapid_drop = _rapid_drop_for_stop(momentum_state, loss_pct=loss_pct)
    liquidity_break = _liquidity_break_for_stop(momentum_state)

    state = {
        "state": "candidate",
        "loss_pct": loss_pct,
        "stop_loss_price": position.stop_loss_price,
        "hard_stop_price": hard_stop_price,
        "candidate_since": position.stop_loss_candidate_since.isoformat(),
        "hold_max_seconds": settings.paper_stop_loss_hold_max_seconds,
        "deep_break": deep_break,
        "rapid_drop": rapid_drop,
        "liquidity_break": liquidity_break,
        "hold_allowed": False,
    }
    momentum_state["stop_loss_state"] = state

    if current_price <= hard_stop_price:
        state["state"] = "hard_stop"
        _clear_stop_loss_hold(position)
        return "hard_stop_loss", False
    if rapid_drop:
        state["state"] = "rapid_stop"
        _clear_stop_loss_hold(position)
        return "rapid_stop_loss", False
    if deep_break:
        state["state"] = "structure_break"
        _clear_stop_loss_hold(position)
        return "structure_stop_loss", False
    if liquidity_break:
        state["state"] = "liquidity_break"
        _clear_stop_loss_hold(position)
        return "liquidity_stop_loss", False

    hold_allowed, hold_reason = _stop_loss_hold_allowed(momentum_state)
    state["hold_allowed"] = hold_allowed
    state["hold_reason"] = hold_reason
    elapsed = (now - _to_aware(position.stop_loss_candidate_since)).total_seconds()
    state["elapsed_seconds"] = elapsed
    if settings.paper_stop_loss_hold_enabled and hold_allowed and elapsed < settings.paper_stop_loss_hold_max_seconds:
        state["state"] = "hold"
        position.stop_loss_hold_reason = hold_reason
        return None, True

    state["state"] = "confirmed"
    _clear_stop_loss_hold(position)
    return "stop_loss_confirmed", False


def _clear_stop_loss_hold(position) -> None:
    position.stop_loss_candidate_since = None
    position.stop_loss_hold_reason = None


def _rapid_drop_for_stop(momentum_state: dict, *, loss_pct: float) -> bool:
    settings = get_settings()
    drawdown_from_high = _to_float(momentum_state.get("drawdown_from_high_pct")) or 0.0
    chart_breakdown = bool(momentum_state.get("chart_breakdown"))
    order_flow_weak = bool(momentum_state.get("order_flow_weak"))
    return (
        loss_pct >= settings.paper_stop_loss_rapid_drop_pct
        and (chart_breakdown or order_flow_weak)
    ) or (
        chart_breakdown
        and order_flow_weak
        and drawdown_from_high >= settings.paper_stop_loss_rapid_drop_pct
    ) or (
        loss_pct >= settings.paper_stop_loss_rapid_drop_pct * 1.5
        or (
            drawdown_from_high >= settings.paper_stop_loss_rapid_drop_pct
            and chart_breakdown
        )
    )


def _liquidity_break_for_stop(momentum_state: dict) -> bool:
    settings = get_settings()
    sell_pressure = _to_float(momentum_state.get("sell_pressure"))
    trade_strength = _to_float(momentum_state.get("trade_strength"))
    if trade_strength is not None and trade_strength <= 1:
        trade_strength *= 100
    flow_velocity = _to_float(momentum_state.get("flow_volume_velocity_10s"))
    chart_breakdown = bool(momentum_state.get("chart_breakdown"))
    severe_sell_pressure = (
        sell_pressure is not None
        and sell_pressure >= min(0.9, settings.strategy_max_sell_pressure_for_entry + 0.2)
        and (trade_strength is None or trade_strength < settings.strategy_min_trade_strength_for_entry)
    )
    flow_dried = flow_velocity is not None and flow_velocity < 0.35
    return chart_breakdown and (severe_sell_pressure or flow_dried or bool(momentum_state.get("spread_widened")))


def _stop_loss_hold_allowed(momentum_state: dict) -> tuple[bool, str]:
    settings = get_settings()
    if not momentum_state.get("chart_breakdown"):
        return True, "chart_structure_holding"
    if momentum_state.get("spread_widened") and momentum_state.get("chart_breakdown"):
        return False, "spread_widened_with_chart_breakdown"
    trade_strength = _to_float(momentum_state.get("trade_strength"))
    if trade_strength is not None and trade_strength <= 1:
        trade_strength *= 100
    sell_pressure = _to_float(momentum_state.get("sell_pressure"))
    flow_velocity = _to_float(momentum_state.get("flow_volume_velocity_10s"))
    trade_strength_ok = trade_strength is None or trade_strength >= max(35.0, settings.strategy_min_trade_strength_for_entry - 10)
    sell_pressure_ok = sell_pressure is None or sell_pressure <= min(0.75, settings.strategy_max_sell_pressure_for_entry + 0.15)
    velocity_ok = flow_velocity is None or flow_velocity >= 0.6
    if trade_strength_ok and sell_pressure_ok and velocity_ok:
        return True, "order_flow_rebound_watch"
    return False, "order_flow_not_supportive"


def _exit_decision(
    *,
    current_price: float,
    position,
    indicators,
    high_watermark: float,
    trailing_stop_price: float | None,
    momentum_state: dict,
) -> tuple[str | None, float]:
    settings = get_settings()
    full_quantity = float(position.quantity)
    partial_exit_enabled = settings.paper_partial_exit_fraction > 0
    partial_quantity = max(1.0, int(full_quantity * settings.paper_partial_exit_fraction)) if partial_exit_enabled else 0.0
    partial_profit_floor = _position_min_profitable_exit_price(position=position, quantity=min(partial_quantity, full_quantity))
    full_profit_floor = _position_min_profitable_exit_price(position=position, quantity=full_quantity)
    now = datetime.now(timezone.utc)
    stop_candidate_elapsed = (
        (now - _to_aware(position.stop_loss_candidate_since)).total_seconds()
        if position.stop_loss_candidate_since is not None
        else None
    )
    result = evaluate_exit_decision(
        current_price=current_price,
        position=ExitDecisionPosition(
            quantity=full_quantity,
            average_price=float(position.average_price),
            opened_elapsed_seconds=(datetime.utcnow() - _to_naive(position.opened_at)).total_seconds(),
            stop_loss_price=position.stop_loss_price,
            take_profit_price=position.take_profit_price,
            partial_take_profit_price=position.partial_take_profit_price,
            partial_exit_done=bool(position.partial_exit_done),
            trailing_activation_price=position.trailing_activation_price,
            stop_loss_candidate_elapsed_seconds=stop_candidate_elapsed,
        ),
        indicators=ExitDecisionIndicators(
            ema9=indicators.ema9,
            ema20=indicators.ema20,
            vwap=indicators.vwap,
            bb_mid=indicators.bb_mid,
            bb_lower=indicators.bb_lower,
        ),
        high_watermark=high_watermark,
        trailing_stop_price=trailing_stop_price,
        momentum_state=momentum_state,
        high_failure_count=_high_failure_count_for_exit(position.symbol, settings.paper_high_failure_lookback_bars),
        full_profit_floor=full_profit_floor,
        partial_profit_floor=partial_profit_floor,
        config=_exit_decision_config(settings),
    )
    if result.stop_loss_state.payload:
        momentum_state["stop_loss_state"] = result.stop_loss_state.payload
    _apply_exit_stop_loss_state(position, result.stop_loss_state, now=now)
    return result.reason, result.quantity


def _exit_decision_config(settings) -> ExitDecisionConfig:
    return ExitDecisionConfig(
        partial_exit_fraction=settings.paper_partial_exit_fraction,
        dynamic_take_profit_enabled=settings.paper_dynamic_take_profit_enabled,
        partial_exit_requires_weakness=settings.paper_partial_exit_requires_weakness,
        high_failure_exit_enabled=settings.paper_high_failure_exit_enabled,
        break_even_activation_pct=settings.paper_break_even_activation_pct,
        trailing_activation_pct=settings.paper_trailing_activation_pct,
        take_profit_requires_weakness=settings.paper_take_profit_requires_weakness,
        exit_on_vwap_ema_break=settings.paper_exit_on_vwap_ema_break,
        vwap_ema_break_min_hold_seconds=settings.paper_vwap_ema_break_min_hold_seconds,
        vwap_ema_break_min_loss_pct=settings.paper_vwap_ema_break_min_loss_pct,
        time_exit_enabled=settings.paper_time_exit_enabled,
        time_exit_seconds=settings.paper_time_exit_seconds,
        stop_loss_hold_enabled=settings.paper_stop_loss_hold_enabled,
        stop_loss_hold_max_seconds=settings.paper_stop_loss_hold_max_seconds,
        max_stop_loss_pct=settings.paper_max_stop_loss_pct,
        stop_loss_deep_break_pct=settings.paper_stop_loss_deep_break_pct,
        stop_loss_rapid_drop_pct=settings.paper_stop_loss_rapid_drop_pct,
        strategy_min_trade_strength_for_entry=settings.strategy_min_trade_strength_for_entry,
        strategy_max_sell_pressure_for_entry=settings.strategy_max_sell_pressure_for_entry,
    )


def _apply_exit_stop_loss_state(position, stop_loss_state, *, now: datetime) -> None:
    if stop_loss_state.action == "clear":
        _clear_stop_loss_hold(position)
        return
    if stop_loss_state.action in {"set", "hold"}:
        if position.stop_loss_candidate_since is None:
            position.stop_loss_candidate_since = now
        position.stop_loss_hold_reason = stop_loss_state.hold_reason


def _is_profit_exit(reason: str | None) -> bool:
    return is_profit_exit_reason(reason)


def _estimated_exit_net_pnl(*, position, quantity: float, exit_price: float) -> float:
    close_ratio = min(1.0, quantity / position.quantity) if position.quantity > 0 else 1.0
    gross_pnl = (exit_price - position.average_price) * quantity
    entry_fees = position.entry_fees_usd * close_ratio
    exit_fees = _estimated_exit_fees(quantity=quantity, price=exit_price)
    return gross_pnl - entry_fees - exit_fees


def _position_min_profitable_exit_price(*, position, quantity: float) -> float:
    settings = get_settings()
    quantity = max(0.0, min(float(quantity), float(position.quantity)))
    if quantity <= 0 or position.average_price <= 0:
        return float("inf")
    close_ratio = min(1.0, quantity / position.quantity) if position.quantity > 0 else 1.0
    entry_fees = position.entry_fees_usd * close_ratio
    min_net_profit = position.average_price * quantity * max(0.0, settings.paper_min_net_take_profit_pct)
    required_price = position.average_price
    for _ in range(3):
        exit_fees = _estimated_exit_fees(quantity=quantity, price=required_price)
        required_price = (position.average_price * quantity + entry_fees + exit_fees + min_net_profit) / quantity
        required_price = max(required_price, position.average_price)
    return required_price


def _estimated_exit_fees(*, quantity: float, price: float) -> float:
    return float(toss_fee_breakdown(side="sell", quantity=quantity, price=price)["total_fees_usd"])


def _high_failure_count_for_exit(symbol: str, lookback: int) -> int:
    candles = candle_builder.live_tick_candles(symbol, limit=max(lookback + 6, 12), include_current=True, newest_first=False)
    normalized = _normalize_candles(candles)
    return _high_failure_count(normalized, lookback=max(2, lookback))


def _volume_decay_for_exit(symbol: str) -> bool:
    # Completed candles only: the current forming 1m candle has only accumulated a few
    # seconds of volume early in the minute, which would otherwise read as a false
    # "volume decay" every minute and prematurely trip the weakness/take-profit exit.
    candles = candle_builder.live_tick_candles(symbol, limit=10, include_current=False, newest_first=False)
    normalized = _normalize_candles(candles)
    if len(normalized) < 6:
        return False
    recent = [_to_float(row.get("volume")) or 0.0 for row in normalized[-3:]]
    previous = [_to_float(row.get("volume")) or 0.0 for row in normalized[-6:-3]]
    recent_avg = sum(recent) / len(recent)
    previous_avg = sum(previous) / len(previous)
    if previous_avg <= 0:
        return False
    return recent_avg < previous_avg * 0.75


def _exit_momentum_state(*, symbol: str, current_price: float, position, indicators, high_watermark: float) -> dict:
    settings = get_settings()
    profit_pct = (current_price - position.average_price) / position.average_price if position.average_price > 0 else 0.0
    drawdown_from_high_pct = (high_watermark - current_price) / high_watermark if high_watermark > 0 else 0.0
    high_failures = _high_failure_count_for_exit(symbol, settings.paper_high_failure_lookback_bars)
    volume_decay = _volume_decay_for_exit(symbol)
    candles, _ = _strategy_candle_window(symbol, prefer_toss_position=True)
    chart_structure = _exit_chart_structure_state(
        current_price=current_price,
        candles=candles,
        indicators=indicators,
    )
    macd_exit = _macd_recovery_status(candles, lookback=settings.paper_macd_fading_hist_slope_lookback)
    flow = get_market_data_service().provider.order_flow_snapshot().get(symbol, {})
    trade_strength = _to_float(flow.get("trade_strength"))
    if trade_strength is not None and trade_strength <= 1:
        trade_strength *= 100
    sell_pressure = _to_float(flow.get("sell_pressure"))
    if sell_pressure is None:
        sell_pressure = _to_float(flow.get("aggressive_sell_ratio"))
    if sell_pressure is not None and sell_pressure > 1:
        sell_pressure /= 100
    flow_volume_60s = _to_float(flow.get("volume_60s"))
    flow_volume_velocity = _to_float(flow.get("volume_velocity_10s"))
    order_flow_strong = (
        (trade_strength is None or trade_strength >= settings.strategy_min_trade_strength_for_entry)
        and (sell_pressure is None or sell_pressure <= settings.strategy_max_sell_pressure_for_entry)
        and (flow_volume_velocity is None or flow_volume_velocity >= 0.8)
    )
    order_flow_weak = (
        (trade_strength is not None and trade_strength < settings.strategy_min_trade_strength_for_entry)
        or (sell_pressure is not None and sell_pressure > settings.strategy_max_sell_pressure_for_entry)
        or (flow_volume_velocity is not None and flow_volume_velocity < 0.6)
        or (flow_volume_60s is not None and flow_volume_60s <= 0)
    )
    above_ema9 = indicators.ema9 is None or current_price >= indicators.ema9
    above_ema20 = indicators.ema20 is None or current_price >= indicators.ema20
    above_vwap = indicators.vwap is None or current_price >= indicators.vwap
    macd_holding = indicators.macd_histogram_delta is None or indicators.macd_histogram_delta >= 0
    upper_band_push = indicators.bb_upper is not None and current_price >= indicators.bb_upper
    near_high = drawdown_from_high_pct <= max(settings.paper_dynamic_trailing_tight_pct, 0.006)
    below_ema9 = indicators.ema9 is not None and current_price < indicators.ema9
    macd_fading_raw = bool(macd_exit.get("histogram_fading_above_zero"))
    chart_profit_weakness = (
        bool(chart_structure.get("ema_vwap_break"))
        or high_failures >= 2
        or (volume_decay and not near_high)
        or (indicators.macd_histogram_delta is not None and indicators.macd_histogram_delta < 0 and not above_ema9)
    )
    flow_weak_confirmation = order_flow_weak and (chart_profit_weakness or drawdown_from_high_pct >= settings.paper_dynamic_trailing_tight_pct)
    strong = (
        profit_pct >= settings.paper_break_even_activation_pct
        and above_ema9
        and (above_vwap or above_ema20)
        and macd_holding
        and near_high
        and high_failures < 2
        and not volume_decay
        and order_flow_strong
    )
    runner_candidate = profit_pct >= settings.paper_runner_candidate_profit_pct
    runner_eligible = (
        runner_candidate
        and above_ema9
        and (above_vwap or above_ema20)
        and macd_holding
        and not macd_fading_raw
        and not volume_decay
        and high_failures <= 1
        and near_high
        and order_flow_strong
    )
    runner = profit_pct >= settings.paper_runner_trailing_profit_pct or runner_eligible
    runner_full_exit_setup = (
        runner
        and high_failures >= settings.paper_runner_full_exit_high_failures
        and volume_decay
        and below_ema9
        and macd_fading_raw
    )
    runner_emergency_exit = runner and drawdown_from_high_pct >= settings.paper_runner_emergency_drawdown_pct
    weak = (
        profit_pct > 0
        and (chart_profit_weakness or flow_weak_confirmation)
    )
    if runner and not runner_full_exit_setup and not runner_emergency_exit:
        weak = False
    elif upper_band_push and strong:
        weak = False
    return {
        "profit_pct": profit_pct,
        "drawdown_from_high_pct": drawdown_from_high_pct,
        "high_failures": high_failures,
        "volume_decay": volume_decay,
        "above_ema9": above_ema9,
        "above_ema20": above_ema20,
        "above_vwap": above_vwap,
        "below_ema9": below_ema9,
        "macd_holding": macd_holding,
        "macd_exit": macd_exit,
        "macd_histogram_fading_raw": macd_fading_raw,
        "macd_histogram_fading_confirmed": False,
        "upper_band_push": upper_band_push,
        "near_high": near_high,
        "trade_strength": trade_strength,
        "sell_pressure": sell_pressure,
        "flow_volume_60s": flow_volume_60s,
        "flow_volume_velocity_10s": flow_volume_velocity,
        "order_flow_strong": order_flow_strong,
        "order_flow_weak": order_flow_weak,
        "chart_structure": chart_structure,
        "chart_breakdown": chart_structure.get("chart_breakdown"),
        "structure_low_break": chart_structure.get("structure_low_break"),
        "ema_vwap_break": chart_structure.get("ema_vwap_break"),
        "bb_lower_break": chart_structure.get("bb_lower_break"),
        "chart_profit_weakness": chart_profit_weakness,
        "flow_weak_confirmation": flow_weak_confirmation,
        "strong": strong,
        "runner_candidate": runner_candidate,
        "runner_eligible": runner_eligible,
        "runner": runner,
        "runner_full_exit_setup": runner_full_exit_setup,
        "runner_full_exit_confirmed": False,
        "runner_emergency_exit": runner_emergency_exit,
        "weak": weak,
    }


def _exit_chart_structure_state(*, current_price: float, candles: list[dict], indicators) -> dict:
    normalized = _normalize_candles(candles)
    previous = normalized[-6:-1] if len(normalized) >= 2 else []
    recent_lows = [_to_float(row.get("low")) for row in previous]
    recent_lows = [value for value in recent_lows if value is not None]
    structure_low = min(recent_lows) if recent_lows else None
    structure_low_break = (
        structure_low is not None
        and current_price < structure_low * 0.998
    )
    below_ema9 = indicators.ema9 is not None and current_price < indicators.ema9
    below_ema20 = indicators.ema20 is not None and current_price < indicators.ema20
    below_vwap = indicators.vwap is not None and current_price < indicators.vwap
    ema_vwap_break = below_ema9 and (below_ema20 or below_vwap)
    bb_lower_break = indicators.bb_lower is not None and current_price < indicators.bb_lower
    bb_mid_reject = indicators.bb_mid is not None and current_price < indicators.bb_mid and below_ema9
    chart_breakdown = bool(structure_low_break and (ema_vwap_break or bb_lower_break))
    return {
        "structure_low": structure_low,
        "structure_low_break": structure_low_break,
        "below_ema9": below_ema9,
        "below_ema20": below_ema20,
        "below_vwap": below_vwap,
        "ema_vwap_break": ema_vwap_break,
        "bb_lower_break": bb_lower_break,
        "bb_mid_reject": bb_mid_reject,
        "chart_breakdown": chart_breakdown,
    }


def _dynamic_trailing_stop_pct(momentum_state: dict) -> float:
    settings = get_settings()
    return choose_dynamic_trailing_pct(
        momentum_state,
        dynamic_take_profit_enabled=settings.paper_dynamic_take_profit_enabled,
        default_pct=settings.paper_trailing_stop_pct,
        tight_pct=settings.paper_dynamic_trailing_tight_pct,
        normal_pct=settings.paper_dynamic_trailing_normal_pct,
        wide_pct=settings.paper_dynamic_trailing_wide_pct,
    )


def _vwap_ema_break(current_price: float, indicators) -> bool:
    if indicators.vwap is None or indicators.ema20 is None:
        return False
    below_vwap = current_price < indicators.vwap
    below_ema20 = current_price < indicators.ema20
    ema_rollover = indicators.ema9 is not None and indicators.ema9 < indicators.ema20
    return below_vwap and (below_ema20 or ema_rollover)


def _to_naive(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value
    return value.astimezone(timezone.utc).replace(tzinfo=None)


def _to_aware(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _to_float(value: str | int | float | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        return None


strategy_runtime = StrategyRuntime()
