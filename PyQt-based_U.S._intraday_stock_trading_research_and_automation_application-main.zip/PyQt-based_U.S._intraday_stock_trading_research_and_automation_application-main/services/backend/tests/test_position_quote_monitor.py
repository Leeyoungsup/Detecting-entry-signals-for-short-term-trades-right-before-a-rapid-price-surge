from app.domain.models import OrderRequest
from app.services.paper_broker import InternalPaperBroker
from app.services import strategy_runtime as strategy_runtime_module


def _enable_internal_paper_monitor(monkeypatch):
    settings = strategy_runtime_module.get_settings()
    monkeypatch.setattr(settings, "trading_mode", "internal_paper")
    monkeypatch.setattr(settings, "toss_position_quote_monitor_enabled", True)
    return settings


def test_position_quote_monitor_backs_off_missing_bid_last(monkeypatch) -> None:
    broker = InternalPaperBroker()
    broker.reset()
    strategy_runtime_module.strategy_runtime._position_quote_blocked_until.clear()

    broker.submit_order(
        OrderRequest(symbol="AAPL", side="buy", quantity=1, limit_price=10, mode="internal_paper"),
        market_snapshot={"ask": 10.0, "bid": 9.99, "last": 10.0, "spread_pct": 0.1},
    )
    calls = {"count": 0}

    def fake_quote(symbol: str, *, max_cache_age_sec: float = 1.0) -> dict:
        calls["count"] += 1
        return {"symbol": symbol, "source": "test"}

    monkeypatch.setattr(strategy_runtime_module, "execution_quote_snapshot", fake_quote)
    settings = _enable_internal_paper_monitor(monkeypatch)
    monkeypatch.setattr(settings, "toss_position_quote_failure_cooldown_sec", 30.0)

    first = strategy_runtime_module.strategy_runtime.monitor_open_positions()
    second = strategy_runtime_module.strategy_runtime.monitor_open_positions()

    assert calls["count"] == 1
    assert first["blocked"][0]["error"] == "missing_bid_last"
    assert second["blocked"][0]["error"] == "quote_failure_cooldown"

    broker.reset()
    strategy_runtime_module.strategy_runtime._position_quote_blocked_until.clear()


def test_position_quote_monitor_rotates_positions_round_robin(monkeypatch) -> None:
    broker = InternalPaperBroker()
    broker.reset()
    runtime = strategy_runtime_module.strategy_runtime
    runtime._position_quote_blocked_until.clear()
    runtime._position_quote_cursor = 0

    settings = _enable_internal_paper_monitor(monkeypatch)
    monkeypatch.setattr(settings, "paper_max_open_positions", 20)
    monkeypatch.setattr(settings, "paper_max_total_exposure_pct", 10.0)
    monkeypatch.setattr(settings, "toss_position_quote_max_symbols_per_tick", 4)
    monkeypatch.setattr(runtime, "_monitor_exit", lambda *args, **kwargs: None)

    for index in range(10):
        broker.submit_order(
            OrderRequest(symbol=f"T{index:02d}", side="buy", quantity=1, limit_price=10, mode="internal_paper"),
            market_snapshot={"ask": 10.0, "bid": 9.99, "last": 10.0, "spread_pct": 0.01},
        )

    def fake_quote(symbol: str, *, max_cache_age_sec: float = 1.0) -> dict:
        return {"symbol": symbol, "bid": 10.0, "ask": 10.01, "last": 10.0, "source": "test"}

    monkeypatch.setattr(strategy_runtime_module, "execution_quote_snapshot", fake_quote)

    first = runtime.monitor_open_positions()
    second = runtime.monitor_open_positions()
    third = runtime.monitor_open_positions()

    assert first["selected_symbols"] == ["T00", "T01", "T02", "T03"]
    assert second["selected_symbols"] == ["T04", "T05", "T06", "T07"]
    assert third["selected_symbols"] == ["T08", "T09", "T00", "T01"]

    broker.reset()
    runtime._position_quote_blocked_until.clear()
    runtime._position_quote_cursor = 0


def test_position_quote_monitor_reuses_one_quote_for_same_symbol_strategies(monkeypatch) -> None:
    broker = InternalPaperBroker()
    broker.reset()
    runtime = strategy_runtime_module.strategy_runtime
    runtime._position_quote_blocked_until.clear()
    runtime._position_quote_cursor = 0

    settings = _enable_internal_paper_monitor(monkeypatch)
    monkeypatch.setattr(settings, "paper_max_open_positions", 20)
    monkeypatch.setattr(settings, "paper_max_total_exposure_pct", 10.0)
    monkeypatch.setattr(settings, "toss_position_quote_max_symbols_per_tick", 1)

    for parameter_set_id in ("surge", "ofi", "runner"):
        broker.submit_order(
            OrderRequest(
                symbol="AAPL",
                side="buy",
                quantity=1,
                limit_price=10,
                mode="internal_paper",
                strategy_signal_id=parameter_set_id,
            ),
            market_snapshot={
                "ask": 10.0,
                "bid": 9.99,
                "last": 10.0,
                "spread_pct": 0.01,
                "parameter_set_id": parameter_set_id,
            },
        )
    broker.submit_order(
        OrderRequest(
            symbol="MSFT",
            side="buy",
            quantity=1,
            limit_price=10,
            mode="internal_paper",
            strategy_signal_id="surge",
        ),
        market_snapshot={"ask": 10.0, "bid": 9.99, "last": 10.0, "spread_pct": 0.01, "parameter_set_id": "surge"},
    )

    quote_calls: list[str] = []
    exit_position_keys: list[str] = []

    def fake_quote(symbol: str, *, max_cache_age_sec: float = 1.0) -> dict:
        quote_calls.append(symbol)
        return {"symbol": symbol, "bid": 10.0, "ask": 10.01, "last": 10.0, "source": "test"}

    def fake_monitor_exit(symbol: str, event: dict, candle: dict, *, execution_market: dict | None = None, position_key: str | None = None) -> None:
        exit_position_keys.append(str(position_key))

    monkeypatch.setattr(strategy_runtime_module, "execution_quote_snapshot", fake_quote)
    monkeypatch.setattr(runtime, "_monitor_exit", fake_monitor_exit)

    first = runtime.monitor_open_positions()
    second = runtime.monitor_open_positions()

    assert first["selected_symbols"] == ["AAPL"]
    assert first["unique_symbols_quoted"] == 1
    assert first["checked"] == 3
    assert quote_calls == ["AAPL", "MSFT"]
    assert len(exit_position_keys[:3]) == 3
    assert all(key.startswith("AAPL::") for key in exit_position_keys[:3])
    assert second["selected_symbols"] == ["MSFT"]
    assert second["checked"] == 1

    broker.reset()
    runtime._position_quote_blocked_until.clear()
    runtime._position_quote_cursor = 0
