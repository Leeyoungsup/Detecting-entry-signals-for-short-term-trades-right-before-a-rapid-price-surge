"use client";

import { useMemo, useState } from "react";
import { BarChart3, Clock3, FileSpreadsheet, Loader2, Play, TestTube2 } from "lucide-react";

import { PageTitle } from "@/components/page-title";
import { apiPost } from "@/lib/api";

type ReplayBar = {
  timestamp_kst: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  notional_usd?: number | null;
  ema9?: number | null;
  ema20?: number | null;
  bb_mid20?: number | null;
  bb_upper20?: number | null;
  bb_lower20?: number | null;
  session_vwap?: number | null;
  macd_histogram?: number | null;
  avg_spread_pct?: number | null;
  trade_strength?: number | null;
  sell_pressure?: number | null;
};

type SummaryRow = {
  strategy: string;
  trades: number;
  wins: number;
  losses: number;
  win_rate_pct: number;
  net_pnl_usd: number;
  return_on_2000_pct: number;
  avg_win_usd: number;
  avg_loss_usd: number;
  profit_factor: number;
  max_win_usd: number;
  max_loss_usd: number;
};

type TradeRow = {
  strategy: string;
  entry_time: string;
  exit_time: string;
  quantity: number;
  entry_price: number;
  exit_price: number;
  net_pnl: number;
  return_pct: number;
  entry_reason: string;
  exit_reason: string;
};

type DiagnosticRow = {
  timestamp_kst: string;
  close: number;
  volume?: number | null;
  notional_usd?: number | null;
  bb_position?: number | null;
  avg_spread_pct?: number | null;
  trade_strength?: number | null;
  sell_pressure?: number | null;
  expected_upside_pct: number;
  expected_pullback_upside_pct?: number;
  expected_runner_upside_pct?: number;
  required_profit_pct: number;
  signals: string[];
  blockers: string[];
};

type ReplayResponse = {
  symbol: string;
  date_kst: string;
  end_date_kst?: string;
  start_time_kst: string;
  end_time_kst: string;
  bars: ReplayBar[];
  summary_rows: SummaryRow[];
  trades: TradeRow[];
  diagnostics: DiagnosticRow[];
  totals: {
    strategies: number;
    trades: number;
    net_pnl_usd: number;
    return_on_2000_pct: number;
  };
  source: {
    bars_csv: string;
    enriched_csv: string;
    quotes?: number;
    trade_ticks?: number;
  };
  assumptions: Record<string, string>;
};

const currency = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 });
const number = new Intl.NumberFormat("ko-KR", { maximumFractionDigits: 2 });

function kstToday() {
  return new Date(Date.now() + 9 * 60 * 60 * 1000).toISOString().slice(0, 10);
}

function toEasternLabel(dateKst: string, timeKst: string) {
  const date = new Date(`${dateKst}T${timeKst}:00+09:00`);
  if (Number.isNaN(date.getTime())) return "-";
  return new Intl.DateTimeFormat("ko-KR", {
    timeZone: "America/New_York",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(date);
}

function moneyClass(value: number) {
  if (value > 0) return "text-emerald-600";
  if (value < 0) return "text-red-600";
  return "text-zinc-700";
}

function pct(value?: number | null) {
  if (value === null || value === undefined || Number.isNaN(value)) return "-";
  return `${number.format(value)}%`;
}

function timeLabel(value: string) {
  return value?.slice(11, 16) ?? "-";
}

function StrategyReplayChart({ bars, trades }: { bars: ReplayBar[]; trades: TradeRow[] }) {
  const chart = useMemo(() => {
    const priceValues = bars.flatMap((bar) =>
      [bar.high, bar.low, bar.bb_upper20, bar.bb_lower20, bar.session_vwap, bar.ema9, bar.ema20].filter(
        (value): value is number => typeof value === "number" && Number.isFinite(value),
      ),
    );
    const min = Math.min(...priceValues);
    const max = Math.max(...priceValues);
    const range = Math.max(max - min, max * 0.01);
    return { min: min - range * 0.08, max: max + range * 0.08 };
  }, [bars]);

  if (!bars.length) {
    return <div className="grid h-80 place-items-center text-sm text-zinc-500">Replay할 차트 데이터가 없습니다.</div>;
  }

  const width = 1180;
  const height = 520;
  const left = 58;
  const right = 22;
  const top = 26;
  const priceHeight = 340;
  const volumeTop = top + priceHeight + 26;
  const volumeHeight = 100;
  const plotWidth = width - left - right;
  const step = plotWidth / Math.max(1, bars.length - 1);
  const candleWidth = Math.max(3, Math.min(10, step * 0.55));
  const volumeMax = Math.max(...bars.map((bar) => bar.volume || 0), 1);
  const x = (index: number) => left + index * step;
  const y = (value: number) => top + ((chart.max - value) / (chart.max - chart.min)) * priceHeight;
  const vy = (value: number) => volumeTop + volumeHeight - (value / volumeMax) * volumeHeight;
  const line = (key: keyof ReplayBar) =>
    bars
      .map((bar, index) => {
        const value = bar[key];
        return typeof value === "number" && Number.isFinite(value) ? `${x(index)},${y(value)}` : "";
      })
      .filter(Boolean)
      .join(" ");
  const tradeByMinute = new Map<string, TradeRow[]>();
  for (const trade of trades) {
    for (const [time, marker] of [
      [trade.entry_time, "B"],
      [trade.exit_time, "S"],
    ] as const) {
      const key = time.slice(0, 16);
      const row = { ...trade, exit_reason: marker === "B" ? trade.entry_reason : trade.exit_reason };
      tradeByMinute.set(key, [...(tradeByMinute.get(key) ?? []), row]);
    }
  }

  return (
    <div className="overflow-x-auto">
      <svg viewBox={`0 0 ${width} ${height}`} className="min-w-[980px] rounded bg-slate-50">
        {[0, 1, 2, 3, 4].map((tick) => {
          const yy = top + (priceHeight / 4) * tick;
          const value = chart.max - ((chart.max - chart.min) / 4) * tick;
          return (
            <g key={tick}>
              <line x1={left} x2={width - right} y1={yy} y2={yy} stroke="#e2e8f0" />
              <text x={8} y={yy + 4} className="fill-slate-500 text-[12px]">
                {value.toFixed(3)}
              </text>
            </g>
          );
        })}
        {[0, Math.floor(bars.length / 3), Math.floor((bars.length * 2) / 3), bars.length - 1].map((index) => (
          <g key={`${index}-${bars[index]?.timestamp_kst}`}>
            <line x1={x(index)} x2={x(index)} y1={top} y2={volumeTop + volumeHeight} stroke="#e2e8f0" />
            <text x={x(index) - 18} y={height - 18} className="fill-slate-500 text-[12px]">
              {timeLabel(bars[index]?.timestamp_kst)}
            </text>
          </g>
        ))}
        <polygon
          points={`${line("bb_upper20")} ${line("bb_lower20").split(" ").reverse().join(" ")}`}
          fill="#dbeafe"
          opacity="0.5"
        />
        <polyline points={line("bb_upper20")} fill="none" stroke="#60a5fa" strokeDasharray="6 5" strokeWidth="1.8" />
        <polyline points={line("bb_lower20")} fill="none" stroke="#60a5fa" strokeDasharray="6 5" strokeWidth="1.8" />
        <polyline points={line("session_vwap")} fill="none" stroke="#7c3aed" strokeWidth="2" />
        <polyline points={line("ema9")} fill="none" stroke="#f59e0b" strokeWidth="1.8" />
        <polyline points={line("ema20")} fill="none" stroke="#10b981" strokeWidth="1.8" />
        {bars.map((bar, index) => {
          const up = bar.close >= bar.open;
          const color = up ? "#dc2626" : "#2563eb";
          const bodyTop = y(Math.max(bar.open, bar.close));
          const bodyHeight = Math.max(2, Math.abs(y(bar.open) - y(bar.close)));
          const key = bar.timestamp_kst.slice(0, 16);
          const markers = tradeByMinute.get(key) ?? [];
          return (
            <g key={bar.timestamp_kst}>
              <line x1={x(index)} x2={x(index)} y1={y(bar.high)} y2={y(bar.low)} stroke={color} strokeWidth="1.5" />
              <rect
                x={x(index) - candleWidth / 2}
                y={bodyTop}
                width={candleWidth}
                height={bodyHeight}
                fill={up ? "#fff1f2" : "#eff6ff"}
                stroke={color}
                strokeWidth="1.5"
              >
                <title>{`${bar.timestamp_kst} O:${bar.open} H:${bar.high} L:${bar.low} C:${bar.close} V:${bar.volume}`}</title>
              </rect>
              <rect
                x={x(index) - candleWidth / 2}
                y={vy(bar.volume)}
                width={candleWidth}
                height={volumeTop + volumeHeight - vy(bar.volume)}
                fill={up ? "#f87171" : "#60a5fa"}
                opacity="0.75"
              />
              {markers.map((marker, markerIndex) => {
                const isBuy = marker.exit_reason === marker.entry_reason;
                const cy = y(isBuy ? bar.low : bar.high) + (isBuy ? 18 + markerIndex * 12 : -18 - markerIndex * 12);
                return (
                  <g key={`${marker.strategy}-${markerIndex}`}>
                    <circle cx={x(index)} cy={cy} r="8" fill={isBuy ? "#2563eb" : "#ef4444"} />
                    <text x={x(index) - 4} y={cy + 4} className="fill-white text-[10px] font-bold">
                      {isBuy ? "B" : "S"}
                    </text>
                  </g>
                );
              })}
            </g>
          );
        })}
        <line x1={left} x2={width - right} y1={volumeTop + volumeHeight} y2={volumeTop + volumeHeight} stroke="#94a3b8" />
        <g className="text-[12px]">
          <line x1={left} x2={left + 22} y1={height - 4} y2={height - 4} stroke="#60a5fa" strokeDasharray="5 4" />
          <text x={left + 28} y={height - 1} className="fill-slate-600">
            Bollinger
          </text>
          <line x1={left + 115} x2={left + 137} y1={height - 4} y2={height - 4} stroke="#7c3aed" strokeWidth="2" />
          <text x={left + 143} y={height - 1} className="fill-slate-600">
            VWAP
          </text>
          <line x1={left + 205} x2={left + 227} y1={height - 4} y2={height - 4} stroke="#f59e0b" strokeWidth="2" />
          <text x={left + 233} y={height - 1} className="fill-slate-600">
            EMA9
          </text>
          <line x1={left + 292} x2={left + 314} y1={height - 4} y2={height - 4} stroke="#10b981" strokeWidth="2" />
          <text x={left + 320} y={height - 1} className="fill-slate-600">
            EMA20
          </text>
        </g>
      </svg>
    </div>
  );
}

const MAX_DURATION_MIN = 16 * 60;
const isValidTime = (value: string) => /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
const pad2 = (value: number) => String(value).padStart(2, "0");

function addDaysKst(dateStr: string, days: number) {
  const date = new Date(`${dateStr}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

// End datetime derived from a KST start + a duration in minutes (pure KST component
// math, so it crosses midnight into the next date without timezone drift).
function computeEnd(startDate: string, startTime: string, durationMin: number) {
  if (!isValidTime(startTime) || durationMin <= 0) return null;
  const [hours, minutes] = startTime.split(":").map(Number);
  const total = hours * 60 + minutes + durationMin;
  const dayOffset = Math.floor(total / 1440);
  const minuteOfDay = total % 1440;
  return {
    endDate: addDaysKst(startDate, dayOffset),
    endTime: `${pad2(Math.floor(minuteOfDay / 60))}:${pad2(minuteOfDay % 60)}`,
  };
}

export default function BacktestsPage() {
  const [symbol, setSymbol] = useState("TC");
  const [startDate, setStartDate] = useState(kstToday());
  const [startTime, setStartTime] = useState("17:20");
  const [durationHours, setDurationHours] = useState(1);
  const [durationMinutes, setDurationMinutes] = useState(40);
  const [result, setResult] = useState<ReplayResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const durationMin = durationHours * 60 + durationMinutes;
  const end = useMemo(() => computeEnd(startDate, startTime, durationMin), [startDate, startTime, durationMin]);
  const rangeValid = end != null && durationMin > 0 && durationMin <= MAX_DURATION_MIN;
  const easternWindow = useMemo(
    () => (end ? `${toEasternLabel(startDate, startTime)} ~ ${toEasternLabel(end.endDate, end.endTime)} ET` : "-"),
    [startDate, startTime, end],
  );

  async function runReplay() {
    if (!rangeValid || !end) {
      setError("시작 시간은 24시간 HH:MM 형식이어야 하고, 지속 시간은 1분 이상 16시간 이하여야 합니다.");
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const payload = await apiPost<
        ReplayResponse,
        { symbol: string; date_kst: string; end_date_kst: string; start_time_kst: string; end_time_kst: string }
      >("/backtests/strategy-replay", {
        symbol,
        date_kst: startDate,
        end_date_kst: end.endDate,
        start_time_kst: startTime,
        end_time_kst: end.endTime,
      });
      setResult(payload);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Replay 실행 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <PageTitle
        title="전략 테스트"
        description="Ticker와 KST 구간을 입력해 Toss 1분봉/호가/체결 데이터를 기준으로 현재 shadow 전략들을 독립 portfolio로 replay합니다."
        icon={<TestTube2 className="h-5 w-5" aria-hidden />}
      />
      <div className="space-y-5 p-4 md:p-6">
        <section className="rounded border border-line bg-white shadow-soft">
          <div className="grid gap-px bg-line md:grid-cols-[1fr_1.7fr_1.7fr_auto]">
            <label className="bg-white p-4">
              <span className="text-xs font-semibold uppercase text-zinc-500">Ticker</span>
              <input
                value={symbol}
                onChange={(event) => setSymbol(event.target.value.toUpperCase())}
                className="mt-2 h-11 w-full rounded border border-line px-3 text-lg font-bold outline-none focus:border-blue-400"
                placeholder="TC"
              />
            </label>
            <div className="bg-white p-4">
              <span className="text-xs font-semibold uppercase text-zinc-500">시작 (KST)</span>
              <div className="mt-2 grid grid-cols-[1fr_auto] gap-2">
                <input
                  type="date"
                  value={startDate}
                  onChange={(event) => setStartDate(event.target.value)}
                  className="h-11 w-full rounded border border-line px-3 font-semibold outline-none focus:border-blue-400"
                />
                <input
                  type="text"
                  inputMode="numeric"
                  value={startTime}
                  onChange={(event) => setStartTime(event.target.value)}
                  placeholder="17:20"
                  maxLength={5}
                  aria-label="시작 시간 (24시간 HH:MM)"
                  className={`h-11 w-24 rounded border px-3 text-center font-semibold outline-none focus:border-blue-400 ${isValidTime(startTime) ? "border-line" : "border-red-300 bg-red-50"}`}
                />
              </div>
            </div>
            <div className="bg-white p-4">
              <span className="text-xs font-semibold uppercase text-zinc-500">지속 시간</span>
              <div className="mt-2 flex items-center gap-2">
                <input
                  type="number"
                  min={0}
                  max={16}
                  value={durationHours}
                  onChange={(event) => setDurationHours(Math.max(0, Math.min(16, Math.floor(Number(event.target.value)) || 0)))}
                  className="h-11 w-16 rounded border border-line px-3 text-center font-semibold outline-none focus:border-blue-400"
                />
                <span className="text-sm text-zinc-500">시간</span>
                <input
                  type="number"
                  min={0}
                  max={59}
                  step={5}
                  value={durationMinutes}
                  onChange={(event) => setDurationMinutes(Math.max(0, Math.min(59, Math.floor(Number(event.target.value)) || 0)))}
                  className="h-11 w-16 rounded border border-line px-3 text-center font-semibold outline-none focus:border-blue-400"
                />
                <span className="text-sm text-zinc-500">분</span>
              </div>
              <div className="mt-2 truncate text-xs text-zinc-500">{end ? `→ 종료 ${end.endDate} ${end.endTime} KST` : "시작 시간 형식 확인"}</div>
            </div>
            <div className="flex items-end bg-white p-4">
              <button
                type="button"
                onClick={runReplay}
                disabled={loading || !rangeValid}
                className="inline-flex h-11 w-full items-center justify-center gap-2 rounded bg-navy px-5 text-sm font-bold text-white shadow-soft transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60 md:w-40"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Play className="h-4 w-4" aria-hidden />}
                Replay
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-2 border-t border-line px-4 py-3 text-sm text-zinc-600 md:flex-row md:items-center md:justify-between">
            <span>미국 동부시간 변환: {easternWindow}</span>
            <span>시작 시간은 24시간 HH:MM · 지속 시간 최대 16시간(오버나이트 자동 계산)</span>
          </div>
        </section>

        {error ? (
          <div className="rounded border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-700">{error}</div>
        ) : null}

        {result ? (
          <>
            <section className="grid gap-4 md:grid-cols-4">
              <div className="rounded border border-line bg-white p-4 shadow-soft">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase text-zinc-500">
                  <Clock3 className="h-4 w-4" aria-hidden />
                  구간
                </div>
                <div className="mt-2 text-lg font-bold text-ink">
                  {result.symbol} {result.date_kst} {result.start_time_kst}~
                  {result.end_date_kst && result.end_date_kst !== result.date_kst ? `${result.end_date_kst} ` : ""}
                  {result.end_time_kst}
                </div>
                <div className="mt-1 text-xs text-zinc-500">
                  {result.bars.length}개 1분봉 / {timeLabel(result.bars[0]?.timestamp_kst)}~
                  {timeLabel(result.bars[result.bars.length - 1]?.timestamp_kst)}
                </div>
              </div>
              <div className="rounded border border-line bg-white p-4 shadow-soft">
                <div className="text-xs font-semibold uppercase text-zinc-500">총 Shadow 손익</div>
                <div className={`mt-2 text-2xl font-bold ${moneyClass(result.totals.net_pnl_usd)}`}>
                  {currency.format(result.totals.net_pnl_usd)}
                </div>
                <div className="mt-1 text-xs text-zinc-500">{pct(result.totals.return_on_2000_pct)} / $2,000 기준</div>
              </div>
              <div className="rounded border border-line bg-white p-4 shadow-soft">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase text-zinc-500">
                  <BarChart3 className="h-4 w-4" aria-hidden />
                  체결 기반 데이터
                </div>
                <div className="mt-2 text-2xl font-bold text-ink">{number.format(result.source.trade_ticks ?? 0)}</div>
                <div className="mt-1 text-xs text-zinc-500">quotes {number.format(result.source.quotes ?? 0)}</div>
              </div>
              <div className="rounded border border-line bg-white p-4 shadow-soft">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase text-zinc-500">
                  <FileSpreadsheet className="h-4 w-4" aria-hidden />
                  저장 CSV
                </div>
                <div className="mt-2 truncate text-sm font-semibold text-ink">{result.source.enriched_csv}</div>
                <div className="mt-1 text-xs text-zinc-500">실제 주문 호출 없음</div>
              </div>
            </section>

            <section className="rounded border border-line bg-white shadow-soft">
              <div className="border-b border-line px-5 py-4">
                <h2 className="text-base font-bold text-ink">차트 Replay</h2>
                <p className="mt-1 text-sm text-zinc-500">캔들, 거래량, Bollinger Band, VWAP, EMA9/20, 전략별 B/S 마커</p>
              </div>
              <div className="p-4">
                <StrategyReplayChart bars={result.bars} trades={result.trades} />
              </div>
            </section>

            <section className="rounded border border-line bg-white shadow-soft">
              <div className="border-b border-line px-5 py-4">
                <h2 className="text-base font-bold text-ink">전략별 손익 비교</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase text-zinc-500">
                    <tr>
                      <th className="px-4 py-3">전략</th>
                      <th className="px-4 py-3">거래</th>
                      <th className="px-4 py-3">승/패</th>
                      <th className="px-4 py-3">승률</th>
                      <th className="px-4 py-3">순손익</th>
                      <th className="px-4 py-3">수익률</th>
                      <th className="px-4 py-3">평균 이익</th>
                      <th className="px-4 py-3">평균 손실</th>
                      <th className="px-4 py-3">PF</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {result.summary_rows.map((row) => (
                      <tr key={row.strategy}>
                        <td className="px-4 py-3 font-bold text-ink">{row.strategy}</td>
                        <td className="px-4 py-3">{row.trades}</td>
                        <td className="px-4 py-3">
                          {row.wins}/{row.losses}
                        </td>
                        <td className="px-4 py-3">{pct(row.win_rate_pct)}</td>
                        <td className={`px-4 py-3 font-bold ${moneyClass(row.net_pnl_usd)}`}>
                          {currency.format(row.net_pnl_usd)}
                        </td>
                        <td className={`px-4 py-3 ${moneyClass(row.return_on_2000_pct)}`}>
                          {pct(row.return_on_2000_pct)}
                        </td>
                        <td className="px-4 py-3">{currency.format(row.avg_win_usd)}</td>
                        <td className="px-4 py-3">{currency.format(row.avg_loss_usd)}</td>
                        <td className="px-4 py-3">{row.profit_factor >= 900 ? "∞" : number.format(row.profit_factor)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="rounded border border-line bg-white shadow-soft">
              <div className="border-b border-line px-5 py-4">
                <h2 className="text-base font-bold text-ink">미체결 후보 진단</h2>
                <p className="mt-1 text-sm text-zinc-500">
                  거래대금/변동성은 있었지만 전략 신호가 안 난 봉에서 어떤 조건이 막았는지 표시합니다.
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase text-zinc-500">
                    <tr>
                      <th className="px-4 py-3">시간</th>
                      <th className="px-4 py-3">종가</th>
                      <th className="px-4 py-3">거래대금</th>
                      <th className="px-4 py-3">BB 위치</th>
                      <th className="px-4 py-3">체결강도</th>
                      <th className="px-4 py-3">매도압력</th>
                      <th className="px-4 py-3">스프레드</th>
                      <th className="px-4 py-3">기대상승폭</th>
                      <th className="px-4 py-3">차단 조건</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {result.diagnostics.length ? (
                      result.diagnostics.map((row, index) => (
                        <tr key={`${row.timestamp_kst}-${index}`}>
                          <td className="whitespace-nowrap px-4 py-3 font-semibold text-ink">{timeLabel(row.timestamp_kst)}</td>
                          <td className="whitespace-nowrap px-4 py-3">{currency.format(row.close)}</td>
                          <td className="whitespace-nowrap px-4 py-3">{currency.format(row.notional_usd ?? 0)}</td>
                          <td className="whitespace-nowrap px-4 py-3">{row.bb_position == null ? "-" : row.bb_position.toFixed(2)}</td>
                          <td className="whitespace-nowrap px-4 py-3">{pct(row.trade_strength)}</td>
                          <td className="whitespace-nowrap px-4 py-3">{pct(row.sell_pressure)}</td>
                          <td className="whitespace-nowrap px-4 py-3">{pct(row.avg_spread_pct)}</td>
                          <td className="whitespace-nowrap px-4 py-3">
                            보수 {pct(row.expected_pullback_upside_pct ?? row.expected_upside_pct)}
                            <br />
                            러너 {pct(row.expected_runner_upside_pct ?? row.expected_upside_pct)}
                            <br />
                            필요 {pct(row.required_profit_pct)}
                          </td>
                          <td className="min-w-[26rem] px-4 py-3 text-xs text-zinc-600">
                            {row.blockers.length ? row.blockers.join(", ") : row.signals.length ? row.signals.join(", ") : "-"}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={9} className="px-4 py-8 text-center text-zinc-500">
                          진단할 후보 봉이 없습니다.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="rounded border border-line bg-white shadow-soft">
              <div className="border-b border-line px-5 py-4">
                <h2 className="text-base font-bold text-ink">매수/매도 로그</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase text-zinc-500">
                    <tr>
                      <th className="px-4 py-3">전략</th>
                      <th className="px-4 py-3">진입</th>
                      <th className="px-4 py-3">청산</th>
                      <th className="px-4 py-3">수량</th>
                      <th className="px-4 py-3">진입가</th>
                      <th className="px-4 py-3">청산가</th>
                      <th className="px-4 py-3">순손익</th>
                      <th className="px-4 py-3">사유</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {result.trades.length ? (
                      result.trades.map((trade, index) => (
                        <tr key={`${trade.strategy}-${trade.entry_time}-${index}`}>
                          <td className="px-4 py-3 font-semibold text-ink">{trade.strategy}</td>
                          <td className="px-4 py-3">{timeLabel(trade.entry_time)}</td>
                          <td className="px-4 py-3">{timeLabel(trade.exit_time)}</td>
                          <td className="px-4 py-3">{trade.quantity}</td>
                          <td className="px-4 py-3">{currency.format(trade.entry_price)}</td>
                          <td className="px-4 py-3">{currency.format(trade.exit_price)}</td>
                          <td className={`px-4 py-3 font-bold ${moneyClass(trade.net_pnl)}`}>
                            {currency.format(trade.net_pnl)}
                          </td>
                          <td className="max-w-xl px-4 py-3 text-xs text-zinc-600">
                            <div className="font-semibold text-zinc-800">{trade.entry_reason}</div>
                            <div className="mt-1">{trade.exit_reason}</div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={8} className="px-4 py-8 text-center text-zinc-500">
                          해당 구간에서 체결된 shadow trade가 없습니다.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </section>
          </>
        ) : (
          <section className="rounded border border-dashed border-line bg-white p-8 text-center text-sm text-zinc-500">
            구간을 입력하고 Replay를 실행하면 차트와 전략별 결과가 여기에 표시됩니다.
          </section>
        )}
      </div>
    </>
  );
}
