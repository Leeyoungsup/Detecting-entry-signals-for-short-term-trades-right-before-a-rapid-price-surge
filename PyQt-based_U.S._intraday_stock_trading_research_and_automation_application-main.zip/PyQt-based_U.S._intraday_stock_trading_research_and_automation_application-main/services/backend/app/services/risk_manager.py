from app.domain.enums import StatusLevel
from app.domain.models import RiskDecision
from app.services.event_log import record_event


class RiskManager:
    def preview_long_entry(
        self,
        *,
        account_equity_usd: float,
        entry_price: float,
        stop_loss_price: float,
        risk_per_trade_pct: float = 0.002,
        max_notional_per_trade_pct: float = 0.15,
    ) -> RiskDecision:
        stop_loss_pct = max((entry_price - stop_loss_price) / entry_price, 0.0001)
        risk_amount_usd = account_equity_usd * risk_per_trade_pct
        theoretical_notional = risk_amount_usd / stop_loss_pct
        max_notional = account_equity_usd * max_notional_per_trade_pct
        notional = min(theoretical_notional, max_notional)
        quantity = int(notional / entry_price)
        decision = RiskDecision(
            allowed=quantity > 0,
            reason=None if quantity > 0 else "position_size_below_one_share",
            account_equity_usd=account_equity_usd,
            risk_amount_usd=risk_amount_usd,
            max_notional_usd=max_notional,
            quantity=float(quantity),
            stop_loss_price=stop_loss_price,
        )
        record_event(
            level="INFO",
            event_type="risk.decision",
            message="Risk preview calculated." if decision.allowed else "Risk manager blocked order sizing.",
            severity=StatusLevel.NORMAL if decision.allowed else StatusLevel.BLOCKED,
            payload={
                "entry_price": entry_price,
                "stop_loss_price": stop_loss_price,
                "stop_loss_pct": stop_loss_pct,
                "risk_per_trade_pct": risk_per_trade_pct,
                "max_notional_per_trade_pct": max_notional_per_trade_pct,
                "decision": decision.model_dump(),
            },
        )
        return decision
