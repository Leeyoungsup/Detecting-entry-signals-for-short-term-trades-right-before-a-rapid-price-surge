class KisAdapterError(RuntimeError):
    pass


class KisEndpointNotVerifiedError(KisAdapterError):
    pass


class KisConfigurationError(KisAdapterError):
    pass


class KisApiResponseError(KisAdapterError):
    def __init__(self, *, status_code: int, message: str, payload: dict | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload or {}
