@echo off
setlocal
cd /d "%~dp0"
call scripts\run-backend.cmd
