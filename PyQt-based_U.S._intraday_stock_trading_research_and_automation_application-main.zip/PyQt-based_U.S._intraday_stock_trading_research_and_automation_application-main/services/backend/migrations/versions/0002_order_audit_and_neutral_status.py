"""order audit and neutral status fields

Revision ID: 0002_order_audit_status
Revises: 0001_initial_research_schema
Create Date: 2026-07-03
"""

from alembic import op
import sqlalchemy as sa

revision = "0002_order_audit_status"
down_revision = "0001_initial_research_schema"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "system_snapshots",
        sa.Column("market_data_status", sa.String(length=32), nullable=False, server_default="unknown"),
    )
    op.add_column(
        "system_snapshots",
        sa.Column("execution_gateway_status", sa.String(length=32), nullable=False, server_default="unknown"),
    )
    op.create_table(
        "closed_trades",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("position_key", sa.String(length=128), nullable=True),
        sa.Column("symbol", sa.String(length=16), nullable=False),
        sa.Column("strategy_name", sa.String(length=80), nullable=True),
        sa.Column("parameter_set_id", sa.String(length=64), nullable=True),
        sa.Column("entry_mode", sa.String(length=64), nullable=True),
        sa.Column("quantity", sa.Float(), nullable=False),
        sa.Column("entry_price", sa.Float(), nullable=False),
        sa.Column("exit_price", sa.Float(), nullable=False),
        sa.Column("gross_pnl_usd", sa.Float(), nullable=False),
        sa.Column("net_pnl_usd", sa.Float(), nullable=False),
        sa.Column("fees_usd", sa.Float(), nullable=False),
        sa.Column("exit_reason", sa.String(length=128), nullable=True),
        sa.Column("mode", sa.String(length=32), nullable=False),
        sa.Column("entry_snapshot", sa.JSON(), nullable=False),
        sa.Column("exit_snapshot", sa.JSON(), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_closed_trades_position_key", "closed_trades", ["position_key"])
    op.create_index("ix_closed_trades_symbol", "closed_trades", ["symbol"])
    op.create_index("ix_closed_trades_parameter_set_id", "closed_trades", ["parameter_set_id"])


def downgrade() -> None:
    op.drop_index("ix_closed_trades_parameter_set_id", table_name="closed_trades")
    op.drop_index("ix_closed_trades_symbol", table_name="closed_trades")
    op.drop_index("ix_closed_trades_position_key", table_name="closed_trades")
    op.drop_table("closed_trades")
    op.drop_column("system_snapshots", "execution_gateway_status")
    op.drop_column("system_snapshots", "market_data_status")
