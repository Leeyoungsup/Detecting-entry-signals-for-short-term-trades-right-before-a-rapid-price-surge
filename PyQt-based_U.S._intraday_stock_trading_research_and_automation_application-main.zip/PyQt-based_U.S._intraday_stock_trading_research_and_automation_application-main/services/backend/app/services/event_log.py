from collections import deque

from app.domain.enums import RealtimeEventType, StatusLevel
from app.domain.models import StructuredLogEvent
from app.services.event_bus import event_bus
from app.services.logging_service import build_log_event
from app.services import shared_state

_events: deque[StructuredLogEvent] = deque(maxlen=2000)
LOG_HISTORY_KEY = "trading_lab:logs:structured"
LEGACY_LOG_HISTORY_KEY = "kis:logs:structured"


def record_event(
    *,
    level: str,
    event_type: str,
    message: str,
    severity: StatusLevel = StatusLevel.NORMAL,
    payload: dict | None = None,
    symbol: str | None = None,
    order_id: str | None = None,
    correlation_id: str | None = None,
    mode: str | None = None,
) -> StructuredLogEvent:
    if mode is None:
        try:
            from app.core.config import get_settings

            mode = get_settings().trading_mode
        except Exception:
            mode = "internal_paper"
    event = build_log_event(
        level=level,
        event_type=event_type,
        message=message,
        severity=severity,
        payload=payload,
        symbol=symbol,
        order_id=order_id,
        correlation_id=correlation_id,
        mode=mode,
    )
    _events.append(event)
    shared_state.push_json(LOG_HISTORY_KEY, event.model_dump(mode="json"), max_items=2000)
    event_bus.publish(
        RealtimeEventType.LOG_EVENT,
        event.model_dump(mode="json"),
        mode=mode,
        status_level=severity,
        symbol=symbol,
        correlation_id=correlation_id,
    )
    return event


def list_events(
    *,
    limit: int = 200,
    event_type: str | None = None,
    symbol: str | None = None,
    order_id: str | None = None,
    severity: str | None = None,
    correlation_id: str | None = None,
) -> list[StructuredLogEvent]:
    events = list(_events)
    shared = shared_state.list_json_any(LOG_HISTORY_KEY, LEGACY_LOG_HISTORY_KEY, limit=max(2000, limit))
    if shared:
        parsed: list[StructuredLogEvent] = []
        for row in shared:
            try:
                parsed.append(StructuredLogEvent.model_validate(row))
            except Exception:
                continue
        if parsed:
            events = parsed
    if event_type:
        events = [event for event in events if event.event_type == event_type]
    if symbol:
        events = [event for event in events if event.symbol == symbol.upper()]
    if order_id:
        events = [event for event in events if event.order_id == order_id]
    if severity:
        events = [event for event in events if event.severity == severity]
    if correlation_id:
        events = [event for event in events if event.correlation_id == correlation_id]
    return events[-limit:]


def ensure_boot_event() -> None:
    if _events:
        return
    record_event(
        level="INFO",
        event_type="platform.boot",
        message="구조화 로그 저장소가 초기화되었습니다.",
        severity=StatusLevel.NORMAL,
        payload={"storage": "in_memory", "redaction": True},
    )
