from decimal import Decimal, ROUND_CEILING, ROUND_HALF_UP
from typing import Any

from app.core.config import Settings, get_settings

CENT = Decimal("0.01")


def toss_fee_breakdown(
    *,
    side: str,
    quantity: float,
    price: float,
    settings: Settings | None = None,
) -> dict[str, float | str]:
    """Estimate Toss US-stock fees using cent-level settlement behavior.

    Observed live PATH 1-share test:
    - commission is reported to the nearest cent
    - sell-side SEC/TAF-style tax/fee is reported as a combined cent amount,
      rounded up to at least the next cent when positive.
    """
    settings = settings or get_settings()
    quantity_dec = _decimal(quantity)
    price_dec = _decimal(price)
    notional = max(Decimal("0"), quantity_dec * price_dec)

    if not settings.paper_fee_model_enabled:
        return _empty_breakdown(notional, model="disabled")

    commission_raw = notional * _decimal(settings.paper_commission_pct)
    commission_raw += quantity_dec * _decimal(settings.paper_commission_per_share)
    min_commission = _decimal(settings.paper_min_commission_usd)
    if commission_raw > 0 and min_commission > 0:
        commission_raw = max(commission_raw, min_commission)
    commission = _round_cent(commission_raw)

    sell_side = side.lower() == "sell"
    sec_fee_raw = notional * _decimal(settings.paper_sec_fee_pct) if sell_side else Decimal("0")
    taf_fee_raw = (
        min(quantity_dec * _decimal(settings.paper_taf_fee_per_share), _decimal(settings.paper_taf_fee_cap_usd))
        if sell_side
        else Decimal("0")
    )
    regulatory_raw = sec_fee_raw + taf_fee_raw
    regulatory_fee = _ceil_cent(regulatory_raw) if sell_side else Decimal("0")
    total = _round_cent(commission + regulatory_fee)

    return {
        "notional_usd": _float(notional),
        "commission_usd": _float(commission),
        "sec_fee_usd": _float(sec_fee_raw),
        "taf_fee_usd": _float(taf_fee_raw),
        "regulatory_fee_usd": _float(regulatory_fee),
        "total_fees_usd": _float(total),
        "raw_commission_usd": _float(commission_raw),
        "raw_regulatory_fee_usd": _float(regulatory_raw),
        "model": "toss_cent_rounded",
        "rounding": "commission_nearest_cent_regulatory_ceiling_cent",
    }


def _empty_breakdown(notional: Decimal, *, model: str) -> dict[str, float | str]:
    return {
        "notional_usd": _float(notional),
        "commission_usd": 0.0,
        "sec_fee_usd": 0.0,
        "taf_fee_usd": 0.0,
        "regulatory_fee_usd": 0.0,
        "total_fees_usd": 0.0,
        "raw_commission_usd": 0.0,
        "raw_regulatory_fee_usd": 0.0,
        "model": model,
        "rounding": "disabled",
    }


def _decimal(value: Any) -> Decimal:
    try:
        return Decimal(str(value))
    except Exception:
        return Decimal("0")


def _round_cent(value: Decimal) -> Decimal:
    if value <= 0:
        return Decimal("0")
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def _ceil_cent(value: Decimal) -> Decimal:
    if value <= 0:
        return Decimal("0")
    cents = (value / CENT).to_integral_value(rounding=ROUND_CEILING)
    return cents * CENT


def _float(value: Decimal) -> float:
    return float(value)
