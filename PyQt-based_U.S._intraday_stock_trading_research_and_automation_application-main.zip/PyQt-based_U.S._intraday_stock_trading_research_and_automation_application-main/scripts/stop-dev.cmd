@echo off
setlocal

cd /d "%~dp0.."

if exist ".runtime\api-port.txt" (
  set /p API_PORT=<".runtime\api-port.txt"
) else (
  set API_PORT=18001
)

if exist ".runtime\web-port.txt" (
  set /p WEB_PORT=<".runtime\web-port.txt"
) else (
  set WEB_PORT=18000
)

echo Stopping backend on port %API_PORT%
for %%R in (1 2 3 4 5) do (
  for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":%API_PORT% .*LISTENING"') do (
    taskkill /PID %%P /T /F > nul 2> nul
  )
  ping -n 2 127.0.0.1 > nul
)

echo Stopping web on port %WEB_PORT%
for %%R in (1 2 3 4 5) do (
  for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":%WEB_PORT% .*LISTENING"') do (
    taskkill /PID %%P /T /F > nul 2> nul
  )
  ping -n 2 127.0.0.1 > nul
)

echo Stopping worker processes
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { ($_.CommandLine -like '*app.worker*' -or $_.CommandLine -like '*run-worker.cmd*' -or $_.CommandLine -like '*app.realtime_worker*' -or $_.CommandLine -like '*run-realtime-worker.cmd*') -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" > nul 2> nul

echo Dev servers stopped.
exit /b 0
