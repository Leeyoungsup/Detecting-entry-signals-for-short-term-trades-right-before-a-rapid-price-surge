from app.services import strategy_engine as strategy_engine_module


def _candles(count: int = 40) -> list[dict]:
    rows = []
    for index in range(count):
        close = 10.0 + (index * 0.02)
        rows.append(
            {
                "market_date": "2026-01-02",
                "market_time": f"09:{30 + index:02d}:00",
                "open": close - 0.01,
                "high": close + 0.03,
                "low": close - 0.03,
                "close": close,
                "volume": 20_000,
            }
        )
    return rows


def test_runtime_router_evaluates_new_scalp_strategy_set_and_ignores_old_flags(monkeypatch) -> None:
    settings = strategy_engine_module.get_settings()
    monkeypatch.setattr(settings, "strategy_surge_pullback_enabled", True)
    monkeypatch.setattr(settings, "strategy_volume_shock_pullback_enabled", True)
    monkeypatch.setattr(settings, "strategy_liquidity_sweep_reclaim_enabled", True)
    monkeypatch.setattr(settings, "strategy_micro_absorption_breakout_enabled", True)
    monkeypatch.setattr(settings, "strategy_liquidity_pullback_reclaim_enabled", True)

    evaluations = strategy_engine_module.EntryPatternEngine().evaluate_all(
        symbol="TC",
        candles=_candles(),
        risk_preview={"allowed": False},
        allowed_only=False,
    )

    assert sorted(evaluation.strategy_name for evaluation in evaluations) == sorted(
        [
            "Surge Pullback Reclaim",
            "First Pullback After Volume Shock",
            "Liquidity Sweep Reclaim",
            "Micro Breakout With Absorption",
            "Liquidity Pullback Reclaim",
        ]
    )
