from __future__ import annotations

import argparse
import bisect
import csv
import json
import math
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path


KST = timezone(timedelta(hours=9), "KST")
UTC = timezone.utc


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def parse_kst(value: str) -> datetime:
    return datetime.strptime(value, "%Y-%m-%d %H:%M").replace(tzinfo=KST)


def iso_z(value: datetime) -> str:
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def parse_ts(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def minute_key(ts: datetime) -> datetime:
    return ts.replace(second=0, microsecond=0)


def fmt(value) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return ""
        return f"{value:.8f}".rstrip("0").rstrip(".")
    return str(value)


def mean(values: list[float]) -> float | None:
    return sum(values) / len(values) if values else None


def read_bars(path: Path) -> list[dict]:
    rows = list(csv.DictReader(path.open(encoding="utf-8-sig")))
    for row in rows:
        row["_minute_utc"] = parse_ts(row["timestamp_utc"]).replace(second=0, microsecond=0)
    return rows


class AlpacaClient:
    def __init__(self, env: dict[str, str]) -> None:
        self.key = env.get("ALPACA_KEY") or env.get("APCA_API_KEY_ID")
        self.secret = env.get("ALPACA_SECRET") or env.get("APCA_API_SECRET_KEY")
        self.base_url = (env.get("ALPACA_REST_BASE_URL") or "https://data.alpaca.markets").rstrip("/")
        if not self.key or not self.secret:
            raise SystemExit("ALPACA_KEY / ALPACA_SECRET missing in .env")

    @property
    def headers(self) -> dict[str, str]:
        return {
            "APCA-API-KEY-ID": self.key,
            "APCA-API-SECRET-KEY": self.secret,
            "Accept": "application/json",
        }

    def fetch_market_data(self, *, kind: str, symbol: str, start_utc: datetime, end_utc: datetime) -> list[dict]:
        all_rows: list[dict] = []
        page_token = None
        while True:
            params = {
                "symbols": symbol,
                "start": iso_z(start_utc),
                "end": iso_z(end_utc),
                "feed": "sip",
                "sort": "asc",
                "limit": "10000",
            }
            if page_token:
                params["page_token"] = page_token
            url = f"{self.base_url}/v2/stocks/{kind}?{urllib.parse.urlencode(params)}"
            request = urllib.request.Request(url, headers=self.headers, method="GET")
            try:
                with urllib.request.urlopen(request, timeout=45) as response:
                    payload = json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="ignore")
                raise SystemExit(f"Alpaca {kind} HTTP {exc.code}: {body[:700]}")
            all_rows.extend(((payload.get(kind) or {}).get(symbol) or []))
            page_token = payload.get("next_page_token")
            if not page_token:
                break
        return all_rows


def quote_price(quote: dict, key: str) -> float | None:
    value = quote.get(key)
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def aggregate_quotes(quotes: list[dict]) -> dict[datetime, dict]:
    buckets: dict[datetime, list[dict]] = defaultdict(list)
    for quote in quotes:
        ts = parse_ts(quote["t"])
        buckets[minute_key(ts)].append(quote)

    output: dict[datetime, dict] = {}
    for key, rows in buckets.items():
        rows.sort(key=lambda row: parse_ts(row["t"]))
        bids = [quote_price(row, "bp") for row in rows]
        asks = [quote_price(row, "ap") for row in rows]
        bid_sizes = [quote_price(row, "bs") for row in rows]
        ask_sizes = [quote_price(row, "as") for row in rows]
        bids = [value for value in bids if value is not None]
        asks = [value for value in asks if value is not None]
        bid_sizes = [value for value in bid_sizes if value is not None]
        ask_sizes = [value for value in ask_sizes if value is not None]
        spreads: list[float] = []
        valid_quotes: list[tuple[float, float]] = []
        for row in rows:
            bid = quote_price(row, "bp")
            ask = quote_price(row, "ap")
            mid = (bid + ask) / 2 if bid and ask else None
            if mid and ask >= bid:
                spreads.append((ask - bid) / mid * 100)
                valid_quotes.append((bid, ask))
        avg_bid_size = mean(bid_sizes)
        avg_ask_size = mean(ask_sizes)
        first_bid, first_ask = valid_quotes[0] if valid_quotes else (None, None)
        last_bid, last_ask = valid_quotes[-1] if valid_quotes else (None, None)
        output[key] = {
            "quote_count": len(rows),
            "first_bid": first_bid,
            "first_ask": first_ask,
            "last_bid": last_bid,
            "last_ask": last_ask,
            "avg_bid": mean(bids),
            "avg_ask": mean(asks),
            "min_bid": min(bids) if bids else None,
            "max_bid": max(bids) if bids else None,
            "min_ask": min(asks) if asks else None,
            "max_ask": max(asks) if asks else None,
            "avg_spread_pct": mean(spreads),
            "min_spread_pct": min(spreads) if spreads else None,
            "max_spread_pct": max(spreads) if spreads else None,
            "avg_bid_size": avg_bid_size,
            "avg_ask_size": avg_ask_size,
            "bid_ask_imbalance": (
                avg_bid_size / (avg_bid_size + avg_ask_size)
                if avg_bid_size is not None and avg_ask_size is not None and (avg_bid_size + avg_ask_size) > 0
                else None
            ),
        }
    return output


def classify_trades(trades: list[dict], quotes: list[dict]) -> dict[datetime, dict]:
    quote_points: list[tuple[datetime, float, float]] = []
    for quote in quotes:
        bid = quote_price(quote, "bp")
        ask = quote_price(quote, "ap")
        if bid is None or ask is None or ask < bid:
            continue
        quote_points.append((parse_ts(quote["t"]), bid, ask))
    quote_points.sort(key=lambda item: item[0])
    quote_times = [item[0] for item in quote_points]

    buckets: dict[datetime, dict] = defaultdict(
        lambda: {
            "trade_tick_count": 0,
            "trade_volume_from_ticks": 0.0,
            "aggressive_buy_volume": 0.0,
            "aggressive_sell_volume": 0.0,
            "unknown_trade_volume": 0.0,
            "trade_notional_from_ticks": 0.0,
        }
    )
    for trade in trades:
        ts = parse_ts(trade["t"])
        price = quote_price(trade, "p")
        size = quote_price(trade, "s") or 0.0
        if price is None or size <= 0:
            continue
        bucket = buckets[minute_key(ts)]
        bucket["trade_tick_count"] += 1
        bucket["trade_volume_from_ticks"] += size
        bucket["trade_notional_from_ticks"] += price * size
        index = bisect.bisect_right(quote_times, ts) - 1
        if index < 0:
            bucket["unknown_trade_volume"] += size
            continue
        quote_ts, bid, ask = quote_points[index]
        if (ts - quote_ts).total_seconds() > 2:
            bucket["unknown_trade_volume"] += size
            continue
        midpoint = (bid + ask) / 2
        tolerance = max(0.000001, (ask - bid) * 0.15)
        if price >= ask - tolerance:
            bucket["aggressive_buy_volume"] += size
        elif price <= bid + tolerance:
            bucket["aggressive_sell_volume"] += size
        elif price >= midpoint:
            bucket["aggressive_buy_volume"] += size * 0.5
            bucket["unknown_trade_volume"] += size * 0.5
        else:
            bucket["aggressive_sell_volume"] += size * 0.5
            bucket["unknown_trade_volume"] += size * 0.5

    for bucket in buckets.values():
        known = bucket["aggressive_buy_volume"] + bucket["aggressive_sell_volume"]
        total = bucket["trade_volume_from_ticks"]
        bucket["trade_strength"] = bucket["aggressive_buy_volume"] / known * 100 if known > 0 else None
        bucket["sell_pressure"] = bucket["aggressive_sell_volume"] / known * 100 if known > 0 else None
        bucket["unknown_trade_ratio"] = bucket["unknown_trade_volume"] / total * 100 if total > 0 else None
    return buckets


def enrich_csv(*, bars_path: Path, output_path: Path, env_path: Path, symbol: str) -> dict:
    bars = read_bars(bars_path)
    start_utc = bars[0]["_minute_utc"]
    end_utc = bars[-1]["_minute_utc"] + timedelta(minutes=1)
    client = AlpacaClient(read_env(env_path))
    quotes = client.fetch_market_data(kind="quotes", symbol=symbol, start_utc=start_utc, end_utc=end_utc)
    trades = client.fetch_market_data(kind="trades", symbol=symbol, start_utc=start_utc, end_utc=end_utc)
    quote_agg = aggregate_quotes(quotes)
    trade_agg = classify_trades(trades, quotes)

    quote_fields = [
        "quote_count",
        "first_bid",
        "first_ask",
        "last_bid",
        "last_ask",
        "avg_bid",
        "avg_ask",
        "min_bid",
        "max_bid",
        "min_ask",
        "max_ask",
        "avg_spread_pct",
        "min_spread_pct",
        "max_spread_pct",
        "avg_bid_size",
        "avg_ask_size",
        "bid_ask_imbalance",
    ]
    trade_fields = [
        "trade_tick_count",
        "trade_volume_from_ticks",
        "aggressive_buy_volume",
        "aggressive_sell_volume",
        "unknown_trade_volume",
        "trade_notional_from_ticks",
        "trade_strength",
        "sell_pressure",
        "unknown_trade_ratio",
    ]
    base_fields = [key for key in bars[0].keys() if not key.startswith("_")]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=base_fields + quote_fields + trade_fields)
        writer.writeheader()
        for row in bars:
            minute = row["_minute_utc"]
            output = {key: row.get(key, "") for key in base_fields}
            for key, value in quote_agg.get(minute, {}).items():
                output[key] = fmt(value)
            for key, value in trade_agg.get(minute, {}).items():
                output[key] = fmt(value)
            writer.writerow(output)
    return {
        "source": str(bars_path),
        "csv": str(output_path),
        "symbol": symbol,
        "bars": len(bars),
        "quotes": len(quotes),
        "trades": len(trades),
        "start_utc": iso_z(start_utc),
        "end_utc": iso_z(end_utc),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--bars", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--env", default=".env")
    args = parser.parse_args()
    summary = enrich_csv(
        bars_path=Path(args.bars),
        output_path=Path(args.out),
        env_path=Path(args.env),
        symbol=args.symbol.upper(),
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
