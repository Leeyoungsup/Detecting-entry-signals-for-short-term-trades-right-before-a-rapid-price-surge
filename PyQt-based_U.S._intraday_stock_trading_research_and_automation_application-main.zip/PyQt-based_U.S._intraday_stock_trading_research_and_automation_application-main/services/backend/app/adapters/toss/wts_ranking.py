from datetime import datetime, timezone
from typing import Any
import re

from app.core.config import Settings


class TossWtsRankingError(RuntimeError):
    pass


_TOSS_TOTAL_AMOUNT_SECTION = "\ud1a0\uc2a4\uc99d\uad8c \uac70\ub798\ub300\uae08"


class TossWtsRankingClient:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def biggest_total_amount_rows(self, *, limit: int = 30) -> list[dict]:
        rows = self._crawl_rendered_rows()
        normalized = [_normalize_row(row, index=index) for index, row in enumerate(rows, start=1)]
        output = [row for row in normalized if row is not None]
        return output[: max(1, min(int(limit), 100))]

    def _crawl_rendered_rows(self) -> list[dict]:
        try:
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except Exception as exc:
            raise TossWtsRankingError(
                "Playwright is required for Toss WTS webpage crawling. Run setup.bat or "
                "`python -m playwright install chromium`."
            ) from exc

        timeout_ms = int(max(5.0, float(self.settings.toss_wts_ranking_crawl_timeout_sec)) * 1000)
        rows: list[dict] = []
        stock_info_by_code: dict[str, dict] = {}
        ranking_products: list[dict] = []

        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True)
            try:
                context = browser.new_context(
                    locale="ko-KR",
                    user_agent=(
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                        "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
                    ),
                    viewport={"width": 1440, "height": 1200},
                )
                page = context.new_page()

                def capture_stock_info(response) -> None:
                    if "/stock-infos" not in response.url:
                        return
                    try:
                        _merge_stock_info_map(stock_info_by_code, response.json())
                    except Exception:
                        return

                def capture_ranking(response) -> None:
                    if "/dashboard/wts/overview/ranking" not in response.url:
                        return
                    try:
                        ranking_products.extend(_extract_ranking_products(response.json()))
                    except Exception:
                        return

                page.on("response", capture_stock_info)
                page.on("response", capture_ranking)
                page.goto(self.settings.toss_wts_ranking_page_url, wait_until="domcontentloaded", timeout=timeout_ms)
                try:
                    page.wait_for_function(
                        "() => document.querySelectorAll('a[href*=\"/stocks/\"]').length >= 10",
                        timeout=timeout_ms,
                    )
                except PlaywrightTimeoutError:
                    pass
                page.wait_for_timeout(1500)
                rows = page.evaluate(
                    """
                    () => Array.from(document.querySelectorAll('a[href]')).map((anchor) => ({
                      href: anchor.href || '',
                      text: anchor.innerText || anchor.textContent || '',
                      label: anchor.getAttribute('data-content-value') || anchor.getAttribute('aria-label') || '',
                      section: anchor.closest('[data-section-name]')?.getAttribute('data-section-name') || '',
                    }))
                    """
                )
            finally:
                browser.close()

        extracted = _extract_ranking_rows(ranking_products, stock_info_by_code=stock_info_by_code)
        if not extracted:
            extracted = _extract_anchor_rows(rows, stock_info_by_code=stock_info_by_code)
        if not extracted:
            raise TossWtsRankingError("Toss WTS page crawl returned no stock ranking links.")
        return extracted


def _extract_candidate_rows(payload: Any) -> list[dict]:
    if isinstance(payload, list):
        direct = [row for row in payload if isinstance(row, dict) and _row_symbol(row)]
        if direct:
            return direct
        rows: list[dict] = []
        for item in payload:
            rows.extend(_extract_candidate_rows(item))
        return rows
    if not isinstance(payload, dict):
        return []
    direct_keys = ("tics", "stocks", "items", "rankings", "ranking", "data", "result", "results")
    for key in direct_keys:
        value = payload.get(key)
        if isinstance(value, list):
            rows = [row for row in value if isinstance(row, dict) and _row_symbol(row)]
            if rows:
                return rows
        if isinstance(value, dict):
            rows = _extract_candidate_rows(value)
            if rows:
                return rows
    if _row_symbol(payload):
        return [payload]
    rows = []
    for value in payload.values():
        rows.extend(_extract_candidate_rows(value))
    return rows


def _normalize_row(row: dict, *, index: int) -> dict | None:
    symbol = _normalize_us_symbol(_row_symbol(row))
    if not symbol:
        return None
    source_rank = _positive_int(row.get("rank")) or index
    notional = _first_float(
        row,
        (
            "totalAmount",
            "tradingAmount",
            "tradeAmount",
            "marketAmount",
            "amount",
            "accumulatedTradingAmount",
            "tossSecuritiesAmount",
            "value",
        ),
    )
    volume = _first_float(row, ("totalVolume", "tradingVolume", "tradeVolume", "volume", "accumulatedTradingVolume"))
    price = _first_float(row, ("price", "latestPrice", "close", "last", "currentPrice"))
    buy_volume = _first_float(row, ("tossSecuritiesBuy", "toss_buy_volume"))
    sell_volume = _first_float(row, ("tossSecuritiesSell", "toss_sell_volume"))
    toss_trade_volume = _first_float(row, ("tossSecuritiesVolume", "toss_trade_volume")) or volume
    toss_buy_ratio = _ratio_pct(buy_volume, sell_volume)
    score = max(0.0, 101.0 - float(source_rank))
    return {
        "symb": symbol,
        "company_name": _first_text(row, ("companyName", "name", "displayName", "stockName", "productName")),
        "industry": _first_text(row, ("industry", "primaryTicsName", "sector")),
        "market_cap_usd": _first_float(row, ("marketCapUsd", "market_cap_usd")),
        "market_cap_krw": _first_float(row, ("marketCapKrw", "market_cap_krw")),
        "rank": source_rank,
        "trade_notional_rank": source_rank,
        "trade_volume_rank": source_rank,
        "scanner_score": score,
        "volume_score": score,
        "liquidity_impulse_score": score,
        "last": price,
        "daily_volume": toss_trade_volume,
        "toss_trade_amount_krw": notional,
        "toss_trade_volume": toss_trade_volume,
        "toss_buy_volume": buy_volume,
        "toss_sell_volume": sell_volume,
        "toss_buy_ratio_pct": toss_buy_ratio,
        "toss_wts_rank": source_rank,
        "toss_wts_notional": notional,
        "toss_wts_payload_seen_at": datetime.now(timezone.utc).isoformat(),
        "screener_source": "toss_wts_biggest_total_amount",
        "volume_source": "toss_wts_biggest_total_amount",
    }


def _extract_ranking_rows(products: list[dict], *, stock_info_by_code: dict[str, dict] | None = None) -> list[dict]:
    output: list[dict] = []
    seen: set[str] = set()
    stock_info_by_code = stock_info_by_code or {}
    for product in products:
        code = _first_text(product, ("productCode", "code", "guid"))
        stock_info = stock_info_by_code.get(str(code or "").upper())
        symbol = _normalize_us_symbol(stock_info.get("symbol")) if stock_info else None
        if not symbol or symbol in seen:
            continue
        seen.add(symbol)
        price = product.get("price") if isinstance(product.get("price"), dict) else {}
        extra = product.get("extraInfo") if isinstance(product.get("extraInfo"), dict) else {}
        primary_tics = product.get("primaryTics") if isinstance(product.get("primaryTics"), dict) else {}
        output.append(
            {
                "productCode": symbol,
                "companyName": _company_name_from_stock_info(stock_info) or _first_text(product, ("name", "companyName")),
                "rank": _positive_int(product.get("rank")) or len(output) + 1,
                "price": price.get("close") or price.get("base"),
                "currentPrice": price.get("close") or price.get("base"),
                "tossSecuritiesAmount": price.get("tossSecuritiesAmount"),
                "tossSecuritiesVolume": price.get("tossSecuritiesVolume"),
                "tossSecuritiesBuy": extra.get("tossSecuritiesBuy"),
                "tossSecuritiesSell": extra.get("tossSecuritiesSell"),
                "marketCapUsd": product.get("marketCapUsd"),
                "marketCapKrw": product.get("marketCapKrw"),
                "industry": primary_tics.get("name"),
                "toss_product_code": code,
            }
        )
    return output


def _extract_anchor_rows(rows: list[dict], *, stock_info_by_code: dict[str, dict] | None = None) -> list[dict]:
    output: list[dict] = []
    seen: set[str] = set()
    stock_info_by_code = stock_info_by_code or {}
    for row in rows:
        href = str(row.get("href") or "")
        text = str(row.get("text") or row.get("label") or "")
        section = " ".join(str(row.get("section") or "").split())
        if section and _TOSS_TOTAL_AMOUNT_SECTION not in section:
            continue
        if _looks_like_non_ranking_link(href, text):
            continue

        rank, label = _rank_and_label_from_text(text)
        if rank is None:
            continue

        product_code = _product_code_from_href(href)
        stock_info = stock_info_by_code.get(str(product_code or "").upper())
        info_symbol = _normalize_us_symbol(stock_info.get("symbol")) if stock_info else None
        label_symbol = _normalize_us_symbol(label) if _is_symbol_token(label) else None
        symbol = info_symbol or label_symbol or _symbol_from_href(href)
        if not symbol or symbol in seen:
            continue

        seen.add(symbol)
        output.append(
            {
                "productCode": symbol,
                "companyName": _company_name_from_stock_info(stock_info) or _company_name_from_text(label or text),
                "rank": rank,
                "raw_text": text,
                "href": href,
                "toss_product_code": product_code,
            }
        )
    return output


def _symbol_from_href(href: str) -> str | None:
    return _normalize_us_symbol(_product_code_from_href(href))


def _product_code_from_href(href: str) -> str | None:
    for pattern in (
        r"/stocks/([^/?#]+)",
        r"/stock/([^/?#]+)",
        r"[?&](?:stockCode|productCode|code)=([^&#]+)",
    ):
        match = re.search(pattern, href)
        if match:
            return match.group(1).strip()
    return None


def _looks_like_non_ranking_link(href: str, text: str) -> bool:
    if "/stocks/" not in href and "/stock/" not in href:
        return True
    return not text.strip()


def _rank_and_label_from_text(text: str) -> tuple[int | None, str | None]:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return None, None
    if re.fullmatch(r"\d{1,3}", lines[0]) and len(lines) >= 2:
        return int(lines[0]), lines[1]
    match = re.match(r"^\s*(\d{1,3})\s*(?:\||-|\t|\s{2,})\s*(.+?)\s*$", lines[0])
    if match:
        return int(match.group(1)), match.group(2).strip()
    compact = " ".join(lines)
    match = re.match(r"^\s*(\d{1,3})\s*(?:\||-|\t|\s{2,})\s*(.+?)\s*$", compact)
    if match:
        return int(match.group(1)), match.group(2).strip()
    return None, None


def _is_symbol_token(value: str | None) -> bool:
    return bool(re.fullmatch(r"[A-Z]{1,5}(?:\.[A-Z])?", str(value or "").strip().upper()))


def _company_name_from_stock_info(stock_info: dict | None) -> str | None:
    if not stock_info:
        return None
    return _first_text(stock_info, ("companyName", "name", "englishName", "detailName"))


def _company_name_from_text(text: str | None) -> str | None:
    lines = [line.strip() for line in str(text or "").splitlines() if line.strip()]
    for line in lines:
        if re.fullmatch(r"\d+", line):
            continue
        if re.search(r"^[+-]?\$?\d", line):
            continue
        if "%" in line:
            continue
        if _is_symbol_token(line):
            continue
        return line[:120]
    return None


def _row_symbol(row: dict) -> str | None:
    return _first_text(row, ("symbol", "symb", "ticker", "code", "productCode", "stockCode"))


def _normalize_us_symbol(value: str | None) -> str | None:
    raw = str(value or "").strip().upper()
    if not raw:
        return None
    for separator in (":", "/", "_"):
        if separator in raw:
            raw = raw.split(separator)[-1]
    if raw.endswith(".US"):
        raw = raw[:-3]
    if re.fullmatch(r"(?:US|NAS|NYS|AMX)\d{4,}", raw):
        return None
    if re.fullmatch(r"[A-Z]{1,5}(?:\.[A-Z])?", raw):
        return raw
    match = re.search(r"(?:^|[^A-Z0-9.])([A-Z]{1,5}(?:\.[A-Z])?)(?:$|[^A-Z0-9.])", raw)
    return match.group(1) if match else None


def _merge_stock_info_map(output: dict[str, dict], payload: Any) -> None:
    for item in _iter_stock_info_items(payload):
        code = _first_text(item, ("code", "guid", "productCode", "stockCode"))
        symbol = _normalize_us_symbol(item.get("symbol"))
        currency = str(item.get("currency") or "").upper()
        if not code or not symbol or currency != "USD":
            continue
        output[code.upper()] = item


def _extract_ranking_products(payload: Any) -> list[dict]:
    if isinstance(payload, list):
        rows: list[dict] = []
        for item in payload:
            rows.extend(_extract_ranking_products(item))
        return rows
    if not isinstance(payload, dict):
        return []
    products = payload.get("products")
    if isinstance(products, list):
        return [item for item in products if isinstance(item, dict)]
    for key in ("result", "data"):
        rows = _extract_ranking_products(payload.get(key))
        if rows:
            return rows
    return []


def _iter_stock_info_items(payload: Any) -> list[dict]:
    if isinstance(payload, list):
        rows: list[dict] = []
        for item in payload:
            rows.extend(_iter_stock_info_items(item))
        return rows
    if not isinstance(payload, dict):
        return []
    result = payload.get("result")
    if isinstance(result, list):
        return [item for item in result if isinstance(item, dict)]
    for key in ("data", "items", "stocks", "stockInfos"):
        value = payload.get(key)
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
        if isinstance(value, dict):
            rows = _iter_stock_info_items(value)
            if rows:
                return rows
    return []


def _first_text(row: dict, keys: tuple[str, ...]) -> str | None:
    for key in keys:
        value = row.get(key)
        if value not in (None, ""):
            return str(value).strip()
    return None


def _first_float(row: dict, keys: tuple[str, ...]) -> float | None:
    for key in keys:
        value = _to_float(row.get(key))
        if value is not None:
            return value
    return None


def _to_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").replace("$", "").strip())
    except (TypeError, ValueError):
        return None


def _ratio_pct(buy_volume: float | None, sell_volume: float | None) -> float | None:
    total = (buy_volume or 0.0) + (sell_volume or 0.0)
    if total <= 0:
        return None
    return (buy_volume or 0.0) / total * 100


def _positive_int(value: Any) -> int | None:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None
