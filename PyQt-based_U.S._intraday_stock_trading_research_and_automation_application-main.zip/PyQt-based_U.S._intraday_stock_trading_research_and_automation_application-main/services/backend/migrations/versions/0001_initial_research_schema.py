"""initial research schema

Revision ID: 0001_initial_research_schema
Revises:
Create Date: 2026-06-29
"""

from alembic import op
import sqlalchemy as sa

revision = "0001_initial_research_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "system_snapshots",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("trading_mode", sa.String(length=32), nullable=False),
        sa.Column("status_level", sa.String(length=32), nullable=False),
        sa.Column("live_enabled", sa.Boolean(), nullable=False),
        sa.Column("kis_rest_status", sa.String(length=32), nullable=False),
        sa.Column("kis_websocket_status", sa.String(length=32), nullable=False),
        sa.Column("last_tick_age_sec", sa.Float(), nullable=True),
        sa.Column("equity_usd", sa.Float(), nullable=False),
        sa.Column("realized_pnl_usd", sa.Float(), nullable=False),
        sa.Column("unrealized_pnl_usd", sa.Float(), nullable=False),
        sa.Column("exposure_pct", sa.Float(), nullable=False),
        sa.Column("open_positions", sa.Integer(), nullable=False),
        sa.Column("open_orders", sa.Integer(), nullable=False),
        sa.Column("recent_warnings", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "scanner_candidates",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("symbol", sa.String(length=16), nullable=False),
        sa.Column("rank_total", sa.Integer(), nullable=True),
        sa.Column("scanner_score", sa.Float(), nullable=False),
        sa.Column("notional_1m", sa.Float(), nullable=True),
        sa.Column("notional_5m", sa.Float(), nullable=True),
        sa.Column("notional_velocity_10s", sa.Float(), nullable=True),
        sa.Column("trade_strength", sa.Float(), nullable=True),
        sa.Column("sell_pressure", sa.Float(), nullable=True),
        sa.Column("spread_pct", sa.Float(), nullable=True),
        sa.Column("bid_ask_imbalance", sa.Float(), nullable=True),
        sa.Column("atr_pct", sa.Float(), nullable=True),
        sa.Column("relative_strength_vs_qqq", sa.Float(), nullable=True),
        sa.Column("relative_strength_vs_spy", sa.Float(), nullable=True),
        sa.Column("bb_state", sa.String(length=64), nullable=False),
        sa.Column("reclaim_state", sa.String(length=64), nullable=False),
        sa.Column("selected_for_ws", sa.Boolean(), nullable=False),
        sa.Column("selected_for_strategy", sa.Boolean(), nullable=False),
        sa.Column("reject_reason", sa.Text(), nullable=True),
        sa.Column("data_latency_ms", sa.Integer(), nullable=True),
        sa.Column("is_estimated", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_scanner_candidates_symbol", "scanner_candidates", ["symbol"])
    op.create_table(
        "strategy_signals",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("symbol", sa.String(length=16), nullable=False),
        sa.Column("strategy_name", sa.String(length=80), nullable=False),
        sa.Column("strategy_version", sa.String(length=32), nullable=False),
        sa.Column("parameter_set_id", sa.String(length=64), nullable=False),
        sa.Column("signal_type", sa.String(length=32), nullable=False),
        sa.Column("final_score", sa.Float(), nullable=False),
        sa.Column("passed", sa.Boolean(), nullable=False),
        sa.Column("conditions", sa.JSON(), nullable=False),
        sa.Column("reject_reason", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_strategy_signals_symbol", "strategy_signals", ["symbol"])
    op.create_table(
        "orders",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("client_order_id", sa.String(length=64), nullable=False),
        sa.Column("mode", sa.String(length=32), nullable=False),
        sa.Column("symbol", sa.String(length=16), nullable=False),
        sa.Column("side", sa.String(length=8), nullable=False),
        sa.Column("order_type", sa.String(length=32), nullable=False),
        sa.Column("quantity", sa.Float(), nullable=False),
        sa.Column("limit_price", sa.Float(), nullable=True),
        sa.Column("state", sa.String(length=48), nullable=False),
        sa.Column("broker_order_id", sa.String(length=80), nullable=True),
        sa.Column("broker_original_order_id", sa.String(length=80), nullable=True),
        sa.Column("risk_snapshot", sa.JSON(), nullable=False),
        sa.Column("reject_reason", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("client_order_id"),
    )
    op.create_index("ix_orders_symbol", "orders", ["symbol"])
    op.create_index("ix_orders_state", "orders", ["state"])
    op.create_table(
        "positions",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("symbol", sa.String(length=16), nullable=False),
        sa.Column("quantity", sa.Float(), nullable=False),
        sa.Column("average_price", sa.Float(), nullable=False),
        sa.Column("unrealized_pnl_usd", sa.Float(), nullable=False),
        sa.Column("mode", sa.String(length=32), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("symbol"),
    )
    op.create_table(
        "log_events",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("level", sa.String(length=16), nullable=False),
        sa.Column("event_type", sa.String(length=64), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("correlation_id", sa.String(length=64), nullable=True),
        sa.Column("mode", sa.String(length=32), nullable=False),
        sa.Column("symbol", sa.String(length=16), nullable=True),
        sa.Column("order_id", sa.String(length=64), nullable=True),
        sa.Column("severity", sa.String(length=24), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("redaction_applied", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_log_events_level", "log_events", ["level"])
    op.create_index("ix_log_events_event_type", "log_events", ["event_type"])
    op.create_index("ix_log_events_correlation_id", "log_events", ["correlation_id"])
    op.create_index("ix_log_events_symbol", "log_events", ["symbol"])
    op.create_index("ix_log_events_order_id", "log_events", ["order_id"])
    op.create_table(
        "alerts",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("severity", sa.String(length=24), nullable=False),
        sa.Column("title", sa.String(length=120), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("source", sa.String(length=64), nullable=False),
        sa.Column("acknowledged", sa.Boolean(), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "order_events",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("order_id", sa.String(length=36), nullable=False),
        sa.Column("previous_state", sa.String(length=48), nullable=True),
        sa.Column("new_state", sa.String(length=48), nullable=False),
        sa.Column("source", sa.String(length=48), nullable=False),
        sa.Column("message", sa.Text(), nullable=True),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["order_id"], ["orders.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "fills",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("order_id", sa.String(length=36), nullable=False),
        sa.Column("symbol", sa.String(length=16), nullable=False),
        sa.Column("quantity", sa.Float(), nullable=False),
        sa.Column("price", sa.Float(), nullable=False),
        sa.Column("slippage_bps", sa.Float(), nullable=True),
        sa.Column("broker_fill_id", sa.String(length=80), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["order_id"], ["orders.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_fills_symbol", "fills", ["symbol"])


def downgrade() -> None:
    op.drop_index("ix_fills_symbol", table_name="fills")
    op.drop_table("fills")
    op.drop_table("order_events")
    op.drop_table("alerts")
    op.drop_index("ix_log_events_order_id", table_name="log_events")
    op.drop_index("ix_log_events_symbol", table_name="log_events")
    op.drop_index("ix_log_events_correlation_id", table_name="log_events")
    op.drop_index("ix_log_events_event_type", table_name="log_events")
    op.drop_index("ix_log_events_level", table_name="log_events")
    op.drop_table("log_events")
    op.drop_table("positions")
    op.drop_index("ix_orders_state", table_name="orders")
    op.drop_index("ix_orders_symbol", table_name="orders")
    op.drop_table("orders")
    op.drop_index("ix_strategy_signals_symbol", table_name="strategy_signals")
    op.drop_table("strategy_signals")
    op.drop_index("ix_scanner_candidates_symbol", table_name="scanner_candidates")
    op.drop_table("scanner_candidates")
    op.drop_table("system_snapshots")
