import logging
import sys

from pythonjsonlogger import jsonlogger


def configure_logging() -> None:
    root = logging.getLogger()
    if root.handlers:
        return
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        jsonlogger.JsonFormatter(
            "%(asctime)s %(levelname)s %(name)s %(message)s "
            "%(correlation_id)s %(event_type)s %(symbol)s %(order_id)s %(mode)s"
        )
    )
    root.addHandler(handler)
    root.setLevel(logging.INFO)
