from __future__ import annotations

import csv
import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path
from statistics import mean

BACKEND_ROOT = Path(__file__).resolve().parents[1] / "services" / "backend"
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))

from app.core.config import get_settings  # noqa: E402
from app.services.strategy_decision import (  # noqa: E402
    DynamicTakeProfitConfig,
    EntryFillGateConfig,
    ExitDecisionConfig,
    ExitDecisionIndicators,
    ExitDecisionPosition,
    advance_trailing_stop,
    bounded_stop_exit_price,
    choose_dynamic_trailing_pct,
    compute_structure_stop_price,
    crossed_down,
    evaluate_exit_decision,
    evaluate_entry_fill_gate,
    ohlcv_spread_proxy_fraction,
    update_dynamic_take_profit_target,
)
from app.services.fee_model import toss_fee_breakdown  # noqa: E402


INITIAL_EQUITY = 2000.0
MAX_NOTIONAL_PER_TRADE = 300.0
COMMISSION_PCT = 0.001  # Toss: 0.1% of transaction value per side (buy and sell)
SEC_FEE_PCT = 0.0000278
TAF_FEE_PER_SHARE = 0.000166
TAF_FEE_CAP = 8.30
MIN_EXPECTED_EDGE_PCT = 0.0015
MIN_NET_TAKE_PROFIT_PCT = 0.0015
TRAILING_ACTIVATION_PCT = 0.0035
TRAILING_NORMAL_PCT = 0.004
TRAILING_WIDE_PCT = 0.012
RUNNER_CANDIDATE_PROFIT_PCT = 0.04
RUNNER_MODE_PROFIT_PCT = 0.10
RUNNER_FULL_EXIT_HIGH_FAILURES = 3
RUNNER_EMERGENCY_DRAWDOWN_PCT = 0.08
# Shared "strong momentum without VWAP" threshold, used by vwap_or_strong_momentum
# (continuation/pullback/liquidity helpers). Formerly VWAP_SOFT_MIN_10BAR_CHANGE_PCT;
# kept after VWAP Soft Reclaim was retired 2026-07-16.
STRONG_MOMENTUM_MIN_10BAR_CHANGE_PCT = 0.045
VOLUME_SHOCK_MIN_10BAR_CHANGE_PCT = 0.060
VOLUME_SHOCK_MIN_NOTIONAL_1M_USD = 300_000.0
VOLUME_SHOCK_MIN_TRADE_STRENGTH = 80.0
VOLUME_SHOCK_MAX_SELL_PRESSURE = 30.0
VOLUME_SHOCK_MAX_ROUNDTRIP_COST_PCT = 0.009
MICRO_BREAKOUT_MIN_TRADE_STRENGTH = 80.0
MICRO_BREAKOUT_MAX_SELL_PRESSURE = 22.0
MICRO_BREAKOUT_MIN_10BAR_CHANGE_PCT = 0.025
MICRO_BREAKOUT_MAX_10BAR_CHANGE_PCT = 0.095
MICRO_BREAKOUT_MIN_RANGE_PCT = 0.020
MICRO_BREAKOUT_MAX_ROUNDTRIP_COST_PCT = 0.0095
LIQUIDITY_PULLBACK_MIN_TRADE_STRENGTH = 68.0
LIQUIDITY_PULLBACK_MAX_SELL_PRESSURE = 32.0
LIQUIDITY_PULLBACK_MIN_RANGE_PCT = 0.018
LIQUIDITY_PULLBACK_DEAD_ZONE_BB_MIN = 0.97
LIQUIDITY_PULLBACK_DEAD_ZONE_BB_MAX = 1.05
ORDER_FLOW_REENTRY_COOLDOWN_BARS = 3
STRATEGY_LOSS_REENTRY_COOLDOWN_BARS = 8
SYMBOL_LOSS_REENTRY_COOLDOWN_BARS = 16
LOSS_CLUSTER_LOOKBACK_BARS = 30
LOSS_CLUSTER_MAX_LOSSES = 2
LOSS_CLUSTER_COOLDOWN_BARS = 24
FINAL_STOP_PCT = 0.035
STRUCTURE_STOP_BUFFER = 0.004
# Gap/slippage guard: a stop fill is modeled no worse than the trigger price
# minus this bounded cap, instead of the bar's worst historical bid (min_bid).
# This reflects a stop-limit style exit and removes the ~2%p of manufactured
# loss that came from always assuming the bar-low bid on every stop-out.
STOP_SLIPPAGE_CAP_PCT = 0.005


@dataclass
class Position:
    strategy: str
    entry_index: int
    entry_time: str
    entry_price: float
    quantity: int
    reason: str
    indicators: dict
    stop_price: float
    high_watermark: float
    reference_high: float | None = None
    entry_fees: float = 0.0
    take_profit_price: float | None = None
    dynamic_take_profit_price: float | None = None
    dynamic_take_profit_reason: str | None = None
    partial_take_profit_price: float | None = None
    partial_exit_done: bool = False
    trailing_activation_price: float | None = None
    trailing_active: bool = False
    trailing_stop_price: float | None = None
    last_exit_snapshot: dict | None = None
    stop_loss_candidate_bars: int | None = None
    stop_loss_hold_reason: str | None = None


@dataclass
class Portfolio:
    strategy: str
    equity: float = INITIAL_EQUITY
    position: Position | None = None
    trades: list[dict] = field(default_factory=list)
    pending_entry: dict | None = None
    pending_exit: str | None = None
    last_exit_index: int | None = None
    last_exit_reason: str | None = None
    last_exit_net_pnl: float | None = None


def f(value: str | float | int | None) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def load_rows(path: Path) -> list[dict]:
    rows = list(csv.DictReader(path.open(encoding="utf-8-sig")))
    for row in rows:
        for key in [
            "open",
            "high",
            "low",
            "close",
            "volume",
            "trade_count",
            "notional_usd",
            "volume_ma20",
            "ma5",
            "ma20",
            "ma60",
            "ma120",
            "ema9",
            "ema20",
            "bb_mid20",
            "bb_upper20",
            "bb_lower20",
            "bb_position_0_1",
            "session_vwap",
            "macd_12_26",
            "macd_signal_9",
            "macd_histogram",
            "return_pct",
            "range_pct",
            "quote_count",
            "first_bid",
            "first_ask",
            "last_bid",
            "last_ask",
            "avg_bid",
            "avg_ask",
            "min_bid",
            "max_bid",
            "min_ask",
            "max_ask",
            "avg_spread_pct",
            "min_spread_pct",
            "max_spread_pct",
            "avg_bid_size",
            "avg_ask_size",
            "bid_ask_imbalance",
            "trade_tick_count",
            "trade_volume_from_ticks",
            "aggressive_buy_volume",
            "aggressive_sell_volume",
            "unknown_trade_volume",
            "trade_notional_from_ticks",
            "trade_strength",
            "sell_pressure",
            "unknown_trade_ratio",
        ]:
            row[key] = f(row.get(key))
    return rows


def spread_fraction(row: dict) -> float:
    if row.get("avg_spread_pct") is not None:
        return max(0.0, row["avg_spread_pct"] / 100.0)
    # No historical quote in this CSV. Use the shared conservative OHLCV proxy.
    return ohlcv_spread_proxy_fraction(
        range_pct=row.get("range_pct"),
        close=row.get("close"),
        volume=row.get("volume"),
        notional=row.get("notional_usd"),
        trade_count=row.get("trade_count") or row.get("trade_tick_count"),
    )


def synthetic_quote_at_price(row: dict, price: float) -> dict:
    spread = spread_fraction(row)
    bid = price * (1 - spread / 2)
    ask = price * (1 + spread / 2)
    open_price = row.get("open")
    if open_price and abs(price - open_price) <= max(open_price * 0.0001, 1e-8):
        known_bid = row.get("first_bid")
        known_ask = row.get("first_ask")
    else:
        known_bid = row.get("last_bid") or row.get("avg_bid")
        known_ask = row.get("last_ask") or row.get("avg_ask")
    if known_bid and known_bid > 0:
        bid = min(bid, known_bid)
    if known_ask and known_ask > 0:
        ask = max(ask, known_ask)
    return {
        "bid": bid,
        "ask": ask,
        "spread_pct": spread * 100,
    }


def execution_price(raw_price: float, row: dict, side: str, reason: str = "signal") -> float:
    slippage = 0.0015 if "stop" in reason else (0.0008 if side == "sell" else 0.0005)
    if side == "buy":
        base = row.get("first_ask") or row.get("avg_ask") or raw_price * (1 + spread_fraction(row) / 2)
        return base * (1 + slippage)
    base = synthetic_quote_at_price(row, raw_price)["bid"] if raw_price > 0 else (
        row.get("first_bid") or row.get("last_bid") or row.get("avg_bid") or raw_price
    )
    fill = base * (1 - slippage)
    if "stop" in reason and raw_price > 0:
        fill = bounded_stop_exit_price(
            fill,
            trigger_price=raw_price,
            reason=reason,
            stop_slippage_cap_pct=STOP_SLIPPAGE_CAP_PCT,
        )
    return fill


def estimated_roundtrip_cost_fraction(row: dict) -> float:
    # A buy pays ask-side slippage and a sell receives bid-side execution.
    # The spread itself behaves like the largest recurring cost in this setup.
    return spread_fraction(row) + 0.0005 + 0.0008 + (COMMISSION_PCT * 2) + SEC_FEE_PCT


def row_range_fraction(row: dict) -> float:
    return max(0.0, (row.get("range_pct") or 0.0) / 100.0)


def entry_edge_ok(rows: list[dict], index: int, min_change: float) -> bool:
    if index + 1 < 10:
        return False
    recent_change = recent_10bar_change_fraction(rows, index)
    if recent_change is None:
        return False
    estimated_cost = spread_fraction(rows[index]) + 0.0033
    return abs(recent_change) >= max(min_change, estimated_cost * 1.4)


def recent_10bar_change_fraction(rows: list[dict], index: int, lookback: int = 10) -> float | None:
    window = rows[max(0, index - lookback + 1) : index + 1]
    if len(window) < 2:
        return None
    first_close = window[0].get("close")
    last_close = window[-1].get("close")
    if first_close is None or first_close <= 0 or last_close is None:
        return None
    return (last_close - first_close) / first_close


def dynamic_take_profit_fraction(row: dict, strategy: str = "", rows: list[dict] | None = None, index: int | None = None) -> float:
    spread = spread_fraction(row)
    cost = estimated_roundtrip_cost_fraction(row)
    recent_change = recent_10bar_change_fraction(rows, index) if rows is not None and index is not None else None
    recent_move = abs(recent_change) if recent_change is not None else 0.0
    bar_range = max(0.0, (row.get("range_pct") or 0.0) / 100.0)
    volatility = max(recent_move, bar_range * 0.35)
    if is_runner_strategy(strategy):
        return max(0.006, cost + MIN_EXPECTED_EDGE_PCT, spread * 2.0 + MIN_EXPECTED_EDGE_PCT, min(0.06, volatility * 0.80))
    if any(name in strategy for name in ["Order Flow", "Liquidity"]):
        return max(0.0035, cost + MIN_EXPECTED_EDGE_PCT, spread * 1.8 + MIN_EXPECTED_EDGE_PCT, volatility * 0.45)
    momentum_bonus = 0.0
    if "Surge" in strategy or "Absorption" in strategy:
        momentum_bonus = min(0.018, volatility * 0.45)
    return max(MIN_NET_TAKE_PROFIT_PCT, cost + MIN_EXPECTED_EDGE_PCT, spread * 1.8 + MIN_EXPECTED_EDGE_PCT + momentum_bonus)


def is_runner_strategy(strategy: str = "") -> bool:
    return "Runner" in strategy or "Continuation" in strategy or "EMA9 Ride" in strategy


def is_momentum_strategy(strategy: str = "") -> bool:
    return is_runner_strategy(strategy) or any(
        name in strategy
        for name in [
            "Surge",
            "Volume Shock",
            "Micro Breakout",
        ]
    )


def bb_width(row: dict) -> float | None:
    upper = row.get("bb_upper20")
    lower = row.get("bb_lower20")
    close = row.get("close")
    if upper is None or lower is None or close is None or close <= 0:
        return None
    return max(0.0, (upper - lower) / close)


def bb_expanding(rows: list[dict], index: int) -> bool:
    if index < 5:
        return False
    current = bb_width(rows[index])
    previous = [bb_width(rows[i]) for i in range(max(0, index - 5), index)]
    previous = [value for value in previous if value is not None]
    if current is None or not previous:
        return False
    return current >= (sum(previous) / len(previous)) * 1.08


def recent_high(rows: list[dict], index: int, lookback: int = 24, include_current: bool = True) -> float | None:
    end = index + 1 if include_current else index
    start = max(0, end - lookback)
    highs = [rows[i].get("high") for i in range(start, end)]
    highs = [value for value in highs if value is not None]
    return max(highs) if highs else None


def conservative_expected_upside_fraction(rows: list[dict], index: int) -> float:
    row = rows[index]
    close = row["close"]
    if close <= 0:
        return 0.0
    start = max(0, index - 24)
    recent = rows[start : index + 1]
    resistance_levels = [
        item["high"]
        for item in recent
        if item.get("high") is not None and item["high"] > close * 1.003
    ]
    for level in [row.get("bb_upper20"), row.get("ema20"), row.get("session_vwap")]:
        if level is not None and level > close * 1.003:
            resistance_levels.append(level)
    recent_move = abs(recent_10bar_change_fraction(rows, index) or 0.0)
    range_fraction = max(0.0, (row.get("range_pct") or 0.0) / 100.0)
    reachable_move = max(0.0035, min(0.08, max(recent_move * 0.75, range_fraction * 0.45)))
    reachable_target = close * (1 + reachable_move)
    if resistance_levels:
        target = min(min(resistance_levels), reachable_target)
    else:
        target = reachable_target
    return max(0.0, (target - close) / close)


def continuation_expected_upside_fraction(rows: list[dict], index: int) -> float:
    row = rows[index]
    close = row["close"]
    if close <= 0:
        return 0.0
    recent_move = abs(recent_10bar_change_fraction(rows, index) or 0.0)
    range_fraction = max(0.0, (row.get("range_pct") or 0.0) / 100.0)
    volume_ma20 = row.get("volume_ma20") or 0.0
    volume_ratio = (row.get("volume") or 0.0) / max(volume_ma20, 1.0)
    trade_strength = row.get("trade_strength")
    sell_pressure = row.get("sell_pressure")
    prior_high = recent_high(rows, index, lookback=24, include_current=False)
    breaking_or_near_high = prior_high is not None and (row["high"] >= prior_high * 0.995 or close >= prior_high * 0.985)
    ema9_ride = row.get("ema9") is not None and close >= row["ema9"] and row["low"] >= row["ema9"] * 0.965
    vwap_supported = vwap_or_strong_momentum(rows, index)
    macd_ok = macd_not_deteriorating(rows, index) or macd_rising(rows, index, count=2) or (row.get("macd_histogram") or 0.0) > 0
    flow_ok = (
        (trade_strength is None or trade_strength >= 52)
        and (sell_pressure is None or sell_pressure <= 52 or sell_pressure_decreasing(rows, index))
    )

    reachable_move = max(0.006, recent_move * 0.95, range_fraction * 0.55)
    if volume_ratio >= 1.2:
        reachable_move += min(0.025, (volume_ratio - 1.0) * 0.012)
    if trade_strength is not None and trade_strength >= 58:
        reachable_move += 0.012
    elif trade_strength is not None and trade_strength >= 52:
        reachable_move += 0.006
    if sell_pressure is not None and sell_pressure <= 42:
        reachable_move += 0.008
    if ema9_ride:
        reachable_move += 0.012
    if vwap_supported:
        reachable_move += 0.006
    if bb_expanding(rows, index):
        reachable_move += 0.012
    if macd_ok:
        reachable_move += 0.008
    if breaking_or_near_high:
        reachable_move += 0.018

    if not flow_ok:
        reachable_move *= 0.72
    if not ema9_ride:
        reachable_move *= 0.78
    if spread_widening(rows, index):
        reachable_move *= 0.70

    reachable_move = max(0.0, min(0.25, reachable_move))
    target_from_move = close * (1 + reachable_move)
    if breaking_or_near_high and prior_high is not None:
        breakout_target = prior_high * (1 + max(0.012, min(0.12, reachable_move * 0.85)))
        target = max(target_from_move, breakout_target)
    else:
        target = target_from_move
    return max(0.0, (target - close) / close)


def expected_upside_fraction(rows: list[dict], index: int, strategy: str = "") -> float:
    conservative = conservative_expected_upside_fraction(rows, index)
    continuation = continuation_expected_upside_fraction(rows, index)
    if is_runner_strategy(strategy):
        return continuation
    if is_momentum_strategy(strategy):
        return max(conservative, continuation * 0.75)
    return conservative


def entry_reachability_ok(rows: list[dict], index: int, strategy: str = "") -> bool:
    """One-sided REACHABILITY floor -- NOT an expected value.

    Checks only whether the (optimistic) reachable upside clears the required
    take-profit target. It has no P(win) term and no downside/stop term, so it
    is not an expectancy. Renamed from ``entry_expectancy_ok`` on 2026-07-20
    after a walk-forward bracket test (accept-all vs reject-all vs reward:risk
    variants) showed it is NON-BINDING on the final trades under the current
    strict flow(ts)/setup gates: disabling it entirely leaves the trade set and
    P&L unchanged. Kept as a cheap cost/room floor in case those gates loosen.
    See claudy_log 2026-07-20.
    """
    row = rows[index]
    required = dynamic_take_profit_fraction(row, strategy, rows, index)
    expected = expected_upside_fraction(rows, index, strategy)
    if expected >= required:
        return True
    recent_move = abs(recent_10bar_change_fraction(rows, index) or 0.0)
    cost = estimated_roundtrip_cost_fraction(row)
    trade_strength = row.get("trade_strength")
    sell_pressure = row.get("sell_pressure")
    volume_ma20 = row.get("volume_ma20") or 0.0
    volume_ratio = (row.get("volume") or 0.0) / max(volume_ma20, 1.0)
    strong_flow = (trade_strength is None or trade_strength >= 58) and (sell_pressure is None or sell_pressure <= 50)
    strong_bar = close_near_high(row) and volume_ratio >= 1.2 and recent_move >= max(cost, required * 0.45)
    runner_like = is_runner_strategy(strategy) and recent_move >= max(cost, required * 0.35)
    return strong_flow and (strong_bar or runner_like)


def spread_stable(rows: list[dict], index: int) -> bool:
    if index < 3:
        return True
    current = spread_fraction(rows[index])
    previous = [spread_fraction(rows[i]) for i in range(index - 3, index)]
    baseline = sum(previous) / max(1, len(previous))
    return current <= baseline * 1.20


def sell_pressure_decreasing(rows: list[dict], index: int) -> bool:
    if index < 1:
        return True
    current = rows[index].get("sell_pressure")
    previous = rows[index - 1].get("sell_pressure")
    if current is None or previous is None:
        return True
    return current <= previous


def entry_confirmation_ok(rows: list[dict], index: int, strategy: str = "") -> bool:
    if index < 2:
        return False
    row = rows[index]
    previous = rows[index - 1]
    bb_position = row.get("bb_position_0_1")
    bb_limit = 1.08 if ("Surge" in strategy or "Order Flow" in strategy or "Absorption" in strategy) else 1.03
    bb_not_extended = bb_position is None or bb_position <= bb_limit
    previous_low_holding = row["low"] >= previous["low"] * 0.995
    macd_confirmed = (row.get("macd_histogram") is not None and previous.get("macd_histogram") is not None and row["macd_histogram"] > previous["macd_histogram"]) or macd_rising(rows, index, count=2)
    above_ema9 = row.get("ema9") is None or row["close"] >= row["ema9"]
    above_vwap = row.get("session_vwap") is None or row["close"] >= row["session_vwap"]
    not_big_chase = (row.get("return_pct") or 0.0) <= 8.0 or lower_wick_support(previous)
    return (
        bb_not_extended
        and previous_low_holding
        and sell_pressure_decreasing(rows, index)
        and spread_stable(rows, index)
        and macd_confirmed
        and above_ema9
        and above_vwap
        and not_big_chase
    )


def common_entry_ok(rows: list[dict], index: int, strategy: str) -> bool:
    row = rows[index]
    return common_liquidity(row) and entry_reachability_ok(rows, index, strategy)


def runner_spread_ok(row: dict) -> bool:
    spread_pct = row.get("avg_spread_pct")
    if spread_pct is None:
        return True
    close = row.get("close") or 0.0
    return spread_pct <= (1.25 if close < 2.0 else 0.75)


def prefill_entry_ok(rows: list[dict], index: int, signal: dict) -> bool:
    row = rows[index]
    strategy = signal.get("strategy") or ""
    signal_close = signal.get("signal_close")
    first_bid = row.get("first_bid")
    first_ask = row.get("first_ask")
    max_spread_pct = 1.25 if first_ask is not None and first_ask < 2.0 else 0.85
    decision = evaluate_entry_fill_gate(
        bid=first_bid,
        ask=first_ask,
        last=row.get("open"),
        spread_pct=None,
        max_spread_pct=max_spread_pct if first_bid is not None and first_ask is not None else None,
        signal_close=signal_close,
        strategy_name=strategy,
        config=EntryFillGateConfig(
            entry_slippage_pct=0.0005,
            max_chase_pct=0.012,
            min_price_usd=0.0,
            runner_negative_chase_pct=0.012,
        ),
    )
    if not decision.allowed:
        signal["reject_at_fill"] = {
            "spread_too_wide": "prefill_first_spread_too_wide",
            "price_chase_too_far": "prefill_price_chase_too_far",
            "runner_signal_failed_before_fill": "prefill_runner_signal_failed_before_fill",
        }.get(decision.reason, f"prefill_{decision.reason}")
        signal["reject_payload"] = decision.payload
        return False
    return True


def previous_low_holding(rows: list[dict], index: int, tolerance: float = 0.995) -> bool:
    if index < 1:
        return False
    return rows[index]["low"] >= rows[index - 1]["low"] * tolerance


def bb_allowed(row: dict, limit: float) -> bool:
    value = row.get("bb_position_0_1")
    return value is None or value <= limit


def ema9_extension_fraction(row: dict) -> float:
    ema9 = row.get("ema9")
    if not ema9 or ema9 <= 0:
        return 0.0
    return max(0.0, (row["close"] - ema9) / ema9)


def runner_extension_ok(row: dict) -> bool:
    extension = ema9_extension_fraction(row)
    bb_position = row.get("bb_position_0_1")
    spread = spread_fraction(row)
    if bb_position is not None and bb_position > 1.25:
        return False
    if extension > 0.10:
        return False
    if extension > 0.08 and spread > 0.0045:
        return False
    return True


def above_ema9(row: dict) -> bool:
    return row.get("ema9") is None or row["close"] >= row["ema9"]


def above_vwap(row: dict) -> bool:
    return row.get("session_vwap") is None or row["close"] >= row["session_vwap"]


def vwap_or_strong_momentum(rows: list[dict], index: int) -> bool:
    row = rows[index]
    if above_vwap(row):
        return True
    recent_move = recent_10bar_change_fraction(rows, index) or 0.0
    trade_strength = row.get("trade_strength")
    sell_pressure = row.get("sell_pressure")
    volume_ma20 = row.get("volume_ma20") or 0.0
    volume_ratio = (row.get("volume") or 0.0) / max(volume_ma20, 1.0)
    strong_flow = (trade_strength is None or trade_strength >= 58) and (sell_pressure is None or sell_pressure <= 50)
    return bool(
        recent_move >= STRONG_MOMENTUM_MIN_10BAR_CHANGE_PCT
        and close_near_high(row)
        and volume_ratio >= 1.15
        and strong_flow
    )


def macd_not_deteriorating(rows: list[dict], index: int) -> bool:
    if index < 1:
        return True
    current = rows[index].get("macd_histogram")
    previous = rows[index - 1].get("macd_histogram")
    if current is None or previous is None:
        return True
    return current >= previous * 0.85


def confirm_pullback_reclaim(rows: list[dict], index: int) -> bool:
    row = rows[index]
    return (
        bb_allowed(row, 0.98)
        and previous_low_holding(rows, index, 0.997)
        and sell_pressure_decreasing(rows, index)
        and spread_stable(rows, index)
        and macd_rising(rows, index, count=2)
        and above_ema9(row)
        and vwap_or_strong_momentum(rows, index)
    )


def confirm_surge_pullback(rows: list[dict], index: int) -> bool:
    row = rows[index]
    previous = rows[index - 1]
    return (
        bb_allowed(row, 1.12)
        and previous_low_holding(rows, index, 0.99)
        and not spread_widening(rows, index)
        and macd_not_deteriorating(rows, index)
        and above_ema9(row)
        and ((row.get("return_pct") or 0.0) <= 10.0 or lower_wick_support(previous))
    )


def confirm_lower_band_snapback(rows: list[dict], index: int) -> bool:
    row = rows[index]
    return (
        bb_allowed(row, 0.65)
        and previous_low_holding(rows, index, 0.992)
        and sell_pressure_decreasing(rows, index)
        and macd_rising(rows, index, count=2)
    )


def confirm_vwap_reclaim(rows: list[dict], index: int) -> bool:
    row = rows[index]
    return (
        bb_allowed(row, 1.03)
        and previous_low_holding(rows, index, 0.997)
        and spread_stable(rows, index)
        and sell_pressure_decreasing(rows, index)
        and macd_rising(rows, index, count=2)
        and above_ema9(row)
        and above_vwap(row)
    )


def confirm_order_flow(rows: list[dict], index: int) -> bool:
    row = rows[index]
    return (
        bb_allowed(row, 1.15)
        and previous_low_holding(rows, index, 0.99)
        and spread_stable(rows, index)
        and sell_pressure_decreasing(rows, index)
        and macd_not_deteriorating(rows, index)
        and above_ema9(row)
    )


def confirm_liquidity_imbalance(rows: list[dict], index: int) -> bool:
    row = rows[index]
    return (
        bb_allowed(row, 1.15)
        and previous_low_holding(rows, index, 0.99)
        and spread_stable(rows, index)
        and sell_pressure_decreasing(rows, index)
        and (above_ema9(row) or vwap_or_strong_momentum(rows, index))
    )


def confirm_absorption_breakout(rows: list[dict], index: int) -> bool:
    row = rows[index]
    return (
        bb_allowed(row, 1.20)
        and previous_low_holding(rows, index, 0.985)
        and spread_stable(rows, index)
        and sell_pressure_decreasing(rows, index)
        and macd_not_deteriorating(rows, index)
    )


def entry_fees(quantity: int, price: float) -> float:
    return float(toss_fee_breakdown(side="buy", quantity=quantity, price=price, settings=get_settings())["total_fees_usd"])


def exit_fees(quantity: int, price: float) -> float:
    return float(toss_fee_breakdown(side="sell", quantity=quantity, price=price, settings=get_settings())["total_fees_usd"])


def macd_rising(rows: list[dict], index: int, count: int = 3) -> bool:
    values = [rows[i].get("macd_histogram") for i in range(max(0, index - count + 1), index + 1)]
    values = [value for value in values if value is not None]
    return len(values) >= count and all(right > left for left, right in zip(values, values[1:]))


def macd_fading(rows: list[dict], index: int, count: int = 3) -> bool:
    values = [rows[i].get("macd_histogram") for i in range(max(0, index - count + 1), index + 1)]
    values = [value for value in values if value is not None]
    return len(values) >= count and all(value > 0 for value in values) and all(right < left for left, right in zip(values, values[1:]))


def volume_decay(rows: list[dict], index: int) -> bool:
    if index < 4:
        return False
    recent = [rows[i].get("volume") or 0 for i in range(index - 2, index + 1)]
    previous = [rows[i].get("volume") or 0 for i in range(index - 5, index - 2)]
    return sum(recent) / max(1.0, sum(previous)) < 0.65


def spread_widening(rows: list[dict], index: int) -> bool:
    if index < 3:
        return False
    current = spread_fraction(rows[index])
    previous = [spread_fraction(rows[i]) for i in range(max(0, index - 3), index)]
    baseline = sum(previous) / max(1, len(previous))
    return current >= baseline * 1.35 and current >= 0.003


def high_failure(rows: list[dict], index: int, lookback: int = 5) -> bool:
    if index < lookback + 1:
        return False
    prev_high = max(rows[i]["high"] for i in range(index - lookback, index) if rows[i].get("high") is not None)
    row = rows[index]
    return row["high"] >= prev_high * 0.995 and row["close"] < prev_high * 0.97


def high_failure_count(rows: list[dict], index: int, lookback: int = 8) -> int:
    start = max(lookback + 1, index - lookback + 1)
    return sum(1 for i in range(start, index + 1) if high_failure(rows, i, lookback=5))


def failed_follow_through_ok(rows: list[dict], index: int) -> bool:
    if index < 3:
        return True
    row = rows[index]
    previous = rows[index - 1]
    trade_strength = row.get("trade_strength")
    sell_pressure = row.get("sell_pressure")
    no_price_follow = row["close"] < previous["close"] and row["high"] <= previous["high"] * 1.002
    volume_not_following = (row.get("volume") or 0.0) <= (previous.get("volume") or 0.0) * 0.85
    flow_failed = trade_strength is not None and trade_strength < 35 and sell_pressure is not None and sell_pressure > 65
    high_failures = high_failure_count(rows, index, lookback=4) >= 2
    return not (high_failures or (no_price_follow and volume_not_following and flow_failed))


def close_near_high(row: dict) -> bool:
    high = row.get("high")
    low = row.get("low")
    close = row.get("close")
    if high is None or low is None or close is None or high <= low:
        return False
    return (close - low) / (high - low) >= 0.65


def lower_wick_support(row: dict) -> bool:
    open_ = row.get("open")
    close = row.get("close")
    low = row.get("low")
    high = row.get("high")
    if None in (open_, close, low, high) or high <= low:
        return False
    body_low = min(open_, close)
    return (body_low - low) / (high - low) >= 0.35 and close >= open_


def indicator_snapshot(rows: list[dict], index: int, strategy: str = "") -> dict:
    row = rows[index]
    return {
        "time": row["timestamp_kst"],
        "close": row.get("close"),
        "volume": row.get("volume"),
        "notional_usd": row.get("notional_usd"),
        "bb_position": row.get("bb_position_0_1"),
        "ema9": row.get("ema9"),
        "ema20": row.get("ema20"),
        "vwap": row.get("session_vwap"),
        "macd": row.get("macd_12_26"),
        "macd_signal": row.get("macd_signal_9"),
        "macd_histogram": row.get("macd_histogram"),
        "range_pct": row.get("range_pct"),
        "first_bid": row.get("first_bid"),
        "first_ask": row.get("first_ask"),
        "last_bid": row.get("last_bid"),
        "last_ask": row.get("last_ask"),
        "avg_bid": row.get("avg_bid"),
        "avg_ask": row.get("avg_ask"),
        "avg_spread_pct": row.get("avg_spread_pct"),
        "bid_ask_imbalance": row.get("bid_ask_imbalance"),
        "trade_strength": row.get("trade_strength"),
        "sell_pressure": row.get("sell_pressure"),
        "unknown_trade_ratio": row.get("unknown_trade_ratio"),
        "spread_proxy_pct": spread_fraction(row) * 100,
        "roundtrip_cost_pct": estimated_roundtrip_cost_fraction(row) * 100,
        "recent_10bar_change_pct": (recent_10bar_change_fraction(rows, index) or 0.0) * 100,
        "dynamic_take_profit_pct": dynamic_take_profit_fraction(row, strategy, rows, index) * 100,
        "expected_upside_pct": expected_upside_fraction(rows, index, strategy) * 100,
        "expected_pullback_upside_pct": conservative_expected_upside_fraction(rows, index) * 100,
        "expected_runner_upside_pct": continuation_expected_upside_fraction(rows, index) * 100,
        "data_quality": "historical_quotes_trades" if row.get("avg_bid") is not None else "bar_proxy_no_historical_quote_tick",
    }


def common_liquidity(row: dict) -> bool:
    return (row.get("notional_usd") or 0) >= 30_000


def signal_surge_pullback(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 30:
        return False, ""
    row = rows[index]
    window = rows[max(0, index - 40) : index + 1]
    surge_low = min(item["low"] for item in window)
    peak_index = max(range(len(window)), key=lambda i: window[i]["high"])
    peak_high = window[peak_index]["high"]
    after_peak = window[peak_index + 1 :] or [window[-1]]
    pullback_low = min(item["low"] for item in after_peak)
    surge_pct = (peak_high - surge_low) / surge_low if surge_low else 0.0
    pullback_pct = (peak_high - pullback_low) / peak_high if peak_high else 0.0
    macd = row.get("macd_12_26")
    signal = row.get("macd_signal_9")
    both_negative = macd is not None and signal is not None and macd < 0 and signal < 0
    support = any(
        level and pullback_low <= level * 1.018 and row["close"] >= level * 0.995
        for level in [row.get("ema9"), row.get("ema20"), row.get("bb_mid20"), row.get("session_vwap")]
    )
    reclaim = close_near_high(row) and (row["close"] >= (row.get("ema9") or row["close"]) or row["close"] >= (row.get("session_vwap") or row["close"]))
    bb_ok = (row.get("bb_position_0_1") is None) or row["bb_position_0_1"] <= 0.85
    macd_ok = (macd_rising(rows, index) or (row.get("macd_histogram") or -1) > 0) and not both_negative
    if common_entry_ok(rows, index, "Surge Pullback Reclaim") and confirm_surge_pullback(rows, index) and surge_pct >= 0.10 and 0.02 <= pullback_pct <= 0.35 and support and reclaim and bb_ok and macd_ok:
        return True, f"surge_{surge_pct:.1%}_pullback_{pullback_pct:.1%}_support_reclaim"
    return False, ""


def signal_first_pullback_volume_shock(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 30:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    window = rows[max(0, index - 10) : index + 1]
    peak_index = max(range(len(window)), key=lambda i: window[i]["high"])
    peak_high = window[peak_index]["high"]
    after_peak = window[peak_index + 1 :] or [window[-1]]
    pullback_low = min(item["low"] for item in after_peak)
    pullback_pct = (peak_high - pullback_low) / peak_high if peak_high else 0.0
    recent_move = recent_10bar_change_fraction(rows, index) or 0.0
    volume_ma20 = row.get("volume_ma20") or 0.0
    volume_ratio = (row.get("volume") or 0.0) / max(volume_ma20, 1.0)
    trade_strength = row.get("trade_strength")
    sell_pressure = row.get("sell_pressure")
    volume_shock = recent_move >= VOLUME_SHOCK_MIN_10BAR_CHANGE_PCT or volume_ratio >= 1.6
    first_pullback = 1 <= len(after_peak) <= 5 and 0.004 <= pullback_pct <= 0.09
    support = any(
        level and pullback_low <= level * 1.015 and row["close"] >= level * 0.995
        for level in [row.get("ema9"), row.get("ema20"), row.get("bb_mid20"), row.get("session_vwap")]
    )
    reclaim = row["close"] >= previous["close"] and row["close"] >= row["open"] and (close_near_high(row) or above_ema9(row))
    # Only take the pullback when price reclaims ABOVE VWAP: a reclaim below VWAP is a
    # downtrend dead-cat bounce that structurally fails. Confirmed on combined
    # 2026-07-07 + 07-08 (winners sit above VWAP, losers at/below it).
    above_vwap = row.get("session_vwap") is None or row["close"] >= row["session_vwap"]
    flow_ok = (trade_strength is None or trade_strength >= VOLUME_SHOCK_MIN_TRADE_STRENGTH) and (
        sell_pressure is None or sell_pressure <= VOLUME_SHOCK_MAX_SELL_PRESSURE
    )
    # Reclaim must arrive on real participation, not a thin-volume drift. This is
    # what separated the strategy's genuine setups from choppy-name whipsaw
    # (e.g. TC), where the pullback reclaimed on fading volume and then failed.
    reclaim_on_volume = volume_ratio >= 1.2
    if (
        common_entry_ok(rows, index, "First Pullback After Volume Shock")
        and failed_follow_through_ok(rows, index)
        and volume_shock
        and entry_edge_ok(rows, index, VOLUME_SHOCK_MIN_10BAR_CHANGE_PCT)
        and first_pullback
        and support
        and reclaim
        and above_vwap
        and reclaim_on_volume
        and flow_ok
        and recent_move >= VOLUME_SHOCK_MIN_10BAR_CHANGE_PCT
        and liquidity_notional(row) >= VOLUME_SHOCK_MIN_NOTIONAL_1M_USD
        and estimated_roundtrip_cost_fraction(row) <= VOLUME_SHOCK_MAX_ROUNDTRIP_COST_PCT
        and not spread_widening(rows, index)
    ):
        return True, f"volume_shock_first_pullback_{recent_move:.1%}_pullback_{pullback_pct:.1%}"
    return False, ""


def signal_liquidity_sweep_reclaim(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 20:
        return False, ""
    row = rows[index]
    prior = rows[max(0, index - 7) : index]
    prior_low = min(item["low"] for item in prior)
    sweep = row["low"] < prior_low * 0.997
    reclaim_pct = (row["close"] - prior_low) / prior_low if prior_low else 0.0
    reclaimed = row["close"] >= prior_low * 1.006
    trade_strength = row.get("trade_strength")
    sell_pressure = row.get("sell_pressure")
    flow_ok = (trade_strength is None or trade_strength >= 45) and (
        sell_pressure is None or sell_pressure <= 55 or sell_pressure_decreasing(rows, index)
    )
    support_reclaim = above_ema9(row) or (row.get("session_vwap") is not None and row["close"] >= row["session_vwap"] * 0.995)
    if (
        common_entry_ok(rows, index, "Liquidity Sweep Reclaim")
        and failed_follow_through_ok(rows, index)
        and sweep
        and reclaimed
        and lower_wick_support(row)
        and flow_ok
        and support_reclaim
        and not spread_widening(rows, index)
    ):
        return True, f"sweep_low_reclaim_{reclaim_pct:.1%}_absorption"
    return False, ""


def signal_micro_breakout_absorption(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 25:
        return False, ""
    row = rows[index]
    lookback = 8
    recent_move = recent_10bar_change_fraction(rows, index) or 0.0
    prior = rows[index - lookback : index]
    prior_high = max(item["high"] for item in prior)
    ranges = [max(0.0, item["high"] - item["low"]) for item in prior]
    avg_range = sum(ranges) / max(1, len(ranges))
    compression = avg_range > 0 and (max(item["high"] for item in prior) - min(item["low"] for item in prior)) <= avg_range * 4.0
    prior_absorption = any(
        lower_wick_support(item)
        or (item.get("ema9") is not None and item["low"] <= item["ema9"] * 1.015 and item["close"] >= item["ema9"] * 0.995)
        for item in prior[-5:]
    )
    volume_ma20 = row.get("volume_ma20") or 0.0
    volume_ratio = (row.get("volume") or 0.0) / max(volume_ma20, 1.0)
    trade_strength = row.get("trade_strength")
    sell_pressure = row.get("sell_pressure")
    flow_ok = (trade_strength is None or trade_strength >= MICRO_BREAKOUT_MIN_TRADE_STRENGTH) and (
        sell_pressure is None or sell_pressure <= MICRO_BREAKOUT_MAX_SELL_PRESSURE
    )
    # A breakout on near-average volume (1.05x) is low-conviction and failed
    # often; require real participation so the break is backed by demand.
    micro_breakout = row["close"] >= prior_high and volume_ratio >= 1.3
    if (
        common_entry_ok(rows, index, "Micro Breakout With Absorption")
        and failed_follow_through_ok(rows, index)
        and micro_breakout
        and prior_absorption
        and compression
        and flow_ok
        and row_range_fraction(row) >= MICRO_BREAKOUT_MIN_RANGE_PCT
        and recent_move >= MICRO_BREAKOUT_MIN_10BAR_CHANGE_PCT
        and recent_move <= MICRO_BREAKOUT_MAX_10BAR_CHANGE_PCT
        and estimated_roundtrip_cost_fraction(row) <= MICRO_BREAKOUT_MAX_ROUNDTRIP_COST_PCT
        and close_near_high(row)
        and not spread_widening(rows, index)
    ):
        return True, "micro_breakout_after_absorption_compression"
    return False, ""


def liquidity_notional(row: dict) -> float:
    explicit = row.get("notional_usd") or row.get("notional")
    if explicit is not None:
        return explicit
    return max(0.0, (row.get("close") or 0.0) * (row.get("volume") or 0.0))


def liquidity_volume_ratio(row: dict) -> float:
    return (row.get("volume") or 0.0) / max(row.get("volume_ma20") or 0.0, 1.0)


def liquidity_imbalance(row: dict) -> float | None:
    value = row.get("bid_ask_imbalance")
    if value is None:
        return None
    return value / 100.0 if value > 1.0 else value


def liquidity_spread_cap(row: dict) -> float:
    close = row.get("close") or 0.0
    return 0.0125 if close < 2.0 else 0.0085


def tight_liquidity_ok(row: dict, min_notional: float = 75_000.0) -> bool:
    quote_count = row.get("quote_count")
    return (
        liquidity_notional(row) >= min_notional
        and spread_fraction(row) <= liquidity_spread_cap(row)
        and (quote_count is None or quote_count >= 8)
    )


def liquidity_flow_ok(
    row: dict,
    *,
    min_strength: float = 50.0,
    max_sell_pressure: float = 55.0,
    min_imbalance: float | None = 0.50,
) -> bool:
    trade_strength = row.get("trade_strength")
    sell_pressure = row.get("sell_pressure")
    imbalance = liquidity_imbalance(row)
    return (
        (trade_strength is None or trade_strength >= min_strength)
        and (sell_pressure is None or sell_pressure <= max_sell_pressure)
        and (min_imbalance is None or imbalance is None or imbalance >= min_imbalance)
    )


def support_reclaim(row: dict, previous: dict) -> bool:
    vwap = row.get("session_vwap")
    ema9 = row.get("ema9")
    vwap_reclaim = vwap is None or (row["low"] <= vwap * 1.012 and row["close"] >= vwap * 0.998)
    ema_reclaim = ema9 is None or (row["low"] <= ema9 * 1.015 and row["close"] >= ema9 * 0.997)
    price_reclaim = row["close"] >= previous["close"] and row["close"] >= row["open"]
    return price_reclaim and (vwap_reclaim or ema_reclaim)


# Active set mirrors the live runtime: the two enabled engines only.
# Liquidity Pullback Reclaim and VWAP Soft Reclaim were retired from live, so they
# are out of the default replay set too -- keeping them here made replay disagree
# with runtime.
STRATEGIES = {
    "First Pullback After Volume Shock": signal_first_pullback_volume_shock,
    "Micro Breakout With Absorption": signal_micro_breakout_absorption,
}


# Retired/disabled strategies (kept for reference / easy reactivation):
# - First Pullback After Volume Shock was reintroduced only for strong 6%+
#   10-bar shock + 300k notional setups. This avoided the 2026-07-10 thin
#   failures while adding five trades in the 4-day replay.
# - VWAP Soft Reclaim: fully retired and removed 2026-07-16. Walk-forward
#   (train 07-07..10 -> holdout 07-13..15) showed 100% in-sample win rate
#   flipping to 0% win / -$45 out of sample, and winners vs losers were
#   indistinguishable on every entry indicator (no separable edge; the in-sample
#   profit rode a single hot name, JLHL 07-09). No entry filter could keep the
#   winners while dropping the losers, so the signal/constants were deleted.
# - Liquidity Sweep Reclaim: fired 0 trades across the replay set; its setups
#   survive every structural gate but fail the entry-expectancy gate (1 of 25),
#   i.e. no real edge. Relaxing it yielded only 6 trades at 33% win.
# - Surge Pullback Reclaim: only net-negative strategy on both corpora (tuning
#   +$2.9 ≈ noise, out-of-sample session -$27.8). No participation/flow gate
#   rescued it without collapsing it, and its losers were triggering symbol
#   cooldowns that blocked healthier strategies, so retiring it lifted the rest.
ARCHIVED_STRATEGIES: dict[str, object] = {
    "Liquidity Sweep Reclaim": signal_liquidity_sweep_reclaim,
    "Surge Pullback Reclaim": signal_surge_pullback,
}


def stop_price(rows: list[dict], index: int, entry_price: float, *, include_current: bool = True) -> float:
    end = index + 1 if include_current else index
    recent_lows = [rows[i].get("low") for i in range(max(0, end - 5), max(0, end))]
    return compute_structure_stop_price(
        recent_lows,
        entry_price,
        final_stop_pct=FINAL_STOP_PCT,
        structure_stop_buffer=STRUCTURE_STOP_BUFFER,
    )


def replay_exit_decision_config() -> ExitDecisionConfig:
    settings = get_settings()
    return ExitDecisionConfig(
        partial_exit_fraction=settings.paper_partial_exit_fraction,
        dynamic_take_profit_enabled=settings.paper_dynamic_take_profit_enabled,
        partial_exit_requires_weakness=settings.paper_partial_exit_requires_weakness,
        high_failure_exit_enabled=settings.paper_high_failure_exit_enabled,
        break_even_activation_pct=settings.paper_break_even_activation_pct,
        trailing_activation_pct=settings.paper_trailing_activation_pct,
        take_profit_requires_weakness=settings.paper_take_profit_requires_weakness,
        exit_on_vwap_ema_break=settings.paper_exit_on_vwap_ema_break,
        vwap_ema_break_min_hold_seconds=settings.paper_vwap_ema_break_min_hold_seconds,
        vwap_ema_break_min_loss_pct=settings.paper_vwap_ema_break_min_loss_pct,
        time_exit_enabled=settings.paper_time_exit_enabled,
        time_exit_seconds=settings.paper_time_exit_seconds,
        stop_loss_hold_enabled=settings.paper_stop_loss_hold_enabled,
        stop_loss_hold_max_seconds=settings.paper_stop_loss_hold_max_seconds,
        max_stop_loss_pct=settings.paper_max_stop_loss_pct,
        stop_loss_deep_break_pct=settings.paper_stop_loss_deep_break_pct,
        stop_loss_rapid_drop_pct=settings.paper_stop_loss_rapid_drop_pct,
        strategy_min_trade_strength_for_entry=settings.strategy_min_trade_strength_for_entry,
        strategy_max_sell_pressure_for_entry=settings.strategy_max_sell_pressure_for_entry,
    )


def replay_exit_indicators(row: dict) -> ExitDecisionIndicators:
    return ExitDecisionIndicators(
        ema9=row.get("ema9"),
        ema20=row.get("ema20"),
        vwap=row.get("session_vwap") or row.get("vwap"),
        bb_mid=row.get("bb_mid"),
        bb_lower=row.get("bb_lower"),
    )


def replay_chart_structure(rows: list[dict], index: int, current_price: float) -> dict:
    row = rows[index]
    previous = rows[max(0, index - 5) : index]
    recent_lows = [item.get("low") for item in previous if item.get("low") is not None]
    structure_low = min(recent_lows) if recent_lows else None
    structure_low_break = structure_low is not None and current_price < structure_low * 0.998
    below_ema9 = row.get("ema9") is not None and current_price < row["ema9"]
    below_ema20 = row.get("ema20") is not None and current_price < row["ema20"]
    vwap = row.get("session_vwap") or row.get("vwap")
    below_vwap = vwap is not None and current_price < vwap
    ema_vwap_break = below_ema9 and (below_ema20 or below_vwap)
    bb_lower_break = row.get("bb_lower") is not None and current_price < row["bb_lower"]
    return {
        "structure_low": structure_low,
        "structure_low_break": structure_low_break,
        "below_ema9": below_ema9,
        "below_ema20": below_ema20,
        "below_vwap": below_vwap,
        "ema_vwap_break": ema_vwap_break,
        "bb_lower_break": bb_lower_break,
        "chart_breakdown": bool(structure_low_break and (ema_vwap_break or bb_lower_break)),
    }


def replay_exit_momentum_state(rows: list[dict], index: int, position: Position, current_price: float) -> dict:
    settings = get_settings()
    row = rows[index]
    profit_pct = (current_price - position.entry_price) / position.entry_price if position.entry_price > 0 else 0.0
    drawdown_from_high = (position.high_watermark - current_price) / position.high_watermark if position.high_watermark > 0 else 0.0
    high_failures = high_failure_count(rows, index, lookback=settings.paper_high_failure_lookback_bars)
    volume_weak = volume_decay(rows, index)
    macd_weak = macd_fading(rows, index)
    chart_structure = replay_chart_structure(rows, index, current_price)
    trade_strength = row.get("trade_strength")
    sell_pressure_pct = row.get("sell_pressure")
    sell_pressure_ratio = sell_pressure_pct / 100 if sell_pressure_pct is not None and sell_pressure_pct > 1 else sell_pressure_pct
    flow_velocity = row.get("volume_velocity_10s") or row.get("notional_velocity_10s")
    order_flow_strong = (
        (trade_strength is None or trade_strength >= settings.strategy_min_trade_strength_for_entry)
        and (sell_pressure_ratio is None or sell_pressure_ratio <= settings.strategy_max_sell_pressure_for_entry)
        and (flow_velocity is None or flow_velocity >= 0.8)
    )
    order_flow_weak = (
        (trade_strength is not None and trade_strength < settings.strategy_min_trade_strength_for_entry)
        or (sell_pressure_ratio is not None and sell_pressure_ratio > settings.strategy_max_sell_pressure_for_entry)
        or (flow_velocity is not None and flow_velocity < 0.6)
    )
    above_ema9 = row.get("ema9") is None or current_price >= row["ema9"]
    above_ema20 = row.get("ema20") is None or current_price >= row["ema20"]
    vwap = row.get("session_vwap") or row.get("vwap")
    above_vwap = vwap is None or current_price >= vwap
    near_high = drawdown_from_high <= max(settings.paper_dynamic_trailing_tight_pct, 0.006)
    upper_band_push = row.get("bb_upper") is not None and current_price >= row["bb_upper"]
    chart_profit_weakness = (
        bool(chart_structure.get("ema_vwap_break"))
        or high_failures >= 2
        or (volume_weak and not near_high)
        or (macd_weak and not above_ema9)
    )
    flow_weak_confirmation = order_flow_weak and (
        chart_profit_weakness or drawdown_from_high >= settings.paper_dynamic_trailing_tight_pct
    )
    strong = (
        profit_pct >= settings.paper_break_even_activation_pct
        and above_ema9
        and (above_vwap or above_ema20)
        and not macd_weak
        and near_high
        and high_failures < 2
        and not volume_weak
        and order_flow_strong
    )
    runner_candidate = profit_pct >= settings.paper_runner_candidate_profit_pct
    runner_eligible = (
        runner_candidate
        and above_ema9
        and (above_vwap or above_ema20)
        and not macd_weak
        and not volume_weak
        and high_failures <= 1
        and near_high
        and order_flow_strong
    )
    runner = profit_pct >= settings.paper_runner_trailing_profit_pct or runner_eligible
    runner_full_exit_confirmed = (
        runner
        and high_failures >= settings.paper_runner_full_exit_high_failures
        and volume_weak
        and row.get("ema9") is not None
        and current_price < row["ema9"]
        and macd_weak
    )
    runner_emergency_exit = runner and drawdown_from_high >= settings.paper_runner_emergency_drawdown_pct
    weak = profit_pct > 0 and (chart_profit_weakness or flow_weak_confirmation)
    if runner and not runner_full_exit_confirmed and not runner_emergency_exit:
        weak = False
    elif upper_band_push and strong:
        weak = False
    return {
        "profit_pct": profit_pct,
        "drawdown_from_high_pct": drawdown_from_high,
        "high_failures": high_failures,
        "volume_decay": volume_weak,
        "trade_strength": trade_strength,
        "sell_pressure": sell_pressure_ratio,
        "flow_volume_velocity_10s": flow_velocity,
        "order_flow_strong": order_flow_strong,
        "order_flow_weak": order_flow_weak,
        "chart_structure": chart_structure,
        "chart_breakdown": chart_structure.get("chart_breakdown"),
        "ema_vwap_break": chart_structure.get("ema_vwap_break"),
        "chart_profit_weakness": chart_profit_weakness,
        "flow_weak_confirmation": flow_weak_confirmation,
        "strong": strong,
        "weak": weak,
        "runner": runner,
        "runner_full_exit_confirmed": runner_full_exit_confirmed,
        "runner_emergency_exit": runner_emergency_exit,
        "spread_widened": spread_widening(rows, index),
        "spread_exit_priority": spread_widening(rows, index) and high_failures >= 1,
    }


def replay_min_profitable_exit_price(position: Position, quantity: float) -> float:
    quantity = max(0.0, min(float(quantity), float(position.quantity)))
    if quantity <= 0 or position.entry_price <= 0:
        return float("inf")
    close_ratio = min(1.0, quantity / position.quantity) if position.quantity > 0 else 1.0
    entry_fee_share = position.entry_fees * close_ratio
    min_net_profit = position.entry_price * quantity * MIN_NET_TAKE_PROFIT_PCT
    required_price = position.entry_price
    for _ in range(3):
        required_price = (position.entry_price * quantity + entry_fee_share + exit_fees(quantity, required_price) + min_net_profit) / quantity
        required_price = max(required_price, position.entry_price)
    return required_price


def replay_dynamic_take_profit_update(
    rows: list[dict],
    index: int,
    position: Position,
    *,
    current_price: float,
    high_watermark: float,
    momentum_state: dict,
    trailing_pct: float,
    quantity: float,
) -> dict | None:
    settings = get_settings()
    base_target = position.take_profit_price or position.entry_price * (
        1 + dynamic_take_profit_fraction(rows[index], position.strategy, rows, index)
    )
    position.take_profit_price = base_target
    return update_dynamic_take_profit_target(
        average_price=position.entry_price,
        quantity=quantity,
        current_price=current_price,
        high_watermark=high_watermark,
        take_profit_price=base_target,
        previous_dynamic_take_profit_price=position.dynamic_take_profit_price,
        profit_floor=replay_min_profitable_exit_price(position, quantity),
        momentum_state=momentum_state,
        trailing_pct=trailing_pct,
        config=DynamicTakeProfitConfig(
            enabled=settings.paper_dynamic_take_profit_enabled,
            default_take_profit_pct=settings.paper_take_profit_pct,
            dynamic_trailing_normal_pct=settings.paper_dynamic_trailing_normal_pct,
            dynamic_trailing_wide_pct=settings.paper_dynamic_trailing_wide_pct,
        ),
    )


def apply_replay_stop_loss_state(position: Position, action: str, hold_reason: str | None) -> None:
    if action == "clear":
        position.stop_loss_candidate_bars = None
        position.stop_loss_hold_reason = None
        return
    if action in {"set", "hold"}:
        position.stop_loss_candidate_bars = 0 if position.stop_loss_candidate_bars is None else position.stop_loss_candidate_bars + 1
        position.stop_loss_hold_reason = hold_reason


def should_exit(
    rows: list[dict],
    index: int,
    position: Position,
    *,
    current_price: float | None = None,
    use_bar_high: bool = False,
) -> tuple[bool, str]:
    row = rows[index]
    price = current_price if current_price is not None else row["close"]
    high_watermark_before = position.high_watermark
    trailing_stop_before = position.trailing_stop_price
    _update_synthetic_trailing(rows, index, position, price)
    config = replay_exit_decision_config()
    full_quantity = float(position.quantity)
    momentum_state = replay_exit_momentum_state(rows, index, position, price)
    trailing_pct = _synthetic_trailing_pct(rows, index, position, price)
    dynamic_take_profit = replay_dynamic_take_profit_update(
        rows,
        index,
        position,
        current_price=price,
        high_watermark=position.high_watermark,
        momentum_state=momentum_state,
        trailing_pct=trailing_pct,
        quantity=full_quantity,
    )
    if dynamic_take_profit:
        position.dynamic_take_profit_price = dynamic_take_profit["price"]
        position.dynamic_take_profit_reason = dynamic_take_profit["reason"]
        position.take_profit_price = dynamic_take_profit["price"]
        momentum_state["dynamic_take_profit"] = dynamic_take_profit
    partial_quantity = max(1.0, int(full_quantity * config.partial_exit_fraction)) if config.partial_exit_fraction > 0 else 0.0
    stop_candidate_elapsed = (
        position.stop_loss_candidate_bars * 60.0
        if position.stop_loss_candidate_bars is not None
        else None
    )
    result = evaluate_exit_decision(
        current_price=price,
        position=ExitDecisionPosition(
            quantity=full_quantity,
            average_price=position.entry_price,
            opened_elapsed_seconds=max(0, index - position.entry_index) * 60.0,
            stop_loss_price=position.stop_price,
            take_profit_price=position.take_profit_price,
            partial_take_profit_price=position.partial_take_profit_price,
            partial_exit_done=position.partial_exit_done,
            trailing_activation_price=position.trailing_activation_price,
            stop_loss_candidate_elapsed_seconds=stop_candidate_elapsed,
        ),
        indicators=replay_exit_indicators(row),
        high_watermark=position.high_watermark,
        trailing_stop_price=position.trailing_stop_price,
        momentum_state=momentum_state,
        high_failure_count=high_failure_count(rows, index, lookback=get_settings().paper_high_failure_lookback_bars),
        full_profit_floor=replay_min_profitable_exit_price(position, full_quantity),
        partial_profit_floor=replay_min_profitable_exit_price(position, min(partial_quantity, full_quantity)),
        config=config,
    )
    apply_replay_stop_loss_state(
        position,
        result.stop_loss_state.action,
        result.stop_loss_state.hold_reason,
    )
    quote = synthetic_quote_at_price(row, price)
    position.last_exit_snapshot = {
        "current_price": price,
        "bid": quote.get("bid"),
        "ask": quote.get("ask"),
        "spread_pct": quote.get("spread_pct"),
        "high_watermark_before": high_watermark_before,
        "high_watermark_after": position.high_watermark,
        "trailing_stop_price_before": trailing_stop_before,
        "trailing_stop_price": position.trailing_stop_price,
        "dynamic_take_profit_price": position.dynamic_take_profit_price,
        "dynamic_take_profit_reason": position.dynamic_take_profit_reason,
        "take_profit_price": position.take_profit_price,
        "momentum_state": momentum_state,
    }
    if result.reason:
        return True, result.reason
    return False, ""


def open_position(
    portfolio: Portfolio,
    rows: list[dict],
    index: int,
    signal: dict,
    *,
    include_current_stop: bool = True,
    fill_price: float | None = None,
) -> None:
    row = rows[index]
    if fill_price is not None:
        # Forming-bar intrabar entry: the fill price is the synthetic intrabar ask at
        # the trigger price (already computed by the caller); there is no next-bar
        # chase to guard against, so skip prefill_entry_ok.
        price = fill_price
    else:
        if not prefill_entry_ok(rows, index, signal):
            return
        raw_price = row["open"]
        price = execution_price(raw_price, row, "buy")
    quantity = max(1, math.floor(min(MAX_NOTIONAL_PER_TRADE, portfolio.equity * 0.15) / price))
    fees = entry_fees(quantity, price)
    portfolio.equity -= fees
    portfolio.position = Position(
        strategy=portfolio.strategy,
        entry_index=index,
        entry_time=row["timestamp_kst"],
        entry_price=price,
        quantity=quantity,
        reason=signal["reason"],
        indicators=signal["indicators"],
        stop_price=stop_price(rows, index, price, include_current=include_current_stop),
        high_watermark=price,
        reference_high=signal.get("reference_high"),
        entry_fees=fees,
        trailing_activation_price=price * (1 + get_settings().paper_trailing_activation_pct),
    )


def close_position(portfolio: Portfolio, rows: list[dict], index: int, reason: str, stop_fill: bool = False, stop_price_override: float | None = None) -> None:
    if not portfolio.position:
        return
    row = rows[index]
    raw_price = stop_price_override if stop_price_override is not None else portfolio.position.stop_price if stop_fill else row["open"]
    price = execution_price(raw_price, row, "sell", reason=reason)
    position = portfolio.position
    quote = synthetic_quote_at_price(row, raw_price) if raw_price and raw_price > 0 else {}
    exit_snapshot = {
        **(position.last_exit_snapshot or {}),
        "current_price": (position.last_exit_snapshot or {}).get("current_price", raw_price),
        "bid": (position.last_exit_snapshot or {}).get("bid", quote.get("bid")),
        "ask": (position.last_exit_snapshot or {}).get("ask", quote.get("ask")),
        "spread_pct": (position.last_exit_snapshot or {}).get("spread_pct", quote.get("spread_pct")),
        "fill_reference_price": raw_price,
        "fill_price": price,
        "high_watermark_after": position.high_watermark,
        "trailing_stop_price": position.trailing_stop_price,
        "dynamic_take_profit_price": position.dynamic_take_profit_price,
        "dynamic_take_profit_reason": position.dynamic_take_profit_reason,
    }
    gross = (price - position.entry_price) * position.quantity
    fees = exit_fees(position.quantity, price)
    net = gross - fees
    portfolio.equity += net
    portfolio.trades.append(
        {
            "symbol": row.get("symbol"),
            "strategy": portfolio.strategy,
            "entry_time": position.entry_time,
            "exit_time": row["timestamp_kst"],
            "quantity": position.quantity,
            "entry_price": round(position.entry_price, 6),
            "exit_price": round(price, 6),
            "gross_pnl": round(gross, 4),
            "fees": round(fees, 4),
            "net_pnl": round(net, 4),
            "return_pct": round((price - position.entry_price) / position.entry_price * 100, 4),
            "entry_reason": position.reason,
            "exit_reason": reason,
            "entry_indicators_json": json.dumps(position.indicators, ensure_ascii=False),
            "exit_indicators_json": json.dumps(indicator_snapshot(rows, index, position.strategy), ensure_ascii=False),
            "exit_snapshot_json": json.dumps(exit_snapshot, ensure_ascii=False),
        }
    )
    portfolio.last_exit_index = index
    portfolio.last_exit_reason = reason
    portfolio.last_exit_net_pnl = net
    portfolio.position = None


def synthetic_path_points(rows: list[dict], index: int, position: Position, path_mode: str) -> list[float]:
    row = rows[index]
    open_price = row.get("open") or row.get("close") or 0.0
    start = open_price
    if position.entry_index < index and index > 0:
        start = rows[index - 1].get("close") or open_price
    low = row.get("low") or open_price
    high = row.get("high") or open_price
    close = row.get("close") or open_price
    if path_mode == "low_first":
        points = [start, low, high, close]
    elif path_mode == "high_first":
        points = [start, high, low, close]
    elif path_mode == "color_path":
        points = [start, low, high, close] if close >= open_price else [start, high, low, close]
    else:
        raise ValueError(f"unknown synthetic path mode: {path_mode}")
    cleaned: list[float] = []
    for price in points:
        if price <= 0:
            continue
        if not cleaned or abs(cleaned[-1] - price) > 1e-12:
            cleaned.append(price)
    return cleaned


def _synthetic_trailing_pct(rows: list[dict], index: int, position: Position, price: float) -> float:
    settings = get_settings()
    return choose_dynamic_trailing_pct(
        replay_exit_momentum_state(rows, index, position, price),
        dynamic_take_profit_enabled=settings.paper_dynamic_take_profit_enabled,
        default_pct=settings.paper_trailing_stop_pct,
        tight_pct=settings.paper_dynamic_trailing_tight_pct,
        normal_pct=settings.paper_dynamic_trailing_normal_pct,
        wide_pct=settings.paper_dynamic_trailing_wide_pct,
    )


def _update_synthetic_trailing(rows: list[dict], index: int, position: Position, price: float) -> None:
    if position.entry_price <= 0:
        return
    trailing_state = advance_trailing_stop(
        entry_price=position.entry_price,
        current_price=price,
        high_watermark=position.high_watermark,
        trailing_stop_price=position.trailing_stop_price,
        activation_price=position.trailing_activation_price,
        activation_pct=get_settings().paper_trailing_activation_pct,
        trailing_pct=_synthetic_trailing_pct(rows, index, position, price),
        break_even_activation_pct=get_settings().paper_break_even_activation_pct,
        break_even_lock_pct=get_settings().paper_break_even_lock_pct,
    )
    position.high_watermark = trailing_state.high_watermark
    position.trailing_active = trailing_state.trailing_active
    position.trailing_stop_price = trailing_state.trailing_stop_price


def apply_synthetic_tick_path(rows: list[dict], index: int, portfolio: Portfolio, path_mode: str) -> bool:
    position = portfolio.position
    if not position:
        return False
    points = synthetic_path_points(rows, index, position, path_mode)
    if len(points) < 2:
        return False
    _update_synthetic_trailing(rows, index, position, points[0])
    for start, end in zip(points, points[1:]):
        if end >= start:
            _update_synthetic_trailing(rows, index, position, end)
            continue
        candidates: list[tuple[float, str]] = []
        hard_stop_price = position.entry_price * (1 - get_settings().paper_max_stop_loss_pct)
        if crossed_down(start, end, hard_stop_price):
            candidates.append((hard_stop_price, "hard_stop_loss"))
        if crossed_down(start, end, position.stop_price):
            candidates.append((position.stop_price, "structure_or_final_stop"))
        trailing_stop = position.trailing_stop_price if position.trailing_active else None
        if crossed_down(start, end, trailing_stop):
            candidates.append((trailing_stop, "trailing_stop_after_profit"))
        if not candidates:
            _update_synthetic_trailing(rows, index, position, end)
            continue
        trigger_price, _reason = max(candidates, key=lambda item: item[0])
        should_close, reason = should_exit(
            rows,
            index,
            position,
            current_price=trigger_price,
            use_bar_high=False,
        )
        if not should_close:
            _update_synthetic_trailing(rows, index, position, end)
            continue
        close_position(
            portfolio,
            rows,
            index,
            reason,
            stop_fill=True,
            stop_price_override=trigger_price,
        )
        portfolio.pending_exit = None
        return True
    return False


def _row_time(row: dict) -> str:
    return str(row.get("timestamp_kst") or "")


def _can_signal_entry(row: dict, next_row: dict, entry_start_time: str | None, entry_end_time: str | None) -> bool:
    current = _row_time(row)
    next_time = _row_time(next_row)
    if entry_start_time and current < entry_start_time:
        return False
    if entry_end_time and (current > entry_end_time or next_time > entry_end_time):
        return False
    return True


def strategy_reentry_allowed(portfolio: Portfolio, index: int, strategy_name: str) -> bool:
    if portfolio.last_exit_index is None:
        return True
    bars_since_exit = index - portfolio.last_exit_index
    if (portfolio.last_exit_net_pnl or 0.0) < 0 and bars_since_exit <= STRATEGY_LOSS_REENTRY_COOLDOWN_BARS:
        return False
    if strategy_name == "Order Flow Imbalance Proxy" and bars_since_exit <= ORDER_FLOW_REENTRY_COOLDOWN_BARS:
        return False
    return True


def symbol_reentry_allowed(portfolios: dict[str, Portfolio], index: int) -> bool:
    loss_indices = [
        portfolio.last_exit_index
        for portfolio in portfolios.values()
        if portfolio.last_exit_index is not None and (portfolio.last_exit_net_pnl or 0.0) < 0
    ]
    if not loss_indices:
        return True
    latest_loss_index = max(loss_indices)
    if index - latest_loss_index <= SYMBOL_LOSS_REENTRY_COOLDOWN_BARS:
        return False
    clustered_losses = [
        loss_index
        for loss_index in loss_indices
        if index - loss_index <= LOSS_CLUSTER_LOOKBACK_BARS
    ]
    if len(clustered_losses) >= LOSS_CLUSTER_MAX_LOSSES and index - max(clustered_losses) <= LOSS_CLUSTER_COOLDOWN_BARS:
        return False
    return True


# ---------------------------------------------------------------------------
# Live-engine entry integration
#
# By default replay detects entries with the standalone signal_* hard gates
# above. To keep replay faithful to what the runtime would actually do, the
# entry decision can instead be delegated to the live EntryPatternEngine
# (weighted score + hard checks). It is fed the same enriched-bar order flow
# through a stub market-data provider, so replay and live share one entry brain.
# Off by default (hard_gate); enable with set_entry_mode("live_engine") or the
# replay_all --entry-engine live_engine flag.
# ---------------------------------------------------------------------------

# "live_engine"        -> EntryPatternEngine on completed bars (DEFAULT, runtime-faithful):
#                         same class the live runtime uses, so replay == runtime entries.
# "hard_gate"          -> standalone signal_* gates (fast ~95% approximation for big sweeps).
# "live_engine_forming"-> EntryPatternEngine on the FORMING bar (intrabar synthetic price path),
#                         decide and fill intrabar. Models the live runtime with
#                         strategy_include_live_forming_candle=True. Price-derived signals react
#                         in real time; volume/flow are frozen at the prior completed bar (N-1)
#                         because they cannot be known mid-bar without tick data (no lookahead).
ENTRY_MODE = "live_engine"
_FORMING_MODES = {"live_engine_forming"}


def set_entry_mode(mode: str) -> None:
    global ENTRY_MODE
    if mode not in ("hard_gate", "live_engine", "live_engine_forming"):
        raise ValueError(f"Unknown entry mode: {mode}")
    ENTRY_MODE = mode


class _LiveFlowStub:
    """Stub market-data provider that returns a caller-set order-flow snapshot."""

    provider_name = "replay_live_stub"

    def __init__(self) -> None:
        self.snapshot: dict[str, dict] = {}

    def order_flow_snapshot(self) -> dict[str, dict]:
        return self.snapshot


class _LiveFlowService:
    def __init__(self, provider: _LiveFlowStub) -> None:
        self.provider = provider


def _live_flow_from_row(symbol: str, row: dict) -> dict:
    """Rebuild the runtime order-flow snapshot from one enriched CSV bar."""
    close = row.get("close")
    bid = row.get("last_bid") or row.get("avg_bid") or row.get("first_bid")
    ask = row.get("last_ask") or row.get("avg_ask") or row.get("first_ask")
    spread_pct = row.get("avg_spread_pct")
    imbalance = row.get("bid_ask_imbalance")
    return {
        "symbol": symbol,
        "quote": {"event_type": "quote", "symbol": symbol, "bid": bid, "ask": ask,
                  "spread_pct": spread_pct, "bid_ask_imbalance": imbalance},
        "trade": {"event_type": "trade", "symbol": symbol, "last": close},
        "spread_pct": spread_pct,
        "bid_ask_imbalance": imbalance,
        "trade_strength": row.get("trade_strength"),
        "sell_pressure": row.get("sell_pressure"),
        "volume_60s": row.get("volume"),
        "notional_1m": row.get("notional_usd"),
        "aggressive_buy_volume": row.get("aggressive_buy_volume") or 0.0,
        "aggressive_sell_volume": row.get("aggressive_sell_volume") or 0.0,
        "last_update_age_sec": 0.0,
    }


class _LiveEngineEntryAdapter:
    """Delegate entry detection to the live EntryPatternEngine, fed enriched flow.

    One evaluate_all call per bar is cached and shared across all strategies, so
    the per-bar cost is paid once even though four detectors query the same bar.
    """

    def __init__(self) -> None:
        from app.services import strategy_engine
        from app.services.risk_manager import RiskManager

        self._engine_module = strategy_engine
        self._risk_manager = RiskManager()
        self._stub = _LiveFlowStub()
        # Point the engine's market-data lookup at the stub.
        strategy_engine.get_market_data_service = lambda: _LiveFlowService(self._stub)
        strategy_engine.record_event = lambda *args, **kwargs: None
        # The engine AND RiskManager both emit an audit event on every evaluation.
        # record_event funnels into shared_state.push_json (a read-append-rewrite of
        # a 2000-item JSON file under .runtime, i.e. O(n) disk IO per call) and the
        # realtime event bus -- in a per-bar offline sweep that was >85% of the wall
        # time and is pure logging with no bearing on the entry decision. Neuter the
        # two IO sinks once, at the choke point, so every record_event caller becomes
        # cheap no matter how it imported record_event. There are NO network/API
        # calls in this path; the cost was all local disk/bus IO.
        from app.services import shared_state as _shared_state
        from app.services.event_bus import event_bus as _event_bus

        _shared_state.push_json = lambda *args, **kwargs: None
        _event_bus.publish = lambda *args, **kwargs: None
        # All four engines rebuild the SAME indicator/flow context from the same
        # candle window on every bar; recomputing MACD/EMA/BB/ATR four times per bar
        # is what makes an offline sweep crawl. Memoise the context for one bar so
        # the four engines share a single computation. Keyed on the last candle's
        # identity (rows[index] persists for the whole window, so no id reuse) plus
        # the window length, both of which are unique per bar.
        original_context = strategy_engine._scalp_strategy_context
        self._context_cache: dict = {"key": None, "value": None}

        def _memoized_context(symbol, candles, risk_preview):
            key = (symbol, len(candles), id(candles[-1]) if candles else None)
            if self._context_cache["key"] != key:
                self._context_cache["key"] = key
                self._context_cache["value"] = original_context(symbol, candles, risk_preview)
            return self._context_cache["value"]

        strategy_engine._scalp_strategy_context = _memoized_context
        self._entry_engine = strategy_engine.EntryPatternEngine()
        self._cache_rows_id: int | None = None
        self._cache: dict[int, dict[str, tuple[bool, str]]] = {}
        self._forming_cache: dict[int, dict[str, tuple[str, float]]] = {}

    def reset_caches(self) -> None:
        """Drop all per-bar caches. Call between sweep configs: the context memo
        (base gates depend on settings) and entry results become stale when a
        threshold changes."""
        self._cache = {}
        self._forming_cache = {}
        self._context_cache = {"key": None, "value": None}
        self._cache_rows_id = None

    def _reset_if_new_window(self, rows: list[dict]) -> None:
        if id(rows) != self._cache_rows_id:
            self._cache_rows_id = id(rows)
            self._cache = {}
            self._forming_cache = {}

    def evaluate(self, name: str, rows: list[dict], index: int) -> tuple[bool, str]:
        self._reset_if_new_window(rows)
        if index not in self._cache:
            self._cache[index] = self._evaluate_bar(rows, index)
        return self._cache[index].get(name, (False, ""))

    def forming_scan(self, rows: list[dict], index: int, path_mode: str) -> dict[str, tuple[str, float]]:
        """Intrabar entry scan on the forming bar N.

        Walks bar N's synthetic price path; at each price point the forming bar's
        price-derived fields (close/high/low, hence EMA/BB/VWAP/MACD/close-near-high)
        update in real time while volume and order flow stay frozen at the prior
        completed bar (N-1) -- those cannot be known mid-bar without tick data, so
        freezing them avoids lookahead. Returns {strategy: (reason, fill_price)} for
        the first intrabar point at which each strategy would enter.
        """
        self._reset_if_new_window(rows)
        if index not in self._forming_cache:
            self._forming_cache[index] = self._forming_scan_bar(rows, index, path_mode)
        return self._forming_cache[index]

    def _forming_scan_bar(self, rows: list[dict], index: int, path_mode: str) -> dict[str, tuple[str, float]]:
        result: dict[str, tuple[str, float]] = {}
        if index < 1:
            return result
        completed = rows[max(0, index - 119): index]
        if len(completed) + 1 < get_settings().strategy_official_min_candles:
            return result
        row = rows[index]
        prior = rows[index - 1]
        symbol = str(row.get("symbol") or "REPLAY").upper()
        # Order flow / volume frozen at the prior completed bar (no lookahead).
        self._stub.snapshot = {symbol: _live_flow_from_row(symbol, prior)}
        frozen_volume = prior.get("volume")
        frozen_notional = prior.get("notional_usd")
        run_high = run_low = None
        for price in _forming_entry_path(rows, index, path_mode):
            run_high = price if run_high is None else max(run_high, price)
            run_low = price if run_low is None else min(run_low, price)
            forming = {
                **row,
                "high": run_high,
                "low": run_low,
                "close": price,
                "volume": frozen_volume,
                "notional_usd": frozen_notional,
            }
            candles = completed + [forming]
            risk = self._risk_manager.preview_long_entry(
                account_equity_usd=get_settings().paper_initial_equity_usd,
                entry_price=price,
                stop_loss_price=price * (1 - 0.004),
            )
            evaluations = self._entry_engine.evaluate_all(
                symbol=symbol, candles=candles, risk_preview=risk.model_dump(), allowed_only=False,
            )
            for item in evaluations:
                if item.entry_allowed and item.strategy_name not in result:
                    fill = _forming_fill_price(row, price)
                    result[item.strategy_name] = (f"live_forming_{item.entry_mode or 'entry'}", fill)
            if len(result) == len(STRATEGIES):
                break
        return result

    def _evaluate_bar(self, rows: list[dict], index: int) -> dict[str, tuple[bool, str]]:
        row = rows[index]
        close = row.get("close")
        if close is None or close <= 0:
            return {}
        candles = rows[max(0, index - 119): index + 1]
        # Below the runtime candle-window minimum the live engine can neither allow
        # an entry (candle_window_ready hard check) nor even build some patterns
        # safely (the <12-candle pattern branch omits keys the scorer reads), so
        # mirror runtime and skip. No entries are lost: entry is impossible here.
        if len(candles) < get_settings().strategy_official_min_candles:
            return {}
        symbol = str(row.get("symbol") or "REPLAY").upper()
        self._stub.snapshot = {symbol: _live_flow_from_row(symbol, row)}
        risk = self._risk_manager.preview_long_entry(
            account_equity_usd=get_settings().paper_initial_equity_usd,
            entry_price=close,
            stop_loss_price=close * (1 - 0.004),
        )
        evaluations = self._entry_engine.evaluate_all(
            symbol=symbol,
            candles=candles,
            risk_preview=risk.model_dump(),
            allowed_only=False,
        )
        result: dict[str, tuple[bool, str]] = {}
        for item in evaluations:
            reason = f"live_{item.entry_mode or 'entry'}_score_{item.final_score:.0f}"
            result[item.strategy_name] = (bool(item.entry_allowed), reason)
        return result


_LIVE_ENTRY_ADAPTER: _LiveEngineEntryAdapter | None = None


def _live_entry_adapter() -> "_LiveEngineEntryAdapter":
    global _LIVE_ENTRY_ADAPTER
    if _LIVE_ENTRY_ADAPTER is None:
        _LIVE_ENTRY_ADAPTER = _LiveEngineEntryAdapter()
    return _LIVE_ENTRY_ADAPTER


def entry_signal(name: str, rows: list[dict], index: int) -> tuple[bool, str]:
    """Completed-bar entry decision for one strategy, dispatched by ENTRY_MODE."""
    if ENTRY_MODE == "live_engine":
        return _live_entry_adapter().evaluate(name, rows, index)
    return STRATEGIES[name](rows, index)


def _forming_entry_path(rows: list[dict], index: int, path_mode: str) -> list[float]:
    """Synthetic intrabar price sequence for entering during bar N."""
    row = rows[index]
    open_price = row.get("open") or row.get("close") or 0.0
    start = (rows[index - 1].get("close") if index > 0 else open_price) or open_price
    low = row.get("low") or open_price
    high = row.get("high") or open_price
    close = row.get("close") or open_price
    if path_mode == "high_first":
        points = [start, high, low, close]
    elif path_mode == "color_path":
        points = [start, low, high, close] if close >= open_price else [start, high, low, close]
    else:  # low_first: runtime-aligned conservative default
        points = [start, low, high, close]
    cleaned: list[float] = []
    for price in points:
        if price and price > 0 and (not cleaned or abs(cleaned[-1] - price) > 1e-12):
            cleaned.append(price)
    return cleaned


def _forming_fill_price(row: dict, price: float) -> float:
    """Intrabar buy fill: synthetic ask at the trigger price plus entry slippage."""
    quote = synthetic_quote_at_price(row, price)
    ask = quote.get("ask") or price
    return ask * (1 + 0.0005)


def replay(
    rows: list[dict],
    *,
    entry_start_time: str | None = None,
    entry_end_time: str | None = None,
) -> dict[str, Portfolio]:
    portfolios = {name: Portfolio(strategy=name) for name in STRATEGIES}
    for index, row in enumerate(rows):
        # Execute pending orders at this bar open.
        for portfolio in portfolios.values():
            if portfolio.pending_exit and portfolio.position:
                close_position(portfolio, rows, index, portfolio.pending_exit)
                portfolio.pending_exit = None
            if portfolio.pending_entry and portfolio.position is None:
                open_position(portfolio, rows, index, portfolio.pending_entry, include_current_stop=False)
                portfolio.pending_entry = None

        # Intrabar replay goes through the synthetic path; high watermark only
        # advances through prices the synthetic tick path actually visits.
        for portfolio in portfolios.values():
            if portfolio.position and apply_synthetic_tick_path(rows, index, portfolio, "low_first"):
                portfolio.pending_exit = None

        if index >= len(rows) - 1:
            continue
        allow_new_entry = _can_signal_entry(row, rows[index + 1], entry_start_time, entry_end_time)

        # Decide at bar close; execute next bar open.
        for name in STRATEGIES:
            portfolio = portfolios[name]
            if portfolio.position:
                should, reason = should_exit(rows, index, portfolio.position)
                if should:
                    portfolio.pending_exit = reason
            elif (
                allow_new_entry
                and not portfolio.pending_entry
                and strategy_reentry_allowed(portfolio, index, name)
                and symbol_reentry_allowed(portfolios, index)
            ):
                ok, reason = entry_signal(name, rows, index)
                if ok:
                    portfolio.pending_entry = {
                        "reason": reason,
                        "strategy": name,
                        "signal_close": row.get("close"),
                        "reference_high": recent_high(rows, index, lookback=18, include_current=False),
                        "indicators": indicator_snapshot(rows, index, name),
                    }

    # Force close at last close/open proxy.
    last_index = len(rows) - 1
    for portfolio in portfolios.values():
        if portfolio.position:
            close_position(portfolio, rows, last_index, "end_of_replay_flatten")
    return portfolios


def replay_synthetic(
    rows: list[dict],
    *,
    path_mode: str = "low_first",
    entry_start_time: str | None = None,
    entry_end_time: str | None = None,
) -> dict[str, Portfolio]:
    portfolios = {name: Portfolio(strategy=name) for name in STRATEGIES}
    for index, row in enumerate(rows):
        for portfolio in portfolios.values():
            if portfolio.pending_exit and portfolio.position:
                close_position(portfolio, rows, index, portfolio.pending_exit)
                portfolio.pending_exit = None
            if portfolio.pending_entry and portfolio.position is None:
                open_position(portfolio, rows, index, portfolio.pending_entry, include_current_stop=False)
                portfolio.pending_entry = None

        for portfolio in portfolios.values():
            if portfolio.position:
                apply_synthetic_tick_path(rows, index, portfolio, path_mode)

        if index >= len(rows) - 1:
            continue
        allow_new_entry = _can_signal_entry(row, rows[index + 1], entry_start_time, entry_end_time)
        forming = ENTRY_MODE in _FORMING_MODES
        forming_hits = _live_entry_adapter().forming_scan(rows, index, path_mode) if forming and allow_new_entry else {}
        for name in STRATEGIES:
            portfolio = portfolios[name]
            if portfolio.position:
                should, reason = should_exit(rows, index, portfolio.position, use_bar_high=False)
                if should:
                    portfolio.pending_exit = reason
            elif (
                allow_new_entry
                and not portfolio.pending_entry
                and strategy_reentry_allowed(portfolio, index, name)
                and symbol_reentry_allowed(portfolios, index)
            ):
                if forming:
                    # Intrabar entry: fill immediately at the synthetic trigger price on bar N.
                    hit = forming_hits.get(name)
                    if hit:
                        reason, fill_price = hit
                        open_position(
                            portfolio,
                            rows,
                            index,
                            {
                                "reason": reason,
                                "strategy": name,
                                "signal_close": row.get("close"),
                                "reference_high": recent_high(rows, index, lookback=18, include_current=False),
                                "indicators": indicator_snapshot(rows, index, name),
                            },
                            include_current_stop=False,
                            fill_price=fill_price,
                        )
                    continue
                ok, reason = entry_signal(name, rows, index)
                if ok:
                    portfolio.pending_entry = {
                        "reason": reason,
                        "strategy": name,
                        "signal_close": row.get("close"),
                        "reference_high": recent_high(rows, index, lookback=18, include_current=False),
                        "indicators": indicator_snapshot(rows, index, name),
                    }

    last_index = len(rows) - 1
    for portfolio in portfolios.values():
        if portfolio.position:
            close_position(portfolio, rows, last_index, "end_of_replay_flatten")
    return portfolios


def summary_row(portfolio: Portfolio) -> dict:
    trades = portfolio.trades
    wins = [trade for trade in trades if trade["net_pnl"] > 0]
    losses = [trade for trade in trades if trade["net_pnl"] < 0]
    gross_profit = sum(trade["net_pnl"] for trade in wins)
    gross_loss = abs(sum(trade["net_pnl"] for trade in losses))
    return {
        "strategy": portfolio.strategy,
        "trades": len(trades),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate_pct": round(len(wins) / len(trades) * 100, 2) if trades else 0.0,
        "net_pnl_usd": round(sum(trade["net_pnl"] for trade in trades), 4),
        "return_on_2000_pct": round(sum(trade["net_pnl"] for trade in trades) / INITIAL_EQUITY * 100, 4),
        "avg_win_usd": round(mean([trade["net_pnl"] for trade in wins]), 4) if wins else 0.0,
        "avg_loss_usd": round(mean([trade["net_pnl"] for trade in losses]), 4) if losses else 0.0,
        "profit_factor": round(gross_profit / gross_loss, 4) if gross_loss else (999.0 if gross_profit > 0 else 0.0),
        "max_win_usd": round(max([trade["net_pnl"] for trade in trades], default=0.0), 4),
        "max_loss_usd": round(min([trade["net_pnl"] for trade in losses], default=0.0), 4),
    }


def write_outputs(portfolios: dict[str, Portfolio], summary_path: Path, trades_path: Path) -> None:
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summaries = [summary_row(portfolio) for portfolio in portfolios.values()]
    with summary_path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=list(summaries[0].keys()))
        writer.writeheader()
        writer.writerows(summaries)
    trade_rows = [trade for portfolio in portfolios.values() for trade in portfolio.trades]
    if trade_rows:
        with trades_path.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=list(trade_rows[0].keys()))
            writer.writeheader()
            writer.writerows(trade_rows)


def main() -> None:
    enriched_source = Path("exports/tc_1m_enriched_2026-07-01_1720-1900_kst.csv")
    fallback_source = Path("exports/tc_1m_2026-07-01_1720-1900_kst.csv")
    source = enriched_source if enriched_source.exists() else fallback_source
    summary = Path("exports/tc_shadow_replay_summary_2026-07-01_1720-1900_kst.csv")
    trades = Path("exports/tc_shadow_replay_trades_2026-07-01_1720-1900_kst.csv")
    rows = load_rows(source)
    portfolios = replay(rows)
    write_outputs(portfolios, summary, trades)
    using_enriched = any(row.get("avg_bid") is not None and row.get("avg_ask") is not None for row in rows)
    result = {
        "source": str(source),
        "summary": str(summary),
        "trades": str(trades),
        "rows": len(rows),
        "assumptions": {
            "execution": "signal at bar close, fill next bar first quote; intrabar stop uses low touch first",
            "spread": (
                "historical Alpaca quotes: buy at first_ask, normal sell at first_bid, stop exits use min_bid; "
                "spread does not hard-block entries; it raises the required dynamic target and entry expectancy threshold"
                if using_enriched
                else "bar proxy: max(0.20%, min(2.00%, range_pct * 8%)) because historical quotes are not in this CSV"
            ),
            "trade_direction": (
                "historical Alpaca trades matched to latest quote; ask-side trades count as aggressive buy, bid-side trades as aggressive sell"
                if using_enriched
                else "not available; bar proxy only"
            ),
            "slippage": "entry 0.05%, normal exit 0.08%, stop exit 0.15%",
            "fees": {
                "commission_pct_each_side": COMMISSION_PCT,
                "sec_fee_pct_sell": SEC_FEE_PCT,
                "taf_fee_per_share_sell": TAF_FEE_PER_SHARE,
            },
            "notional_per_trade_usd": MAX_NOTIONAL_PER_TRADE,
        },
        "summary_rows": [summary_row(portfolio) for portfolio in portfolios.values()],
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
