from uuid import uuid4

from app.core.config import Settings
from app.services import live_broker as live_module
from app.services.live_broker import LiveBroker


class FakeTossClient:
    def __init__(self) -> None:
        self.created: list[dict] = []
        self.details: dict[str, dict] = {}
        self.sellable = 10.0

    def live_order_enabled(self) -> bool:
        return True

    def create_order(self, **kwargs) -> dict:
        order_id = f"order-{len(self.created) + 1}"
        self.created.append({**kwargs, "order_id": order_id})
        return {"orderId": order_id, "clientOrderId": kwargs.get("client_order_id")}

    def order_detail(self, *, order_id: str, account_seq: int | None = None) -> dict:
        return self.details[order_id]

    def cancel_order(self, *, order_id: str, account_seq: int | None = None) -> dict:
        detail = self.details.get(order_id, {})
        detail["status"] = "CANCELED"
        self.details[order_id] = detail
        return {"orderId": order_id}

    def sellable_quantity(self, *, symbol: str, account_seq: int | None = None) -> dict:
        return {"sellableQuantity": str(self.sellable)}


def _settings(**overrides) -> Settings:
    base = {
        "toss_app_key": "app-key",
        "toss_app_secret": "app-secret",
        "trading_mode": "live",
        "live_enabled": True,
        "toss_environment": "live",
        "toss_live_order_enabled": True,
        "toss_live_auto_trade_enabled": True,
        "toss_live_max_quantity": 1.0,
        "toss_live_max_order_notional_usd": 25.0,
        "toss_live_max_open_positions": 2,
        "toss_live_max_total_exposure_usd": 50.0,
        "toss_live_cancel_stale_orders_enabled": False,
        "toss_live_emergency_stop_enabled": False,
    }
    base.update(overrides)
    return Settings(**base)


def _fresh_broker(monkeypatch, client: FakeTossClient, settings: Settings | None = None) -> LiveBroker:
    monkeypatch.setattr(live_module, "LIVE_STATE_KEY", f"test:live:{uuid4()}")
    live_module._orders.clear()
    live_module._positions.clear()
    live_module._timeline.clear()
    live_module._fills.clear()
    live_module._closed_trades.clear()
    live_module._health.clear()
    live_module._health.update({"consecutive_errors": 0})
    live_module._emergency_stop = False
    live_module._shared_state_updated_at = None
    return LiveBroker(settings=settings or _settings(), client=client)


def _entry_snapshot(parameter_set_id: str = "test-strategy") -> dict:
    return {
        "strategy_name": "Test Strategy",
        "parameter_set_id": parameter_set_id,
        "entry_mode": "test",
    }


def _exit_plan(entry_price: float = 10.0) -> dict:
    return {
        "stop_loss_price": entry_price * 0.98,
        "take_profit_price": entry_price * 1.02,
        "dynamic_take_profit_price": entry_price * 1.02,
        "partial_take_profit_price": entry_price * 1.01,
        "trailing_activation_price": entry_price * 1.005,
        "trailing_stop_price": None,
    }


def _detail(*, side: str, status: str, quantity: float, avg_price: float | None, commission: float = 0.0, tax: float = 0.0) -> dict:
    return {
        "orderId": "order-1",
        "symbol": "PATH",
        "side": side.upper(),
        "orderType": "MARKET",
        "timeInForce": "DAY",
        "status": status,
        "quantity": str(quantity),
        "currency": "USD",
        "orderedAt": "2026-07-11T04:00:00+09:00",
        "execution": {
            "filledQuantity": str(quantity if avg_price is not None else 0),
            "averageFilledPrice": None if avg_price is None else str(avg_price),
            "filledAmount": None if avg_price is None else str(quantity * avg_price),
            "commission": str(commission) if commission else None,
            "tax": str(tax) if tax else None,
            "filledAt": "2026-07-11T04:00:01+09:00" if avg_price is not None else None,
            "settlementDate": "2026-07-14" if avg_price is not None else None,
        },
    }


def test_live_broker_entry_fill_opens_position(monkeypatch) -> None:
    client = FakeTossClient()
    broker = _fresh_broker(monkeypatch, client)
    client.details["order-1"] = _detail(side="buy", status="FILLED", quantity=1, avg_price=10.0, commission=0.01)

    broker.submit_entry_order(
        symbol="PATH",
        quantity=1,
        market_snapshot={"ask": 10.0, "entry_snapshot": _entry_snapshot(), "exit_plan": _exit_plan(10.0)},
        strategy_signal_id="test-strategy-PATH-bucket",
    )

    state = broker.state()
    assert state["orders"][0]["state"] == "FILLED"
    assert state["positions"][0]["symbol"] == "PATH"
    assert state["positions"][0]["quantity"] == 1
    assert state["positions"][0]["entry_fees_usd"] == 0.01


def test_live_broker_blocks_duplicate_symbol_strategy_exposure(monkeypatch) -> None:
    client = FakeTossClient()
    broker = _fresh_broker(monkeypatch, client)
    snapshot = {"ask": 10.0, "entry_snapshot": _entry_snapshot("dup"), "exit_plan": _exit_plan(10.0)}
    client.details["order-1"] = _detail(side="buy", status="FILLED", quantity=1, avg_price=10.0, commission=0.01)
    broker.submit_entry_order(symbol="PATH", quantity=1, market_snapshot=snapshot, strategy_signal_id="dup-1")

    result = broker.submit_entry_order(symbol="PATH", quantity=1, market_snapshot=snapshot, strategy_signal_id="dup-2")

    assert result["blocked"] is True
    assert result["reason"] == "duplicate_symbol_strategy_exposure"
    assert len(client.created) == 1


def test_live_broker_enforces_total_exposure_cap(monkeypatch) -> None:
    client = FakeTossClient()
    broker = _fresh_broker(monkeypatch, client, _settings(toss_live_max_total_exposure_usd=9.0))

    result = broker.submit_entry_order(
        symbol="PATH",
        quantity=1,
        market_snapshot={"ask": 10.0, "entry_snapshot": _entry_snapshot(), "exit_plan": _exit_plan(10.0)},
        strategy_signal_id="cap-1",
    )

    assert result["blocked"] is True
    assert result["reason"] == "max_total_exposure_exceeded"
    assert client.created == []


def test_live_broker_reconcile_applies_partial_fill_delta_once(monkeypatch) -> None:
    client = FakeTossClient()
    broker = _fresh_broker(monkeypatch, client)
    snapshot = {"ask": 10.0, "entry_snapshot": _entry_snapshot("partial"), "exit_plan": _exit_plan(10.0)}
    client.details["order-1"] = _detail(side="buy", status="PARTIAL_FILLED", quantity=0.5, avg_price=10.0, commission=0.01)

    broker.submit_entry_order(symbol="PATH", quantity=1, market_snapshot=snapshot, strategy_signal_id="partial-1")
    client.details["order-1"] = _detail(side="buy", status="FILLED", quantity=1, avg_price=10.2, commission=0.02)
    broker.reconcile_order("order-1")
    broker.reconcile_order("order-1")

    state = broker.state()
    assert len(state["fills"]) == 2
    assert state["positions"][0]["quantity"] == 1
    assert round(state["positions"][0]["average_price"], 4) == 10.2
    assert state["positions"][0]["entry_fees_usd"] == 0.02


def test_live_broker_exit_fill_closes_position_and_records_net_pnl(monkeypatch) -> None:
    client = FakeTossClient()
    broker = _fresh_broker(monkeypatch, client)
    client.details["order-1"] = _detail(side="buy", status="FILLED", quantity=1, avg_price=10.0, commission=0.01)
    broker.submit_entry_order(
        symbol="PATH",
        quantity=1,
        market_snapshot={"ask": 10.0, "entry_snapshot": _entry_snapshot(), "exit_plan": _exit_plan(10.0)},
        strategy_signal_id="exit-setup",
    )
    position = broker.position("PATH", parameter_set_id="test-strategy")
    assert position is not None
    client.details["order-2"] = _detail(side="sell", status="FILLED", quantity=1, avg_price=11.0, commission=0.01, tax=0.01)

    broker.submit_exit_order(position=position, quantity=1, reason="take_profit", market_snapshot={"bid": 11.0})

    state = broker.state()
    assert state["positions"] == []
    assert len(state["closed_trades"]) == 1
    assert round(state["closed_trades"][0]["net_pnl_usd"], 4) == 0.97


def test_live_broker_emergency_stop_blocks_new_entries(monkeypatch) -> None:
    client = FakeTossClient()
    broker = _fresh_broker(monkeypatch, client)

    broker.activate_emergency_stop(reason="test")
    result = broker.submit_entry_order(
        symbol="PATH",
        quantity=1,
        market_snapshot={"ask": 10.0, "entry_snapshot": _entry_snapshot(), "exit_plan": _exit_plan(10.0)},
        strategy_signal_id="blocked",
    )

    assert result["blocked"] is True
    assert result["reason"] == "emergency_stop_active"
    assert client.created == []
