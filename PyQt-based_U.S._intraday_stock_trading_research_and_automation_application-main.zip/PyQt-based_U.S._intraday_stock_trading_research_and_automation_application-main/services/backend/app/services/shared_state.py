from __future__ import annotations

import asyncio
import hashlib
import json
import uuid
from pathlib import Path
from time import time
from typing import Any, Awaitable, Callable

import redis
import redis.asyncio as aioredis

from app.core.config import get_settings

PROCESS_ID = str(uuid.uuid4())
RUNTIME_STATE_DIR = Path(__file__).resolve().parents[4] / ".runtime" / "shared_state"
_REDIS_RETRY_AFTER = 0.0
REDIS_RETRY_INTERVAL_SEC = 30.0


def _url() -> str:
    return get_settings().redis_url


def client() -> redis.Redis:
    return redis.Redis.from_url(_url(), decode_responses=True, socket_timeout=0.2, socket_connect_timeout=0.2)


def available() -> bool:
    if not _redis_attempt_allowed():
        return _fallback_available()
    try:
        return bool(client().ping())
    except Exception:
        _mark_redis_unavailable()
        return _fallback_available()


def set_json(key: str, value: Any, *, ex: int | None = None) -> bool:
    if not _redis_attempt_allowed():
        return _fallback_set_json(key, value, ex=ex)
    try:
        client().set(key, json.dumps(value, ensure_ascii=False, default=str), ex=ex)
        return True
    except Exception:
        _mark_redis_unavailable()
        return _fallback_set_json(key, value, ex=ex)


def get_json(key: str) -> Any | None:
    if not _redis_attempt_allowed():
        return _fallback_get_json(key)
    try:
        raw = client().get(key)
    except Exception:
        _mark_redis_unavailable()
        return _fallback_get_json(key)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except ValueError:
        return _fallback_get_json(key)


def get_json_any(*keys: str) -> Any | None:
    for key in keys:
        value = get_json(key)
        if value is not None:
            return value
    return None


def push_json(key: str, value: Any, *, max_items: int) -> bool:
    if not _redis_attempt_allowed():
        return _fallback_push_json(key, value, max_items=max_items)
    try:
        pipe = client().pipeline()
        pipe.rpush(key, json.dumps(value, ensure_ascii=False, default=str))
        pipe.ltrim(key, -max_items, -1)
        pipe.execute()
        return True
    except Exception:
        _mark_redis_unavailable()
        return _fallback_push_json(key, value, max_items=max_items)


def list_json(key: str, *, limit: int) -> list[Any]:
    if not _redis_attempt_allowed():
        return _fallback_list_json(key, limit=limit)
    try:
        rows = client().lrange(key, max(-limit, -10000), -1)
    except Exception:
        _mark_redis_unavailable()
        return _fallback_list_json(key, limit=limit)
    parsed: list[Any] = []
    for row in rows:
        try:
            parsed.append(json.loads(row))
        except ValueError:
            continue
    return parsed


def list_json_any(*keys: str, limit: int) -> list[Any]:
    for key in keys:
        rows = list_json(key, limit=limit)
        if rows:
            return rows
    return []


def acquire_lock(key: str, *, ttl_sec: float) -> str | None:
    """Best-effort cross-process lock. Returns an owner id on success, else None.

    Uses Redis SET NX when available. The file fallback is not perfectly atomic but still
    prevents most concurrent acquisitions across processes on the same host.
    """
    lock_id = str(uuid.uuid4())
    if not _redis_attempt_allowed():
        return lock_id if _fallback_acquire_lock(key, lock_id, ttl_sec) else None
    try:
        acquired = client().set(key, lock_id, nx=True, ex=max(1, int(ttl_sec)))
        return lock_id if acquired else None
    except Exception:
        _mark_redis_unavailable()
        return lock_id if _fallback_acquire_lock(key, lock_id, ttl_sec) else None


def release_lock(key: str, lock_id: str) -> None:
    if not _redis_attempt_allowed():
        _fallback_release_lock(key, lock_id)
        return
    try:
        conn = client()
        if conn.get(key) == lock_id:
            conn.delete(key)
    except Exception:
        _mark_redis_unavailable()
        _fallback_release_lock(key, lock_id)


def _fallback_acquire_lock(key: str, lock_id: str, ttl_sec: float) -> bool:
    existing = _fallback_get_json(key)
    if existing is not None:
        return False
    return _fallback_set_json(key, lock_id, ex=int(max(1, ttl_sec)))


def _fallback_release_lock(key: str, lock_id: str) -> None:
    if _fallback_get_json(key) == lock_id:
        try:
            _fallback_path(key).unlink(missing_ok=True)
        except Exception:
            pass


def publish_json(channel: str, value: Any) -> bool:
    if not _redis_attempt_allowed():
        return False
    try:
        client().publish(channel, json.dumps(value, ensure_ascii=False, default=str))
        return True
    except Exception:
        _mark_redis_unavailable()
        return False


async def subscribe_json(channel: str, handler: Callable[[dict], Awaitable[None]]) -> None:
    if not _redis_attempt_allowed():
        await asyncio.sleep(2.0)
        return
    redis_client = aioredis.Redis.from_url(_url(), decode_responses=True, socket_timeout=5.0, socket_connect_timeout=0.2)
    pubsub = redis_client.pubsub()
    await pubsub.subscribe(channel)
    try:
        async for message in pubsub.listen():
            if message.get("type") != "message":
                continue
            try:
                payload = json.loads(message.get("data") or "{}")
            except ValueError:
                continue
            await handler(payload)
            await asyncio.sleep(0)
    finally:
        await pubsub.unsubscribe(channel)
        await pubsub.close()
        await redis_client.aclose()


def _redis_attempt_allowed() -> bool:
    return time() >= _REDIS_RETRY_AFTER


def _mark_redis_unavailable() -> None:
    global _REDIS_RETRY_AFTER
    _REDIS_RETRY_AFTER = time() + REDIS_RETRY_INTERVAL_SEC


def _fallback_available() -> bool:
    try:
        RUNTIME_STATE_DIR.mkdir(parents=True, exist_ok=True)
        probe = RUNTIME_STATE_DIR / ".probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def _fallback_path(key: str) -> Path:
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
    return RUNTIME_STATE_DIR / f"{digest}.json"


def _fallback_set_json(key: str, value: Any, *, ex: int | None = None) -> bool:
    try:
        RUNTIME_STATE_DIR.mkdir(parents=True, exist_ok=True)
        payload = {
            "key": key,
            "expires_at": time() + ex if ex else None,
            "value": value,
        }
        _fallback_path(key).write_text(json.dumps(payload, ensure_ascii=False, default=str), encoding="utf-8")
        return True
    except Exception:
        return False


def _fallback_get_json(key: str) -> Any | None:
    path = _fallback_path(key)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    expires_at = payload.get("expires_at")
    if expires_at is not None and float(expires_at) <= time():
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass
        return None
    return payload.get("value")


def _fallback_push_json(key: str, value: Any, *, max_items: int) -> bool:
    rows = _fallback_list_json(key, limit=max_items)
    rows.append(value)
    rows = rows[-max_items:]
    return _fallback_set_json(key, rows)


def _fallback_list_json(key: str, *, limit: int) -> list[Any]:
    value = _fallback_get_json(key)
    if not isinstance(value, list):
        return []
    return value[-limit:]
