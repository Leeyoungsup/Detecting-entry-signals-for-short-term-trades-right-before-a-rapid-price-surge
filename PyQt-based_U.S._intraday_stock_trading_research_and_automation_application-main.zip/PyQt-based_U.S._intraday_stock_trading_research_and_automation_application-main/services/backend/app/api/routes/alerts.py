from fastapi import APIRouter

from app.core.config import get_settings

router = APIRouter()


@router.get("")
def alerts() -> dict:
    settings = get_settings()
    if settings.trading_mode == "live" and settings.live_enabled:
        title = "Live 자동 주문 활성" if settings.toss_live_auto_trade_enabled else "Live 주문 게이트 대기"
        message = (
            "전략 신호 통과 시 Toss live 주문을 제출하며, 종목/수량/노출 cap과 emergency stop을 적용합니다."
            if settings.toss_live_auto_trade_enabled
            else "Live 모드이지만 자동 전략 주문 게이트가 꺼져 있습니다."
        )
        severity = "CAUTION" if settings.toss_live_auto_trade_enabled else "BLOCKED"
    else:
        title = "Live 주문 비활성화"
        message = "현재는 backtest 또는 paper 흐름만 활성화되어 있습니다."
        severity = "BLOCKED"

    return {
        "alerts": [
            {
                "severity": severity,
                "title": title,
                "message": message,
                "source": "live_order_gate",
                "acknowledged": False,
            }
        ]
    }
