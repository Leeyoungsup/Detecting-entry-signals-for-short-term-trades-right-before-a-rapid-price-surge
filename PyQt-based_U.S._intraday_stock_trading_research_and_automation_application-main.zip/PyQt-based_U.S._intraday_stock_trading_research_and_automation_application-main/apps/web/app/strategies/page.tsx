"use client";

import {
  Activity,
  BarChart3,
  CheckCircle2,
  CircleDashed,
  Gauge,
  LineChart,
  Settings2,
  Signal,
  TrendingUp,
  XCircle,
} from "lucide-react";
import { LiveStatus } from "@/components/live-status";
import { PageTitle } from "@/components/page-title";
import { StatusPill } from "@/components/status-pill";
import { useLiveResource, type RealtimeEnvelope } from "@/lib/use-live-resource";

type StrategyBreakdown = {
  strategy_name: string;
  signals: number;
  rejects: number;
  trades: number;
  wins: number;
  losses: number;
  net_pnl_usd: number;
  notional_usd: number;
  win_rate_pct: number | null;
  return_pct: number | null;
  profit_factor: number | null;
  avg_score: number | null;
  expectancy_usd: number | null;
};

type ActiveStrategy = {
  strategy_name: string;
  parameter_set_id?: string;
  role: string;
  enabled: boolean;
};

type StrategyConditionRow = {
  strategy_name: string;
  symbol?: string | null;
  entry_allowed: boolean;
  reject_reason?: string | null;
  conditions: Record<string, boolean>;
};

type Strategy = {
  strategy_name: string;
  strategy_version: string;
  parameter_set_id: string;
  enabled: boolean;
  watching_symbols: number;
  ws_candle_symbols: number;
  ws_candle_counts: Record<string, number>;
  signals_today: number;
  rejects_today: number;
  orders_submitted: number;
  fills: number;
  win_loss: string;
  net_pnl_usd: number;
  expectancy: number | null;
  latest_symbol?: string | null;
  latest_reject_reason?: string | null;
  latest_conditions?: Record<string, boolean>;
  strategy_conditions?: StrategyConditionRow[];
  pattern_status?: Record<string, unknown>;
  lower_band_status?: Record<string, unknown>;
  last_runtime_evaluation?: Record<string, string>;
  strategy_breakdown?: StrategyBreakdown[];
  active_strategies?: ActiveStrategy[];
  auxiliary_strategies?: ActiveStrategy[];
};

type StrategyData = { strategies: Strategy[] };

const fallback: StrategyData = { strategies: [] };

export default function StrategiesPage() {
  const { data, connected, eventAt, updatedAt } = useLiveResource<StrategyData>({
    path: "/strategies",
    fallback,
    shouldReload: strategiesShouldReload,
    minIntervalMs: 1000,
  });
  const strategy = data.strategies[0];
  const activeStrategies = strategy?.active_strategies ?? strategy?.auxiliary_strategies ?? [];

  return (
    <>
      <PageTitle
        title="Strategy Router"
        description="Monitor active entry strategies, entry conditions, pattern state, risk, and live/simulation trade results."
        icon={<Signal className="h-5 w-5" aria-hidden />}
        action={<LiveStatus connected={connected} eventAt={eventAt} updatedAt={updatedAt} />}
      />

      <section className="space-y-5 p-6">
        {!strategy ? (
          <div className="rounded border border-line bg-white p-8 text-center text-sm text-zinc-500">
            Strategy data is not available.
          </div>
        ) : (
          <>
            <StrategyHeader strategy={strategy} />
            <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_440px]">
              <main className="space-y-5">
                <OverviewGrid strategy={strategy} />
                <StrategyBreakdownTable rows={strategy.strategy_breakdown ?? []} />
                {(strategy.strategy_conditions?.length ?? 0) > 0 ? (
                  <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                    {strategy.strategy_conditions!.map((row) => (
                      <ConditionsPanel key={row.strategy_name} row={row} />
                    ))}
                  </div>
                ) : (
                  <div className="rounded border border-line bg-white p-8 text-center text-sm text-zinc-500">
                    아직 평가된 전략 조건이 없습니다.
                  </div>
                )}
                <PatternPanel
                  pattern={strategy.pattern_status ?? {}}
                  lowerBand={strategy.lower_band_status ?? {}}
                />
                <RuntimePanel strategy={strategy} />
              </main>
              <aside className="space-y-5">
                <ActiveStrategiesPanel strategies={activeStrategies} />
              </aside>
            </div>
          </>
        )}
      </section>
    </>
  );
}

function strategiesShouldReload(event: RealtimeEnvelope) {
  if (event.event_type !== "log.event") return false;
  return [
    "strategy.signal_evaluation",
    "risk.decision",
    "live.order_candidate",
    "live.order_blocked",
    "paper.order_event",
    "paper.exit_signal",
    "paper.exit_blocked",
    "scanner.snapshot",
  ].includes(String(event.payload?.event_type ?? ""));
}

function StrategyHeader({ strategy }: { strategy: Strategy }) {
  return (
    <section className="rounded border border-line bg-white">
      <div className="flex flex-col gap-5 border-b border-line px-5 py-5 xl:flex-row xl:items-end xl:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-2xl font-bold tracking-normal text-ink">{strategy.strategy_name}</h1>
            <StatusPill status={strategy.enabled ? "NORMAL" : "BLOCKED"} />
          </div>
          <p className="mt-2 text-sm text-zinc-500">
            v{strategy.strategy_version} / {strategy.parameter_set_id} / runtime synced
          </p>
        </div>
        <div className="grid gap-2 sm:grid-cols-3 xl:min-w-[520px]">
          <HeaderStat label="Latest Symbol" value={strategy.latest_symbol ?? "-"} />
          <HeaderStat label="조건 통과" value={conditionsSummary(strategy.latest_conditions)} />
          <HeaderStat label="Latest Reject" value={strategy.latest_reject_reason ?? "None"} />
        </div>
      </div>
      <div className="grid gap-px bg-line sm:grid-cols-2">
        <MiniStatus icon={<Signal className="h-4 w-4" />} label="Watching" value={`${strategy.watching_symbols}`} />
        <MiniStatus icon={<BarChart3 className="h-4 w-4" />} label="Candle Symbols" value={`${strategy.ws_candle_symbols}`} />
      </div>
    </section>
  );
}

function HeaderStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border border-line bg-zinc-50 px-3 py-2">
      <div className="text-xs font-medium text-zinc-500">{label}</div>
      <div className="mt-1 truncate text-sm font-bold text-ink">{value}</div>
    </div>
  );
}

function MiniStatus({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-white px-5 py-3">
      <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
        <span className="text-info">{icon}</span>
        {label}
      </div>
      <div className="mt-1 text-lg font-bold text-ink">{value}</div>
    </div>
  );
}

function OverviewGrid({ strategy }: { strategy: Strategy }) {
  const cards = [
    { label: "Signals", value: strategy.signals_today, icon: <Signal className="h-5 w-5" />, tone: "info" },
    { label: "Rejects", value: strategy.rejects_today, icon: <XCircle className="h-5 w-5" />, tone: "warn" },
    { label: "Fills", value: strategy.fills, icon: <CheckCircle2 className="h-5 w-5" />, tone: "ok" },
    { label: "Win / Loss", value: strategy.win_loss, icon: <TrendingUp className="h-5 w-5" />, tone: "info" },
    { label: "Net PnL", value: formatUsd(strategy.net_pnl_usd), icon: <Gauge className="h-5 w-5" />, tone: strategy.net_pnl_usd >= 0 ? "ok" : "block" },
    { label: "Expectancy", value: strategy.expectancy == null ? "-" : strategy.expectancy.toFixed(4), icon: <Activity className="h-5 w-5" />, tone: "info" },
  ];
  return (
    <div className="grid gap-3 md:grid-cols-3">
      {cards.map((card) => (
        <div key={card.label} className="rounded border border-line bg-white p-4">
          <div className="flex items-center justify-between gap-3">
            <div className="text-xs font-medium text-zinc-500">{card.label}</div>
            <span className={toneText(card.tone)}>{card.icon}</span>
          </div>
          <div className="mt-3 text-2xl font-bold text-ink">{card.value}</div>
        </div>
      ))}
    </div>
  );
}

function ConditionsPanel({ row }: { row: StrategyConditionRow }) {
  const entries = Object.entries(row.conditions);
  const passed = entries.filter(([, ok]) => ok).length;

  return (
    <section className="rounded border border-line bg-white">
      <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-4">
        <div className="min-w-0">
          <h3 className="truncate text-sm font-semibold text-ink">{row.strategy_name}</h3>
          <div className="mt-0.5 truncate text-xs text-zinc-500">최근 평가{row.symbol ? ` · ${row.symbol}` : ""}</div>
        </div>
        <span className={row.entry_allowed ? "shrink-0 rounded bg-emerald-50 px-2 py-1 text-xs font-bold text-ok ring-1 ring-emerald-100" : "shrink-0 rounded bg-amber-50 px-2 py-1 text-xs font-bold text-warn ring-1 ring-amber-100"}>
          {row.entry_allowed ? "진입 가능" : "대기"}
        </span>
      </div>
      <div className="p-5">
        <div className="flex items-end justify-between gap-3">
          <div className="text-3xl font-bold text-ink">
            {entries.length ? `${passed}/${entries.length}` : "-"}
            <span className="ml-1 text-sm font-medium text-zinc-500">조건 통과</span>
          </div>
          <div className="shrink-0 text-right text-xs text-zinc-400">전 조건 통과 시 진입 (AND)</div>
        </div>
        <div className="mt-4 space-y-2">
          {entries.length ? entries.map(([key, ok]) => (
            <div key={key} className="flex items-center justify-between gap-3 text-sm">
              <span className={ok ? "text-ink" : "text-zinc-500"}>{labelForKey(key)}</span>
              <span className={ok ? "font-semibold text-ok" : "font-semibold text-warn"}>{ok ? "통과" : "실패"}</span>
            </div>
          )) : <div className="text-sm text-zinc-500">아직 평가된 조건이 없습니다.</div>}
        </div>
      </div>
    </section>
  );
}

function PatternPanel({ pattern, lowerBand }: { pattern: Record<string, unknown>; lowerBand: Record<string, unknown> }) {
  const rows = Object.entries({ ...pattern, ...lowerBand })
    .slice(0, 10)
    .map(([key, value]): [string, unknown] => [labelForKey(key), formatPatternValue(key, value)]);

  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="Pattern State" icon={<LineChart className="h-5 w-5 text-info" />} />
      <div className="grid gap-px bg-line sm:grid-cols-2">
        {rows.length ? rows.map(([label, value]) => (
          <StateTile key={label} label={String(label)} value={value} />
        )) : <div className="bg-white p-5 text-sm text-zinc-500 sm:col-span-2">No pattern state yet.</div>}
      </div>
    </section>
  );
}

function ActiveStrategiesPanel({ strategies }: { strategies: ActiveStrategy[] }) {
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="Active Strategies" icon={<Signal className="h-5 w-5 text-info" />} />
      <div className="divide-y divide-line">
        {strategies.length ? strategies.map((strategy) => (
          <div key={strategy.strategy_name} className="p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="font-semibold text-ink">{strategy.strategy_name}</div>
                <div className="mt-1 text-xs text-zinc-500">{strategy.parameter_set_id ?? "runtime strategy"}</div>
              </div>
              <StatusPill status={strategy.enabled ? "NORMAL" : "BLOCKED"} />
            </div>
            <p className="mt-3 text-sm text-zinc-500">{strategy.role}</p>
          </div>
        )) : (
          <div className="p-5 text-sm text-zinc-500">No active strategies configured.</div>
        )}
      </div>
    </section>
  );
}

function StateTile({ label, value }: { label: string; value: unknown }) {
  const isBool = typeof value === "boolean";
  return (
    <div className="bg-white p-4">
      <div className="text-xs font-medium text-zinc-500">{label}</div>
      <div className="mt-2 flex items-center gap-2 text-sm font-bold text-ink">
        {isBool ? (
          value ? <CheckCircle2 className="h-4 w-4 text-ok" /> : <CircleDashed className="h-4 w-4 text-zinc-400" />
        ) : null}
        {formatUnknown(value)}
      </div>
    </div>
  );
}

function RuntimePanel({ strategy }: { strategy: Strategy }) {
  const candleRows = Object.entries(strategy.ws_candle_counts ?? {}).slice(0, 12);
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="Runtime State" icon={<Settings2 className="h-5 w-5 text-info" />} />
      <div className="grid gap-px bg-line md:grid-cols-2">
        <div className="bg-white p-5">
          <div className="text-sm font-semibold text-ink">Candle Window</div>
          <div className="mt-3 space-y-2">
            {candleRows.length ? candleRows.map(([symbol, count]) => (
              <div key={symbol} className="flex items-center justify-between rounded bg-zinc-50 px-3 py-2 text-sm">
                <span className="font-semibold text-ink">{symbol}</span>
                <span className="text-zinc-500">{count}</span>
              </div>
            )) : <div className="text-sm text-zinc-500">No candle window yet.</div>}
          </div>
        </div>
        <div className="bg-white p-5">
          <div className="text-sm font-semibold text-ink">Last Evaluation Bucket</div>
          <div className="mt-3 space-y-2">
            {Object.entries(strategy.last_runtime_evaluation ?? {}).slice(0, 12).map(([symbol, bucket]) => (
              <div key={symbol} className="flex items-center justify-between rounded bg-zinc-50 px-3 py-2 text-sm">
                <span className="font-semibold text-ink">{symbol}</span>
                <span className="text-zinc-500">{String(bucket)}</span>
              </div>
            ))}
            {!Object.keys(strategy.last_runtime_evaluation ?? {}).length ? <div className="text-sm text-zinc-500">No recent evaluation.</div> : null}
          </div>
        </div>
      </div>
    </section>
  );
}

function StrategyBreakdownTable({ rows }: { rows: StrategyBreakdown[] }) {
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="Strategy Result" icon={<BarChart3 className="h-5 w-5 text-info" />} />
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-zinc-50 text-xs text-zinc-500">
            <tr>
              <th className="px-4 py-3 text-left font-semibold">Strategy</th>
              <th className="px-4 py-3 text-right font-semibold">Signals</th>
              <th className="px-4 py-3 text-right font-semibold">Rejects</th>
              <th className="px-4 py-3 text-right font-semibold">Trades</th>
              <th className="px-4 py-3 text-right font-semibold">W/L</th>
              <th className="px-4 py-3 text-right font-semibold">Win Rate</th>
              <th className="px-4 py-3 text-right font-semibold">Net PnL</th>
              <th className="px-4 py-3 text-right font-semibold">Return</th>
              <th className="px-4 py-3 text-right font-semibold">PF</th>
              <th className="px-4 py-3 text-right font-semibold">Avg Score</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {rows.length ? rows.map((row) => (
              <tr key={row.strategy_name} className="hover:bg-zinc-50">
                <td className="whitespace-nowrap px-4 py-3 font-semibold text-ink">{row.strategy_name}</td>
                <td className="px-4 py-3 text-right text-zinc-600">{row.signals}</td>
                <td className="px-4 py-3 text-right text-zinc-600">{row.rejects}</td>
                <td className="px-4 py-3 text-right text-zinc-600">{row.trades}</td>
                <td className="px-4 py-3 text-right text-zinc-600">{row.wins}/{row.losses}</td>
                <td className="px-4 py-3 text-right text-zinc-600">{formatPct(row.win_rate_pct)}</td>
                <td className={`px-4 py-3 text-right font-semibold ${row.net_pnl_usd >= 0 ? "text-ok" : "text-block"}`}>{formatUsd(row.net_pnl_usd)}</td>
                <td className={`px-4 py-3 text-right font-semibold ${(row.return_pct ?? 0) >= 0 ? "text-ok" : "text-block"}`}>{formatPct(row.return_pct)}</td>
                <td className="px-4 py-3 text-right text-zinc-600">{row.profit_factor == null ? "-" : row.profit_factor.toFixed(2)}</td>
                <td className="px-4 py-3 text-right text-zinc-600">{row.avg_score == null ? "-" : row.avg_score.toFixed(1)}</td>
              </tr>
            )) : (
              <tr>
                <td colSpan={10} className="px-4 py-8 text-center text-zinc-500">No strategy result yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function PanelHeader({ title, icon }: { title: string; icon: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-line px-5 py-4">
      <h2 className="text-base font-semibold text-ink">{title}</h2>
      {icon}
    </div>
  );
}

function toneText(tone: string) {
  return {
    ok: "text-ok",
    warn: "text-warn",
    block: "text-block",
    info: "text-info",
  }[tone] ?? "text-info";
}

function formatUnknown(value: unknown) {
  if (typeof value === "boolean") return value ? "true" : "false";
  if (value == null || value === "") return "-";
  if (typeof value === "number") return formatNumber(value);
  return String(value);
}

function formatNumber(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "-";
  return value.toLocaleString("en-US", { maximumFractionDigits: 2 });
}

function formatUsd(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "-";
  return `$${value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatPct(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "-";
  return `${value.toLocaleString("en-US", { maximumFractionDigits: 2 })}%`;
}

function formatPatternPct(value: unknown) {
  if (typeof value !== "number" || !Number.isFinite(value)) return "-";
  return `${(value * 100).toLocaleString("en-US", { maximumFractionDigits: 2 })}%`;
}

function formatPatternValue(key: string, value: unknown) {
  if (typeof value === "number" && (key.endsWith("_pct") || key.includes("pct"))) {
    return formatPatternPct(value);
  }
  return value;
}

function labelForKey(key: string) {
  const labels: Record<string, string> = {
    surge_context: "Surge context",
    pullback_support: "Pullback support",
    reclaim_confirmation: "Reclaim confirmation",
    chase_avoidance: "Chase avoidance",
    liquidity_reacceleration: "Liquidity reacceleration",
    bb_position: "BB position",
  };
  return labels[key] ?? key.split("_").filter(Boolean).map(capitalize).join(" ");
}

function capitalize(value: string) {
  return value ? `${value[0].toUpperCase()}${value.slice(1)}` : value;
}

function conditionsSummary(conditions?: Record<string, boolean>) {
  const entries = Object.entries(conditions ?? {});
  if (!entries.length) return "-";
  return `${entries.filter(([, ok]) => ok).length}/${entries.length}`;
}
