# US Intraday Trading Research Platform

미국장 1분봉 단타 연구/검증용 개인 SaaS 플랫폼입니다. 기존 PyQt 방향은 폐기하고, FastAPI backend + Next.js frontend + PostgreSQL + Redis 기반 모노레포로 구성합니다.

현재 아키텍처는 **Toss OpenAPI를 실시간 차트/tick, 호가, 계좌 preview, 향후 실행 gateway의 중심으로 사용**합니다. Alpaca는 primary market data로 쓰지 않으며, 남아 있는 adapter는 명시적으로 요청했을 때만 켜는 optional/legacy 코드로 취급합니다. KIS는 legacy fallback/debug 용도로만 남기며, KIS 단독 market data는 실시간 초단타 차트 기준으로 쓰지 않습니다.

현재 범위:

- 기본 모드: `internal_paper`
- live trading 미구현 및 기본 차단
- 기본 검증 자본: USD 2,000
- Bollinger Lower Band Reclaim + Toss order flow scanner 구조
- Toss OpenAPI market data provider가 기본값입니다. `MARKET_DATA_PROVIDER=toss`
- Alpaca adapter는 optional/legacy adapter입니다. 기본 provider로 사용하지 않습니다.
- KIS REST/WebSocket market-data 사용은 `MARKET_DATA_PROVIDER=kis_legacy` 임시 fallback으로만 허용
- Toss는 execution/account gateway 역할이며 live order는 공식 API 검증 전까지 차단
- KIS는 legacy fallback/debug adapter로만 유지
- DB schema, domain models, structured logs, realtime event envelope 제공
- Command Center, Scanner Funnel, Symbol Detail, Strategy Monitor, Orders Timeline, Logs Explorer, Alerts 화면 skeleton 제공

## Structure

```text
apps/web                 Next.js dashboard
services/backend         FastAPI API, domain, DB, Toss market-data/execution gateway
configs/default.yaml     research/internal_paper-first defaults
docker-compose.yml       PostgreSQL, Redis, backend, web
```

## Quick Start With Conda And Cmd

PowerShell에서 한글이 깨지는 환경이면 cmd를 기준으로 실행합니다.

더블클릭 또는 cmd에서 실행:

```cmd
setup.bat
start-all.bat
```

`start-all.bat` runs inside the current VSCode terminal. It does not open extra cmd windows. Backend and web logs are written to port-specific files such as:

```text
logs\backend-8001.log
logs\web-3000.log
```

In this background mode, the backend runs without `uvicorn --reload` so `stop-dev.bat` can terminate it cleanly.

개별 bat 파일:

```cmd
start-postgres.bat
migrate-db.bat
run-dev.bat
stop-dev.bat
stop-all-dev.bat
stop-postgres.bat
check.bat
logs.bat
follow-logs.bat
```

내부 스크립트를 직접 실행할 수도 있습니다.

```cmd
scripts\setup-conda.cmd
scripts\start-postgres.cmd
scripts\migrate-db.cmd
scripts\run-dev.cmd
```

개별 실행:

```cmd
scripts\start-postgres.cmd
scripts\run-backend.cmd
scripts\run-web.cmd
```

Dashboard: http://127.0.0.1:3000

Backend API: http://127.0.0.1:8000/api/health

API docs: http://127.0.0.1:8000/docs

If port 8000 or 3000 is already in use, `scripts\run-dev.cmd` automatically tries 8001 or 3001.

환경 확인:

```cmd
scripts\check-conda.cmd
```

Redis note: Windows conda channels do not provide a current Redis server package. The current backend skeleton uses an in-memory realtime event bus so it can run without Redis. The `REDIS_URL` setting is still present for the later Redis Pub/Sub implementation.

## Docker Quick Start

```powershell
Copy-Item .env.example .env
docker compose up --build
```

Dashboard: http://localhost:3000

Backend API: http://localhost:8000/api/health

API docs: http://localhost:8000/docs

## Backend Local Run Without Scripts

```cmd
cd services/backend
..\..\scripts\run-backend.cmd
```

## Frontend Local Run Without Scripts

```cmd
scripts\run-web.cmd
```

## Safety Defaults

Live trading is intentionally not implemented. Toss OpenAPI is used for chart/tick market data, quote/account preview, and the future execution gateway. Alpaca is not the primary market-data provider. KIS is legacy fallback/debug only. Toss live order endpoints remain disabled until endpoint mapping, field behavior, and safety gates are explicitly implemented and reviewed.

## Strategy Replay Model

현재 전략 비교는 단일 포지션을 공유하지 않고, 전략별 shadow portfolio로 분리해서 본다. 같은 종목, 같은 시각에 여러 전략이 동시에 조건을 만족하면 각 전략이 독립적으로 paper position을 만든다. 이 구조는 실전 주문 수량을 늘리기 위한 것이 아니라, 어떤 전략의 진입/청산 논리가 더 나은지 비교하기 위한 연구용 구조다.

TC replay 기준 체결 모델은 아래처럼 둔다.

```text
데이터: Toss 1분봉/호가/체결 polling 데이터. 과거 replay 깊이가 부족하면 데이터 공백을 명시한다.
진입: 신호 봉 마감 후 다음 1분봉의 first_ask 기준
일반 청산: 청산 신호 후 다음 1분봉의 first_bid 기준
손절 청산: intrabar low touch를 보수적으로 보고 min_bid 기준
체결 방향: trade를 직전 quote와 매칭해 aggressive buy/sell 추정
비용: 수수료, SEC fee, TAF, spread, slippage 반영
```

### 공통 규칙

공통 규칙은 모든 전략에 적용하지만, 전략을 똑같이 만들 정도로 강하게 쓰지 않는다.

```text
1. 최소 유동성:
   1분 거래대금 기준 $30,000 이상

2. 비용 대비 기대값:
   기대 상승폭이 roundtrip cost + 최소 edge보다 작으면 진입하지 않는다.
   roundtrip cost에는 spread, entry slippage, exit slippage, 왕복 수수료, SEC fee가 포함된다.

3. 체결 기준:
   평균가가 아니라 first_ask / first_bid 기준으로 replay한다.

4. 손절:
   구조적 저점과 최후 손절선을 함께 본다.

5. runner:
   수익이 커지고 추세가 유지되면 작은 약화 신호 1회로 바로 전량청산하지 않는다.

6. 위험 청산:
   spread 확대 + 매도 우위 전환 + 고점 실패가 같이 나오면 청산 후보가 된다.
```

### 전략별 진입 성격

### Expected Upside Model

Expected upside is now strategy-specific.

```text
Pullback/Reclaim family:
  Treats recent 24-bar highs, BB upper, EMA20, and VWAP as nearby resistance.
  This remains conservative because these strategies are mean-reversion/reclaim entries.

Runner/Continuation family:
  Treats recent highs as breakout candidates instead of hard resistance.
  Expands expected upside when volume re-accelerates, trade_strength improves,
  sell_pressure stays controlled, EMA9 ride holds, BB width expands, MACD slope holds,
  and price closes near or above recent highs.

Common:
  Entry is blocked when expected upside is smaller than the dynamic target.
  Dynamic target includes spread, fees, slippage, and volatility.
```

### Active Intraday Strategy Set

전략 테스트 페이지의 shadow replay는 단타에 의미가 있는 전략만 기본 실행한다.

```text
Active:
- Surge Pullback Reclaim
- Order Flow Imbalance Proxy
- Liquidity Absorption Breakout
- Runner Continuation / EMA9 Ride

Archived:
- Pullback Reclaim: Surge Pullback과 신호가 겹치고 급등주 단타 색이 약함
- Lower Band Snapback: 하락 반등 전용이라 현재 유동성 급등주 실험과 우선순위가 낮음
- VWAP Reclaim: 단독 전략으로는 너무 느리고 범용적임
- Liquidity Imbalance Proxy: 호가 imbalance 단독 의존도가 높아 fake liquidity 위험이 큼
- Opening Liquidity Imbalance: 프리/오픈 전용 미구현 placeholder
```

#### Runner Continuation / EMA9 Ride

This strategy is for hot momentum names that keep riding EMA9 without a deep pullback.

```text
- Close is near or above recent highs
- Price holds above EMA9, with lows defending near EMA9
- trade_strength >= 58
- sell_pressure <= 42, or <= 48 while decreasing
- Volume >= 1.15x volume_ma20
- No sharp spread widening
- MACD histogram is not fading
- BB position <= 1.45
- Early failure exit:
  if the entry signal was only a near-VWAP breakout and the next 1-3 bars fail
  to hold the breakout/VWAP, exit before the final structure stop.

Unlike pullback strategies, recent highs are treated as possible breakout points.
This strategy is evaluated as an independent shadow portfolio because chase risk is higher.
```

#### Archived: VWAP Reclaim

VWAP 이탈 후 다시 VWAP 위로 올라오는 회복 전략이다. 안정적인 재진입 확인을 중시한다.

```text
핵심 신호:
- 직전 봉 종가가 VWAP 아래
- 현재 봉 종가가 VWAP 위
- EMA9 위 유지
- 종가가 봉 상단부에 위치

전략별 확인:
- BB position <= 1.03
- 직전 저점 방어
- spread 안정
- sell pressure 감소
- MACD histogram 상승
- EMA9/VWAP 위 유지

성격:
- 보수적
- 추격 매수 제한 강함
- 안정적인 회복 확인용
```

#### Order Flow Imbalance Proxy

실제 체결 방향 추정이 매수 우위로 바뀌는 순간을 보는 전략이다. 차트보다 order flow를 더 우선한다.

```text
핵심 신호:
- trade_strength >= 58
- sell_pressure <= 45
- MACD histogram이 양수권에서 이미 둔화 중이면 신규 진입하지 않음
- 청산 직후 3봉 동안 같은 Order Flow 전략 재진입 금지
- 종가가 봉 상단부에 위치
- 또는 양봉 + 거래량 증가

전략별 확인:
- BB position <= 1.15
- 직전 저점 방어
- spread 안정
- sell pressure 감소
- MACD가 급격히 악화되지 않음
- EMA9 위 유지

성격:
- VWAP 전략보다 빠름
- BB 상단 근처를 일부 허용
- 급등 초기 impulse를 더 잘 잡는 대신 false entry 위험이 더 큼
```

#### Archived: Liquidity Imbalance Proxy

호가 불균형 또는 하단 흡수 흔적을 보고 들어가는 전략이다. EMA/VWAP는 보조로만 본다.

```text
핵심 신호:
- bid_ask_imbalance >= 0.52
- 또는 하단 꼬리 흡수 + 거래량 증가
- 종가가 봉 상단부에 위치

전략별 확인:
- BB position <= 1.15
- 직전 저점 방어
- spread 안정
- sell pressure 감소
- EMA9 또는 VWAP 중 하나만 회복해도 허용

성격:
- 눌림 흡수 감지용
- VWAP 완전 회복 전에도 일부 진입 가능
- 저점 방어 실패 시 취약
```

#### Liquidity Absorption Breakout

눌림 또는 흡수 흔적 이후 다시 직전 고점을 돌파할 때 들어가는 전략이다. 단순 돌파는 피하고, 먼저 흡수 흔적이 있어야 한다.

```text
핵심 신호:
- 최근 6봉 안에 하단 꼬리 흡수 또는 EMA9 근처 지지
- 현재 봉이 최근 8봉 고점 돌파
- 거래량이 20봉 평균의 1.4배 이상
- 종가가 봉 상단부에 위치

전략별 확인:
- BB position <= 1.20
- 직전 저점 방어
- spread 안정
- sell pressure 감소
- MACD가 급격히 악화되지 않음

성격:
- 가장 공격적인 돌파형
- 거래 수를 늘리는 후보
- 고점 실패와 spread 확대에 민감하게 청산해야 함
```

#### Surge Pullback Reclaim

급등 후 눌림이 나온 뒤 지지선을 회복하는 전략이다. BB 상단 돌파 자체는 매수 신호가 아니라 관심 등록 신호로 본다.

```text
핵심 신호:
- 최근 구간에서 10% 이상 surge
- 고점 대비 2%~35% 눌림
- EMA9/EMA20/BB mid/VWAP 중 하나 근처에서 지지
- 재상승 확인
- MACD가 악화되지 않음

전략별 확인:
- BB position <= 1.12
- 직전 저점 방어
- spread 급확대 없음
- EMA9 위 유지
- 큰 양봉 추격은 흡수 흔적이 있을 때만 허용

성격:
- runner 후보 탐색용
- 좋은 차트에서는 가장 큰 수익을 낼 수 있지만, 진입이 늦으면 손익비가 나빠진다.
```

#### Archived: Pullback Reclaim

EMA/VWAP/BB mid 근처 눌림 후 재상승을 보는 일반 눌림 전략이다.

```text
핵심 신호:
- 최근 저점이 EMA20, BB mid, VWAP 근처에서 방어
- EMA9 또는 VWAP 위로 회복
- 종가가 봉 상단부
- MACD 상승 또는 양수권 유지

전략별 확인:
- BB position <= 0.98
- 직전 저점 강하게 방어
- spread 안정
- sell pressure 감소
- EMA9/VWAP 위 유지

성격:
- 가장 보수적인 눌림 전략
- 급등주에서는 진입이 적을 수 있다.
```

#### Archived: Lower Band Snapback

BB 하단 이탈 후 밴드 안으로 회복하는 과매도 반등 전략이다. 현재 급등주 TC replay에서는 거의 신호가 나오지 않는다.

```text
핵심 신호:
- BB lower touch 또는 하단 이탈
- 종가가 다시 lower band 위
- 양봉 회복
- MACD histogram 상승

전략별 확인:
- BB position <= 0.65
- 직전 저점 방어
- sell pressure 감소
- MACD 상승

성격:
- 급등 추격과 별개
- 하락 후 snapback 전용
```

### TC Replay Snapshot

`exports/strategy_replay/tc_2026-07-01_1700-2330_kst_a4d0e386_enriched.csv` 기준 active 전략 replay 결과:

```text
Surge Pullback Reclaim        1 trade   -$0.77   -0.04%
Order Flow Imbalance Proxy    3 trades +$30.71   +1.54%
Liquidity Absorption Breakout 1 trade  +$25.42   +1.27%
Runner Continuation / EMA9    4 trades +$13.99   +0.70%
```

이 결과는 단일 종목, 단일 구간 replay이므로 전략 검증으로 간주하지 않는다. 다음 단계는 여러 급등주 구간을 같은 방식으로 replay해서, 전략별 거래 수, 손익비, 최대 손실, false entry 패턴을 비교하는 것이다.
