@echo off
setlocal
cd /d "%~dp0"
call scripts\start-postgres.cmd
if errorlevel 1 (
  echo.
  echo PostgreSQL failed to start.
  pause
  exit /b %errorlevel%
)
echo.
echo PostgreSQL is ready.
pause
