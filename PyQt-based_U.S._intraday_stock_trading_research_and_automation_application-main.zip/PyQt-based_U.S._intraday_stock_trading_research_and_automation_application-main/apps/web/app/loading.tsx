import { Activity } from "lucide-react";

export default function Loading() {
  return (
    <section className="space-y-5 p-6">
      <div className="rounded border border-line bg-white p-5">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded bg-blue-50 text-info">
            <Activity className="h-5 w-5 animate-pulse" aria-hidden />
          </div>
          <div>
            <div className="h-4 w-32 rounded bg-zinc-200" />
            <div className="mt-2 h-3 w-56 rounded bg-zinc-100" />
          </div>
        </div>
      </div>
      <div className="grid gap-4 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, index) => (
          <div key={index} className="rounded border border-line bg-white p-4">
            <div className="h-3 w-24 rounded bg-zinc-100" />
            <div className="mt-4 h-7 w-20 rounded bg-zinc-200" />
            <div className="mt-3 h-3 w-32 rounded bg-zinc-100" />
          </div>
        ))}
      </div>
      <div className="rounded border border-line bg-white p-5">
        <div className="h-4 w-36 rounded bg-zinc-200" />
        <div className="mt-5 space-y-3">
          {Array.from({ length: 8 }).map((_, index) => (
            <div key={index} className="grid gap-3 md:grid-cols-6">
              <div className="h-4 rounded bg-zinc-100" />
              <div className="h-4 rounded bg-zinc-100" />
              <div className="h-4 rounded bg-zinc-100" />
              <div className="h-4 rounded bg-zinc-100" />
              <div className="h-4 rounded bg-zinc-100" />
              <div className="h-4 rounded bg-zinc-100" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
