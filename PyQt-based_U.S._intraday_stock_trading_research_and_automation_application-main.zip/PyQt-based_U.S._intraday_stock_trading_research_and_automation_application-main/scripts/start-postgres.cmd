@echo off
setlocal

cd /d "%~dp0.."

set CONDA_ENV_DIR=%USERPROFILE%\.conda\envs\kis-trading-research
if not exist "%CONDA_ENV_DIR%\python.exe" set CONDA_ENV_DIR=C:\ProgramData\anaconda3\envs\kis-trading-research
set PATH=%CONDA_ENV_DIR%;%CONDA_ENV_DIR%\Library\bin;%CONDA_ENV_DIR%\Scripts;%PATH%

if not exist "data\postgres\PG_VERSION" (
  call "%~dp0init-postgres.cmd"
  if errorlevel 1 exit /b %errorlevel%
)

echo Starting PostgreSQL on 127.0.0.1:5432
pg_ctl -D "data\postgres" status > nul 2> nul
if not errorlevel 1 (
  echo PostgreSQL is already running.
  goto ensure_db
)

pg_ctl -D "data\postgres" -l "data\postgres.log" -o "-h 127.0.0.1 -p 5432" start
if errorlevel 1 (
  echo PostgreSQL failed to start.
  exit /b %errorlevel%
)

:ensure_db
psql -h 127.0.0.1 -p 5432 -U kis_app -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='kis_trading_research'" | findstr /C:"1" > nul
if errorlevel 1 (
  createdb -h 127.0.0.1 -p 5432 -U kis_app kis_trading_research
  if errorlevel 1 (
    echo Failed to create database kis_trading_research.
    exit /b %errorlevel%
  )
) else (
  echo Database kis_trading_research already exists.
)

echo PostgreSQL ready.
exit /b 0
