from typing import Any

from app.adapters.market_data.base import MarketDataUnavailableError
from app.adapters.toss.client import TossApiError, TossExecutionClient
from app.core.config import get_settings
from app.services.market_data import get_market_data_service


class ExecutionPricingError(RuntimeError):
    def __init__(self, message: str, *, payload: dict | None = None) -> None:
        super().__init__(message)
        self.payload = payload or {}


def execution_market_snapshot(symbol: str, *, side: str) -> dict:
    settings = get_settings()
    if settings.execution_provider == "toss" or settings.toss_app_key or settings.toss_app_secret:
        try:
            preview = TossExecutionClient(settings).execution_preview(symbol=symbol, side=side, currency="USD")
        except TossApiError as exc:
            raise ExecutionPricingError(
                "Toss orderbook/buying power 조회 실패",
                payload={"status_code": exc.status_code, "payload": exc.payload},
            ) from exc
        best_ask = _to_float(preview.get("best_ask"))
        best_bid = _to_float(preview.get("best_bid"))
        return {
            "last": best_ask or best_bid,
            "bid": best_bid,
            "ask": best_ask,
            "spread_pct": preview.get("spread_pct"),
            "cash_buying_power": preview.get("cash_buying_power"),
            "account_seq": preview.get("account_seq"),
            "currency": preview.get("currency"),
            "source": "toss_orderbook_buying_power",
            "toss_preview": preview,
            "live_order_called": False,
        }
    return market_data_snapshot(symbol)


def execution_quote_snapshot(symbol: str, *, max_cache_age_sec: float = 1.0) -> dict:
    settings = get_settings()
    if settings.execution_provider == "toss" or settings.toss_app_key or settings.toss_app_secret:
        try:
            quote = TossExecutionClient(settings).orderbook_quote(
                symbol=symbol,
                max_cache_age_sec=max_cache_age_sec,
            )
        except TossApiError as exc:
            raise ExecutionPricingError(
                "Toss orderbook 조회 실패",
                payload={"status_code": exc.status_code, "payload": exc.payload},
            ) from exc
        best_ask = _to_float(quote.get("best_ask"))
        best_bid = _to_float(quote.get("best_bid"))
        return {
            "last": best_bid or best_ask,
            "bid": best_bid,
            "ask": best_ask,
            "spread_pct": quote.get("spread_pct"),
            "currency": quote.get("currency"),
            "source": "toss_orderbook_quote",
            "toss_quote": quote,
            "live_order_called": False,
        }
    return market_data_snapshot(symbol)


def market_data_snapshot(symbol: str) -> dict:
    provider = get_market_data_service().provider
    realtime = provider.realtime_snapshot()
    trade = realtime.get("trades", {}).get(symbol) or {}
    quote = realtime.get("quotes", {}).get(symbol) or {}
    last = _to_float(trade.get("last"))
    bid = _to_float(quote.get("bid"))
    ask = _to_float(quote.get("ask"))
    if last is None:
        try:
            last = _to_float((provider.price(symbol=symbol, exchange="NAS").get("output") or {}).get("last"))
        except MarketDataUnavailableError:
            pass
    if bid is None or ask is None:
        try:
            quote_output2 = provider.quote(symbol=symbol, exchange="NAS").get("output2") or {}
            bid = bid if bid is not None else _to_float(quote_output2.get("pbid1"))
            ask = ask if ask is not None else _to_float(quote_output2.get("pask1"))
        except MarketDataUnavailableError:
            pass
    return {
        "last": last,
        "bid": bid,
        "ask": ask,
        "spread_pct": _spread_pct(bid, ask),
        "source": "market_data_provider_snapshot",
        "live_order_called": False,
    }


def _spread_pct(bid: float | None, ask: float | None) -> float | None:
    if not bid or not ask:
        return None
    midpoint = (bid + ask) / 2
    if midpoint <= 0:
        return None
    return (ask - bid) / midpoint * 100


def _to_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        return None
