"""Capture the Toss 거래대금순 (trading-amount) ranking at US market close and save
a dated snapshot. The ranking is the only time-sensitive, non-retrievable piece
(the API only exposes rolling windows, never a past date), so this is meant to
run daily right after the close and accumulate snapshots. Charts stay retrievable
from Alpaca historically and are fetched on demand from a saved snapshot.

Self-contained / CWD-independent (derives repo root from __file__), so it runs
cleanly from Windows Task Scheduler. On US-market weekends it exits without
writing (the API would only echo the last session).

Output: exports/strategy_replay/rankings/ranking_<ET-session-date>.json
        (+ appends one line to rankings/index.jsonl)
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

PROJECT_ROOT = Path(__file__).resolve().parents[1]
BACKEND_ROOT = PROJECT_ROOT / "services" / "backend"
RANKINGS_DIR = PROJECT_ROOT / "exports" / "strategy_replay" / "rankings"
ET = ZoneInfo("America/New_York")


def _to_float(value) -> float | None:
    try:
        return float(str(value).replace(",", "").replace("$", "").strip())
    except (TypeError, ValueError):
        return None


def fetch_universe(max_price: float, common_only: bool, keep: set[str]) -> tuple[list[dict], str]:
    if str(BACKEND_ROOT) not in sys.path:
        sys.path.insert(0, str(BACKEND_ROOT))
    from app.core.config import Settings
    from app.adapters.toss.client import TossExecutionClient
    from app.adapters.market_data.toss import _is_common_stock

    client = TossExecutionClient(Settings())

    def _rankings(duration: str) -> list[dict]:
        result = client.rankings(
            ranking_type="TOSS_SECURITIES_TRADING_AMOUNT",
            market_country="US",
            duration=duration,
            count=100,
        )
        return result.get("rankings") or []

    duration_used = "realtime"
    rows = _rankings("realtime")
    if not rows:
        duration_used = "1d"
        rows = _rankings("1d")

    filtered: list[dict] = []
    for row in rows:
        symbol = str(row.get("symbol") or "").upper()
        price = _to_float((row.get("price") or {}).get("lastPrice"))
        if not symbol or price is None or price > max_price:
            continue
        filtered.append(
            {
                "symbol": symbol,
                "rank": row.get("rank"),
                "price": price,
                "trade_amount_usd": _to_float(row.get("tradingAmount")),
            }
        )

    if common_only and filtered:
        meta = {str(m.get("symbol") or "").upper(): m for m in client.stocks(symbols=[u["symbol"] for u in filtered])}
        kept = []
        for item in filtered:
            if item["symbol"] in keep or _is_common_stock(meta.get(item["symbol"])):
                item["security_type"] = (meta.get(item["symbol"]) or {}).get("securityType")
                kept.append(item)
        filtered = kept
    return filtered, duration_used


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-price", type=float, default=20.0)
    parser.add_argument("--common-only", action="store_true", default=True)
    parser.add_argument("--include-etf", dest="common_only", action="store_false")
    parser.add_argument("--always-keep", default="TC")
    parser.add_argument("--force", action="store_true", help="overwrite an existing snapshot for the session date")
    args = parser.parse_args()

    # Tag by the most recently CLOSED US regular session (16:00 ET), so the label
    # is correct whether the job fires right at close (05-06 KST) or a bit later.
    now_et = datetime.now(ET)
    session_dt = now_et
    if not (now_et.weekday() < 5 and now_et.hour >= 16):
        session_dt = now_et - timedelta(days=1)
        while session_dt.weekday() >= 5:
            session_dt -= timedelta(days=1)
    session_date = session_dt.strftime("%Y-%m-%d")

    RANKINGS_DIR.mkdir(parents=True, exist_ok=True)
    out_path = RANKINGS_DIR / f"ranking_{session_date}.json"
    if out_path.exists() and not args.force:
        print(f"snapshot already exists: {out_path.name} (use --force to overwrite)")
        return

    keep = {t.strip().upper() for t in (args.always_keep or "").split(",") if t.strip()}
    try:
        universe, duration_used = fetch_universe(args.max_price, args.common_only, keep)
    except Exception as exc:  # keep the cron alive; log and exit non-zero
        print(f"ERROR fetching ranking: {type(exc).__name__}: {exc}")
        raise SystemExit(1)

    snapshot = {
        "session_date_et": session_date,
        "captured_at_kst": datetime.now(ZoneInfo("Asia/Seoul")).isoformat(),
        "captured_at_et": now_et.isoformat(),
        "duration_used": duration_used,
        "max_price": args.max_price,
        "common_only": args.common_only,
        "count": len(universe),
        "symbols_csv": ",".join(u["symbol"] for u in universe),
        "universe": universe,
    }
    out_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")

    index_path = RANKINGS_DIR / "index.jsonl"
    with index_path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps({
            "session_date_et": session_date,
            "captured_at_kst": snapshot["captured_at_kst"],
            "count": len(universe),
            "symbols_csv": snapshot["symbols_csv"],
        }, ensure_ascii=False) + "\n")

    print(f"saved {out_path.relative_to(PROJECT_ROOT)}  ({len(universe)} symbols, duration={duration_used})")
    print(f"  {snapshot['symbols_csv']}")


if __name__ == "__main__":
    main()
