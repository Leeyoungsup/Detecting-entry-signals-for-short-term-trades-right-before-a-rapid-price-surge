@echo off
setlocal EnableDelayedExpansion

cd /d "%~dp0.."

call scripts\load-env.cmd

if not exist "logs" mkdir "logs"
if not exist ".runtime" mkdir ".runtime"

if exist ".runtime\api-port.txt" (
  set /p PREV_API_PORT=<".runtime\api-port.txt"
  for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":!PREV_API_PORT! .*LISTENING"') do (
    echo Stopping previous backend on port !PREV_API_PORT!
    taskkill /PID %%P /T /F > nul 2> nul
  )
)

if exist ".runtime\web-port.txt" (
  set /p PREV_WEB_PORT=<".runtime\web-port.txt"
  for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":!PREV_WEB_PORT! .*LISTENING"') do (
    echo Stopping previous web on port !PREV_WEB_PORT!
    taskkill /PID %%P /T /F > nul 2> nul
  )
)

echo Stopping previous worker processes
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { ($_.CommandLine -like '*app.worker*' -or $_.CommandLine -like '*run-worker.cmd*' -or $_.CommandLine -like '*app.realtime_worker*' -or $_.CommandLine -like '*run-realtime-worker.cmd*') -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" > nul 2> nul

if "%API_PORT%"=="" (
  if not "%NEXT_PUBLIC_API_BASE_URL%"=="" (
    for /f "tokens=3 delims=:" %%A in ("%NEXT_PUBLIC_API_BASE_URL%") do (
      for /f "tokens=1 delims=/" %%B in ("%%A") do set API_PORT=%%B
    )
  )
)
if "%API_PORT%"=="" set API_PORT=18001
netstat -ano | findstr /R /C:":%API_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%API_PORT%"=="18001" set API_PORT=18002
)
netstat -ano | findstr /R /C:":%API_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%API_PORT%"=="18002" set API_PORT=18003
)
netstat -ano | findstr /R /C:":%API_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%API_PORT%"=="18003" set API_PORT=18004
)

if "%WEB_PORT%"=="" set WEB_PORT=18000
netstat -ano | findstr /R /C:":%WEB_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%WEB_PORT%"=="18000" set WEB_PORT=18004
)
netstat -ano | findstr /R /C:":%WEB_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%WEB_PORT%"=="18004" set WEB_PORT=18008
)
netstat -ano | findstr /R /C:":%WEB_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%WEB_PORT%"=="18008" set WEB_PORT=18012
)

echo %API_PORT%> ".runtime\api-port.txt"
echo %WEB_PORT%> ".runtime\web-port.txt"
set BACKEND_LOG=logs\backend-%API_PORT%.log
set WORKER_LOG=logs\worker-%API_PORT%.log
set REALTIME_WORKER_LOG=logs\realtime-worker-%API_PORT%.log
set WEB_LOG=logs\web-%WEB_PORT%.log

echo Starting backend in COMBINED mode (scanner + realtime polling + strategy eval in one process).
echo Backend log: %BACKEND_LOG%
start "" /B cmd /c "set API_PORT=%API_PORT%&& set BACKEND_RELOAD=false&& set BACKEND_PROCESS_ROLE=combined&& call scripts\run-backend.cmd > %BACKEND_LOG% 2>&1"

timeout /t 4 /nobreak > nul

echo Combined mode: scanner, realtime polling and strategy evaluation all run inside the backend,
echo   so state is shared in-process and Redis is NOT required. Skipping separate worker / realtime-worker.

echo Starting web in this VSCode session background.
echo Web log: %WEB_LOG%
start "" /B cmd /c "set API_PORT=%API_PORT%&& set WEB_PORT=%WEB_PORT%&& call scripts\run-web.cmd > %WEB_LOG% 2>&1"

echo.
echo Backend: http://127.0.0.1:%API_PORT%
echo API docs: http://127.0.0.1:%API_PORT%/docs
echo Web:     http://127.0.0.1:%WEB_PORT%
echo %BACKEND_LOG%> ".runtime\backend-log.txt"
echo %WORKER_LOG%> ".runtime\worker-log.txt"
echo %REALTIME_WORKER_LOG%> ".runtime\realtime-worker-log.txt"
echo %WEB_LOG%> ".runtime\web-log.txt"
echo.
echo To stop dev servers, run stop-dev.bat.
exit /b 0
