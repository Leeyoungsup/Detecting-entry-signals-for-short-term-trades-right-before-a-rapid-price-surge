"""Toss execution/account adapter stubs."""
