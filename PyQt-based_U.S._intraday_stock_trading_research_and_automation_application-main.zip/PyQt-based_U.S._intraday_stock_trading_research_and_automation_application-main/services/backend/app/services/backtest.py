from dataclasses import dataclass


@dataclass(frozen=True)
class CandlePathDecision:
    exit_reason: str
    exit_price: float
    conservative_note: str | None = None


class ConservativeFillModel:
    def decide_exit(
        self,
        *,
        candle_high: float,
        candle_low: float,
        stop_loss: float,
        take_profit: float,
    ) -> CandlePathDecision | None:
        hit_stop = candle_low <= stop_loss
        hit_take_profit = candle_high >= take_profit
        if hit_stop and hit_take_profit:
            return CandlePathDecision(
                exit_reason="stop_loss",
                exit_price=stop_loss,
                conservative_note="Same candle touched stop and target; stop is assumed first.",
            )
        if hit_stop:
            return CandlePathDecision(exit_reason="stop_loss", exit_price=stop_loss)
        if hit_take_profit:
            return CandlePathDecision(exit_reason="take_profit", exit_price=take_profit)
        return None
