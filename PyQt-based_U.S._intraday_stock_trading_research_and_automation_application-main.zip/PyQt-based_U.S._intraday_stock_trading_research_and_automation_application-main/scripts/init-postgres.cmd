@echo off
setlocal

cd /d "%~dp0.."

set CONDA_ENV_DIR=%USERPROFILE%\.conda\envs\kis-trading-research
if not exist "%CONDA_ENV_DIR%\python.exe" set CONDA_ENV_DIR=C:\ProgramData\anaconda3\envs\kis-trading-research
set PATH=%CONDA_ENV_DIR%;%CONDA_ENV_DIR%\Library\bin;%CONDA_ENV_DIR%\Scripts;%PATH%

if not exist "data" mkdir "data"

if exist "data\postgres\PG_VERSION" (
  echo PostgreSQL data directory already exists: data\postgres
  exit /b 0
)

echo Initializing PostgreSQL data directory at data\postgres
initdb -D "data\postgres" -U kis_app --encoding=UTF8
if errorlevel 1 exit /b %errorlevel%

echo PostgreSQL initialized.
