"""Collect enriched replay charts for the most recent captured Toss ranking.

Companion to capture_toss_ranking.py. The capture task saves the daily ranking
(the only non-retrievable piece) at the US close; this then fetches that day's
enriched bars/charts from Alpaca (historically retrievable) so the replay dataset
auto-completes. Meant to run daily right after capture, from Windows Task
Scheduler. Idempotent: collect_toss_ranking_charts skips symbols already done, so
weekend runs (no new ranking) are harmless no-ops.

Session date D (ET) maps to the KST collection window [D 17:00, D+1 08:00] and
out-dir exports/strategy_replay/session_D, matching the existing sessions.
"""

from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RANKINGS_DIR = PROJECT_ROOT / "exports" / "strategy_replay" / "rankings"
MAX_PRICE = "20"


def _latest_ranking_file() -> Path | None:
    files = sorted(RANKINGS_DIR.glob("ranking_20*.json"))
    return files[-1] if files else None


def main() -> None:
    path_ranking = _latest_ranking_file()
    if path_ranking is None:
        print("no ranking snapshot found; run capture_toss_ranking.py first")
        return
    data = json.loads(path_ranking.read_text(encoding="utf-8"))
    str_session = str(data.get("session_date_et") or "")
    try:
        dt_session = datetime.strptime(str_session, "%Y-%m-%d")
    except ValueError:
        print(f"ranking snapshot has no valid session_date_et: {path_ranking.name}")
        return
    str_start_kst = f"{str_session} 17:00"
    str_end_kst = (dt_session + timedelta(days=1)).strftime("%Y-%m-%d") + " 08:00"
    path_out = PROJECT_ROOT / "exports" / "strategy_replay" / f"session_{str_session}"

    list_cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "collect_toss_ranking_charts.py"),
        "--start-kst", str_start_kst,
        "--end-kst", str_end_kst,
        "--ranking-file", str(path_ranking),
        "--max-price", MAX_PRICE,
        "--out-dir", str(path_out),
    ]
    print(f"collecting charts for session {str_session} -> {path_out.name}")
    print("cmd:", " ".join(list_cmd))
    subprocess.run(list_cmd, cwd=str(PROJECT_ROOT), check=False)


if __name__ == "__main__":
    main()
