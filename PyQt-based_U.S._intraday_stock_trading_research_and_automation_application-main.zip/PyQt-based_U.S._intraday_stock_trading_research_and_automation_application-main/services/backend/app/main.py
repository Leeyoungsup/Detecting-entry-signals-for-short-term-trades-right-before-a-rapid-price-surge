from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.router import api_router
from app.core.config import get_settings
from app.core.logging import configure_logging
from app.services.runtime_supervisor import runtime_supervisor


def create_app() -> FastAPI:
    settings = get_settings()
    configure_logging()

    app = FastAPI(
        title="US Intraday Trading Research API",
        version="0.1.0",
        description="Private Toss-based intraday strategy platform with replay, monitoring, and gated live execution.",
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(api_router, prefix="/api")

    @app.on_event("startup")
    async def _start_runtime_supervisor() -> None:
        if settings.app_process_role in ("combined", "worker"):
            runtime_supervisor.start()

    @app.on_event("shutdown")
    async def _stop_runtime_supervisor() -> None:
        if settings.app_process_role in ("combined", "worker"):
            await runtime_supervisor.stop()

    return app


app = create_app()
