"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { API_BASE_URL } from "@/lib/api";

export type RealtimeEnvelope = {
  event_type?: string;
  symbol?: string | null;
  payload?: {
    event_type?: string;
    scope?: string;
    symbol?: string;
    [key: string]: unknown;
  };
};

function realtimeUrl() {
  return `${API_BASE_URL.replace(/^http/, "ws").replace(/\/$/, "")}/api/realtime/ws`;
}

export function useLiveResource<T>({
  path,
  fallback,
  shouldReload,
  minIntervalMs = 1000,
  fallbackIntervalMs = 10000,
}: {
  path: string;
  fallback: T;
  shouldReload: (event: RealtimeEnvelope) => boolean;
  minIntervalMs?: number;
  fallbackIntervalMs?: number;
}) {
  const [data, setData] = useState<T>(fallback);
  const [connected, setConnected] = useState(false);
  const [eventAt, setEventAt] = useState<Date | null>(null);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const timerRef = useRef<number | null>(null);
  const watchdogRef = useRef<number | null>(null);
  const fallbackRef = useRef<number | null>(null);
  const lastLoadRef = useRef(0);
  const lastEventMsRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);

  const load = useCallback(async () => {
    abortRef.current?.abort();
    // Mark the attempt time up-front (not only on success). Otherwise an aborted
    // request never updates lastLoadRef, so the throttle keeps computing delay=0
    // and every incoming event immediately fires another load that aborts the
    // in-flight one — a self-sustaining cancel storm that starves setData.
    lastLoadRef.current = Date.now();
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      const response = await fetch(`${API_BASE_URL}/api${path}`, {
        cache: "no-store",
        signal: controller.signal,
      });
      if (!response.ok) return;
      setData((await response.json()) as T);
      lastLoadRef.current = Date.now();
      setUpdatedAt(new Date());
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      return;
    }
  }, [path]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    let closed = false;
    let socket: WebSocket | null = null;

    function scheduleLoad() {
      if (document.visibilityState !== "visible") return;
      if (timerRef.current !== null) return;
      const elapsed = Date.now() - lastLoadRef.current;
      const delay = Math.max(0, minIntervalMs - elapsed);
      timerRef.current = window.setTimeout(() => {
        timerRef.current = null;
        void load();
      }, delay);
    }

    function connect() {
      if (closed) return;
      socket = new WebSocket(realtimeUrl());
      socket.onopen = () => {
        const now = Date.now();
        lastEventMsRef.current = now;
        setEventAt(new Date(now));
        setConnected(true);
      };
      socket.onerror = () => setConnected(false);
      socket.onclose = () => {
        setConnected(false);
        if (!closed) window.setTimeout(connect, 3000);
      };
      socket.onmessage = (message) => {
        try {
          const now = Date.now();
          lastEventMsRef.current = now;
          setEventAt(new Date(now));
          const event = JSON.parse(message.data) as RealtimeEnvelope;
          if (shouldReload(event)) {
            scheduleLoad();
          }
        } catch {
          return;
        }
      };
    }

    function watchdog() {
      if (closed) return;
      const idleMs = Date.now() - lastEventMsRef.current;
      if (lastEventMsRef.current > 0 && idleMs > 15000) {
        setConnected(false);
        socket?.close();
      }
      watchdogRef.current = window.setTimeout(watchdog, 5000);
    }

    connect();
    watchdog();
    fallbackRef.current = window.setInterval(() => {
      if (document.visibilityState === "visible") {
        void load();
      }
    }, Math.max(5000, fallbackIntervalMs));
    return () => {
      closed = true;
      abortRef.current?.abort();
      socket?.close();
      if (timerRef.current !== null) {
        window.clearTimeout(timerRef.current);
      }
      if (watchdogRef.current !== null) {
        window.clearTimeout(watchdogRef.current);
      }
      if (fallbackRef.current !== null) {
        window.clearInterval(fallbackRef.current);
      }
    };
  }, [fallbackIntervalMs, load, minIntervalMs, shouldReload]);

  return { data, connected, eventAt, updatedAt, reload: load, setData };
}
