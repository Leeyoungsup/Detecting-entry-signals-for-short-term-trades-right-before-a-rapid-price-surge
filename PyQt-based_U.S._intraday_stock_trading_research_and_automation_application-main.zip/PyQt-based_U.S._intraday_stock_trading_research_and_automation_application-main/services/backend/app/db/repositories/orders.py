from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.db import models
from app.domain.models import Fill, OrderEvent, OrderRequest


class PaperOrderRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def record_order_lifecycle(
        self,
        *,
        client_order_id: str,
        request: OrderRequest,
        final_state: str,
        events: list[OrderEvent],
        fill: Fill | None,
        market_snapshot: dict,
        closed_trades: list[dict] | None = None,
    ) -> None:
        order = (
            self.db.query(models.Order)
            .filter(models.Order.client_order_id == client_order_id)
            .one_or_none()
        )
        if order is None:
            order = models.Order(
                client_order_id=client_order_id,
                mode=request.mode,
                symbol=request.symbol.upper(),
                side=request.side.lower(),
                order_type=request.order_type,
                quantity=request.quantity,
                limit_price=request.limit_price,
                state=final_state,
                broker_order_id=None,
                broker_original_order_id=None,
                risk_snapshot=_json_dict(market_snapshot.get("risk_preview")),
                reject_reason=None if final_state not in {"REJECTED", "ERROR", "EXPIRED"} else events[-1].message,
            )
            self.db.add(order)
            self.db.flush()
        else:
            order.state = final_state
            order.reject_reason = None if final_state not in {"REJECTED", "ERROR", "EXPIRED"} else events[-1].message

        for event in events:
            self.db.add(
                models.OrderEvent(
                    order_id=order.id,
                    previous_state=str(event.previous_state) if event.previous_state else None,
                    new_state=str(event.new_state),
                    source=event.source,
                    message=event.message,
                    payload=event.model_dump(mode="json"),
                )
            )

        if fill is not None:
            self.db.add(
                models.Fill(
                    order_id=order.id,
                    symbol=fill.symbol.upper(),
                    quantity=fill.quantity,
                    price=fill.price,
                    slippage_bps=fill.slippage_bps,
                    broker_fill_id=fill.broker_fill_id,
                )
            )

        for trade in closed_trades or []:
            self.db.add(
                models.ClosedTrade(
                    position_key=_to_str(trade.get("position_key")),
                    symbol=str(trade.get("symbol") or "").upper(),
                    strategy_name=_to_str(trade.get("strategy_name")),
                    parameter_set_id=_to_str(trade.get("parameter_set_id")),
                    entry_mode=_to_str(trade.get("entry_mode")),
                    quantity=_to_float(trade.get("quantity")),
                    entry_price=_to_float(trade.get("entry_price")),
                    exit_price=_to_float(trade.get("exit_price")),
                    gross_pnl_usd=_to_float(trade.get("gross_pnl_usd")),
                    net_pnl_usd=_to_float(trade.get("net_pnl_usd")),
                    fees_usd=_to_float(trade.get("fees_usd")),
                    exit_reason=_to_str(trade.get("exit_reason")),
                    mode=str(trade.get("mode") or "internal_paper"),
                    entry_snapshot=_json_dict(trade.get("entry_snapshot")),
                    exit_snapshot=_json_dict(trade.get("exit_snapshot")),
                    payload=trade,
                )
            )

        self.db.commit()

    def rollback_quietly(self) -> None:
        try:
            self.db.rollback()
        except SQLAlchemyError:
            pass


def _json_dict(value: object) -> dict:
    return value if isinstance(value, dict) else {}


def _to_float(value: object) -> float:
    try:
        return float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _to_str(value: object) -> str | None:
    if value in (None, ""):
        return None
    return str(value)
