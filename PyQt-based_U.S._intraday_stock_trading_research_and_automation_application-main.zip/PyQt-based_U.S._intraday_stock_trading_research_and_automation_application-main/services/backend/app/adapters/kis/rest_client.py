from typing import Literal

import httpx

from app.adapters.kis.auth import KisAuthClient
from app.adapters.kis.errors import KisApiResponseError
from app.core.config import Settings, get_settings


class KisRestClient:
    def __init__(self, settings: Settings | None = None, auth_client: KisAuthClient | None = None) -> None:
        self.settings = settings or get_settings()
        self.auth_client = auth_client or KisAuthClient(self.settings)

    @property
    def base_url(self) -> str:
        return (
            self.settings.kis_rest_base_url_live
            if self.settings.kis_environment == "live"
            else self.settings.kis_rest_base_url_mock
        )

    def request_sync(
        self,
        *,
        tr_id: str,
        path: str,
        method: Literal["GET", "POST"] = "GET",
        payload: dict | None = None,
        tr_cont: str = "",
        require_token: bool = True,
        include_headers: bool = False,
    ) -> dict:
        token = self.auth_client.get_access_token_sync() if require_token else None
        headers = {
            "Content-Type": "application/json",
            "Accept": "text/plain",
            "charset": "UTF-8",
            "User-Agent": self.settings.kis_user_agent,
            "appkey": self.settings.kis_app_key or "",
            "appsecret": self.settings.kis_app_secret or "",
            "tr_id": tr_id,
            "custtype": "P",
            "tr_cont": tr_cont,
        }
        if token:
            headers["authorization"] = f"Bearer {token.access_token}"

        url = f"{self.base_url}{path}"
        if method == "POST":
            response = httpx.post(url, headers=headers, json=payload or {}, timeout=10.0)
        else:
            response = httpx.get(url, headers=headers, params=payload or {}, timeout=10.0)

        data = _json_or_empty(response)
        if response.status_code != 200:
            raise KisApiResponseError(
                status_code=response.status_code,
                message=data.get("msg1") or response.text,
                payload=data,
            )
        if data.get("rt_cd") not in (None, "0"):
            raise KisApiResponseError(
                status_code=response.status_code,
                message=data.get("msg1") or "KIS API 응답 오류",
                payload=data,
            )
        if include_headers:
            data["_response_headers"] = {
                "tr_cont": response.headers.get("tr_cont", ""),
            }
        return data

    async def request(self, *, tr_id: str, path: str, method: str = "GET", payload: dict | None = None) -> dict:
        return self.request_sync(tr_id=tr_id, path=path, method=method, payload=payload)


def _json_or_empty(response: httpx.Response) -> dict:
    try:
        return response.json()
    except ValueError:
        return {}
