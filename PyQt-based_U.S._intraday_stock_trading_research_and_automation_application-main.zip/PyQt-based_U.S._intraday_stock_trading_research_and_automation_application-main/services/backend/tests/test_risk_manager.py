from app.services.risk_manager import RiskManager


def test_preview_long_entry_caps_notional_by_account_limit() -> None:
    decision = RiskManager().preview_long_entry(
        account_equity_usd=2_000,
        entry_price=10,
        stop_loss_price=9.90,
        risk_per_trade_pct=0.002,
        max_notional_per_trade_pct=0.15,
    )

    assert decision.allowed is True
    assert decision.risk_amount_usd == 4
    assert decision.max_notional_usd == 300
    assert decision.quantity == 30
