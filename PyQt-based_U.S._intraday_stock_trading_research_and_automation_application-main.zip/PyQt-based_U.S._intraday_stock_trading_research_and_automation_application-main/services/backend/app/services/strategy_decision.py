from __future__ import annotations

from dataclasses import dataclass, field


EMERGENCY_EXIT_REASONS = {
    "stop_loss",
    "stop_loss_confirmed",
    "hard_stop_loss",
    "rapid_stop_loss",
    "structure_stop_loss",
    "liquidity_stop_loss",
    "structure_or_final_stop",
}

PROFIT_EXIT_REASONS = {
    "partial_take_profit",
    "bb_mid_partial_take_profit",
    "take_profit",
    "spread_widen_exit",
    "high_failure_exit",
    "time_exit",
}


@dataclass(frozen=True)
class EntryFillGateConfig:
    entry_slippage_pct: float
    max_chase_pct: float
    min_price_usd: float = 0.0
    runner_negative_chase_pct: float | None = None


@dataclass(frozen=True)
class EntryFillGateDecision:
    allowed: bool
    reason: str | None = None
    execution_price: float | None = None
    raw_ask: float | None = None
    spread_pct: float | None = None
    chase_pct: float | None = None
    payload: dict = field(default_factory=dict)


@dataclass(frozen=True)
class TrailingAdvanceResult:
    high_watermark: float
    trailing_stop_price: float | None
    trailing_active: bool
    trailing_pct: float


@dataclass(frozen=True)
class ExitDecisionConfig:
    partial_exit_fraction: float
    dynamic_take_profit_enabled: bool
    partial_exit_requires_weakness: bool
    high_failure_exit_enabled: bool
    break_even_activation_pct: float
    trailing_activation_pct: float
    take_profit_requires_weakness: bool
    exit_on_vwap_ema_break: bool
    vwap_ema_break_min_hold_seconds: float
    vwap_ema_break_min_loss_pct: float
    time_exit_enabled: bool
    time_exit_seconds: float
    stop_loss_hold_enabled: bool
    stop_loss_hold_max_seconds: float
    max_stop_loss_pct: float
    stop_loss_deep_break_pct: float
    stop_loss_rapid_drop_pct: float
    strategy_min_trade_strength_for_entry: float
    strategy_max_sell_pressure_for_entry: float


@dataclass(frozen=True)
class ExitDecisionPosition:
    quantity: float
    average_price: float
    opened_elapsed_seconds: float
    stop_loss_price: float | None = None
    take_profit_price: float | None = None
    partial_take_profit_price: float | None = None
    partial_exit_done: bool = False
    trailing_activation_price: float | None = None
    stop_loss_candidate_elapsed_seconds: float | None = None


@dataclass(frozen=True)
class ExitDecisionIndicators:
    ema9: float | None = None
    ema20: float | None = None
    vwap: float | None = None
    bb_mid: float | None = None
    bb_lower: float | None = None


@dataclass(frozen=True)
class StopLossDecisionState:
    action: str = "none"
    hold_reason: str | None = None
    payload: dict = field(default_factory=dict)


@dataclass(frozen=True)
class ExitDecisionResult:
    reason: str | None
    quantity: float
    stop_loss_state: StopLossDecisionState = field(default_factory=StopLossDecisionState)


@dataclass(frozen=True)
class DynamicTakeProfitConfig:
    enabled: bool
    default_take_profit_pct: float
    dynamic_trailing_normal_pct: float
    dynamic_trailing_wide_pct: float
    max_exit_spread_pct: float | None = None


def is_runner_strategy_name(strategy_name: str | None) -> bool:
    name = strategy_name or ""
    return "Runner" in name or "Continuation" in name or "EMA9 Ride" in name


def evaluate_entry_fill_gate(
    *,
    bid: float | None,
    ask: float | None,
    last: float | None,
    spread_pct: float | None,
    max_spread_pct: float | None,
    signal_close: float | None,
    strategy_name: str | None,
    config: EntryFillGateConfig,
) -> EntryFillGateDecision:
    raw_ask = ask or last
    effective_spread_pct = spread_pct
    if effective_spread_pct is None and bid is not None and ask is not None and ask > bid:
        midpoint = (ask + bid) / 2
        effective_spread_pct = (ask - bid) / midpoint * 100 if midpoint > 0 else 0.0

    payload = {
        "bid": bid,
        "ask": ask,
        "last": last,
        "spread_pct": effective_spread_pct,
        "max_spread_pct": max_spread_pct,
    }
    if (
        effective_spread_pct is not None
        and max_spread_pct is not None
        and effective_spread_pct > max_spread_pct
    ):
        return EntryFillGateDecision(False, "spread_too_wide", raw_ask=raw_ask, spread_pct=effective_spread_pct, payload=payload)

    if raw_ask is None or raw_ask <= 0:
        return EntryFillGateDecision(False, "missing_ask_or_last", raw_ask=raw_ask, spread_pct=effective_spread_pct, payload=payload)

    execution_price = raw_ask * (1 + max(0.0, config.entry_slippage_pct))
    if signal_close is not None and signal_close > 0:
        chase_pct = (raw_ask - signal_close) / signal_close
        payload = {**payload, "signal_close": signal_close, "chase_pct": chase_pct, "max_chase_pct": config.max_chase_pct}
        if chase_pct > config.max_chase_pct:
            return EntryFillGateDecision(
                False,
                "price_chase_too_far",
                execution_price=execution_price,
                raw_ask=raw_ask,
                spread_pct=effective_spread_pct,
                chase_pct=chase_pct,
                payload=payload,
            )
        if (
            config.runner_negative_chase_pct is not None
            and is_runner_strategy_name(strategy_name)
            and chase_pct < -abs(config.runner_negative_chase_pct)
        ):
            return EntryFillGateDecision(
                False,
                "runner_signal_failed_before_fill",
                execution_price=execution_price,
                raw_ask=raw_ask,
                spread_pct=effective_spread_pct,
                chase_pct=chase_pct,
                payload=payload,
            )

    if config.min_price_usd > 0 and execution_price < config.min_price_usd:
        return EntryFillGateDecision(
            False,
            "below_min_price",
            execution_price=execution_price,
            raw_ask=raw_ask,
            spread_pct=effective_spread_pct,
            payload={**payload, "execution_price": execution_price, "min_price_usd": config.min_price_usd},
        )

    return EntryFillGateDecision(
        True,
        execution_price=execution_price,
        raw_ask=raw_ask,
        spread_pct=effective_spread_pct,
        chase_pct=payload.get("chase_pct"),
        payload={**payload, "execution_price": execution_price},
    )


def compute_structure_stop_price(
    lows: list[float | None],
    entry_price: float,
    *,
    final_stop_pct: float,
    structure_stop_buffer: float,
) -> float:
    valid_lows = [low for low in lows if low is not None and low > 0]
    structure = min(valid_lows) * (1 - structure_stop_buffer) if valid_lows else 0.0
    final = entry_price * (1 - final_stop_pct)
    return max(structure, final) if structure > 0 else final


def ohlcv_spread_proxy_fraction(
    *,
    range_pct: float | None,
    close: float | None,
    volume: float | None = None,
    notional: float | None = None,
    trade_count: float | None = None,
) -> float:
    range_fraction = max(0.0, (range_pct or 0.0) / 100.0)
    proxy = range_fraction * 0.08
    implied_notional = notional
    if implied_notional is None and close is not None and volume is not None:
        implied_notional = close * volume
    if implied_notional is not None:
        if implied_notional >= 1_000_000:
            proxy *= 0.65
        elif implied_notional >= 300_000:
            proxy *= 0.80
        elif implied_notional < 50_000:
            proxy *= 1.25
    if trade_count is not None:
        if trade_count >= 300:
            proxy *= 0.85
        elif trade_count > 0 and trade_count < 25:
            proxy *= 1.15
    return max(0.002, min(0.02, proxy))


def advance_trailing_stop(
    *,
    entry_price: float,
    current_price: float,
    high_watermark: float | None,
    trailing_stop_price: float | None,
    activation_price: float | None,
    activation_pct: float,
    trailing_pct: float,
    break_even_activation_pct: float | None = None,
    break_even_lock_pct: float = 0.0,
) -> TrailingAdvanceResult:
    high = max(high_watermark or entry_price, current_price)
    stop = trailing_stop_price
    if break_even_activation_pct is not None and current_price >= entry_price * (1 + break_even_activation_pct):
        break_even_stop = entry_price * (1 + break_even_lock_pct)
        stop = max(stop or break_even_stop, break_even_stop)

    trigger_price = activation_price if activation_price is not None else entry_price * (1 + activation_pct)
    trailing_active = high >= trigger_price
    if trailing_active:
        candidate = high * (1 - trailing_pct)
        stop = max(stop or candidate, candidate)
    return TrailingAdvanceResult(
        high_watermark=high,
        trailing_stop_price=stop,
        trailing_active=trailing_active,
        trailing_pct=trailing_pct,
    )


def choose_dynamic_trailing_pct(
    momentum_state: dict,
    *,
    dynamic_take_profit_enabled: bool,
    default_pct: float,
    tight_pct: float,
    normal_pct: float,
    wide_pct: float,
) -> float:
    if not dynamic_take_profit_enabled:
        return default_pct
    profile = momentum_state.get("dynamic_exit_profile") if isinstance(momentum_state.get("dynamic_exit_profile"), dict) else {}
    profile_trailing = _as_float(profile.get("trailing_stop_pct"))
    base = profile_trailing if profile_trailing is not None and profile_trailing > 0 else default_pct
    if momentum_state.get("runner"):
        return max(base, wide_pct)
    if momentum_state.get("strong"):
        return max(base, normal_pct)
    if momentum_state.get("weak"):
        return min(base, tight_pct)
    return base


def update_dynamic_take_profit_target(
    *,
    average_price: float,
    quantity: float,
    current_price: float,
    high_watermark: float,
    take_profit_price: float | None,
    previous_dynamic_take_profit_price: float | None,
    profit_floor: float,
    momentum_state: dict,
    trailing_pct: float,
    config: DynamicTakeProfitConfig,
) -> dict | None:
    if not config.enabled:
        return None
    if quantity <= 0 or average_price <= 0:
        return None

    base_target = take_profit_price or average_price * (1 + config.default_take_profit_pct)
    previous_target = previous_dynamic_take_profit_price or base_target
    target = max(previous_target, profit_floor)
    reason = "neutral_keep_target"
    action = "hold"

    strong = bool(momentum_state.get("strong"))
    runner = bool(momentum_state.get("runner"))
    weak = bool(momentum_state.get("weak"))
    spread_widened = bool(momentum_state.get("spread_widened"))

    if spread_widened:
        if current_price >= profit_floor:
            target = max(profit_floor, min(target, current_price))
            reason = "spread_widened_exit_priority"
            action = "exit_priority"
        else:
            target = max(profit_floor, min(target, base_target))
            reason = "spread_widened_wait_profit_floor"
            action = "lower_to_profit_floor"
    elif runner:
        extension_pct = max(config.dynamic_trailing_wide_pct, trailing_pct)
        target = max(target, base_target, high_watermark * (1 + extension_pct * 0.5), profit_floor)
        reason = "runner_buy_dominance_raise_target"
        action = "raise"
    elif strong:
        extension_pct = max(config.dynamic_trailing_normal_pct, trailing_pct)
        target = max(target, base_target, high_watermark * (1 + extension_pct * 0.25), profit_floor)
        reason = "buy_dominance_hold_or_raise"
        action = "hold_or_raise"
    elif weak:
        if current_price >= profit_floor:
            target = max(profit_floor, min(target, current_price))
            reason = "sell_dominance_lower_target"
            action = "lower_or_exit_candidate"
        else:
            target = max(profit_floor, min(target, base_target))
            reason = "sell_dominance_wait_profit_floor"
            action = "lower_to_profit_floor"
    else:
        target = max(profit_floor, min(target, max(base_target, high_watermark * (1 + trailing_pct * 0.25))))

    spread_exit_priority = spread_widened and current_price >= profit_floor
    momentum_state["spread_exit_priority"] = spread_exit_priority
    momentum_state["dynamic_take_profit_action"] = action
    return {
        "price": target,
        "previous_price": previous_target,
        "base_price": base_target,
        "profit_floor": profit_floor,
        "reason": reason,
        "action": action,
        "spread_exit_priority": spread_exit_priority,
        "spread_pct": momentum_state.get("execution_spread_pct"),
        "max_exit_spread_pct": config.max_exit_spread_pct,
        "trade_strength": momentum_state.get("trade_strength"),
        "sell_pressure": momentum_state.get("sell_pressure"),
        "flow_volume_velocity_10s": momentum_state.get("flow_volume_velocity_10s"),
    }


def evaluate_exit_decision(
    *,
    current_price: float,
    position: ExitDecisionPosition,
    indicators: ExitDecisionIndicators,
    high_watermark: float,
    trailing_stop_price: float | None,
    momentum_state: dict,
    high_failure_count: int,
    full_profit_floor: float,
    partial_profit_floor: float,
    config: ExitDecisionConfig,
) -> ExitDecisionResult:
    full_quantity = float(position.quantity)
    weakness_confirmed = bool(momentum_state.get("weak"))
    strength_confirmed = bool(momentum_state.get("strong"))
    partial_exit_enabled = config.partial_exit_fraction > 0
    partial_quantity = max(1.0, int(full_quantity * config.partial_exit_fraction)) if partial_exit_enabled else 0.0

    stop_result = evaluate_stop_loss_decision(
        current_price=current_price,
        position=position,
        momentum_state=momentum_state,
        config=config,
    )
    if stop_result.reason:
        return ExitDecisionResult(stop_result.reason, full_quantity, stop_result.stop_loss_state)
    if stop_result.quantity == -1:
        return ExitDecisionResult(None, 0.0, stop_result.stop_loss_state)

    trailing_active = (
        trailing_stop_price is not None
        and high_watermark >= (position.trailing_activation_price or position.average_price * (1 + config.trailing_activation_pct))
        and trailing_stop_price >= position.average_price
    )
    runner_mode = bool(momentum_state.get("runner"))
    runner_full_exit_confirmed = bool(momentum_state.get("runner_full_exit_confirmed"))
    runner_emergency_exit = bool(momentum_state.get("runner_emergency_exit"))
    if trailing_active and current_price <= trailing_stop_price:
        if runner_mode and not (runner_full_exit_confirmed or runner_emergency_exit):
            return ExitDecisionResult(None, 0.0, stop_result.stop_loss_state)
        if weakness_confirmed or momentum_state.get("chart_profit_weakness") or momentum_state.get("spread_widened"):
            return ExitDecisionResult("trailing_stop", full_quantity, stop_result.stop_loss_state)
    if (
        momentum_state.get("spread_exit_priority")
        and current_price >= full_profit_floor
        and not strength_confirmed
        and (weakness_confirmed or momentum_state.get("chart_profit_weakness"))
    ):
        if runner_mode and not runner_full_exit_confirmed:
            return ExitDecisionResult(None, 0.0, stop_result.stop_loss_state)
        return ExitDecisionResult("spread_widen_exit", full_quantity, stop_result.stop_loss_state)
    if (
        partial_exit_enabled
        and not position.partial_exit_done
        and position.partial_take_profit_price is not None
        and current_price >= position.partial_take_profit_price
        and current_price >= partial_profit_floor
        and full_quantity > 1
        and (
            not config.dynamic_take_profit_enabled
            or not config.partial_exit_requires_weakness
            or weakness_confirmed
            or runner_mode
        )
    ):
        return ExitDecisionResult("partial_take_profit", partial_quantity, stop_result.stop_loss_state)
    if (
        partial_exit_enabled
        and not position.partial_exit_done
        and indicators.bb_mid is not None
        and current_price >= indicators.bb_mid
        and current_price >= partial_profit_floor
        and full_quantity > 1
        and (
            not config.dynamic_take_profit_enabled
            or not config.partial_exit_requires_weakness
            or weakness_confirmed
        )
    ):
        return ExitDecisionResult("bb_mid_partial_take_profit", partial_quantity, stop_result.stop_loss_state)
    if (
        config.high_failure_exit_enabled
        and high_watermark >= position.average_price * (1 + config.break_even_activation_pct)
        and current_price >= full_profit_floor
        and high_failure_count >= 2
        and not strength_confirmed
    ):
        if runner_mode and not runner_full_exit_confirmed:
            return ExitDecisionResult(None, 0.0, stop_result.stop_loss_state)
        return ExitDecisionResult("high_failure_exit", full_quantity, stop_result.stop_loss_state)
    if (
        position.take_profit_price is not None
        and current_price >= position.take_profit_price
        and current_price >= full_profit_floor
        and (
            not config.dynamic_take_profit_enabled
            or not config.take_profit_requires_weakness
            or weakness_confirmed
        )
    ):
        if runner_mode and not runner_full_exit_confirmed:
            return ExitDecisionResult(None, 0.0, stop_result.stop_loss_state)
        return ExitDecisionResult("take_profit", full_quantity, stop_result.stop_loss_state)
    loss_pct = (position.average_price - current_price) / position.average_price if position.average_price > 0 else 0.0
    if (
        config.exit_on_vwap_ema_break
        and position.opened_elapsed_seconds >= config.vwap_ema_break_min_hold_seconds
        and loss_pct >= config.vwap_ema_break_min_loss_pct
        and vwap_ema_break(current_price, indicators)
    ):
        return ExitDecisionResult("vwap_ema_break", full_quantity, stop_result.stop_loss_state)
    if (
        config.time_exit_enabled
        and position.opened_elapsed_seconds >= config.time_exit_seconds
        and not strength_confirmed
        and current_price >= full_profit_floor
        and (weakness_confirmed or momentum_state.get("chart_profit_weakness"))
    ):
        if runner_mode and not runner_full_exit_confirmed:
            return ExitDecisionResult(None, 0.0, stop_result.stop_loss_state)
        return ExitDecisionResult("time_exit", full_quantity, stop_result.stop_loss_state)
    return ExitDecisionResult(None, 0.0, stop_result.stop_loss_state)


def evaluate_stop_loss_decision(
    *,
    current_price: float,
    position: ExitDecisionPosition,
    momentum_state: dict,
    config: ExitDecisionConfig,
) -> ExitDecisionResult:
    if position.stop_loss_price is None:
        return ExitDecisionResult(None, 0.0, StopLossDecisionState(action="clear"))
    if current_price > position.stop_loss_price:
        return ExitDecisionResult(None, 0.0, StopLossDecisionState(action="clear"))

    candidate_elapsed = position.stop_loss_candidate_elapsed_seconds
    action = "hold" if candidate_elapsed is not None else "set"
    elapsed = candidate_elapsed or 0.0
    loss_pct = (position.average_price - current_price) / position.average_price if position.average_price > 0 else 0.0
    hard_stop_price = position.average_price * (1 - config.max_stop_loss_pct)
    deep_break = current_price <= position.stop_loss_price * (1 - config.stop_loss_deep_break_pct)
    rapid_drop = rapid_drop_for_stop(momentum_state, loss_pct=loss_pct, config=config)
    liquidity_break = liquidity_break_for_stop(momentum_state, config=config)

    state = {
        "state": "candidate",
        "loss_pct": loss_pct,
        "stop_loss_price": position.stop_loss_price,
        "hard_stop_price": hard_stop_price,
        "elapsed_seconds": elapsed,
        "hold_max_seconds": config.stop_loss_hold_max_seconds,
        "deep_break": deep_break,
        "rapid_drop": rapid_drop,
        "liquidity_break": liquidity_break,
        "hold_allowed": False,
    }

    if current_price <= hard_stop_price:
        state["state"] = "hard_stop"
        return ExitDecisionResult("hard_stop_loss", 0.0, StopLossDecisionState(action="clear", payload=state))
    if rapid_drop:
        state["state"] = "rapid_stop"
        return ExitDecisionResult("rapid_stop_loss", 0.0, StopLossDecisionState(action="clear", payload=state))
    if deep_break:
        state["state"] = "structure_break"
        return ExitDecisionResult("structure_stop_loss", 0.0, StopLossDecisionState(action="clear", payload=state))
    if liquidity_break:
        state["state"] = "liquidity_break"
        return ExitDecisionResult("liquidity_stop_loss", 0.0, StopLossDecisionState(action="clear", payload=state))

    hold_allowed, hold_reason = stop_loss_hold_allowed(momentum_state, config=config)
    state["hold_allowed"] = hold_allowed
    state["hold_reason"] = hold_reason
    if config.stop_loss_hold_enabled and hold_allowed and elapsed < config.stop_loss_hold_max_seconds:
        state["state"] = "hold"
        return ExitDecisionResult(None, -1.0, StopLossDecisionState(action=action, hold_reason=hold_reason, payload=state))

    state["state"] = "confirmed"
    return ExitDecisionResult("stop_loss_confirmed", 0.0, StopLossDecisionState(action="clear", payload=state))


def rapid_drop_for_stop(momentum_state: dict, *, loss_pct: float, config: ExitDecisionConfig) -> bool:
    drawdown_from_high = _as_float(momentum_state.get("drawdown_from_high_pct")) or 0.0
    chart_breakdown = bool(momentum_state.get("chart_breakdown"))
    order_flow_weak = bool(momentum_state.get("order_flow_weak"))
    return (
        loss_pct >= config.stop_loss_rapid_drop_pct
        and (chart_breakdown or order_flow_weak)
    ) or (
        chart_breakdown
        and order_flow_weak
        and drawdown_from_high >= config.stop_loss_rapid_drop_pct
    ) or (
        loss_pct >= config.stop_loss_rapid_drop_pct * 1.5
        or (
            drawdown_from_high >= config.stop_loss_rapid_drop_pct
            and chart_breakdown
        )
    )


def liquidity_break_for_stop(momentum_state: dict, *, config: ExitDecisionConfig) -> bool:
    sell_pressure = _normalize_ratio(_as_float(momentum_state.get("sell_pressure")))
    trade_strength = _normalize_percent(_as_float(momentum_state.get("trade_strength")))
    flow_velocity = _as_float(momentum_state.get("flow_volume_velocity_10s"))
    chart_breakdown = bool(momentum_state.get("chart_breakdown"))
    severe_sell_pressure = (
        sell_pressure is not None
        and sell_pressure >= min(0.9, config.strategy_max_sell_pressure_for_entry + 0.2)
        and (trade_strength is None or trade_strength < config.strategy_min_trade_strength_for_entry)
    )
    flow_dried = flow_velocity is not None and flow_velocity < 0.35
    return chart_breakdown and (severe_sell_pressure or flow_dried or bool(momentum_state.get("spread_widened")))


def stop_loss_hold_allowed(momentum_state: dict, *, config: ExitDecisionConfig) -> tuple[bool, str]:
    if not momentum_state.get("chart_breakdown"):
        return True, "chart_structure_holding"
    if momentum_state.get("spread_widened") and momentum_state.get("chart_breakdown"):
        return False, "spread_widened_with_chart_breakdown"
    trade_strength = _normalize_percent(_as_float(momentum_state.get("trade_strength")))
    sell_pressure = _normalize_ratio(_as_float(momentum_state.get("sell_pressure")))
    flow_velocity = _as_float(momentum_state.get("flow_volume_velocity_10s"))
    trade_strength_ok = trade_strength is None or trade_strength >= max(35.0, config.strategy_min_trade_strength_for_entry - 10)
    sell_pressure_ok = sell_pressure is None or sell_pressure <= min(0.75, config.strategy_max_sell_pressure_for_entry + 0.15)
    velocity_ok = flow_velocity is None or flow_velocity >= 0.6
    if trade_strength_ok and sell_pressure_ok and velocity_ok:
        return True, "order_flow_rebound_watch"
    return False, "order_flow_not_supportive"


def vwap_ema_break(current_price: float, indicators: ExitDecisionIndicators) -> bool:
    if indicators.vwap is None or indicators.ema20 is None:
        return False
    below_vwap = current_price < indicators.vwap
    below_ema20 = current_price < indicators.ema20
    ema_rollover = indicators.ema9 is not None and indicators.ema9 < indicators.ema20
    return below_vwap and (below_ema20 or ema_rollover)


def crossed_down(start: float, end: float, trigger: float | None) -> bool:
    return trigger is not None and start > trigger >= end


def bounded_stop_exit_price(
    exit_price: float,
    *,
    trigger_price: float | None,
    reason: str | None,
    stop_slippage_cap_pct: float,
) -> float:
    if exit_price <= 0 or not trigger_price or trigger_price <= 0:
        return exit_price
    if reason not in EMERGENCY_EXIT_REASONS and "stop" not in (reason or ""):
        return exit_price
    return max(exit_price, trigger_price * (1 - max(0.0, stop_slippage_cap_pct)))


def is_profit_exit_reason(reason: str | None) -> bool:
    return reason in PROFIT_EXIT_REASONS


def _as_float(value) -> float | None:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _normalize_percent(value: float | None) -> float | None:
    if value is not None and value <= 1:
        return value * 100
    return value


def _normalize_ratio(value: float | None) -> float | None:
    if value is not None and value > 1:
        return value / 100
    return value
