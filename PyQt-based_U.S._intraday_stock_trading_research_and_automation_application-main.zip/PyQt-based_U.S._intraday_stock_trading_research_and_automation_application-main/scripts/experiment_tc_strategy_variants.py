import importlib.util
import sys
from pathlib import Path


def load_replay_module():
    spec = importlib.util.spec_from_file_location("tc_replay", "scripts/replay_tc_shadow_strategies.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load replay module")
    module = importlib.util.module_from_spec(spec)
    sys.modules["tc_replay"] = module
    spec.loader.exec_module(module)
    return module


def summary(module, rows):
    portfolios = module.replay(rows)
    rows_out = [module.summary_row(portfolio) for portfolio in portfolios.values()]
    active = [row for row in rows_out if row["trades"]]
    return {
        "trades": sum(row["trades"] for row in active),
        "net": round(sum(row["net_pnl_usd"] for row in active), 4),
        "losses": sum(row["losses"] for row in active),
        "rows": active,
    }


def patch_dynamic_target(module, *, min_target: float, edge: float, spread_mult: float, add: float):
    original = module.dynamic_take_profit_fraction

    def dynamic(row, strategy=""):
        if any(name in strategy for name in ["Order Flow", "Liquidity"]):
            spread = module.spread_fraction(row)
            cost = module.estimated_roundtrip_cost_fraction(row)
            return max(min_target, cost + edge, spread * spread_mult + add)
        return original(row, strategy)

    module.dynamic_take_profit_fraction = dynamic


def patch_confirm_guards(module, *, order_bb: float, liq_bb: float, abs_bb: float, strict_spread: bool):
    def stable(rows, index):
        return module.spread_stable(rows, index) if strict_spread else not module.spread_widening(rows, index)

    def confirm_order_flow(rows, index):
        row = rows[index]
        return (
            module.bb_allowed(row, order_bb)
            and module.previous_low_holding(rows, index, 0.99)
            and stable(rows, index)
            and module.sell_pressure_decreasing(rows, index)
            and module.macd_not_deteriorating(rows, index)
            and module.above_ema9(row)
        )

    def confirm_liquidity_imbalance(rows, index):
        row = rows[index]
        return (
            module.bb_allowed(row, liq_bb)
            and module.previous_low_holding(rows, index, 0.99)
            and stable(rows, index)
            and module.sell_pressure_decreasing(rows, index)
            and (module.above_ema9(row) or module.above_vwap(row))
        )

    def confirm_absorption_breakout(rows, index):
        row = rows[index]
        return (
            module.bb_allowed(row, abs_bb)
            and module.previous_low_holding(rows, index, 0.985)
            and stable(rows, index)
            and module.sell_pressure_decreasing(rows, index)
            and module.macd_not_deteriorating(rows, index)
        )

    module.confirm_order_flow = confirm_order_flow
    module.confirm_liquidity_imbalance = confirm_liquidity_imbalance
    module.confirm_absorption_breakout = confirm_absorption_breakout


def run_variant(name, *, dynamic=None, guards=None):
    module = load_replay_module()
    rows = module.load_rows(Path("exports/tc_1m_enriched_2026-07-01_1720-1900_kst.csv"))
    if dynamic:
        patch_dynamic_target(module, **dynamic)
    if guards:
        patch_confirm_guards(module, **guards)
    result = summary(module, rows)
    print(f"\n{name}: trades={result['trades']} net={result['net']} losses={result['losses']}")
    for row in result["rows"]:
        print(
            f"  {row['strategy']}: trades={row['trades']} win={row['win_rate_pct']} "
            f"net={row['net_pnl_usd']} return={row['return_on_2000_pct']} pf={row['profit_factor']}"
        )


def main():
    run_variant("baseline")
    run_variant(
        "A_guard_only",
        guards={"order_bb": 1.15, "liq_bb": 1.12, "abs_bb": 1.20, "strict_spread": False},
    )
    run_variant(
        "B_guard_target_loose",
        dynamic={"min_target": 0.009, "edge": 0.0025, "spread_mult": 2.2, "add": 0.0035},
        guards={"order_bb": 1.15, "liq_bb": 1.12, "abs_bb": 1.20, "strict_spread": False},
    )
    run_variant(
        "C_guard_target_looser",
        dynamic={"min_target": 0.0085, "edge": 0.002, "spread_mult": 2.0, "add": 0.003},
        guards={"order_bb": 1.15, "liq_bb": 1.12, "abs_bb": 1.20, "strict_spread": False},
    )
    run_variant(
        "D_bb_loose_with_guards",
        dynamic={"min_target": 0.0085, "edge": 0.002, "spread_mult": 2.0, "add": 0.003},
        guards={"order_bb": 1.18, "liq_bb": 1.16, "abs_bb": 1.25, "strict_spread": False},
    )
    run_variant(
        "E_bb_loose_strict_spread",
        dynamic={"min_target": 0.0085, "edge": 0.002, "spread_mult": 2.0, "add": 0.003},
        guards={"order_bb": 1.18, "liq_bb": 1.16, "abs_bb": 1.25, "strict_spread": True},
    )
    run_variant(
        "F_target_looser_strict_spread_current_bb",
        dynamic={"min_target": 0.0085, "edge": 0.002, "spread_mult": 2.0, "add": 0.003},
        guards={"order_bb": 1.15, "liq_bb": 1.12, "abs_bb": 1.20, "strict_spread": True},
    )
    run_variant(
        "G_target_mid_strict_spread_loose_bb",
        dynamic={"min_target": 0.009, "edge": 0.0025, "spread_mult": 2.2, "add": 0.0035},
        guards={"order_bb": 1.18, "liq_bb": 1.16, "abs_bb": 1.25, "strict_spread": True},
    )


if __name__ == "__main__":
    main()
