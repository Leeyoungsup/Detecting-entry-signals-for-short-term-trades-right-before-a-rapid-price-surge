"use client";

import {
  Activity,
  ArrowDownCircle,
  ArrowUpCircle,
  CheckCircle2,
  Clock3,
  DollarSign,
  Flag,
  GitCommitHorizontal,
  ListChecks,
  ShieldCheck,
  TimerReset,
  Wallet,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { LiveStatus } from "@/components/live-status";
import { OrdersTestControls } from "@/components/orders-test-controls";
import { PageTitle } from "@/components/page-title";
import { StatusPill } from "@/components/status-pill";
import { API_BASE_URL } from "@/lib/api";

type OrderRow = {
  order_id: string;
  request: { symbol: string; side: string; quantity: number; limit_price?: number; order_type?: string; mode?: string };
  state: string;
  average_fill_price?: number | null;
  filled_quantity?: number;
  created_at?: string;
  updated_at?: string;
};

type PositionRow = {
  position_key?: string | null;
  symbol: string;
  strategy_name?: string | null;
  parameter_set_id?: string | null;
  entry_mode?: string | null;
  quantity: number;
  average_price: number;
  entry_fees_usd?: number | null;
  unrealized_pnl_usd?: number;
  mode: string;
  stop_loss_price?: number | null;
  take_profit_price?: number | null;
  dynamic_take_profit_price?: number | null;
  dynamic_take_profit_reason?: string | null;
  dynamic_take_profit_updated_at?: string | null;
  partial_take_profit_price?: number | null;
  trailing_stop_price?: number | null;
  high_watermark?: number | null;
  stop_loss_candidate_since?: string | null;
  stop_loss_hold_reason?: string | null;
  opened_at?: string;
};

type TimelineRow = {
  order_id: string;
  previous_state?: string | null;
  new_state: string;
  source: string;
  message?: string | null;
  occurred_at: string;
  payload?: Record<string, unknown>;
};

type ClosedTradeRow = {
  position_key?: string | null;
  symbol: string;
  strategy_name?: string | null;
  parameter_set_id?: string | null;
  entry_mode?: string | null;
  quantity: number;
  entry_price: number;
  exit_price: number;
  gross_pnl_usd: number;
  net_pnl_usd?: number | null;
  fees_usd?: number | null;
  exit_reason?: string;
  closed_at: string;
  mode: string;
  entry_snapshot?: Record<string, unknown>;
  exit_snapshot?: Record<string, unknown>;
};

type OrdersData = {
  mode?: string;
  paper_enabled?: boolean;
  message?: string;
  orders: OrderRow[];
  positions: PositionRow[];
  timeline: TimelineRow[];
  fills: unknown[];
  closed_trades: ClosedTradeRow[];
};

const fallback: OrdersData = { mode: "live", paper_enabled: false, orders: [], positions: [], timeline: [], fills: [], closed_trades: [] };

const orderRefreshEvents = new Set([
  "live.order_candidate",
  "live.order_blocked",
  "paper.order_event",
  "paper.exit_signal",
  "paper.exit_blocked",
  "paper.order_blocked",
  "paper.reset",
]);

function realtimeUrl() {
  return `${API_BASE_URL.replace(/^http/, "ws").replace(/\/$/, "")}/api/realtime/ws`;
}

export default function OrdersPage() {
  const [data, setData] = useState<OrdersData>(fallback);
  const [connected, setConnected] = useState(false);
  const [eventAt, setEventAt] = useState<Date | null>(null);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const refreshTimerRef = useRef<number | null>(null);
  const watchdogRef = useRef<number | null>(null);
  const fallbackTimerRef = useRef<number | null>(null);
  const lastEventMsRef = useRef(0);
  const ordersAbortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    void loadOrders();
  }, []);

  useEffect(() => {
    let closed = false;
    let socket: WebSocket | null = null;

    function scheduleLoad() {
      if (document.visibilityState !== "visible") return;
      if (refreshTimerRef.current !== null) return;
      refreshTimerRef.current = window.setTimeout(() => {
        refreshTimerRef.current = null;
        void loadOrders();
      }, 250);
    }

    function connect() {
      if (closed) return;
      socket = new WebSocket(realtimeUrl());
      socket.onopen = () => {
        const now = Date.now();
        lastEventMsRef.current = now;
        setEventAt(new Date(now));
        setConnected(true);
      };
      socket.onerror = () => setConnected(false);
      socket.onclose = () => {
        setConnected(false);
        if (!closed) window.setTimeout(connect, 3000);
      };
      socket.onmessage = (message) => {
        try {
          const now = Date.now();
          lastEventMsRef.current = now;
          setEventAt(new Date(now));
          const event = JSON.parse(message.data) as { event_type?: string; payload?: { event_type?: string } };
          const logEventType = event.payload?.event_type;
          if (event.event_type === "log.event" && logEventType && orderRefreshEvents.has(logEventType)) {
            scheduleLoad();
          }
        } catch {
          return;
        }
      };
    }

    function watchdog() {
      if (closed) return;
      const idleMs = Date.now() - lastEventMsRef.current;
      if (lastEventMsRef.current > 0 && idleMs > 15000) {
        setConnected(false);
        socket?.close();
      }
      watchdogRef.current = window.setTimeout(watchdog, 5000);
    }

    connect();
    watchdog();
    fallbackTimerRef.current = window.setInterval(() => {
      if (document.visibilityState === "visible") {
        void loadOrders();
      }
    }, 10000);
    return () => {
      closed = true;
      ordersAbortRef.current?.abort();
      socket?.close();
      if (refreshTimerRef.current !== null) {
        window.clearTimeout(refreshTimerRef.current);
      }
      if (watchdogRef.current !== null) {
        window.clearTimeout(watchdogRef.current);
      }
      if (fallbackTimerRef.current !== null) {
        window.clearInterval(fallbackTimerRef.current);
      }
    };
  }, []);

  async function loadOrders() {
    ordersAbortRef.current?.abort();
    const controller = new AbortController();
    ordersAbortRef.current = controller;
    try {
      const response = await fetch(`${API_BASE_URL}/api/orders`, { cache: "no-store", signal: controller.signal });
      if (!response.ok) return;
      setData((await response.json()) as OrdersData);
      setUpdatedAt(new Date());
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      return;
    }
  }

  const firstPositionSymbol = data.positions[0]?.symbol;
  const openOrders = data.orders.filter((order) => isOpenState(order.state));
  const closedPnl = data.closed_trades.reduce((sum, trade) => sum + closedTradeNetPnl(trade), 0);
  const fees = data.closed_trades.reduce((sum, trade) => sum + (trade.fees_usd ?? 0), 0);
  const exposure = data.positions.reduce((sum, position) => sum + position.quantity * position.average_price, 0);
  const wins = data.closed_trades.filter((trade) => closedTradeNetPnl(trade) > 0).length;
  const losses = data.closed_trades.filter((trade) => closedTradeNetPnl(trade) < 0).length;

  return (
    <>
      <PageTitle
        title="주문 타임라인"
        description="live/시뮬레이션 주문, 포지션, 자동 청산, 수수료 반영 손익, 상태 머신 흐름을 확인합니다."
        icon={<GitCommitHorizontal className="h-5 w-5" aria-hidden />}
        action={<LiveStatus connected={connected} eventAt={eventAt} updatedAt={updatedAt} />}
      />
      {data.paper_enabled !== false ? <OrdersTestControls firstPositionSymbol={firstPositionSymbol} onChanged={loadOrders} /> : null}

      <section className="space-y-5 p-6">
        <SummaryBar
          openOrders={openOrders.length}
          positions={data.positions.length}
          closedTrades={data.closed_trades.length}
          fills={data.fills.length}
          pnl={closedPnl}
          fees={fees}
          exposure={exposure}
          wins={wins}
          losses={losses}
        />

        <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_440px]">
          <main className="space-y-5">
            <PositionsPanel positions={data.positions} />
            <ClosedTradesPanel trades={data.closed_trades} />
          </main>
          <aside className="space-y-5">
            <OrdersPanel orders={data.orders} />
            <StateLegend />
          </aside>
        </div>

        <TimelinePanel rows={data.timeline} />
      </section>
    </>
  );
}

function SummaryBar({
  openOrders,
  positions,
  closedTrades,
  fills,
  pnl,
  fees,
  exposure,
  wins,
  losses,
}: {
  openOrders: number;
  positions: number;
  closedTrades: number;
  fills: number;
  pnl: number;
  fees: number;
  exposure: number;
  wins: number;
  losses: number;
}) {
  return (
    <section className="grid gap-3 md:grid-cols-3 xl:grid-cols-6">
      <SummaryCard icon={<ListChecks className="h-5 w-5" />} label="열린 주문" value={openOrders} tone={openOrders ? "warn" : "info"} />
      <SummaryCard icon={<Wallet className="h-5 w-5" />} label="보유 포지션" value={positions} tone={positions ? "ok" : "info"} />
      <SummaryCard icon={<CheckCircle2 className="h-5 w-5" />} label="체결 이벤트" value={fills} tone="info" />
      <SummaryCard icon={<Flag className="h-5 w-5" />} label="청산 거래" value={closedTrades} tone="info" />
      <SummaryCard icon={<DollarSign className="h-5 w-5" />} label="순손익" value={formatUsd(pnl)} tone={pnl >= 0 ? "ok" : "block"} />
      <SummaryCard icon={<ShieldCheck className="h-5 w-5" />} label="수수료/노출" value={`${formatUsd(fees)} / ${formatUsd(exposure)}`} tone="warn" detail={`승/패 ${wins}/${losses}`} />
    </section>
  );
}

function SummaryCard({ icon, label, value, tone, detail }: { icon: React.ReactNode; label: string; value: string | number; tone: Tone; detail?: string }) {
  return (
    <div className="rounded border border-line bg-white p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="text-xs font-medium text-zinc-500">{label}</div>
        <span className={toneText(tone)}>{icon}</span>
      </div>
      <div className="mt-3 truncate text-2xl font-bold text-ink">{value}</div>
      {detail ? <div className="mt-2 text-xs text-zinc-500">{detail}</div> : null}
    </div>
  );
}

function PositionsPanel({ positions }: { positions: PositionRow[] }) {
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="보유 포지션" icon={<Wallet className="h-5 w-5 text-info" />} />
      {positions.length ? (
        <div className="grid gap-px bg-line md:grid-cols-2">
          {positions.map((position) => (
            <PositionCard key={position.position_key ?? `${position.symbol}-${position.parameter_set_id ?? position.entry_mode ?? "manual"}`} position={position} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<Wallet className="h-8 w-8 text-zinc-400" />}
          title="열린 포지션 없음"
          text="테스트 매수 또는 전략 신호가 통과하면 여기에 손절, 익절, trailing 상태가 표시됩니다."
        />
      )}
    </section>
  );
}

function PositionCard({ position }: { position: PositionRow }) {
  const notional = position.quantity * position.average_price;
  return (
    <div className="bg-white p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="text-xl font-bold text-ink">{position.symbol}</div>
            {position.strategy_name ? <span className="rounded bg-blue-50 px-2 py-1 text-xs font-bold text-info ring-1 ring-blue-100">{position.strategy_name}</span> : null}
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            {position.mode} / {position.parameter_set_id ?? "manual"} / opened {position.opened_at ? formatDateTimeKst(position.opened_at) : "-"}
          </div>
        </div>
        <StatusPill status="NORMAL" />
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        <MiniMetric label="수량" value={formatNumber(position.quantity)} />
        <MiniMetric label="평균가" value={formatUsd(position.average_price)} />
        <MiniMetric label="금액" value={formatUsd(notional)} />
      </div>
      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        <ExitLevel label="손절" value={position.stop_loss_price} tone="block" />
        <ExitLevel label="부분익절" value={position.partial_take_profit_price} tone="ok" />
        <ExitLevel label="익절" value={position.take_profit_price} tone="ok" />
        <ExitLevel label="동적 익절" value={position.dynamic_take_profit_price} tone="info" detail={position.dynamic_take_profit_reason ?? undefined} />
        <ExitLevel label="Trailing" value={position.trailing_stop_price} tone="info" />
        <ExitLevel label="손절 관찰" value={null} tone={position.stop_loss_candidate_since ? "warn" : "info"} detail={position.stop_loss_candidate_since ? position.stop_loss_hold_reason ?? "관찰 중" : "대기 없음"} />
      </div>
      <div className="mt-3 flex items-center justify-between rounded bg-zinc-50 px-3 py-2 text-sm">
        <span className="text-zinc-500">진입 비용</span>
        <span className="font-semibold text-ink">{formatUsd(position.entry_fees_usd)}</span>
      </div>
    </div>
  );
}

function ExitLevel({ label, value, tone, detail }: { label: string; value?: number | null; tone: Tone; detail?: string }) {
  return (
    <div className="rounded border border-line px-3 py-2">
      <div className="text-xs text-zinc-500">{label}</div>
      <div className={`mt-1 font-bold ${toneText(tone)}`}>{formatUsd(value)}</div>
      {detail ? <div className="mt-1 truncate text-[11px] text-zinc-500">{detail}</div> : null}
    </div>
  );
}

function OrdersPanel({ orders }: { orders: OrderRow[] }) {
  const sorted = [...orders].reverse();
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="주문 상태" icon={<ListChecks className="h-5 w-5 text-info" />} />
      {sorted.length ? (
        <div className="divide-y divide-line">
          {sorted.slice(0, 12).map((order) => (
            <OrderItem key={order.order_id} order={order} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<ListChecks className="h-8 w-8 text-zinc-400" />}
          title="주문 없음"
          text="상단 테스트 매수로 CREATED부터 FILLED까지 상태 머신을 확인할 수 있습니다."
        />
      )}
    </section>
  );
}

function OrderItem({ order }: { order: OrderRow }) {
  const side = order.request.side === "buy" ? "매수" : "매도";
  const sideTone: Tone = order.request.side === "buy" ? "ok" : "block";
  return (
    <div className="px-5 py-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            {order.request.side === "buy" ? <ArrowUpCircle className="h-4 w-4 text-ok" /> : <ArrowDownCircle className="h-4 w-4 text-block" />}
            <span className="font-bold text-ink">{order.request.symbol}</span>
            <span className={`text-sm font-semibold ${toneText(sideTone)}`}>{side}</span>
          </div>
          <div className="mt-1 font-mono text-xs text-zinc-500">{shortId(order.order_id)}</div>
        </div>
        <StateBadge state={order.state} />
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        <MiniMetric label="수량" value={`${formatNumber(order.filled_quantity ?? 0)} / ${formatNumber(order.request.quantity)}`} />
        <MiniMetric label="지정가" value={formatUsd(order.request.limit_price)} />
        <MiniMetric label="평균가" value={formatUsd(order.average_fill_price)} />
      </div>
    </div>
  );
}

function ClosedTradesPanel({ trades }: { trades: ClosedTradeRow[] }) {
  const sorted = [...trades].reverse();
  return (
    <section className="overflow-hidden rounded border border-line bg-white">
      <PanelHeader title="청산 거래" icon={<Flag className="h-5 w-5 text-info" />} />
      {sorted.length ? (
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-zinc-50 text-xs text-zinc-500">
              <tr>
                <Header label="KST 시간" />
                <Header label="종목" />
                <Header label="수량" align="right" />
                <Header label="진입가" align="right" />
                <Header label="청산가" align="right" />
                <Header label="순손익" align="right" />
                <Header label="수수료" align="right" />
                <Header label="청산 사유" />
                <Header label="복기 요약" />
              </tr>
            </thead>
            <tbody>
              {sorted.map((trade, index) => {
                const pnl = closedTradeNetPnl(trade);
                return (
                  <tr key={`${trade.position_key ?? trade.symbol}-${trade.closed_at}-${index}`} className="border-t border-line">
                    <td className="whitespace-nowrap px-4 py-3 text-zinc-500">{formatDateTimeKst(trade.closed_at)}</td>
                    <td className="px-4 py-3">
                      <div className="font-bold text-ink">{trade.symbol}</div>
                      <div className="mt-1 text-xs text-zinc-500">{trade.strategy_name ?? trade.parameter_set_id ?? "-"}</div>
                    </td>
                    <td className="px-4 py-3 text-right">{formatNumber(trade.quantity)}</td>
                    <td className="px-4 py-3 text-right">{formatUsd(trade.entry_price)}</td>
                    <td className="px-4 py-3 text-right">{formatUsd(trade.exit_price)}</td>
                    <td className={`px-4 py-3 text-right font-bold ${pnl >= 0 ? "text-ok" : "text-block"}`}>{formatSignedUsd(pnl)}</td>
                    <td className="px-4 py-3 text-right text-zinc-500">{formatUsd(trade.fees_usd)}</td>
                    <td className="px-4 py-3">{exitReasonLabel(trade.exit_reason)}</td>
                    <td className="min-w-[360px] px-4 py-3">
                      <TradeReviewSummary trade={trade} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState
          icon={<Flag className="h-8 w-8 text-zinc-400" />}
          title="청산 거래 없음"
          text="자동 손절, 익절, 시간 청산, trailing stop 결과가 여기에 기록됩니다."
        />
      )}
    </section>
  );
}

function TradeReviewSummary({ trade }: { trade: ClosedTradeRow }) {
  const entry = trade.entry_snapshot ?? {};
  const exit = trade.exit_snapshot ?? {};
  const entryBb = objectValue(entry.bb_context);
  const exitBb = objectValue(exit.bb_context);
  const momentum = objectValue(exit.momentum_state);
  const entryZone = stringValue(entryBb.zone);
  const exitZone = stringValue(exitBb.zone);
  const highFailures = numberValue(momentum.high_failures);
  const volumeDecay = boolValue(momentum.volume_decay);
  const aboveVwap = boolValue(momentum.above_vwap);

  if (!Object.keys(entry).length && !Object.keys(exit).length) {
    return <span className="text-xs text-zinc-400">이전 거래는 차트 스냅샷 없음</span>;
  }

  return (
    <div className="space-y-1 text-xs leading-5 text-zinc-600">
      <div>
        <span className="font-semibold text-ink">진입</span>{" "}
        BB {entryZone || "-"}
      </div>
      <div>
        <span className="font-semibold text-ink">청산</span>{" "}
        BB {exitZone || "-"}, 고점실패 {highFailures ?? "-"}, 거래량감소 {boolLabel(volumeDecay)}, VWAP위 {boolLabel(aboveVwap)}
      </div>
    </div>
  );
}

function TimelinePanel({ rows }: { rows: TimelineRow[] }) {
  const sorted = [...rows].reverse();
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="상태 머신 타임라인" icon={<GitCommitHorizontal className="h-5 w-5 text-info" />} />
      {sorted.length ? (
        <div className="divide-y divide-line">
          {sorted.slice(0, 80).map((row, index) => (
            <TimelineItem key={`${row.order_id}-${row.new_state}-${index}`} row={row} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<TimerReset className="h-8 w-8 text-zinc-400" />}
          title="타임라인 이벤트 없음"
          text="주문이 생성되면 CREATED, ACKNOWLEDGED, FILLED, CANCELLED 같은 상태 전이가 시간순으로 표시됩니다."
        />
      )}
    </section>
  );
}

function TimelineItem({ row }: { row: TimelineRow }) {
  return (
    <div className="grid gap-3 px-5 py-4 md:grid-cols-[180px_1fr_180px] md:items-center">
      <div className="flex items-center gap-2 text-sm text-zinc-500">
        <Clock3 className="h-4 w-4" />
        {formatDateTimeKst(row.occurred_at)}
      </div>
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-xs text-zinc-500">{shortId(row.order_id)}</span>
          <StateTransition previous={row.previous_state} next={row.new_state} />
        </div>
        <div className="mt-1 text-sm text-zinc-600">{row.message || "-"}</div>
      </div>
      <div className="justify-self-start md:justify-self-end">
        <span className="rounded bg-zinc-50 px-2 py-1 text-xs font-semibold text-zinc-600 ring-1 ring-zinc-200">{row.source}</span>
      </div>
    </div>
  );
}

function StateTransition({ previous, next }: { previous?: string | null; next: string }) {
  return (
    <span className="inline-flex items-center gap-2 text-sm font-bold text-ink">
      {previous ? <StateBadge state={previous} compact /> : null}
      {previous ? <span className="text-zinc-400">→</span> : null}
      <StateBadge state={next} />
    </span>
  );
}

function StateLegend() {
  const states = ["CREATED", "ACKNOWLEDGED", "FILLED", "PARTIALLY_FILLED", "CANCELLED", "REJECTED"];
  return (
    <section className="rounded border border-line bg-white">
      <PanelHeader title="상태 설명" icon={<Activity className="h-5 w-5 text-info" />} />
      <div className="space-y-2 p-5">
        {states.map((state) => (
          <div key={state} className="flex items-center justify-between gap-3 rounded bg-zinc-50 px-3 py-2 text-sm">
            <StateBadge state={state} />
            <span className="text-right text-xs text-zinc-500">{stateDescription(state)}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function StateBadge({ state, compact = false }: { state: string; compact?: boolean }) {
  const tone = stateTone(state);
  return (
    <span className={`${compact ? "px-1.5 py-0.5" : "px-2 py-1"} inline-flex rounded text-xs font-bold ring-1 ${badgeClass(tone)}`}>
      {state}
    </span>
  );
}

function MiniMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded bg-zinc-50 px-3 py-2">
      <div className="text-xs text-zinc-500">{label}</div>
      <div className="mt-1 truncate text-sm font-bold text-ink">{value}</div>
    </div>
  );
}

function Header({ label, align = "left" }: { label: string; align?: "left" | "right" }) {
  return <th className={`whitespace-nowrap px-4 py-3 font-semibold ${align === "right" ? "text-right" : ""}`}>{label}</th>;
}

function PanelHeader({ title, icon }: { title: string; icon: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-line px-5 py-4">
      <h2 className="text-base font-semibold text-ink">{title}</h2>
      {icon}
    </div>
  );
}

function EmptyState({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="flex min-h-56 flex-col items-center justify-center px-6 py-10 text-center">
      {icon}
      <div className="mt-3 text-base font-semibold text-ink">{title}</div>
      <div className="mt-2 max-w-md text-sm leading-6 text-zinc-500">{text}</div>
    </div>
  );
}

type Tone = "ok" | "warn" | "block" | "info";

function toneText(tone: Tone) {
  return {
    ok: "text-ok",
    warn: "text-warn",
    block: "text-block",
    info: "text-info",
  }[tone];
}

function badgeClass(tone: Tone) {
  return {
    ok: "bg-emerald-50 text-ok ring-emerald-100",
    warn: "bg-amber-50 text-warn ring-amber-100",
    block: "bg-red-50 text-block ring-red-100",
    info: "bg-blue-50 text-info ring-blue-100",
  }[tone];
}

function stateTone(state: string): Tone {
  if (["FILLED", "ACKNOWLEDGED", "REPLACED"].includes(state)) return "ok";
  if (["CREATED", "RISK_CHECKED", "SUBMITTED", "PARTIALLY_FILLED", "CANCEL_REQUESTED", "REPLACE_REQUESTED"].includes(state)) return "warn";
  if (["REJECTED", "ERROR", "UNKNOWN_RECONCILE_REQUIRED"].includes(state)) return "block";
  return "info";
}

function stateDescription(state: string) {
  const labels: Record<string, string> = {
    CREATED: "주문 요청 생성",
    ACKNOWLEDGED: "브로커 접수",
    FILLED: "전체 체결",
    PARTIALLY_FILLED: "일부 체결",
    CANCELLED: "취소 완료",
    REJECTED: "거절",
  };
  return labels[state] ?? state;
}

function isOpenState(state: string) {
  return ["CREATED", "RISK_CHECKED", "SUBMITTED", "ACKNOWLEDGED", "PARTIALLY_FILLED", "CANCEL_REQUESTED", "REPLACE_REQUESTED"].includes(state);
}

function exitReasonLabel(value?: string | null) {
  const labels: Record<string, string> = {
    stop_loss: "손절",
    stop_loss_confirmed: "손절 확정",
    hard_stop_loss: "최후 손절",
    rapid_stop_loss: "급락 손절",
    structure_stop_loss: "구조 이탈 손절",
    liquidity_stop_loss: "유동성 붕괴 손절",
    take_profit: "익절",
    partial_take_profit: "부분익절",
    bb_mid_partial_take_profit: "BB 중앙 부분익절",
    trailing_stop: "트레일링 스탑",
    time_exit: "시간 청산",
    no_progress_time_exit: "비활성화된 과거 청산",
    vwap_ema_break: "VWAP/EMA 이탈",
    high_failure_exit: "고점 실패 청산",
  };
  return value ? labels[value] ?? value : "-";
}

function formatUsd(value?: number | null) {
  if (value == null || !Number.isFinite(value)) return "-";
  return `$${value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatSignedUsd(value?: number | null) {
  if (value == null || !Number.isFinite(value)) return "-";
  return `${value > 0 ? "+" : ""}${formatUsd(value)}`;
}

function formatNumber(value?: number | null) {
  if (value == null || !Number.isFinite(value)) return "-";
  return value.toLocaleString("en-US", { maximumFractionDigits: 4 });
}

function closedTradeNetPnl(trade: ClosedTradeRow) {
  return trade.net_pnl_usd ?? trade.gross_pnl_usd;
}

function objectValue(value: unknown) {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

function numberValue(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function stringValue(value: unknown) {
  return typeof value === "string" ? value : "";
}

function boolValue(value: unknown) {
  return typeof value === "boolean" ? value : null;
}

function boolLabel(value: boolean | null) {
  if (value == null) return "-";
  return value ? "Y" : "N";
}

function formatDateTimeKst(value?: string | null) {
  if (!value) return "-";
  return parseUtcDate(value).toLocaleString("ko-KR", {
    timeZone: "Asia/Seoul",
    year: "2-digit",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function parseUtcDate(value: string) {
  if (/[zZ]$|[+-]\d{2}:?\d{2}$/.test(value)) return new Date(value);
  return new Date(`${value}Z`);
}

function shortId(value: string) {
  return value.length > 8 ? value.slice(0, 8) : value;
}
