"""Batch-replay the currently active strategies across every window in exports/strategy_replay.

This reuses the exact runtime-equivalent ``replay`` engine from
``replay_tc_shadow_strategies`` so the numbers match what the live engine would
have produced. It walks all ``*_enriched.csv`` files under
``exports/strategy_replay``, de-duplicates re-exported windows (same
symbol/date/timerange), runs the active ``STRATEGIES`` set on each, and writes an
aggregated JSON summary plus a combined trades CSV.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

RANDOM_SEED = 0  # replay is deterministic; kept for naming-rule compliance.

PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPLAY_DIR = PROJECT_ROOT / "exports" / "strategy_replay"
ENGINE_PATH = PROJECT_ROOT / "scripts" / "replay_tc_shadow_strategies.py"

FILENAME_RE = re.compile(
    r"^(?P<symbol>[a-z0-9]+)_(?P<date>\d{4}-\d{2}-\d{2})_(?P<timerange>\d{4}-\d{4})_kst_(?P<hash>[0-9a-f]+)_enriched\.csv$"
)


def load_engine():
    """Import the shadow-strategy replay engine as a module."""
    spec = importlib.util.spec_from_file_location("tc_replay_engine", ENGINE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module  # dataclass field resolution needs this registered
    spec.loader.exec_module(module)
    return module


def configure_replay_mode(engine, replay_mode: str):
    engine.REPLAY_MODE = replay_mode
    if replay_mode == "bar_intrabar":
        return engine
    path_mode = replay_mode.replace("synthetic_", "", 1)

    def replay_with_synthetic_path(rows, *, entry_start_time=None, entry_end_time=None):
        return engine.replay_synthetic(
            rows,
            path_mode=path_mode,
            entry_start_time=entry_start_time,
            entry_end_time=entry_end_time,
        )

    engine.replay = replay_with_synthetic_path
    return engine


def parse_window_key(path_file: Path) -> tuple[str, str, str] | None:
    match = FILENAME_RE.match(path_file.name)
    if not match:
        return None
    return (
        match.group("symbol").upper(),
        match.group("date"),
        match.group("timerange"),
    )


def dedup_windows(list_files: list[Path]) -> dict[tuple[str, str, str], Path]:
    """One file per (symbol, date, timerange); keep the most recently exported."""
    dict_best: dict[tuple[str, str, str], Path] = {}
    for path_file in list_files:
        tuple_key = parse_window_key(path_file)
        if tuple_key is None:
            continue
        current = dict_best.get(tuple_key)
        if current is None or path_file.stat().st_mtime > current.stat().st_mtime:
            dict_best[tuple_key] = path_file
    return dict_best


def aggregate(list_summaries: list[dict]) -> dict:
    int_trades = sum(item["trades"] for item in list_summaries)
    int_wins = sum(item["wins"] for item in list_summaries)
    int_losses = sum(item["losses"] for item in list_summaries)
    float_net = round(sum(item["net_pnl_usd"] for item in list_summaries), 4)
    return {
        "trades": int_trades,
        "wins": int_wins,
        "losses": int_losses,
        "net_pnl": float_net,
        "return_pct": round(float_net / 2000.0 * 100, 4),
        "win_rate_pct": round(int_wins / int_trades * 100, 2) if int_trades else 0.0,
    }


def replay_window(engine, path_file: Path) -> tuple[list[dict], list[dict]]:
    """Return (per-strategy summary rows, trade rows) for one window."""
    list_rows = engine.load_rows(path_file)
    dict_portfolios = engine.replay(list_rows)
    list_summaries = [engine.summary_row(portfolio) for portfolio in dict_portfolios.values()]
    list_trades = [
        {"source_file": path_file.name, **trade}
        for portfolio in dict_portfolios.values()
        for trade in portfolio.trades
    ]
    return list_summaries, list_trades


def build_report(engine, dict_windows: dict[tuple[str, str, str], Path]) -> tuple[dict, list[dict]]:
    list_window_reports: list[dict] = []
    list_all_trades: list[dict] = []
    dict_by_symbol_summaries: dict[str, list[dict]] = defaultdict(list)
    dict_by_strategy_summaries: dict[str, list[dict]] = defaultdict(list)
    list_total_summaries: list[dict] = []

    for tuple_key in sorted(dict_windows):
        str_symbol, str_date, str_timerange = tuple_key
        path_file = dict_windows[tuple_key]
        list_summaries, list_trades = replay_window(engine, path_file)
        list_all_trades.extend(list_trades)
        list_total_summaries.extend(list_summaries)
        for dict_summary in list_summaries:
            dict_by_symbol_summaries[str_symbol].append(dict_summary)
            dict_by_strategy_summaries[dict_summary["strategy"]].append(dict_summary)

        dict_window_total = aggregate(list_summaries)
        list_window_reports.append(
            {
                "key": [str_symbol, str_date, str_timerange],
                "file": path_file.name,
                "trades": dict_window_total["trades"],
                "wins": dict_window_total["wins"],
                "losses": dict_window_total["losses"],
                "net_pnl": dict_window_total["net_pnl"],
                "return_pct": dict_window_total["return_pct"],
                "by_strategy": {item["strategy"]: item for item in list_summaries},
            }
        )

    dict_by_strategy = {}
    for str_name, list_items in dict_by_strategy_summaries.items():
        dict_agg = aggregate(list_items)
        dict_agg.pop("return_pct", None)
        dict_by_strategy[str_name] = dict_agg

    dict_report = {
        "generated_from": str(REPLAY_DIR.relative_to(PROJECT_ROOT)),
        "engine": str(ENGINE_PATH.relative_to(PROJECT_ROOT)),
        "replay_mode": getattr(engine, "REPLAY_MODE", "bar_intrabar"),
        "entry_engine": getattr(engine, "ENTRY_MODE", "hard_gate"),
        "strategy_names_active": list(engine.STRATEGIES.keys()),
        "dedup_windows": len(dict_windows),
        "total": aggregate(list_total_summaries),
        "by_symbol": {
            str_symbol: {
                "windows": sum(1 for r in list_window_reports if r["key"][0] == str_symbol),
                **aggregate(list_items),
            }
            for str_symbol, list_items in sorted(dict_by_symbol_summaries.items())
        },
        "by_strategy": dict_by_strategy,
        "windows": list_window_reports,
    }
    return dict_report, list_all_trades


def print_console(dict_report: dict) -> None:
    print("=" * 78)
    print(f"Active strategies: {', '.join(dict_report['strategy_names_active'])}")
    print(f"Windows replayed : {dict_report['dedup_windows']}")
    dict_total = dict_report["total"]
    print(
        f"TOTAL            : {dict_total['trades']} trades | "
        f"win {dict_total['win_rate_pct']}% | net ${dict_total['net_pnl']} | "
        f"return {dict_total['return_pct']}% (on $2000/strategy)"
    )
    print("-" * 78)
    print(f"{'BY STRATEGY':<34}{'trades':>7}{'win%':>8}{'net$':>12}")
    for str_name, dict_stat in sorted(
        dict_report["by_strategy"].items(), key=lambda kv: kv[1]["net_pnl"], reverse=True
    ):
        print(f"{str_name:<34}{dict_stat['trades']:>7}{dict_stat['win_rate_pct']:>8}{dict_stat['net_pnl']:>12}")
    print("-" * 78)
    print(f"{'BY SYMBOL':<10}{'win':>5}{'trades':>8}{'win%':>8}{'net$':>12}{'ret%':>9}")
    for str_symbol, dict_stat in sorted(
        dict_report["by_symbol"].items(), key=lambda kv: kv[1]["net_pnl"], reverse=True
    ):
        print(
            f"{str_symbol:<10}{dict_stat['windows']:>5}{dict_stat['trades']:>8}"
            f"{dict_stat['win_rate_pct']:>8}{dict_stat['net_pnl']:>12}{dict_stat['return_pct']:>9}"
        )
    print("=" * 78)


def write_outputs(dict_report: dict, list_trades: list[dict]) -> tuple[Path, Path]:
    # live_engine is the runtime-faithful default and owns the canonical (unsuffixed)
    # summary/trades; the hard_gate approximation writes to a suffixed file so it does
    # not clobber the canonical result.
    str_entry_engine = dict_report.get("entry_engine", "live_engine")
    str_suffix = "" if str_entry_engine == "live_engine" else f"_{str_entry_engine}"
    path_summary = REPLAY_DIR / f"active_strategies_replay_summary{str_suffix}.json"
    path_summary.write_text(json.dumps(dict_report, ensure_ascii=False, indent=2), encoding="utf-8")

    path_trades = REPLAY_DIR / f"active_strategies_replay_trades{str_suffix}.csv"
    if list_trades:
        list_fields = list(list_trades[0].keys())
        with path_trades.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=list_fields)
            writer.writeheader()
            writer.writerows(list_trades)
    return path_summary, path_trades


def main() -> None:
    global REPLAY_DIR
    parser = argparse.ArgumentParser(description="Batch-replay active strategies over a folder of enriched windows.")
    parser.add_argument(
        "--dir",
        default=str(REPLAY_DIR),
        help="Folder of *_enriched.csv windows (default: exports/strategy_replay).",
    )
    parser.add_argument(
        "--replay-mode",
        choices=["synthetic_low_first", "synthetic_color_path", "synthetic_high_first", "bar_intrabar"],
        default="synthetic_low_first",
        help="Intrabar execution path model. synthetic_low_first is the runtime-aligned conservative default.",
    )
    parser.add_argument(
        "--entry-engine",
        choices=["hard_gate", "live_engine", "live_engine_forming"],
        default="live_engine",
        help="Entry detector. live_engine=live EntryPatternEngine on completed bars "
        "(DEFAULT, runtime-faithful: replay == runtime entries); "
        "hard_gate=standalone signal_* gates (fast ~95% approximation for big sweeps); "
        "live_engine_forming=live engine on the forming bar (intrabar, prior-bar flow) "
        "to model strategy_include_live_forming_candle=True.",
    )
    args = parser.parse_args()
    REPLAY_DIR = Path(args.dir).resolve()

    engine = configure_replay_mode(load_engine(), args.replay_mode)
    engine.set_entry_mode(args.entry_engine)
    list_files = sorted(REPLAY_DIR.glob("*_enriched.csv"))
    dict_windows = dedup_windows(list_files)
    dict_report, list_trades = build_report(engine, dict_windows)
    path_summary, path_trades = write_outputs(dict_report, list_trades)
    print_console(dict_report)
    print(f"raw files: {len(list_files)}  ->  dedup windows: {len(dict_windows)}")
    print(f"summary : {path_summary.relative_to(PROJECT_ROOT)}")
    print(f"trades  : {path_trades.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
