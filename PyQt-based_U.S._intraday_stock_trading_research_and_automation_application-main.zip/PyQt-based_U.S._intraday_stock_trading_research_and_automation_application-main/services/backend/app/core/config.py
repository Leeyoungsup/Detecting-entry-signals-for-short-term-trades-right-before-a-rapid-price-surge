from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

TradingMode = Literal["research", "backtest", "internal_paper", "kis_mock", "live"]
MarketDataProviderName = Literal["external_stub", "alpaca", "toss", "kis_legacy"]
ExecutionProviderName = Literal["toss", "kis"]
ScannerCandidateSource = Literal["alpaca_movers", "toss_biggest_total_amount"]
REPO_ROOT = Path(__file__).resolve().parents[4]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(REPO_ROOT / ".env", ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_process_role: Literal["api", "worker", "realtime", "combined"] = "combined"
    app_env: str = "local"
    cors_origins: list[str] = Field(
        default_factory=lambda: [
            "http://localhost:3000",
            "http://127.0.0.1:3000",
            "http://localhost:3001",
            "http://127.0.0.1:3001",
            "http://localhost:18000",
            "http://127.0.0.1:18000",
            "http://localhost:18004",
            "http://127.0.0.1:18004",
        ]
    )

    trading_mode: TradingMode = "internal_paper"
    live_enabled: bool = False
    kis_live_enabled: bool = False
    kis_mock_enabled: bool = False
    strategy_validated: bool = False

    paper_initial_equity_usd: float = 2000.00

    database_url: str = "postgresql+psycopg://kis_app:change_me@localhost:5432/kis_trading_research"
    redis_url: str = "redis://localhost:6379/0"
    session_secret: str = "change_this_local_secret"

    market_data_provider: MarketDataProviderName = "toss"
    external_market_data_provider_name: str = "TODO_PROVIDER"
    external_market_data_enabled: bool = False
    external_market_data_api_key: str | None = None
    external_market_data_base_url: str | None = None
    external_market_data_websocket_url: str | None = None
    kis_market_data_fallback_enabled: bool = False
    alpaca_endpoint: str | None = None
    alpaca_key: str | None = None
    alpaca_secret: str | None = None
    alpaca_auth_mode: Literal["auto", "trading", "broker"] = "auto"
    alpaca_feed: Literal["sip", "iex", "delayed_sip"] = "sip"
    alpaca_rest_base_url: str = "https://data.alpaca.markets"
    alpaca_websocket_url: str = "wss://stream.data.alpaca.markets/v2/sip"
    alpaca_oauth_token_url: str = "https://authx.alpaca.markets/v1/oauth2/token"

    execution_provider: ExecutionProviderName = "toss"
    toss_environment: Literal["mock", "live"] = "mock"
    toss_app_key: str | None = None
    toss_app_secret: str | None = None
    toss_account_id: str | None = None
    toss_base_url: str = "https://openapi.tossinvest.com"
    toss_token_url: str = "https://openapi.tossinvest.com/oauth2/token"
    toss_live_order_enabled: bool = False
    toss_live_order_arm_token: str | None = None
    toss_live_auto_trade_enabled: bool = False
    toss_live_max_order_notional_usd: float = 25.0
    toss_live_max_quantity: float = 1.0
    toss_live_max_open_positions: int = 1
    toss_live_max_total_exposure_usd: float = 25.0
    toss_live_pending_cancel_after_sec: float = 20.0
    toss_live_cancel_stale_orders_enabled: bool = True
    toss_live_reconcile_max_orders_per_tick: int = 20
    toss_live_emergency_stop_enabled: bool = False
    toss_live_emergency_stop_error_threshold: int = 3

    kis_environment: Literal["mock", "live"] = "mock"
    kis_app_key: str | None = None
    kis_app_secret: str | None = None
    kis_account_no: str | None = None
    kis_account_product_code: str | None = None
    kis_hts_id: str | None = None
    kis_user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
    )
    kis_rest_base_url_mock: str = "https://openapivts.koreainvestment.com:29443"
    kis_rest_base_url_live: str = "https://openapi.koreainvestment.com:9443"
    kis_websocket_url_mock: str = "ws://ops.koreainvestment.com:31000"
    kis_websocket_url_live: str = "ws://ops.koreainvestment.com:21000"

    scanner_auto_start_enabled: bool = True
    scanner_background_loop_enabled: bool = True
    scanner_background_loop_interval_sec: int = 15
    scanner_regular_session_only: bool = False
    scanner_allow_premarket: bool = True
    scanner_allow_afterhours: bool = True
    scanner_allow_daymarket: bool = False
    scanner_stop_realtime_when_session_closed: bool = True
    scanner_candidate_source: ScannerCandidateSource = "toss_biggest_total_amount"
    scanner_max_websocket_symbols: int = 30
    scanner_candidate_universe_size: int = 120
    scanner_subscription_refresh_sec: int = 30
    scanner_realtime_stale_restart_sec: int = 90
    scanner_websocket_exchange: str = "NAS"
    scanner_websocket_key_mode: Literal["regular", "daytime"] = "regular"
    scanner_fallback_symbols: str = ""
    scanner_use_fallback_when_no_rankings: bool = False
    scanner_allow_ranking_only_for_ws: bool = False
    # When False, the scanner does NOT gate candidates at the order-flow stage
    # (spread / data-freshness / trade-strength / impulse). Every subscribed candidate is
    # handed to the strategy-signal stage, which then does the real filtering. Set True to
    # restore the pre-filter behaviour.
    scanner_require_order_flow_for_strategy: bool = False
    scanner_min_ranking_daily_volume: float = 30_000_000.0
    scanner_min_trade_strength_regular: float = 55.0
    scanner_max_spread_pct_regular: float = 0.20
    scanner_min_bid_ask_imbalance_regular: float = 0.52
    scanner_min_trade_strength_extended: float = 50.0
    scanner_max_spread_pct_extended: float = 0.60
    scanner_min_bid_ask_imbalance_extended: float = 0.45
    scanner_candidate_warmup_sec: int = 30
    scanner_candidate_memory_sec: int = 300
    scanner_candidate_reject_cooldown_sec: int = 90
    scanner_require_trade_strength: bool = False
    scanner_require_bid_ask_imbalance: bool = False
    scanner_min_price_usd: float = 0.0
    scanner_max_price_usd: float = 20.0
    scanner_min_1m_volume: float = 0.0
    scanner_min_1m_notional_usd: float = 0.0
    scanner_min_10m_volume: float = 0.0
    scanner_min_10m_notional_usd: float = 10_000.0
    scanner_min_candidate_score: float = 8.0
    scanner_min_trade_count: float = 0.0
    scanner_max_latest_bar_age_sec: int = 300
    scanner_exclude_fund_like_symbols: bool = True
    scanner_excluded_symbols: str = (
        "SPY,QQQ,IWM,DIA,XLF,XLK,XLE,XLI,XLV,XLY,XLP,XLU,XLB,XLC,TLT,SHY,HYG,LQD,"
        "BITO,ETHA,IBIT,FBTC,GBTC,"
        "TQQQ,SQQQ,SOXL,SOXS,TSLL,TSLQ,TSLS,TSLT,"
        "UVIX,SVIX,VXX,UVXY,TZA,SDS,SPXS,SPXL,SPDN,"
        "LABU,LABD,DRIP,GUSH,BOIL,KOLD,UNG,USO,FXI"
    )
    toss_wts_ranking_base_url: str = "https://api.tossinvest.com"
    toss_wts_ranking_path: str = "/api/v2/dashboard/wts/overview/ranking"
    toss_wts_ranking_page_url: str = "https://www.tossinvest.com/?market=us&live-chart=biggest_total_amount"
    toss_wts_ranking_id: str = "biggest_total_amount"
    toss_wts_ranking_market: str = "us"
    toss_wts_ranking_duration: str | None = "1d"
    toss_wts_ranking_crawl_timeout_sec: float = 20.0
    toss_wts_ranking_authorization: str | None = None
    toss_wts_ranking_cookie: str | None = None

    strategy_entry_mode: Literal["strict", "loose"] = "loose"
    strategy_loose_min_score: float = 25.0
    strategy_loose_require_order_flow: bool = False
    strategy_loose_require_vwap_distance: bool = False
    strategy_loose_require_macd: bool = False
    strategy_loose_require_lower_band_reclaim: bool = False
    strategy_primary_name: str = "micro_breakout_with_absorption"
    # LONG TRACK DISABLED 2026-07-20 (step 1 of long-track removal). The user
    # trades short only, and every long strategy here was net-negative or non-
    # participating out of sample across ~10 analyses (see claudy_log). All long
    # engine flags are now False so the runtime generates no long entries. The
    # active research track is the short/extreme-fade set in
    # scripts/replay_extreme_shorts.py (Parabolic + Volume Blow-off). The long
    # engine code is deletion-pending once the short track is runtime-integrated.
    strategy_surge_pullback_enabled: bool = False
    strategy_volume_shock_pullback_enabled: bool = False
    strategy_liquidity_sweep_reclaim_enabled: bool = False
    strategy_micro_absorption_breakout_enabled: bool = False
    strategy_liquidity_pullback_reclaim_enabled: bool = False
    # Short track (extreme-fade). When enabled AND trading_mode == internal_paper,
    # the runtime evaluates the validated Parabolic Exhaustion / Volume Blow-off
    # short setups on completed candles and manages short paper positions.
    # Default OFF so nothing changes until explicitly turned on. Live short order
    # submission stays blocked regardless of this flag (internal_paper only).
    strategy_short_track_enabled: bool = False
    strategy_short_max_notional_usd: float = 300.0
    strategy_failed_follow_through_filter_enabled: bool = True
    # Require real participation on the reclaim/breakout bar (replay-tuned): a
    # thin-volume reclaim/breakout failed often (whipsaw). 1.0 disables the gate.
    strategy_volume_shock_reclaim_min_volume_ratio: float = 1.2
    strategy_micro_breakout_min_volume_ratio: float = 1.3
    strategy_liquidity_pullback_min_volume_ratio: float = 1.1
    strategy_liquidity_pullback_min_notional_1m_usd: float = 100_000.0
    strategy_liquidity_pullback_min_10bar_change_pct: float = 0.025
    strategy_liquidity_pullback_max_10bar_change_pct: float = 0.080
    strategy_liquidity_pullback_max_roundtrip_cost_pct: float = 0.010
    strategy_liquidity_pullback_avoid_bb_dead_zone_min: float = 0.97
    strategy_liquidity_pullback_avoid_bb_dead_zone_max: float = 1.05
    strategy_volume_pullback_min_score: float = 70.0
    strategy_volume_pullback_watch_score: float = 55.0
    strategy_surge_pullback_min_score: float = 72.0
    strategy_surge_pullback_watch_score: float = 58.0
    strategy_surge_min_move_pct: float = 0.10
    strategy_surge_min_pullback_pct: float = 0.02
    strategy_surge_max_pullback_pct: float = 0.35
    strategy_surge_pullback_max_bb_position: float = 0.85
    strategy_surge_reclaim_lookback_bars: int = 8
    strategy_surge_require_macd_not_both_negative: bool = True
    strategy_surge_macd_hist_slope_lookback: int = 3
    strategy_volume_shock_pullback_min_score: float = 68.0
    strategy_liquidity_sweep_reclaim_min_score: float = 67.0
    strategy_micro_absorption_breakout_min_score: float = 68.0
    strategy_liquidity_pullback_reclaim_min_score: float = 68.0
    strategy_volume_shock_min_10bar_change_pct: float = 0.060
    strategy_volume_shock_min_notional_1m_usd: float = 300_000.0
    strategy_liquidity_sweep_min_reclaim_pct: float = 0.006
    # Shared "strong momentum without VWAP" threshold (formerly vwap_soft-specific;
    # kept after VWAP Soft Reclaim was retired because _strong_momentum_without_vwap
    # is used by other strategies too).
    strategy_strong_momentum_min_10bar_change_pct: float = 0.045
    strategy_volume_shock_min_trade_strength: float = 80.0
    strategy_volume_shock_max_sell_pressure: float = 0.30
    strategy_volume_shock_max_roundtrip_cost_pct: float = 0.009
    strategy_micro_breakout_min_trade_strength: float = 90.0
    strategy_micro_breakout_max_sell_pressure: float = 0.22
    # Config D (2026-07-12): 0.0 disables the gate. Micro Breakout already requires
    # a confirmed break + prior absorption, so the extra "recent 10-bar surge" filter
    # was redundant and only blocked good setups (ablation: removing it added 6 trades
    # and +$23 over the 4-day replay, lifting the mediocre 7/09 day the most).
    strategy_micro_breakout_min_10bar_change_pct: float = 0.0
    strategy_micro_breakout_max_10bar_change_pct: float = 0.095
    strategy_micro_breakout_min_range_pct: float = 0.020
    strategy_micro_breakout_max_roundtrip_cost_pct: float = 0.0095
    strategy_liquidity_pullback_min_trade_strength: float = 68.0
    strategy_liquidity_pullback_max_sell_pressure: float = 0.32
    strategy_liquidity_pullback_min_range_pct: float = 0.018
    strategy_micro_breakout_lookback_bars: int = 8
    strategy_snapback_min_score: float = 65.0
    strategy_snapback_watch_score: float = 50.0
    strategy_snapback_max_bb_position: float = 0.70
    strategy_snapback_reclaim_lookback_bars: int = 3
    strategy_ofi_min_score: float = 68.0
    strategy_liquidity_imbalance_min_score: float = 66.0
    strategy_absorption_breakout_min_score: float = 70.0
    strategy_vwap_reclaim_min_score: float = 66.0
    strategy_opening_imbalance_min_score: float = 68.0
    strategy_min_volume_60s: float = 100.0
    # Config D (2026-07-12): dropped from 30k. Ablation showed 0.0 added 3 trades / +$7
    # and helped the worst day most, but a zero floor lets Micro Breakout (its only 1m
    # notional gate) fill on thin bars where replay's first_ask model understates
    # slippage. Set to 10_000 for live safety -- keeps most of the benefit while
    # bounding thin-bar entries. Scanner-level notional filters also still apply.
    strategy_min_notional_1m_usd: float = 10_000.0
    strategy_min_volume_velocity_10s: float = 1.1
    # Entry gate toggles. When False the hard condition is disabled (treated as always-passing)
    # so it neither blocks entry nor drags the score down. Removed from default entry checks per
    # operator request; set True to re-enable.
    strategy_gate_tick_stale_enabled: bool = False
    strategy_gate_min_volume_60s_enabled: bool = False
    strategy_gate_liquidity_impulse_enabled: bool = False
    strategy_gate_opening_window_enabled: bool = False
    strategy_min_trade_strength_for_entry: float = 45.0
    strategy_max_sell_pressure_for_entry: float = 0.55
    strategy_min_bid_ask_imbalance_for_entry: float = 0.15
    strategy_require_directional_confirmation: bool = True
    strategy_low_price_threshold: float = 1.0
    strategy_low_price_min_trade_strength: float = 45.0
    strategy_low_price_max_sell_pressure: float = 0.55
    strategy_max_over_upper_band_atr: float = 1.0
    strategy_block_upper_band_entry: bool = True
    strategy_upper_band_block_position: float = 0.9
    strategy_upper_band_caution_position: float = 0.75
    strategy_weight_liquidity_impulse: float = 45.0
    strategy_weight_price_acceleration: float = 25.0
    strategy_weight_bollinger_context: float = 15.0
    strategy_weight_price_action: float = 15.0

    paper_test_orders_enabled: bool = True
    paper_test_relaxed_order_flow_only: bool = True
    paper_test_max_orders_per_call: int = 1
    paper_test_min_realtime_volume_60s: float = 1.0
    paper_risk_hard_caps_enabled: bool = False
    paper_max_open_positions: int = 6
    paper_max_total_exposure_pct: float = 0.90
    paper_order_audit_db_enabled: bool = False
    paper_fee_model_enabled: bool = True
    paper_commission_pct: float = 0.001  # Toss US-stock commission: 0.1% of the transaction value, charged on each of buy and sell (SEC/TAF added on top for sells)
    paper_commission_per_share: float = 0.0
    paper_min_commission_usd: float = 0.0
    paper_sec_fee_pct: float = 0.0000278
    paper_taf_fee_per_share: float = 0.000166
    paper_taf_fee_cap_usd: float = 8.30
    # Fill slippage modeled on paper orders, matched to the replay execution model
    # (buy at ask + entry slippage, sell at bid - exit slippage).
    paper_entry_slippage_pct: float = 0.0005
    paper_exit_slippage_pct: float = 0.0008
    # Reject an entry when the fill-time ask has run more than this fraction above the
    # signal close (replay prefill_entry_ok price-chase cap).
    paper_entry_max_chase_pct: float = 0.012

    paper_exit_monitor_enabled: bool = True
    paper_stop_loss_pct: float = 0.004
    paper_min_stop_loss_pct: float = 0.0025
    paper_max_stop_loss_pct: float = 0.012
    paper_adaptive_max_stop_loss_pct: float = 0.035
    paper_stop_atr_multiplier: float = 1.0
    paper_structure_stop_lookback_bars: int = 5
    paper_stop_loss_hold_enabled: bool = False
    paper_stop_loss_hold_max_seconds: int = 5
    paper_stop_loss_deep_break_pct: float = 0.002
    paper_stop_loss_rapid_drop_pct: float = 0.012
    paper_stop_loss_emergency_limit_buffer_pct: float = 0.005
    # Cap the modeled stop-exit fill at stop_price*(1 - cap) so a gap/spike between 1s
    # polls can't fill far below the stop level (mirrors the replay's STOP_SLIPPAGE_CAP
    # of 0.5%). Keeps runtime stop losses bounded like the replay instead of overshooting.
    paper_stop_slippage_cap_pct: float = 0.005
    # Base take-profit target sized to clear round-trip cost + edge (replay-aligned:
    # replay uses a dynamic max(min_net, cost+edge, spread*1.8+edge) target ~0.6-0.8%).
    # A 0.35% target only netted ~commission; winners now run to ~0.6% while the
    # trailing stop (activates at 0.35%) still protects gains that stall before target.
    paper_take_profit_pct: float = 0.006
    paper_partial_take_profit_pct: float = 0.004
    paper_min_net_take_profit_pct: float = 0.0015
    paper_take_profit_lookback_bars: int = 20
    paper_take_profit_atr_multiplier: float = 1.8
    paper_partial_take_profit_atr_multiplier: float = 0.8
    paper_partial_exit_fraction: float = 0.0
    paper_break_even_activation_pct: float = 0.003
    paper_break_even_lock_pct: float = 0.0005
    paper_dynamic_take_profit_enabled: bool = True
    paper_take_profit_requires_weakness: bool = True
    paper_partial_exit_requires_weakness: bool = True
    paper_macd_fading_exit_enabled: bool = True
    paper_macd_fading_min_profit_pct: float = 0.002
    paper_macd_fading_min_seconds: int = 3
    paper_macd_fading_min_hist_drop_ratio: float = 0.15
    paper_macd_fading_confirm_with_chart: bool = True
    paper_macd_fading_hist_slope_lookback: int = 3
    paper_high_failure_exit_enabled: bool = True
    paper_high_failure_lookback_bars: int = 3
    paper_time_exit_enabled: bool = False
    paper_time_exit_seconds: int = 1800
    paper_trailing_stop_pct: float = 0.0035
    paper_trailing_activation_pct: float = 0.0035
    paper_dynamic_trailing_tight_pct: float = 0.002
    paper_dynamic_trailing_normal_pct: float = 0.0035
    paper_dynamic_trailing_wide_pct: float = 0.012
    paper_runner_candidate_profit_pct: float = 0.04
    paper_runner_trailing_profit_pct: float = 0.10
    paper_runner_full_exit_high_failures: int = 3
    paper_runner_emergency_drawdown_pct: float = 0.08
    paper_exit_on_vwap_ema_break: bool = False
    paper_vwap_ema_break_min_hold_seconds: int = 180
    paper_vwap_ema_break_min_loss_pct: float = 0.003
    paper_exit_cooldown_seconds: int = 1
    paper_symbol_loss_cooldown_seconds: int = 480
    paper_symbol_any_strategy_loss_cooldown_seconds: int = 960
    paper_symbol_loss_cluster_cooldown_seconds: int = 1440
    paper_symbol_loss_cluster_lookback_seconds: int = 1800
    paper_symbol_loss_cluster_max_losses: int = 2
    toss_position_quote_monitor_enabled: bool = False
    toss_position_quote_interval_sec: float = 1.0
    toss_position_quote_cache_sec: float = 0.3
    toss_position_quote_failure_cooldown_sec: float = 30.0
    toss_position_quote_max_symbols_per_tick: int = 8
    toss_realtime_poll_symbols_per_sec: int = 3
    toss_realtime_quote_symbols_per_sec: int = 4
    toss_realtime_trade_symbols_per_sec: int = 2
    # Orderbook/trade (microstructure) round-robin polling is restricted to this many
    # top-ranked candidates plus any symbol with an open paper position. This does NOT reduce
    # per-second MARKET_DATA usage (that is fixed by toss_realtime_quote/trade_symbols_per_sec);
    # it only decides which subscribed symbols share that fixed poll budget. Set it >= the
    # subscribed universe (scanner_max_websocket_symbols) to give every candidate a tick, or
    # lower it to concentrate freshness on the top ranks. 0 = no gate (poll all subscribed).
    toss_realtime_microstructure_top_n: int = 30
    toss_realtime_price_refresh_enabled: bool = True
    scanner_seed_minute_bars_enabled: bool = True
    # Seed the whole subscribed universe (== scanner_max_websocket_symbols) each
    # cycle so no symbol sits with only a few tick candles. Bounded by the Toss
    # MARKET_DATA_CHART rate limit (5/sec): ~30 symbols ≈ 6s of chart budget.
    scanner_seed_minute_bars_max_symbols: int = 30
    scanner_seed_minute_bars_interval_sec: int = 60  # 1min: official 1-minute candles only change once per minute, so re-seeding faster than this is wasted chart-API budget
    scanner_seed_minute_bars_align_wait_sec: int = 15
    chart_live_merge_max_gap_minutes: int = 3
    strategy_max_candle_gap_minutes: int = 3
    strategy_prefer_live_tick_candles: bool = False
    strategy_official_min_candles: int = 30
    strategy_live_tick_min_candles: int = 30
    # Hybrid entry window: keep the historical pattern on completed official bars
    # (no repaint, matches the replay) but append the current forming/live minute
    # as the current bar so breakout/reclaim/close-near-high checks react in
    # real-time instead of waiting for the minute to close. Exits are already
    # tick-real-time. Set False to fall back to completed-bars-only (pure replay).
    strategy_include_live_forming_candle: bool = False
    strategy_tick_stale_caution_sec: int = 10
    strategy_tick_stale_block_sec: int = 45

    @field_validator("trading_mode")
    @classmethod
    def block_live_mode_by_default(cls, value: TradingMode) -> TradingMode:
        return value

    @model_validator(mode="after")
    def guard_live_order_mode(self) -> "Settings":
        if self.trading_mode == "live" and not (
            self.live_enabled and self.toss_environment == "live" and self.toss_live_order_enabled
        ):
            raise ValueError(
                "TRADING_MODE=live requires LIVE_ENABLED=true, TOSS_ENVIRONMENT=live, and TOSS_LIVE_ORDER_ENABLED=true"
            )
        if self.toss_live_order_enabled and not (self.live_enabled and self.toss_environment == "live"):
            raise ValueError("TOSS_LIVE_ORDER_ENABLED=true requires LIVE_ENABLED=true and TOSS_ENVIRONMENT=live")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
