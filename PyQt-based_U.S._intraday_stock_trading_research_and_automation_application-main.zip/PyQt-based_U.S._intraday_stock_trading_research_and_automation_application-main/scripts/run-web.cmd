@echo off
setlocal

cd /d "%~dp0.."

call scripts\load-env.cmd

set CONDA_ENV_DIR=%USERPROFILE%\.conda\envs\kis-trading-research
if not exist "%CONDA_ENV_DIR%\python.exe" set CONDA_ENV_DIR=C:\ProgramData\anaconda3\envs\kis-trading-research
set PATH=%CONDA_ENV_DIR%;%CONDA_ENV_DIR%\Library\bin;%CONDA_ENV_DIR%\Scripts;%PATH%

if not exist ".env" (
  copy ".env.conda.example" ".env" > nul
)

if "%API_PORT%"=="" (
  if exist ".runtime\api-port.txt" (
    set /p API_PORT=<".runtime\api-port.txt"
  ) else (
    if not "%NEXT_PUBLIC_API_BASE_URL%"=="" (
      for /f "tokens=3 delims=:" %%A in ("%NEXT_PUBLIC_API_BASE_URL%") do (
        for /f "tokens=1 delims=/" %%B in ("%%A") do set API_PORT=%%B
      )
    )
  )
)
if "%API_PORT%"=="" set API_PORT=8000

if "%WEB_PORT%"=="" set WEB_PORT=18000
netstat -ano | findstr /R /C:":%WEB_PORT% .*LISTENING" > nul
if not errorlevel 1 (
  if "%WEB_PORT%"=="18000" set WEB_PORT=18004
)

set NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:%API_PORT%
set NEXT_PUBLIC_REALTIME_URL=ws://127.0.0.1:%API_PORT%/api/realtime/ws
(echo NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:%API_PORT%) > "apps\web\.env.local"
(echo NEXT_PUBLIC_REALTIME_URL=ws://127.0.0.1:%API_PORT%/api/realtime/ws) >> "apps\web\.env.local"

echo Starting Next.js dashboard on http://127.0.0.1:%WEB_PORT%
echo Backend API expected at http://127.0.0.1:%API_PORT%
cd apps\web
npx next dev --hostname 0.0.0.0 -p %WEB_PORT%
