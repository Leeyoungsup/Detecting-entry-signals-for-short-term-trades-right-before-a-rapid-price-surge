from typing import Protocol


class MarketDataUnavailableError(RuntimeError):
    pass


class MarketDataProvider(Protocol):
    provider_name: str

    def status(self) -> dict: ...

    def scanner_rankings(self, exchange: str = "NAS") -> dict: ...

    async def start_realtime(
        self,
        *,
        symbols: list[str],
        exchange: str = "NAS",
        key_mode: str = "regular",
        subscribe_quotes: bool = True,
        subscribe_trades: bool = True,
    ) -> dict: ...

    async def stop_realtime(self) -> dict: ...

    async def update_realtime(
        self,
        *,
        symbols: list[str],
        exchange: str = "NAS",
        key_mode: str = "regular",
        subscribe_quotes: bool = True,
        subscribe_trades: bool = True,
    ) -> dict: ...

    def realtime_status(self) -> dict: ...

    def realtime_snapshot(self) -> dict: ...

    def subscribed_symbols(self) -> set[str]: ...

    def order_flow_snapshot(self) -> dict[str, dict]: ...

    def recent_events(self, limit: int = 100) -> list[dict]: ...

    def price(self, symbol: str, exchange: str = "NAS") -> dict: ...

    def quote(self, symbol: str, exchange: str = "NAS") -> dict: ...

    def minute_bars(self, symbol: str, exchange: str = "NAS", interval: str = "1", limit: int = 120) -> dict: ...

    def minute_bars_history(
        self,
        symbol: str,
        exchange: str = "NAS",
        interval: str = "1",
        target_date: str | None = None,
        max_pages: int = 20,
    ) -> dict: ...

    def daily_bars(
        self,
        symbol: str,
        exchange: str = "NAS",
        period: str = "0",
        bymd: str = "",
        adjusted: bool = True,
        max_pages: int = 5,
    ) -> dict: ...
