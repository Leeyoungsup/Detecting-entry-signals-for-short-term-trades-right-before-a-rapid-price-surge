import type { ReactNode } from "react";

export function MetricTile({
  label,
  value,
  detail,
  icon,
}: {
  label: string;
  value: string | number | null;
  detail?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="rounded border border-line bg-panel p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="text-xs font-medium uppercase text-zinc-500">{label}</div>
        {icon ? <span className="text-info">{icon}</span> : null}
      </div>
      <div className="mt-2 text-xl font-bold text-ink">{value ?? "-"}</div>
      {detail ? <div className="mt-1 text-xs text-zinc-500">{detail}</div> : null}
    </div>
  );
}
