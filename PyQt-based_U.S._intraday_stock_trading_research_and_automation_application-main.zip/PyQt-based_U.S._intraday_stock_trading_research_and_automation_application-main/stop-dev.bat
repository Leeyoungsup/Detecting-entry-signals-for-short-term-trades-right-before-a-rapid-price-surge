@echo off
setlocal
cd /d "%~dp0"
call scripts\stop-dev.cmd
echo.
echo Dev server stop command complete.
