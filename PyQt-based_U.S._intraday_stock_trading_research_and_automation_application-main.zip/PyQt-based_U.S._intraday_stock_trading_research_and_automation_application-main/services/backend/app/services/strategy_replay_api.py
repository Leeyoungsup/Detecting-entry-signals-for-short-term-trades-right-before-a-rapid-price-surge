from __future__ import annotations

import importlib.util
import re
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import ModuleType
from typing import Any
from zoneinfo import ZoneInfo


KST = timezone(timedelta(hours=9), "KST")
ET = ZoneInfo("America/New_York")
MAX_REPLAY_MINUTES = 16 * 60
INDICATOR_WARMUP_MINUTES = 180


class StrategyReplayError(RuntimeError):
    pass


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[4]


def _load_script(module_name: str, relative_path: str) -> ModuleType:
    path = _repo_root() / relative_path
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise StrategyReplayError(f"script load failed: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _parse_kst_window(
    date_kst: str,
    start_time_kst: str,
    end_time_kst: str,
    end_date_kst: str | None = None,
) -> tuple[datetime, datetime]:
    try:
        start = datetime.strptime(f"{date_kst} {start_time_kst}", "%Y-%m-%d %H:%M").replace(tzinfo=KST)
        end = datetime.strptime(f"{end_date_kst or date_kst} {end_time_kst}", "%Y-%m-%d %H:%M").replace(tzinfo=KST)
    except ValueError as exc:
        raise StrategyReplayError("날짜/시간 형식은 YYYY-MM-DD, HH:MM 이어야 합니다.") from exc
    if end <= start:
        raise StrategyReplayError("종료 일시는 시작 일시보다 뒤여야 합니다.")
    minutes = (end - start).total_seconds() / 60
    if minutes > MAX_REPLAY_MINUTES:
        raise StrategyReplayError("한 번에 최대 16시간까지만 replay할 수 있습니다.")
    return start, end


def _window_label(start_kst: datetime, end_kst: datetime) -> str:
    start_et = start_kst.astimezone(ET)
    end_et = end_kst.astimezone(ET)
    return (
        f"{start_kst:%Y-%m-%d %H:%M}~{end_kst:%H:%M} KST"
        f" / {start_et:%Y-%m-%d %H:%M}~{end_et:%H:%M} ET"
    )


def _no_bars_message(symbol: str, start_kst: datetime, end_kst: datetime, raw_message: str) -> str:
    label = _window_label(start_kst, end_kst)
    now_kst = datetime.now(KST)
    if start_kst > now_kst + timedelta(minutes=1):
        return (
            f"{symbol} {label} 구간은 아직 시작 전입니다. "
            "미래 구간은 1분봉이 없으니 이미 지나간 KST 구간으로 replay해 주세요."
        )
    if end_kst > now_kst + timedelta(minutes=1):
        return (
            f"{symbol} {label} 구간의 종료 시각이 아직 지나지 않았습니다. "
            "이미 생성된 구간까지만 선택하거나 장이 지난 뒤 다시 실행해 주세요."
        )
    return (
        f"{symbol} {label} 구간에 Alpaca 1분봉이 없습니다. "
        "프리마켓/애프터마켓 초반 무거래, 휴장, ticker 변경, 또는 아직 데이터 미반영일 수 있습니다. "
        f"원본 메시지: {raw_message}"
    )


def _clean_symbol(symbol: str) -> str:
    cleaned = re.sub(r"[^A-Z0-9.\-]", "", symbol.upper().strip())
    if not cleaned:
        raise StrategyReplayError("Ticker를 입력해야 합니다.")
    return cleaned


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _json_safe(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_safe(item) for item in value]
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            return None
        return value
    return value


def _chart_row(row: dict[str, Any]) -> dict[str, Any]:
    keys = [
        "timestamp_kst",
        "open",
        "high",
        "low",
        "close",
        "volume",
        "notional_usd",
        "ema9",
        "ema20",
        "bb_mid20",
        "bb_upper20",
        "bb_lower20",
        "session_vwap",
        "macd_histogram",
        "avg_spread_pct",
        "trade_strength",
        "sell_pressure",
        "first_bid",
        "first_ask",
        "last_bid",
        "last_ask",
    ]
    return {key: row.get(key) for key in keys}


def _filter_rows_by_window(
    rows: list[dict[str, Any]],
    *,
    start_kst: datetime,
    end_kst: datetime,
) -> list[dict[str, Any]]:
    start = start_kst.strftime("%Y-%m-%d %H:%M:%S")
    end = end_kst.strftime("%Y-%m-%d %H:%M:%S")
    return [row for row in rows if start <= str(row.get("timestamp_kst") or "") <= end]


def _build_reject_diagnostics(
    rows: list[dict[str, Any]],
    replay_module: ModuleType,
    *,
    start_kst: datetime,
    end_kst: datetime,
) -> list[dict[str, Any]]:
    diagnostics: list[dict[str, Any]] = []
    start = start_kst.strftime("%Y-%m-%d %H:%M:%S")
    end = end_kst.strftime("%Y-%m-%d %H:%M:%S")
    for index, row in enumerate(rows):
        if index < 20:
            continue
        timestamp = str(row.get("timestamp_kst") or "")
        if timestamp < start or timestamp > end:
            continue
        signals: list[str] = []
        for name, detector in replay_module.STRATEGIES.items():
            ok, _reason = detector(rows, index)
            if ok:
                signals.append(name)
        expected_pullback_pct = replay_module.conservative_expected_upside_fraction(rows, index) * 100
        expected_runner_pct = replay_module.continuation_expected_upside_fraction(rows, index) * 100
        expected_pct = replay_module.expected_upside_fraction(rows, index, "Surge Pullback Reclaim") * 100
        required_pct = replay_module.dynamic_take_profit_fraction(row, "Surge Pullback Reclaim", rows, index) * 100
        volume_ma20 = row.get("volume_ma20") or 0
        candidate_like = (
            replay_module.common_liquidity(row)
            and (
                expected_pct >= 0.8
                or (row.get("volume") or 0) >= volume_ma20 * 1.2
                or (row.get("range_pct") or 0) >= 3.0
                or replay_module.close_near_high(row)
            )
        )
        if not candidate_like:
            continue
        blockers: list[str] = []
        if signals:
            blockers.append("전략 신호 발생")
        if expected_pct < required_pct:
            blockers.append(f"기대상승폭 부족({expected_pct:.2f}% < {required_pct:.2f}%)")
        if not replay_module.previous_low_holding(rows, index, 0.99):
            blockers.append("직전 저점 유지 실패")
        if not replay_module.spread_stable(rows, index):
            blockers.append("스프레드 안정 실패")
        if not replay_module.sell_pressure_decreasing(rows, index):
            blockers.append("매도 압력 감소 실패")
        if not replay_module.macd_not_deteriorating(rows, index):
            blockers.append("MACD 둔화/악화")
        if not replay_module.above_ema9(row):
            blockers.append("EMA9 아래")
        if not replay_module.above_vwap(row):
            blockers.append("VWAP 아래")
        if not replay_module.close_near_high(row):
            blockers.append("종가가 고가권 아님")
        trade_strength = row.get("trade_strength")
        if trade_strength is not None and trade_strength < 58:
            blockers.append(f"Order Flow 체결강도 부족({trade_strength:.1f} < 58)")
        sell_pressure = row.get("sell_pressure")
        if sell_pressure is not None and sell_pressure > 45:
            blockers.append(f"매도 압력 높음({sell_pressure:.1f} > 45)")
        bb_position = row.get("bb_position_0_1")
        if bb_position is not None and bb_position > 0.85:
            blockers.append(f"Pullback 기준 BB 위치 높음({bb_position:.2f} > 0.85)")
        if bb_position is not None and bb_position > 1.15:
            blockers.append(f"추격매수 제한({bb_position:.2f} > 1.15)")
        diagnostics.append(
            {
                "timestamp_kst": row.get("timestamp_kst"),
                "close": row.get("close"),
                "volume": row.get("volume"),
                "notional_usd": row.get("notional_usd"),
                "bb_position": bb_position,
                "ema9": row.get("ema9"),
                "vwap": row.get("session_vwap"),
                "macd_histogram": row.get("macd_histogram"),
                "avg_spread_pct": row.get("avg_spread_pct"),
                "trade_strength": trade_strength,
                "sell_pressure": sell_pressure,
                "expected_upside_pct": round(expected_pct, 4),
                "expected_pullback_upside_pct": round(expected_pullback_pct, 4),
                "expected_runner_upside_pct": round(expected_runner_pct, 4),
                "required_profit_pct": round(required_pct, 4),
                "signals": signals,
                "blockers": blockers[:5],
            }
        )
    return diagnostics[-120:]


def run_strategy_replay(
    *,
    symbol: str,
    date_kst: str,
    start_time_kst: str,
    end_time_kst: str,
    end_date_kst: str | None = None,
) -> dict[str, Any]:
    symbol = _clean_symbol(symbol)
    end_date_kst = end_date_kst or date_kst
    start_kst, end_kst = _parse_kst_window(date_kst, start_time_kst, end_time_kst, end_date_kst)
    warmup_start_kst = start_kst - timedelta(minutes=INDICATOR_WARMUP_MINUTES)
    root = _repo_root()
    exports_dir = root / "exports" / "strategy_replay"
    exports_dir.mkdir(parents=True, exist_ok=True)
    suffix = uuid.uuid4().hex[:8]
    stem = (
        f"{symbol.lower().replace('.', '_')}_"
        f"{date_kst}_{start_time_kst.replace(':', '')}-{end_time_kst.replace(':', '')}_kst_{suffix}"
    )
    bars_path = exports_dir / f"{stem}_bars.csv"
    enriched_path = exports_dir / f"{stem}_enriched.csv"

    bars_module = _load_script("alpaca_bars_export_for_api", "scripts/export_alpaca_bars_csv.py")
    enriched_module = _load_script("alpaca_enriched_export_for_api", "scripts/export_alpaca_enriched_bars_csv.py")
    replay_module = _load_script("shadow_replay_for_api", "scripts/replay_tc_shadow_strategies.py")

    try:
        bars_summary = bars_module.export_csv(
            symbol=symbol,
            start_kst=warmup_start_kst,
            end_kst=end_kst,
            output=bars_path,
            env_path=root / ".env",
        )
        enriched_summary = enriched_module.enrich_csv(
            bars_path=bars_path,
            output_path=enriched_path,
            env_path=root / ".env",
            symbol=symbol,
        )
        rows = replay_module.load_rows(enriched_path)
        selected_rows = _filter_rows_by_window(rows, start_kst=start_kst, end_kst=end_kst)
        if not selected_rows:
            raise StrategyReplayError(
                f"{symbol} {_window_label(start_kst, end_kst)} 구간에 replay 가능한 1분봉이 없습니다."
            )
        portfolios = replay_module.replay(
            rows,
            entry_start_time=start_kst.strftime("%Y-%m-%d %H:%M:%S"),
            entry_end_time=end_kst.strftime("%Y-%m-%d %H:%M:%S"),
        )
    except SystemExit as exc:
        message = str(exc)
        if "No bars returned" in message:
            raise StrategyReplayError(_no_bars_message(symbol, start_kst, end_kst, message)) from exc
        raise StrategyReplayError(message) from exc
    except Exception as exc:
        raise StrategyReplayError(str(exc)) from exc

    summaries = [replay_module.summary_row(portfolio) for portfolio in portfolios.values()]
    trades = [trade for portfolio in portfolios.values() for trade in portfolio.trades]
    trades.sort(key=lambda item: (item.get("entry_time") or "", item.get("strategy") or ""))
    total_net = sum(float(row.get("net_pnl_usd") or 0.0) for row in summaries)

    return _json_safe(
        {
            "symbol": symbol,
            "date_kst": date_kst,
            "end_date_kst": end_date_kst,
            "start_time_kst": start_time_kst,
            "end_time_kst": end_time_kst,
            "bars": [_chart_row(row) for row in selected_rows],
            "summary_rows": summaries,
            "trades": trades,
            "diagnostics": _build_reject_diagnostics(rows, replay_module, start_kst=start_kst, end_kst=end_kst),
            "totals": {
                "strategies": len(summaries),
                "trades": len(trades),
                "net_pnl_usd": round(total_net, 4),
                "return_on_2000_pct": round(total_net / 2000.0 * 100, 4),
            },
            "source": {
                "bars_csv": str(bars_path.relative_to(root)),
                "enriched_csv": str(enriched_path.relative_to(root)),
                "bars": bars_summary,
                "warmup_minutes": INDICATOR_WARMUP_MINUTES,
                "warmup_bars": max(0, len(rows) - len(selected_rows)),
                "selected_bars": len(selected_rows),
                "quotes": enriched_summary.get("quotes"),
                "trade_ticks": enriched_summary.get("trades"),
            },
            "assumptions": {
                "timezone": "입력 시각은 Asia/Seoul 기준입니다.",
                "data": "Alpaca SIP 1분봉 + historical quotes/trades를 같은 1분 단위로 집계합니다.",
                "execution": "신호는 봉 마감 기준, 체결은 다음 1분봉 첫 quote ask/bid 기준입니다.",
                "cost": "수수료, SEC/TAF, 스프레드, 슬리피지를 replay 엔진에 반영합니다.",
                "mode": "전략별 독립 shadow portfolio이며 실제 주문은 호출하지 않습니다.",
            },
        }
    )
