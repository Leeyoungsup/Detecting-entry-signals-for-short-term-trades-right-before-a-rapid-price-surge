from datetime import datetime, timedelta, timezone
from collections import deque
from threading import Lock
from time import monotonic, sleep
from typing import Any
from zoneinfo import ZoneInfo

import httpx

from app.core.config import Settings

KST = ZoneInfo("Asia/Seoul")

_TOKEN_CACHE: dict[tuple[str, str], tuple[str, datetime]] = {}
_ACCOUNT_SEQ_CACHE: dict[tuple[str, str], tuple[int, datetime]] = {}
_PREVIEW_CACHE: dict[tuple[str, str, str, str, str], tuple[dict, datetime]] = {}
_ORDERBOOK_QUOTE_CACHE: dict[tuple[str, str, str], tuple[dict, datetime]] = {}
# Toss refreshes the KRW<->USD rate every ~60s server-side, so caching for the same window
# avoids spending MARKET_INFO budget on a value that hasn't changed.
_EXCHANGE_RATE_CACHE: dict[tuple[str, str, str], tuple[float, datetime]] = {}
# Toss issues a single active token per client (a new token invalidates the previous one), so
# the token is shared across every backend process via Redis instead of each process minting its
# own and invalidating the others.
_SHARED_TOKEN_KEY = "trading_lab:toss:access_token:"
_SHARED_TOKEN_LOCK_KEY = "trading_lab:toss:token_lock:"
_TOKEN_LOCK = Lock()
_RATE_LIMIT_LOCK = Lock()
_RATE_LIMIT_WINDOWS: dict[str, deque[float]] = {}
# Per-group live state derived from Toss response headers.
#   {"limit": int, "remaining": int, "cooldown_until": float(monotonic)}
_RATE_LIMIT_STATE: dict[str, dict[str, float]] = {}

# Official per-second limits (documented X-RateLimit-Limit / burst capacity). The client
# keeps a headroom margin below these and also adopts the live X-RateLimit-Limit value the
# server advertises, since Toss may adjust the allowance without notice.
_RATE_LIMITS_PER_SEC: dict[str, int] = {
    "AUTH": 5,
    "ACCOUNT": 1,
    "ASSET": 5,
    "STOCK": 5,
    "MARKET_INFO": 3,
    "MARKET_DATA": 10,
    "MARKET_DATA_CHART": 5,
    "RANKING": 5,
    "MARKET_INDICATOR_PRICE": 10,
    "MARKET_INDICATOR": 10,
    "MARKET_INDICATOR_CHART": 5,
    "ORDER": 6,
    "ORDER_HISTORY": 5,
    "ORDER_INFO": 6,
    "CONDITIONAL_ORDER": 5,
    "CONDITIONAL_ORDER_HISTORY": 10,
}
# Peak-window (09:00~09:10 KST) tighter caps.
_PEAK_RATE_LIMITS_PER_SEC: dict[str, int] = {
    "ORDER": 3,
    "ORDER_INFO": 3,
}
# Fraction of each per-second limit kept unused as safety headroom. This absorbs clock skew
# and bursts from the other backend processes (api / worker / realtime_worker) that share
# the same Toss token bucket but cannot see each other's in-process windows.
_RATE_LIMIT_HEADROOM_RATIO = 0.2
# Extra headroom to hold back once the server tells us the shared bucket is running low.
_RATE_LIMIT_LOW_REMAINING = 1
_MAX_RATE_LIMIT_RETRIES = 3


class TossApiError(RuntimeError):
    def __init__(self, message: str, *, status_code: int | None = None, payload: dict | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload or {}


class TossExecutionClient:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._access_token: str | None = None
        self._access_token_expires_at: datetime | None = None

    def status(self) -> dict:
        configured = bool(self.settings.toss_app_key and self.settings.toss_app_secret)
        live_order_enabled = self.live_order_enabled()
        live_auto_trade_enabled = bool(live_order_enabled and self.settings.toss_live_auto_trade_enabled)
        if live_auto_trade_enabled:
            message = "Toss live auto trading is armed with live order caps and emergency stop."
            live_order_message = "Live automatic strategy orders are enabled with configured caps."
        elif live_order_enabled:
            message = "Toss live order API is armed; automatic strategy orders are blocked."
            live_order_message = "Manual live orders are enabled, but automatic strategy orders are blocked."
        elif configured:
            message = "Toss execution credentials configured. Live order API remains blocked."
            live_order_message = "Toss order creation API is verified but live order calls are blocked by default."
        else:
            message = "TOSS_APP_KEY/TOSS_APP_SECRET is required."
            live_order_message = "Toss execution credentials are missing."
        return {
            "provider": "toss",
            "role": "execution_account_gateway",
            "environment": self.settings.toss_environment,
            "configured": configured,
            "status": "configured" if configured else "credentials_missing",
            "base_url": self.settings.toss_base_url,
            "account_configured": bool(self.settings.toss_account_id),
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "message": message,
            "live_order_enabled": live_order_enabled,
            "live_auto_trade_enabled": live_auto_trade_enabled,
            "live_order_message": live_order_message,
        }

    def live_order_enabled(self) -> bool:
        return bool(
            self.settings.execution_provider == "toss"
            and self.settings.toss_app_key
            and self.settings.toss_app_secret
            and self.settings.trading_mode == "live"
            and self.settings.live_enabled
            and self.settings.toss_environment == "live"
            and self.settings.toss_live_order_enabled
        )

    def accounts(self) -> list[dict]:
        payload = self._request("GET", "/api/v1/accounts")
        return payload.get("result") or []

    def account_seq(self) -> int:
        if self.settings.toss_account_id:
            return int(self.settings.toss_account_id)
        cache_key = (self.settings.toss_base_url, self.settings.toss_app_key or "")
        cached = _ACCOUNT_SEQ_CACHE.get(cache_key)
        now = datetime.now(timezone.utc)
        if cached and cached[1] > now:
            return cached[0]
        accounts = self.accounts()
        if not accounts:
            raise TossApiError("Toss 계좌 목록이 비어 있습니다. TOSS_ACCOUNT_ID(accountSeq)를 설정하세요.")
        account_seq = int(accounts[0]["accountSeq"])
        _ACCOUNT_SEQ_CACHE[cache_key] = (account_seq, now + timedelta(minutes=10))
        return account_seq

    def buying_power(self, *, currency: str = "USD", account_seq: int | None = None) -> dict:
        payload = self._request(
            "GET",
            "/api/v1/buying-power",
            params={"currency": currency},
            account_seq=account_seq or self.account_seq(),
        )
        return payload.get("result") or {}

    def holdings(self, *, symbol: str | None = None, account_seq: int | None = None) -> dict:
        params = {"symbol": symbol.upper()} if symbol else None
        payload = self._request("GET", "/api/v1/holdings", params=params, account_seq=account_seq or self.account_seq())
        return payload.get("result") or {}

    def sellable_quantity(self, *, symbol: str, account_seq: int | None = None) -> dict:
        payload = self._request(
            "GET",
            "/api/v1/sellable-quantity",
            params={"symbol": symbol.upper()},
            account_seq=account_seq or self.account_seq(),
        )
        return payload.get("result") or {}

    def orderbook(self, *, symbol: str) -> dict:
        payload = self._request("GET", "/api/v1/orderbook", params={"symbol": symbol.upper()})
        return payload.get("result") or {}

    def prices(self, *, symbols: list[str]) -> list[dict]:
        normalized = _normalize_symbols(symbols, max_count=200)
        if not normalized:
            return []
        payload = self._request("GET", "/api/v1/prices", params={"symbols": ",".join(normalized)})
        return payload.get("result") or []

    def trades(self, *, symbol: str, count: int = 50) -> list[dict]:
        payload = self._request(
            "GET",
            "/api/v1/trades",
            params={"symbol": symbol.upper(), "count": max(1, min(int(count), 50))},
        )
        return payload.get("result") or []

    def candles(
        self,
        *,
        symbol: str,
        interval: str = "1m",
        count: int = 120,
        before: str | None = None,
        adjusted: bool = True,
    ) -> list[dict]:
        params: dict[str, Any] = {
            "symbol": symbol.upper(),
            "interval": interval,
            "count": max(1, min(int(count), 200)),
            "adjusted": adjusted,
        }
        if before:
            params["before"] = before
        payload = self._request("GET", "/api/v1/candles", params=params)
        result = payload.get("result") or []
        if isinstance(result, dict):
            return result.get("candles") or []
        return result

    def stocks(self, *, symbols: list[str]) -> list[dict]:
        normalized = _normalize_symbols(symbols, max_count=200)
        if not normalized:
            return []
        payload = self._request("GET", "/api/v1/stocks", params={"symbols": ",".join(normalized)})
        return payload.get("result") or []

    def rankings(
        self,
        *,
        ranking_type: str,
        market_country: str = "US",
        duration: str = "realtime",
        exclude_investment_caution: bool = False,
        count: int = 100,
    ) -> dict:
        payload = self._request(
            "GET",
            "/api/v1/rankings",
            params={
                "type": ranking_type,
                "marketCountry": market_country,
                "duration": duration,
                "excludeInvestmentCaution": exclude_investment_caution,
                "count": max(1, min(int(count), 100)),
            },
        )
        return payload.get("result") or {}

    def exchange_rate(self, *, base_currency: str = "USD", quote_currency: str = "KRW") -> float | None:
        cache_key = (self.settings.toss_base_url, base_currency.upper(), quote_currency.upper())
        now = datetime.now(timezone.utc)
        cached = _EXCHANGE_RATE_CACHE.get(cache_key)
        if cached and cached[1] > now:
            return cached[0]
        try:
            payload = self._request(
                "GET",
                "/api/v1/exchange-rate",
                params={"baseCurrency": base_currency.upper(), "quoteCurrency": quote_currency.upper()},
            )
        except TossApiError:
            return cached[0] if cached else None
        rate = _to_float((payload.get("result") or {}).get("rate"))
        if rate is None:
            return cached[0] if cached else None
        _EXCHANGE_RATE_CACHE[cache_key] = (rate, now + timedelta(seconds=60))
        return rate

    def orderbook_quote(self, *, symbol: str, max_cache_age_sec: float = 1.0) -> dict:
        symbol = symbol.upper()
        cache_key = (self.settings.toss_base_url, self.settings.toss_app_key or "", symbol)
        now = datetime.now(timezone.utc)
        cached = _ORDERBOOK_QUOTE_CACHE.get(cache_key)
        if max_cache_age_sec > 0 and cached and cached[1] > now:
            return {**cached[0], "cached": True}

        orderbook = self.orderbook(symbol=symbol)
        best_ask = _first_price(orderbook.get("asks"))
        best_bid = _first_price(orderbook.get("bids"))
        quote = {
            "provider": "toss",
            "symbol": symbol,
            "currency": orderbook.get("currency") or "USD",
            "best_ask": best_ask,
            "best_bid": best_bid,
            "ask_depth": _depth_sum(orderbook.get("asks")),
            "bid_depth": _depth_sum(orderbook.get("bids")),
            "spread_pct": _spread_pct(best_bid, best_ask),
            "orderbook": orderbook,
            "cached": False,
            "quoted_at": now.isoformat(),
        }
        _ORDERBOOK_QUOTE_CACHE[cache_key] = (quote, now + timedelta(seconds=max_cache_age_sec))
        return quote

    def execution_preview(self, *, symbol: str, side: str = "buy", currency: str = "USD") -> dict:
        symbol = symbol.upper()
        side = side.lower()
        currency = currency.upper()
        cache_key = (
            self.settings.toss_base_url,
            str(self.settings.toss_account_id or "auto"),
            symbol,
            side,
            currency,
        )
        cached = _PREVIEW_CACHE.get(cache_key)
        now = datetime.now(timezone.utc)
        if cached and cached[1] > now:
            return {**cached[0], "cached": True}

        account_seq = self.account_seq()
        orderbook = self.orderbook(symbol=symbol)
        buying_power = self.buying_power(currency=currency, account_seq=account_seq) if side == "buy" else {}
        best_ask = _first_price(orderbook.get("asks"))
        best_bid = _first_price(orderbook.get("bids"))
        preview = {
            "provider": "toss",
            "symbol": symbol,
            "side": side,
            "currency": orderbook.get("currency") or currency,
            "best_ask": best_ask,
            "best_bid": best_bid,
            "ask_depth": _depth_sum(orderbook.get("asks")),
            "bid_depth": _depth_sum(orderbook.get("bids")),
            "spread_pct": _spread_pct(best_bid, best_ask),
            "cash_buying_power": _to_float(buying_power.get("cashBuyingPower")),
            "buying_power": buying_power,
            "orderbook": orderbook,
            "account_seq": account_seq,
            "live_order_enabled": self.live_order_enabled(),
            "cached": False,
        }
        _PREVIEW_CACHE[cache_key] = (preview, now + timedelta(seconds=3))
        return preview

    def create_order(
        self,
        *,
        symbol: str,
        side: str,
        order_type: str = "MARKET",
        quantity: str | int | float | None = None,
        price: str | int | float | None = None,
        order_amount: str | int | float | None = None,
        time_in_force: str = "DAY",
        client_order_id: str | None = None,
        confirm_high_value_order: bool = False,
        account_seq: int | None = None,
        require_live_enabled: bool = True,
    ) -> dict:
        if require_live_enabled and not self.live_order_enabled():
            raise TossApiError(
                "Toss live order is disabled. Enable LIVE_ENABLED=true, TOSS_ENVIRONMENT=live, and TOSS_LIVE_ORDER_ENABLED=true first.",
                payload=self.status(),
            )

        normalized_side = side.upper()
        normalized_type = order_type.upper()
        if normalized_side not in {"BUY", "SELL"}:
            raise TossApiError("Toss 주문 방향은 BUY 또는 SELL 이어야 합니다.")
        if normalized_type not in {"MARKET", "LIMIT"}:
            raise TossApiError("Toss 주문 유형은 MARKET 또는 LIMIT 이어야 합니다.")
        if (quantity is None) == (order_amount is None):
            raise TossApiError("Toss 주문은 quantity 또는 orderAmount 중 정확히 하나만 사용해야 합니다.")
        if normalized_type == "MARKET" and price is not None:
            raise TossApiError("Toss MARKET 주문에는 price를 전달할 수 없습니다.")
        if normalized_type == "LIMIT" and price is None:
            raise TossApiError("Toss LIMIT 주문에는 price가 필요합니다.")
        if client_order_id and (len(client_order_id) > 36 or not all(ch.isalnum() or ch in "-_" for ch in client_order_id)):
            raise TossApiError("clientOrderId는 36자 이하 영숫자, '-' 또는 '_'만 사용할 수 있습니다.")

        body: dict[str, str | bool] = {
            "symbol": symbol.upper(),
            "side": normalized_side,
            "orderType": normalized_type,
            "timeInForce": time_in_force.upper(),
            "confirmHighValueOrder": bool(confirm_high_value_order),
        }
        if client_order_id:
            body["clientOrderId"] = client_order_id
        if quantity is not None:
            body["quantity"] = _decimal_string(quantity)
        if order_amount is not None:
            body["orderAmount"] = _decimal_string(order_amount)
        if price is not None:
            body["price"] = _decimal_string(price)

        payload = self._request(
            "POST",
            "/api/v1/orders",
            json_body=body,
            account_seq=account_seq or self.account_seq(),
        )
        return payload.get("result") or {}

    async def submit_order(self, **kwargs: object) -> dict:
        return self.create_order(**kwargs)

    def order_detail(self, *, order_id: str, account_seq: int | None = None) -> dict:
        payload = self._request(
            "GET",
            f"/api/v1/orders/{order_id}",
            account_seq=account_seq or self.account_seq(),
        )
        return payload.get("result") or {}

    def list_orders(
        self,
        *,
        status: str = "OPEN",
        symbol: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
        account_seq: int | None = None,
    ) -> dict:
        params: dict[str, str | int] = {"status": status.upper()}
        if symbol:
            params["symbol"] = symbol.upper()
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
        if cursor:
            params["cursor"] = cursor
        if limit is not None:
            params["limit"] = max(1, min(int(limit), 100))
        payload = self._request(
            "GET",
            "/api/v1/orders",
            params=params,
            account_seq=account_seq or self.account_seq(),
        )
        return payload.get("result") or {}

    def cancel_order(self, *, order_id: str, account_seq: int | None = None) -> dict:
        payload = self._request(
            "POST",
            f"/api/v1/orders/{order_id}/cancel",
            json_body={},
            account_seq=account_seq or self.account_seq(),
        )
        return payload.get("result") or {}

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json_body: dict | None = None,
        account_seq: int | None = None,
    ) -> dict:
        self._ensure_credentials()
        group = _rate_limit_group(path, method)
        last_error: TossApiError | None = None
        for attempt in range(_MAX_RATE_LIMIT_RETRIES):
            _wait_for_rate_limit(group)
            token = self._access_token_value()
            response = self._send_authorized_request(
                method,
                path,
                params=params,
                json_body=json_body,
                account_seq=account_seq,
                token=token,
            )
            if response.status_code == 401:
                token = self._refresh_access_token(stale_token=token)
                response = self._send_authorized_request(
                    method,
                    path,
                    params=params,
                    json_body=json_body,
                    account_seq=account_seq,
                    token=token,
                )
            response_headers = getattr(response, "headers", None)
            _note_rate_limit_headers(group, response_headers)
            if response.status_code == 429:
                cooldown = _apply_rate_limit_penalty(group, response_headers)
                last_error = TossApiError(
                    f"Toss API rate limited ({group}). Retry-After {cooldown:.1f}s.",
                    status_code=429,
                    payload=_safe_json(response),
                )
                if attempt + 1 < _MAX_RATE_LIMIT_RETRIES:
                    sleep(min(cooldown, 5.0))
                    continue
                raise last_error
            if response.status_code >= 400:
                payload = _safe_json(response)
                if response.status_code == 401 and _error_code(payload) == "invalid-token":
                    raise TossApiError(
                        "Toss token rejected after refresh. Check TOSS_APP_KEY/TOSS_APP_SECRET/TOSS_BASE_URL/TOSS_TOKEN_URL and restart the backend.",
                        status_code=response.status_code,
                        payload=payload,
                    )
                raise TossApiError(
                    f"Toss API error {response.status_code}: {response.text[:300]}",
                    status_code=response.status_code,
                    payload=payload,
                )
            return response.json()
        raise last_error or TossApiError(
            f"Toss API rate limit retries exhausted ({group}).", status_code=429
        )

    def _send_authorized_request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None,
        json_body: dict | None,
        account_seq: int | None,
        token: str,
    ) -> httpx.Response:
        headers = {"Authorization": f"Bearer {token}"}
        if account_seq is not None:
            headers["X-Tossinvest-Account"] = str(account_seq)
        with httpx.Client(timeout=20) as client:
            return client.request(
                method,
                f"{self.settings.toss_base_url.rstrip('/')}{path}",
                headers=headers,
                params=params or {},
                json=json_body,
            )

    def _access_token_value(self) -> str:
        with _TOKEN_LOCK:
            now = datetime.now(timezone.utc)
            if self._access_token and self._access_token_expires_at and self._access_token_expires_at > now:
                return self._access_token
            cached = self._local_cached_token()
            if cached and cached[1] > now:
                return self._adopt_token(*cached)
            shared = self._read_shared_token()
            if shared and shared[1] > now:
                return self._adopt_token(*shared)
            return self._acquire_new_token_locked(stale_token=None)

    def _refresh_access_token(self, *, stale_token: str) -> str:
        """Obtain a working token after a 401, coalescing the refresh app-wide.

        Toss issues a single active token per client: minting a new one invalidates the previous
        one. With api/worker/realtime_worker each running their own client that turns into a
        cascade where every process keeps invalidating the others. So the token is shared through
        Redis and only one holder of a cross-process lock ever mints a new one; everyone else
        adopts the freshly published token.
        """
        with _TOKEN_LOCK:
            now = datetime.now(timezone.utc)
            cached = self._local_cached_token()
            if cached and cached[1] > now and cached[0] != stale_token:
                return self._adopt_token(*cached)
            shared = self._read_shared_token()
            if shared and shared[1] > now and shared[0] != stale_token:
                return self._adopt_token(*shared)
            return self._acquire_new_token_locked(stale_token=stale_token)

    def _local_cached_token(self) -> tuple[str, datetime] | None:
        return _TOKEN_CACHE.get((self.settings.toss_token_url, self.settings.toss_app_key or ""))

    def _adopt_token(self, token: str, expires_at: datetime) -> str:
        self._access_token = token
        self._access_token_expires_at = expires_at
        _TOKEN_CACHE[(self.settings.toss_token_url, self.settings.toss_app_key or "")] = (token, expires_at)
        return token

    def _read_shared_token(self) -> tuple[str, datetime] | None:
        from app.services import shared_state

        payload = shared_state.get_json(_SHARED_TOKEN_KEY + (self.settings.toss_app_key or ""))
        if not isinstance(payload, dict):
            return None
        token = payload.get("token")
        expires_at = _parse_dt(payload.get("expires_at"))
        if not token or expires_at is None:
            return None
        return str(token), expires_at

    def _write_shared_token(self, token: str, expires_at: datetime) -> None:
        from app.services import shared_state

        ttl = max(1, int((expires_at - datetime.now(timezone.utc)).total_seconds()) + 60)
        shared_state.set_json(
            _SHARED_TOKEN_KEY + (self.settings.toss_app_key or ""),
            {"token": token, "expires_at": expires_at.isoformat()},
            ex=ttl,
        )

    def _acquire_new_token_locked(self, *, stale_token: str | None) -> str:
        from app.services import shared_state

        lock_key = _SHARED_TOKEN_LOCK_KEY + (self.settings.toss_app_key or "")
        lock_id = shared_state.acquire_lock(lock_key, ttl_sec=15)
        try:
            if lock_id is None:
                token = self._await_shared_token(stale_token=stale_token, timeout_sec=8.0)
                if token is not None:
                    return token
            else:
                now = datetime.now(timezone.utc)
                shared = self._read_shared_token()
                if shared and shared[1] > now and shared[0] != stale_token:
                    return self._adopt_token(*shared)
            return self._fetch_new_token_locked()
        finally:
            if lock_id is not None:
                shared_state.release_lock(lock_key, lock_id)

    def _await_shared_token(self, *, stale_token: str | None, timeout_sec: float) -> str | None:
        deadline = monotonic() + timeout_sec
        while monotonic() < deadline:
            sleep(0.2)
            now = datetime.now(timezone.utc)
            shared = self._read_shared_token()
            if shared and shared[1] > now and shared[0] != stale_token:
                return self._adopt_token(*shared)
        return None

    def _fetch_new_token_locked(self) -> str:
        cache_key = (self.settings.toss_token_url, self.settings.toss_app_key or "")
        self._ensure_credentials()
        response = None
        for attempt in range(_MAX_RATE_LIMIT_RETRIES):
            _wait_for_rate_limit("AUTH")
            with httpx.Client(timeout=20) as client:
                response = client.post(
                    self.settings.toss_token_url,
                    data={
                        "grant_type": "client_credentials",
                        "client_id": self.settings.toss_app_key or "",
                        "client_secret": self.settings.toss_app_secret or "",
                    },
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
            _note_rate_limit_headers("AUTH", response.headers)
            if response.status_code == 429:
                cooldown = _apply_rate_limit_penalty("AUTH", response.headers)
                if attempt + 1 < _MAX_RATE_LIMIT_RETRIES:
                    sleep(min(cooldown, 5.0))
                    continue
                raise TossApiError(
                    f"Toss OAuth rate limited. Retry-After {cooldown:.1f}s.",
                    status_code=429,
                    payload=_safe_json(response),
                )
            break
        if response.status_code >= 400:
            raise TossApiError(
                f"Toss OAuth error {response.status_code}: {response.text[:300]}",
                status_code=response.status_code,
                payload=_safe_json(response),
            )
        now = datetime.now(timezone.utc)
        payload = response.json()
        token = payload.get("access_token")
        if not token:
            raise TossApiError("Toss OAuth 응답에 access_token이 없습니다.", payload=payload)
        expires_in = _to_float(payload.get("expires_in")) or 3600
        self._access_token = str(token)
        self._access_token_expires_at = now + timedelta(seconds=max(60, expires_in - 60))
        _TOKEN_CACHE[cache_key] = (self._access_token, self._access_token_expires_at)
        self._write_shared_token(self._access_token, self._access_token_expires_at)
        return self._access_token

    def _ensure_credentials(self) -> None:
        if not self.settings.toss_app_key or not self.settings.toss_app_secret:
            raise TossApiError("TOSS_APP_KEY/TOSS_APP_SECRET이 설정되어 있지 않습니다.")


def _first_price(rows: Any) -> float | None:
    if not rows:
        return None
    return _to_float((rows[0] or {}).get("price"))


def _depth_sum(rows: Any) -> float | None:
    if not rows:
        return None
    total = 0.0
    for row in rows:
        total += _to_float((row or {}).get("volume")) or 0.0
    return total


def _spread_pct(bid: float | None, ask: float | None) -> float | None:
    if not bid or not ask:
        return None
    midpoint = (bid + ask) / 2
    return (ask - bid) / midpoint * 100 if midpoint > 0 else None


def _to_float(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def _decimal_string(value: str | int | float) -> str:
    parsed = _to_float(value)
    if parsed is None or parsed <= 0:
        raise TossApiError("Toss 주문 수량/금액/가격은 0보다 커야 합니다.")
    return f"{parsed:.6f}".rstrip("0").rstrip(".")


def _parse_dt(value: Any) -> datetime | None:
    raw = str(value or "")
    if not raw:
        return None
    if raw.endswith("Z"):
        raw = f"{raw[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _normalize_symbols(symbols: list[str], *, max_count: int) -> list[str]:
    normalized: list[str] = []
    for symbol in symbols:
        item = str(symbol or "").strip().upper()
        if item and item not in normalized:
            normalized.append(item)
        if len(normalized) >= max_count:
            break
    return normalized


def _safe_json(response: httpx.Response) -> dict:
    try:
        payload = response.json()
    except ValueError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _error_code(payload: dict) -> str | None:
    error = payload.get("error")
    if isinstance(error, dict):
        value = error.get("code")
        return str(value) if value else None
    return None


def _rate_limit_group(path: str, method: str = "GET") -> str:
    """Map a Toss REST path/method to its documented Rate Limits Group.

    Groups are taken verbatim from toss_openAPI.json. A few endpoints share a path but
    split by verb (e.g. GET /orders is ORDER_HISTORY while POST /orders is ORDER).
    """
    normalized = path.lower()
    verb = (method or "GET").upper()
    if "/accounts" in normalized:
        return "ACCOUNT"
    if "/holdings" in normalized:
        return "ASSET"
    if "/buying-power" in normalized or "/sellable-quantity" in normalized or "/commissions" in normalized:
        return "ORDER_INFO"
    if "/conditional-orders" in normalized:
        if "/modify" in normalized or "/cancel" in normalized:
            return "CONDITIONAL_ORDER"
        return "CONDITIONAL_ORDER_HISTORY" if verb == "GET" else "CONDITIONAL_ORDER"
    if "/market-indicators" in normalized:
        return "MARKET_INDICATOR_CHART" if "/candles" in normalized else "MARKET_INDICATOR"
    if "/orderbook" in normalized or "/prices" in normalized or "/trades" in normalized or "/price-limits" in normalized:
        return "MARKET_DATA"
    if "/orders" in normalized:
        if "/modify" in normalized or "/cancel" in normalized:
            return "ORDER"
        return "ORDER_HISTORY" if verb == "GET" else "ORDER"
    if "/candles" in normalized or "/chart" in normalized:
        return "MARKET_DATA_CHART"
    if "/rankings" in normalized:
        return "RANKING"
    if "/stocks" in normalized:
        return "STOCK"
    if "/exchange-rate" in normalized or "/market-calendar" in normalized:
        return "MARKET_INFO"
    return "MARKET_DATA"


def _effective_rate_limit(group: str, state: dict[str, float] | None = None) -> int:
    base = _RATE_LIMITS_PER_SEC.get(group, 3)
    if _is_order_peak_time_kst() and group in _PEAK_RATE_LIMITS_PER_SEC:
        base = min(base, _PEAK_RATE_LIMITS_PER_SEC[group])
    server_limit = (state or {}).get("limit")
    if server_limit and server_limit > 0:
        base = min(base, int(server_limit))
    return max(1, int(base * (1.0 - _RATE_LIMIT_HEADROOM_RATIO)))


def _is_order_peak_time_kst() -> bool:
    now = datetime.now(KST).time()
    return now >= datetime.strptime("09:00", "%H:%M").time() and now < datetime.strptime("09:10", "%H:%M").time()


def _parse_int_header(value: object) -> int | None:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def _parse_float_header(value: object) -> float | None:
    try:
        parsed = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    return parsed if parsed >= 0 else None


def _note_rate_limit_headers(group: str, headers: Any) -> None:
    """Fold the server's X-RateLimit-* headers into the shared per-group state.

    Because every backend process hits the same Toss token bucket, reacting to the
    server-reported ``remaining``/``reset`` gives cross-process coordination for free: the
    process that drains the bucket sees ``remaining == 0`` and backs everyone off until it
    refills, even though the in-process sliding window still shows room.
    """
    if headers is None:
        return
    limit = _parse_int_header(headers.get("X-RateLimit-Limit"))
    remaining = _parse_int_header(headers.get("X-RateLimit-Remaining"))
    reset = _parse_float_header(headers.get("X-RateLimit-Reset"))
    with _RATE_LIMIT_LOCK:
        state = _RATE_LIMIT_STATE.setdefault(group, {})
        if limit and limit > 0:
            state["limit"] = limit
        if remaining is not None:
            state["remaining"] = remaining
            if remaining <= _RATE_LIMIT_LOW_REMAINING:
                cooldown = reset if (reset and reset > 0) else 1.0
                state["cooldown_until"] = max(state.get("cooldown_until", 0.0), monotonic() + cooldown)


def _apply_rate_limit_penalty(group: str, headers: Any) -> float:
    """Honour Retry-After (or X-RateLimit-Reset) after a 429 and return the cooldown."""
    retry_after: float | None = None
    if headers is not None:
        retry_after = _parse_float_header(headers.get("Retry-After"))
        if retry_after is None:
            retry_after = _parse_float_header(headers.get("X-RateLimit-Reset"))
    cooldown = retry_after if (retry_after and retry_after > 0) else 1.0
    with _RATE_LIMIT_LOCK:
        state = _RATE_LIMIT_STATE.setdefault(group, {})
        state["remaining"] = 0
        state["cooldown_until"] = max(state.get("cooldown_until", 0.0), monotonic() + cooldown)
    return cooldown


def _wait_for_rate_limit(group: str) -> None:
    while True:
        with _RATE_LIMIT_LOCK:
            now = monotonic()
            state = _RATE_LIMIT_STATE.setdefault(group, {})
            cooldown_until = state.get("cooldown_until", 0.0)
            if cooldown_until > now:
                wait_seconds = cooldown_until - now
            else:
                limit = _effective_rate_limit(group, state)
                window = _RATE_LIMIT_WINDOWS.setdefault(group, deque())
                while window and now - window[0] >= 1.0:
                    window.popleft()
                if len(window) < limit:
                    window.append(now)
                    return
                wait_seconds = max(0.02, 1.0 - (now - window[0]) + 0.01)
        sleep(min(wait_seconds, 5.0))
