from fastapi import APIRouter

from app.core.config import get_settings

router = APIRouter()


@router.get("/status")
def paper_status() -> dict:
    settings = get_settings()
    if settings.trading_mode == "live":
        return {
            "mode": "live",
            "paper_enabled": False,
            "orders_route": None,
            "external_order_api_called": False,
            "toss_order_api_called": False,
            "message": "Internal paper status is disabled while TRADING_MODE=live.",
        }
    return {
        "mode": "internal_paper",
        "paper_enabled": True,
        "initial_equity_usd": 2000.0,
        "equity_usd": 2000.0,
        "orders_route": "/api/orders/paper",
        "external_order_api_called": False,
        "toss_order_api_called": False,
        "kis_order_api_called": False,
        "fill_model": {
            "uses_quote_spread": True,
            "uses_slippage": True,
            "partial_fill_support": "planned",
        },
        "blocked_reasons": ["외부 실시간 market data adapter가 연결되기 전에는 자동 paper 진입을 제한합니다."],
    }
