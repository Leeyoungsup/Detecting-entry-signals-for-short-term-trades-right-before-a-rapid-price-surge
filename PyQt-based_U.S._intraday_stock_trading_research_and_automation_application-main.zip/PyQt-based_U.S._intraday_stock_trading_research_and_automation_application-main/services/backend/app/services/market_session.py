from datetime import datetime, time
from zoneinfo import ZoneInfo

ET = ZoneInfo("America/New_York")
KST = ZoneInfo("Asia/Seoul")


def us_equity_session(now: datetime | None = None) -> dict:
    now_et = (now or datetime.now(tz=ET)).astimezone(ET)
    now_kst = now_et.astimezone(KST)
    weekday = now_et.weekday()
    if weekday >= 5:
        state = "closed_weekend"
        label = "주말 장마감"
    else:
        current = now_et.time()
        if time(4, 0) <= current < time(9, 30):
            state = "premarket"
            label = "프리마켓"
        elif time(9, 30) <= current < time(16, 0):
            state = "regular"
            label = "정규장"
        elif time(16, 0) <= current < time(20, 0):
            state = "afterhours"
            label = "애프터마켓"
        elif _is_daymarket_kst(now_kst):
            state = "daymarket"
            label = "데이마켓"
        else:
            state = "closed"
            label = "장마감"
    return {
        "market": "US equities",
        "state": state,
        "label": label,
        "now_et": now_et.isoformat(),
        "now_market": now_et.strftime("%Y-%m-%d %H:%M:%S ET"),
        "now_local": now_kst.strftime("%Y-%m-%d %H:%M:%S KST"),
        "premarket_open_et": "04:00",
        "regular_open_et": "09:30",
        "regular_close_et": "16:00",
        "afterhours_close_et": "20:00",
        "daymarket_open_kst": "10:00",
        "daymarket_close_kst": "16:50",
        "holiday_calendar": "not_configured",
    }


def active_trading_session(settings, now: datetime | None = None) -> dict:
    session = us_equity_session(now)
    allowed = realtime_session_allowed(settings, session)
    return {
        "active_market": "US" if allowed else "NONE",
        "mode": f"us_{settings.market_data_provider}_toss" if allowed else "closed",
        "label": f"미국장 {session.get('label')}",
        "automation_enabled": allowed,
        "market_data_provider": settings.market_data_provider if allowed else None,
        "execution_provider": "toss",
        "session": session,
        "us_session": session,
    }


def realtime_session_allowed(settings, session: dict | None = None) -> bool:
    current_session = session or us_equity_session()
    state = str(current_session.get("state") or "")
    if state == "regular":
        return True
    if settings.scanner_regular_session_only:
        return False
    if state == "premarket":
        return bool(settings.scanner_allow_premarket)
    if state == "afterhours":
        return bool(settings.scanner_allow_afterhours)
    if state == "daymarket":
        return bool(settings.scanner_allow_daymarket)
    return False


def _is_daymarket_kst(now_kst: datetime) -> bool:
    if now_kst.weekday() >= 5:
        return False
    current = now_kst.time()
    return time(10, 0) <= current < time(16, 50)
