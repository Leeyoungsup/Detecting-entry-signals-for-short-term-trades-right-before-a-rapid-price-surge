from app.adapters.market_data.alpaca import (
    ALPACA_MAX_INDIVIDUAL_BAR_FALLBACK_SYMBOLS,
    AlpacaMarketDataProvider,
    _is_allowed_common_stock,
)
from app.core.config import Settings
from datetime import datetime, timezone


def test_recent_minute_bars_follows_next_page_token_for_multi_symbol_results() -> None:
    provider = AlpacaMarketDataProvider(Settings(alpaca_key="key", alpaca_secret="secret"))
    calls: list[dict] = []

    def fake_request(path: str, params: dict | None = None) -> dict:
        assert path == "/v2/stocks/bars"
        calls.append(dict(params or {}))
        if not params or not params.get("page_token"):
            return {
                "bars": {
                    "AAA": [
                        {
                            "t": "2026-07-02T23:50:00Z",
                            "o": 10.0,
                            "h": 10.1,
                            "l": 9.9,
                            "c": 10.0,
                            "v": 100,
                        }
                    ]
                },
                "next_page_token": "page-2",
            }
        return {
            "bars": {
                "BBB": [
                    {
                        "t": "2026-07-02T23:50:00Z",
                        "o": 20.0,
                        "h": 20.1,
                        "l": 19.9,
                        "c": 20.0,
                        "v": 200,
                    }
                ]
            }
        }

    provider._request = fake_request  # type: ignore[method-assign]

    bars = provider._recent_minute_bars(["AAA", "BBB"], limit=1)

    assert set(bars) == {"AAA", "BBB"}
    assert bars["AAA"][0]["v"] == 100
    assert bars["BBB"][0]["v"] == 200
    assert calls[1]["page_token"] == "page-2"


def test_recent_minute_bars_fetches_missing_symbols_individually_after_batch() -> None:
    provider = AlpacaMarketDataProvider(Settings(alpaca_key="key", alpaca_secret="secret"))
    calls: list[dict] = []

    def fake_request(path: str, params: dict | None = None) -> dict:
        assert path == "/v2/stocks/bars"
        calls.append(dict(params or {}))
        symbols = str((params or {}).get("symbols") or "")
        if symbols == "AAA,BBB":
            return {
                "bars": {
                    "AAA": [
                        {
                            "t": "2026-07-02T23:50:00Z",
                            "o": 10.0,
                            "h": 10.1,
                            "l": 9.9,
                            "c": 10.0,
                            "v": 100,
                        }
                    ]
                }
            }
        if symbols == "BBB":
            return {
                "bars": {
                    "BBB": [
                        {
                            "t": "2026-07-02T23:50:00Z",
                            "o": 20.0,
                            "h": 20.1,
                            "l": 19.9,
                            "c": 20.0,
                            "v": 200,
                        }
                    ]
                }
            }
        return {"bars": {}}

    provider._request = fake_request  # type: ignore[method-assign]

    bars = provider._recent_minute_bars(["AAA", "BBB"], limit=1)

    assert set(bars) == {"AAA", "BBB"}
    assert bars["BBB"][0]["v"] == 200
    assert any(call.get("symbols") == "BBB" for call in calls)


def test_recent_minute_bars_limits_individual_missing_symbol_fallbacks() -> None:
    provider = AlpacaMarketDataProvider(Settings(alpaca_key="key", alpaca_secret="secret"))
    symbols = [f"AAA{i}" for i in range(ALPACA_MAX_INDIVIDUAL_BAR_FALLBACK_SYMBOLS + 3)]
    calls: list[dict] = []

    def fake_request(path: str, params: dict | None = None) -> dict:
        assert path == "/v2/stocks/bars"
        calls.append(dict(params or {}))
        return {"bars": {}}

    provider._request = fake_request  # type: ignore[method-assign]

    bars = provider._recent_minute_bars(symbols, limit=1)

    individual_calls = [
        call
        for call in calls
        if "," not in str(call.get("symbols") or "")
    ]
    assert bars == {}
    assert len(individual_calls) == ALPACA_MAX_INDIVIDUAL_BAR_FALLBACK_SYMBOLS


def test_common_stock_filter_rejects_warrants_rights_and_units() -> None:
    settings = Settings()

    assert not _is_allowed_common_stock("TVGNW", {"class": "us_equity", "status": "active", "name": "TVGN Warrant"}, settings)
    assert not _is_allowed_common_stock("COPL.WS", {"class": "us_equity", "status": "active", "name": "COPL WS"}, settings)
    assert not _is_allowed_common_stock("BAYAR", {"class": "us_equity", "status": "active", "name": "Bayview Rights"}, settings)
    assert not _is_allowed_common_stock("ABCU", {"class": "us_equity", "status": "active", "name": "ABC Units"}, settings)
    assert _is_allowed_common_stock("SNOW", {"class": "us_equity", "status": "active", "name": "Snowflake Inc."}, settings)


def test_stale_movers_payload_is_not_used_as_realtime_candidates() -> None:
    provider = AlpacaMarketDataProvider(Settings(alpaca_key="key", alpaca_secret="secret"))

    def fake_request(path: str, params: dict | None = None) -> dict:
        assert path == "/v1beta1/screener/stocks/movers"
        return {
            "last_updated": "2000-01-01T00:00:00.000000000Z",
            "gainers": [{"symbol": "OLD", "change": 1.0, "percent_change": 100.0}],
            "losers": [],
        }

    provider._request = fake_request  # type: ignore[method-assign]

    assert provider._mover_rows(limit=10) == []
    assert provider._last_data_error is not None
    assert "stale" in provider._last_data_error

    rows = provider._mover_rows(limit=10, allow_stale_bootstrap=True)

    assert rows[0]["symb"] == "OLD"
    assert rows[0]["mover_stale"] is True


def test_scanner_latest_bar_age_uses_bar_timestamp_not_quote_timestamp() -> None:
    provider = AlpacaMarketDataProvider(Settings(alpaca_key="key", alpaca_secret="secret"))
    provider._mover_rows = lambda limit=100, allow_stale_bootstrap=False: [  # type: ignore[method-assign]
        {"symb": "AAPL", "mover_rank": 1, "mover_change_pct": 12.5, "mover_side": "gainers", "screener_source": "movers_gainers"}
    ]
    provider._assets_for_symbols = lambda symbols: {  # type: ignore[method-assign]
        "AAPL": {"class": "us_equity", "status": "active", "name": "Apple Inc.", "tradable": True}
    }
    provider._snapshots = lambda symbols: {  # type: ignore[method-assign]
        "AAPL": {"latestQuote": {"t": datetime.now(timezone.utc).isoformat(), "bp": 10.0, "ap": 10.1}}
    }
    provider._recent_minute_bars = lambda symbols, limit=10: {  # type: ignore[method-assign]
        "AAPL": [{"t": "2000-01-01T00:00:00Z", "o": 10.0, "h": 10.1, "l": 9.9, "c": 10.0, "v": 1000}]
    }

    rows = provider.scanner_rankings()["trade_volume"]["output2"]

    assert rows[0]["latest_activity_age_sec"] < 5
    assert rows[0]["latest_bar_age_sec"] > 3600


def test_scanner_candidates_are_mover_abs_ranked_and_do_not_call_most_actives() -> None:
    provider = AlpacaMarketDataProvider(
        Settings(
            alpaca_key="key",
            alpaca_secret="secret",
            scanner_candidate_source="alpaca_movers",
            scanner_max_websocket_symbols=3,
        )
    )
    provider._mover_rows = lambda limit=100, allow_stale_bootstrap=False: [  # type: ignore[method-assign]
        {"symb": "LOWVOL", "mover_rank": 1, "mover_change_pct": 99.0, "mover_side": "gainers", "screener_source": "movers_gainers"},
        {"symb": "DROP", "mover_rank": 2, "mover_change_pct": -20.0, "mover_side": "losers", "screener_source": "movers_losers"},
        {"symb": "POP", "mover_rank": 3, "mover_change_pct": 15.0, "mover_side": "gainers", "screener_source": "movers_gainers"},
        {"symb": "MOVE", "mover_rank": 4, "mover_change_pct": 8.0, "mover_side": "gainers", "screener_source": "movers_gainers"},
    ]

    def fail_most_active(*, limit: int = 100, by: str = "volume") -> list[dict]:
        raise AssertionError("most-actives should not be used for mover-only scanner seeds")

    provider._most_active_rows = fail_most_active  # type: ignore[method-assign]
    provider._assets_for_symbols = lambda symbols: {  # type: ignore[method-assign]
        symbol: {"class": "us_equity", "status": "active", "name": f"{symbol} Inc.", "tradable": True}
        for symbol in symbols
    }
    provider._snapshots = lambda symbols: {}  # type: ignore[method-assign]
    provider._recent_minute_bars = lambda symbols, limit=10: {  # type: ignore[method-assign]
        symbol: [{"t": datetime.now(timezone.utc).isoformat(), "o": 10.0, "h": 10.1, "l": 9.9, "c": 10.0, "v": 10}]
        if symbol == "LOWVOL"
        else [{"t": datetime.now(timezone.utc).isoformat(), "o": 10.0, "h": 10.1, "l": 9.9, "c": 10.0, "v": 500}]
        for symbol in symbols
    }

    rows = provider.scanner_rankings()["trade_volume"]["output2"]

    assert [row["symb"] for row in rows] == ["DROP", "POP", "MOVE"]
    assert [row["mover_abs_rank"] for row in rows] == [1, 2, 3]


def test_scanner_keeps_movers_as_realtime_bootstrap_when_all_volume_is_missing() -> None:
    provider = AlpacaMarketDataProvider(
        Settings(
            alpaca_key="key",
            alpaca_secret="secret",
            scanner_candidate_source="alpaca_movers",
            scanner_max_websocket_symbols=2,
        )
    )
    provider._mover_rows = lambda limit=100, allow_stale_bootstrap=False: [  # type: ignore[method-assign]
        {"symb": "BOOT1", "mover_rank": 1, "mover_change_pct": 21.0, "mover_side": "gainers", "screener_source": "movers_gainers"},
        {"symb": "BOOT2", "mover_rank": 2, "mover_change_pct": -18.0, "mover_side": "losers", "screener_source": "movers_losers"},
    ]
    provider._assets_for_symbols = lambda symbols: {  # type: ignore[method-assign]
        symbol: {"class": "us_equity", "status": "active", "name": f"{symbol} Inc.", "tradable": True}
        for symbol in symbols
    }
    provider._snapshots = lambda symbols: {}  # type: ignore[method-assign]
    provider._recent_minute_bars = lambda symbols, limit=10: {}  # type: ignore[method-assign]

    rows = provider.scanner_rankings()["trade_volume"]["output2"]

    assert [row["symb"] for row in rows] == ["BOOT1", "BOOT2"]
    assert all(row["realtime_bootstrap_candidate"] is True for row in rows)
    assert all(row["volume_source"] == "provider_movers_realtime_bootstrap" for row in rows)
