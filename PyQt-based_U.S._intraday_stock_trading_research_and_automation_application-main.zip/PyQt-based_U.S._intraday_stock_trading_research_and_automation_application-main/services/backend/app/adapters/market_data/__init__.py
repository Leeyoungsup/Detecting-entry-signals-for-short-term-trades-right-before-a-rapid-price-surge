"""Market data adapters.

KIS is intentionally not the primary realtime market-data source anymore.
External providers should implement the MarketDataProvider interface here.
"""
