@echo off
setlocal
cd /d "%~dp0"
call scripts\setup-conda.cmd
if errorlevel 1 (
  echo.
  echo Setup failed.
  pause
  exit /b %errorlevel%
)
echo.
echo Setup complete.
pause
