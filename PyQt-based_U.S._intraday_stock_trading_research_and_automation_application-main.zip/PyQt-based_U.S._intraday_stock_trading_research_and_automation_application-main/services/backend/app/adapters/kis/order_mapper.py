from app.domain.models import OrderRequest


def map_order_request_to_kis(_: OrderRequest) -> dict:
    return {
        "TODO_KIS_VERIFY": (
            "Confirm overseas stock order endpoint, order type support, price fields, "
            "account fields, and mock/live TR IDs before implementation."
        )
    }
