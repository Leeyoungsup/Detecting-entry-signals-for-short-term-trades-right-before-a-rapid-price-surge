"""Replay-only reset experiment for chart-driven intraday strategies.

This script intentionally starts from a fresh strategy design. It treats BB and
MACD as regime signals, so entries and exits are paired:

- MACD line/signal both below zero: short scalp only, no BB-mid target.
- MACD line reclaim near zero: mean-reversion target can be BB mid.
- Trend pullback reclaim: ride only when structure already supports trend.

It imports the conservative replay utilities but runs its own chart-specific
exit loop so target/stop assumptions match the entry thesis.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ENGINE_PATH = PROJECT_ROOT / "scripts" / "replay_tc_shadow_strategies.py"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "exports" / "strategy_replay" / "chart_reset_experiment"

FILENAME_RE = re.compile(
    r"^(?P<symbol>[a-z0-9]+)_(?P<date>\d{4}-\d{2}-\d{2})_(?P<timerange>\d{4}-\d{4})_kst_(?P<hash>[0-9a-f]+)_enriched\.csv$"
)


def load_engine():
    spec = importlib.util.spec_from_file_location("tc_replay_engine_chart_reset", ENGINE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


engine = load_engine()


def volume_ratio(row: dict) -> float:
    return (row.get("volume") or 0.0) / max(row.get("volume_ma20") or 0.0, 1.0)


def close_location(row: dict) -> float:
    high = row.get("high")
    low = row.get("low")
    close = row.get("close")
    if high is None or low is None or close is None or high <= low:
        return 0.0
    return (close - low) / (high - low)


def green_or_reclaim(row: dict, previous: dict) -> bool:
    return row["close"] >= row["open"] or row["close"] >= previous["close"] * 1.002


def cost_fraction(row: dict) -> float:
    return engine.estimated_roundtrip_cost_fraction(row)


def spread_ok(row: dict) -> bool:
    close = row.get("close") or 0.0
    limit = 0.0115 if close < 2.0 else 0.0085
    return engine.spread_fraction(row) <= limit


def base_quality_ok(row: dict, *, min_notional: float = 60_000.0, max_cost: float = 0.013) -> bool:
    quote_count = row.get("quote_count")
    return (
        (row.get("notional_usd") or 0.0) >= min_notional
        and (quote_count is None or quote_count >= 5)
        and spread_ok(row)
        and cost_fraction(row) <= max_cost
    )


def macd_state(row: dict) -> tuple[float | None, float | None, float | None]:
    return row.get("macd_12_26"), row.get("macd_signal_9"), row.get("macd_histogram")


def macd_both_below_zero(row: dict) -> bool:
    macd, signal, _ = macd_state(row)
    return macd is not None and signal is not None and macd < 0 and signal < 0


def macd_depth_fraction(row: dict) -> float:
    close = row.get("close") or 0.0
    macd, signal, _ = macd_state(row)
    if close <= 0 or macd is None or signal is None:
        return 0.0
    return abs(min(macd, signal, 0.0)) / close


def macd_line_hook(rows: list[dict], index: int) -> bool:
    if index < 2:
        return False
    row = rows[index]
    previous = rows[index - 1]
    before = rows[index - 2]
    macd, signal, histogram = macd_state(row)
    prev_macd, prev_signal, prev_histogram = macd_state(previous)
    before_macd, _, _ = macd_state(before)
    if None in (macd, signal, prev_macd, before_macd):
        return False
    line_turning = macd > prev_macd >= before_macd or macd > prev_macd and prev_macd <= before_macd
    histogram_improving = histogram is None or prev_histogram is None or histogram >= prev_histogram
    gap_not_worsening = prev_signal is None or (macd - signal) >= (prev_macd - prev_signal) * 0.92
    return line_turning and (histogram_improving or gap_not_worsening)


def macd_signal_reclaim(rows: list[dict], index: int) -> bool:
    if index < 2:
        return False
    row = rows[index]
    previous = rows[index - 1]
    macd, signal, _ = macd_state(row)
    prev_macd, prev_signal, _ = macd_state(previous)
    if None in (macd, signal, prev_macd, prev_signal):
        return False
    cross_or_hold = (prev_macd <= prev_signal and macd > signal) or (macd > signal and macd > prev_macd)
    near_zero_or_positive = macd_depth_fraction(row) <= 0.006 or macd >= 0 or signal >= 0
    return cross_or_hold and near_zero_or_positive


def recent_lower_zone_touch(rows: list[dict], index: int, lookback: int = 5) -> int | None:
    for touch_index in range(index, max(0, index - lookback) - 1, -1):
        row = rows[touch_index]
        lower = row.get("bb_lower20")
        bb_position = row.get("bb_position_0_1")
        if lower is None:
            continue
        lower_touch = row["low"] <= lower * 1.012
        lower_zone = bb_position is not None and bb_position <= 0.22
        if lower_touch or lower_zone:
            return touch_index
    return None


def recent_mid_pullback(rows: list[dict], index: int, lookback: int = 8) -> bool:
    for item in rows[max(0, index - lookback) : index + 1]:
        mid = item.get("bb_mid20")
        ema20 = item.get("ema20")
        if mid is not None and item["low"] <= mid * 1.012:
            return True
        if ema20 is not None and item["low"] <= ema20 * 1.012:
            return True
    return False


def not_chasing_after_touch(rows: list[dict], index: int, touch_index: int, max_rebound: float = 0.075) -> bool:
    row = rows[index]
    touch_low = rows[touch_index]["low"]
    if touch_low <= 0:
        return True
    bb_position = row.get("bb_position_0_1")
    if bb_position is not None and bb_position > 0.78:
        return False
    return (row["close"] - touch_low) / touch_low <= max_rebound


def entry_guard(rows: list[dict], index: int, strategy: str, *, min_notional: float, max_cost: float) -> bool:
    row = rows[index]
    return (
        base_quality_ok(row, min_notional=min_notional, max_cost=max_cost)
        and engine.entry_reachability_ok(rows, index, strategy)
        and not engine.spread_widening(rows, index)
        and engine.failed_follow_through_ok(rows, index)
    )


def signal_lower_band_hook_scalp(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 30:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    lower = row.get("bb_lower20")
    if lower is None:
        return False, ""
    touch_index = recent_lower_zone_touch(rows, index, lookback=5)
    if touch_index is None:
        return False, ""
    ema9 = row.get("ema9")
    bb_position = row.get("bb_position_0_1")
    trade_strength = row.get("trade_strength")
    sell_pressure = row.get("sell_pressure")
    recent_change = engine.recent_10bar_change_fraction(rows, index) or 0.0
    reclaimed_lower = row["close"] >= lower * 1.002 and (bb_position is None or bb_position >= 0.08)
    near_ema9 = ema9 is None or row["close"] >= ema9 * 0.998
    flow_sane = (
        (trade_strength is None or trade_strength >= 50.0)
        and (sell_pressure is None or sell_pressure <= 55.0 or engine.sell_pressure_decreasing(rows, index))
    )
    not_still_dumping = row["low"] >= previous["low"] * 0.992 and -0.045 <= recent_change <= 0.035
    not_mid_chase = bb_position is None or bb_position <= 0.58
    if (
        entry_guard(rows, index, "Reset Lower Band Hook Scalp", min_notional=75_000.0, max_cost=0.0115)
        and macd_both_below_zero(row)
        and macd_line_hook(rows, index)
        and reclaimed_lower
        and near_ema9
        and flow_sane
        and not_still_dumping
        and not_mid_chase
        and green_or_reclaim(row, previous)
        and close_location(row) >= 0.58
        and volume_ratio(row) >= 0.85
        and not_chasing_after_touch(rows, index, touch_index, max_rebound=0.055)
    ):
        return True, "below_zero_macd_line_hook_lower_band_scalp"
    return False, ""


def signal_signal_reclaim_to_mid(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 35:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    lower_touch = recent_lower_zone_touch(rows, index, lookback=8)
    if lower_touch is None:
        return False, ""
    bb_mid = row.get("bb_mid20")
    ema9 = row.get("ema9")
    if bb_mid is None or ema9 is None:
        return False, ""
    enough_room = bb_mid >= row["close"] * 1.004
    reclaimed_ema9 = row["close"] >= ema9 * 0.998
    if (
        entry_guard(rows, index, "Reset MACD Signal Reclaim To Mid", min_notional=70_000.0, max_cost=0.012)
        and macd_signal_reclaim(rows, index)
        and enough_room
        and reclaimed_ema9
        and green_or_reclaim(row, previous)
        and close_location(row) >= 0.55
        and volume_ratio(row) >= 0.85
        and not_chasing_after_touch(rows, index, lower_touch, max_rebound=0.095)
    ):
        return True, "macd_line_signal_reclaim_bb_mid_room"
    return False, ""


def signal_trend_pullback_reclaim(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 35:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    ema9 = row.get("ema9")
    ema20 = row.get("ema20")
    vwap = row.get("session_vwap")
    macd, signal, _ = macd_state(row)
    if ema9 is None or ema20 is None or macd is None or signal is None:
        return False, ""
    bb_position = row.get("bb_position_0_1")
    trend_context = row["close"] >= ema20 * 1.002 and (vwap is None or row["close"] >= vwap * 0.998) and ema9 >= ema20 * 0.998
    pullback_seen = recent_mid_pullback(rows, index, lookback=8)
    reclaim = row["close"] >= ema9 * 0.998 and row["close"] >= previous["close"]
    macd_ok = macd > signal and macd >= 0 and signal >= 0
    recent_change = engine.recent_10bar_change_fraction(rows, index) or 0.0
    not_extended = bb_position is None or 0.35 <= bb_position <= 0.92
    if (
        entry_guard(rows, index, "Reset Trend Pullback Reclaim", min_notional=150_000.0, max_cost=0.0085)
        and trend_context
        and pullback_seen
        and reclaim
        and macd_ok
        and -0.01 <= recent_change <= 0.065
        and not_extended
        and green_or_reclaim(row, previous)
        and close_location(row) >= 0.58
        and volume_ratio(row) >= 1.05
    ):
        return True, "trend_pullback_ema9_reclaim_macd_above_signal"
    return False, ""


def signal_reclaim_pullback_continuation(rows: list[dict], index: int) -> tuple[bool, str]:
    if index < 40:
        return False, ""
    row = rows[index]
    previous = rows[index - 1]
    ema9 = row.get("ema9")
    ema20 = row.get("ema20")
    bb_mid = row.get("bb_mid20")
    bb_position = row.get("bb_position_0_1")
    macd, signal, _ = macd_state(row)
    if None in (ema9, ema20, bb_mid, macd, signal):
        return False, ""

    recovery_touch = recent_lower_zone_touch(rows, index, lookback=18)
    if recovery_touch is None:
        return False, ""
    recent_pullback = rows[max(0, index - 4) : index + 1]
    held_support = any(
        item["low"] <= ema9 * 1.012
        and item["low"] >= ema20 * 0.975
        and item["close"] >= ema20 * 0.985
        for item in recent_pullback
    )
    reclaimed = row["close"] >= ema9 * 1.001 and row["close"] >= previous["close"] * 1.001
    macd_ok = macd > signal and (macd >= 0 or macd_depth_fraction(row) <= 0.005)
    recent_change = engine.recent_10bar_change_fraction(rows, index) or 0.0
    not_extended = bb_position is None or 0.35 <= bb_position <= 1.02
    extension_ok = engine.ema9_extension_fraction(row) <= 0.045
    vwap = row.get("session_vwap")
    context_ok = vwap is None or row["close"] >= vwap * 0.985 or recent_change >= 0.025
    if (
        entry_guard(rows, index, "Reset Reclaim Pullback Continuation", min_notional=120_000.0, max_cost=0.0105)
        and held_support
        and reclaimed
        and macd_ok
        and context_ok
        and -0.015 <= recent_change <= 0.09
        and not_extended
        and extension_ok
        and close_location(row) >= 0.62
        and volume_ratio(row) >= 0.95
        and engine.sell_pressure_decreasing(rows, index)
    ):
        return True, "post_lower_band_reclaim_first_pullback_continuation"
    return False, ""


STRATEGIES = {
    "Reset Lower Band Hook Scalp": signal_lower_band_hook_scalp,
    "Reset MACD Signal Reclaim To Mid": signal_signal_reclaim_to_mid,
    "Reset Trend Pullback Reclaim": signal_trend_pullback_reclaim,
    "Reset Reclaim Pullback Continuation": signal_reclaim_pullback_continuation,
}

ALIASES = {
    "scalp": "Reset Lower Band Hook Scalp",
    "mid": "Reset MACD Signal Reclaim To Mid",
    "trend": "Reset Trend Pullback Reclaim",
    "pullback": "Reset Reclaim Pullback Continuation",
}


def strategy_stop_fraction(strategy: str) -> float:
    if strategy == "Reset Lower Band Hook Scalp":
        return 0.0095
    if strategy == "Reset MACD Signal Reclaim To Mid":
        return 0.014
    if strategy == "Reset Reclaim Pullback Continuation":
        return 0.016
    return 0.017


def apply_strategy_stop(portfolio: object, rows: list[dict], index: int) -> None:
    if portfolio.position is None:
        return
    position = portfolio.position
    fraction = strategy_stop_fraction(position.strategy)
    recent_lows = [rows[i]["low"] for i in range(max(0, index - 4), index + 1)]
    structure = min(recent_lows) * 0.996
    fixed = position.entry_price * (1 - fraction)
    position.stop_price = max(structure, fixed)


def target_price(row: dict, position: object) -> float | None:
    entry = position.entry_price
    strategy = position.strategy
    cost = cost_fraction(row)
    if strategy == "Reset Lower Band Hook Scalp":
        return entry * (1 + max(0.0065, min(0.014, cost + 0.0020)))

    if strategy == "Reset MACD Signal Reclaim To Mid":
        bb_mid = row.get("bb_mid20")
        macd, signal, _ = macd_state(row)
        if bb_mid is not None and macd is not None and signal is not None:
            mid_allowed = not (macd < 0 and signal < 0 and macd_depth_fraction(row) > 0.004)
            if mid_allowed and bb_mid > entry * 1.004:
                return min(bb_mid, entry * 1.026)
        return entry * (1 + max(0.006, min(0.018, cost + 0.0025)))

    if strategy == "Reset Reclaim Pullback Continuation":
        return entry * (1 + max(0.010, min(0.028, cost + 0.006)))

    bb_upper = row.get("bb_upper20")
    dynamic = entry * (1 + max(0.009, min(0.035, cost + 0.006)))
    if bb_upper is not None and bb_upper > entry * 1.006:
        return min(bb_upper, dynamic)
    return dynamic


def time_limit(strategy: str) -> int:
    if strategy == "Reset Lower Band Hook Scalp":
        return 4
    if strategy == "Reset MACD Signal Reclaim To Mid":
        return 8
    return 14


def close_at_price(portfolio: object, rows: list[dict], index: int, raw_price: float, reason: str) -> None:
    if portfolio.position is None:
        return
    position = portfolio.position
    row = rows[index]
    price = raw_price * (1 - 0.0008)
    gross = (price - position.entry_price) * position.quantity
    fees = engine.exit_fees(position.quantity, price)
    net = gross - fees
    portfolio.equity += net
    portfolio.trades.append(
        {
            "strategy": portfolio.strategy,
            "entry_time": position.entry_time,
            "exit_time": row["timestamp_kst"],
            "quantity": position.quantity,
            "entry_price": round(position.entry_price, 6),
            "exit_price": round(price, 6),
            "gross_pnl": round(gross, 4),
            "fees": round(fees, 4),
            "net_pnl": round(net, 4),
            "return_pct": round((price - position.entry_price) / position.entry_price * 100, 4),
            "entry_reason": position.reason,
            "exit_reason": reason,
            "entry_indicators_json": json.dumps(position.indicators, ensure_ascii=False),
            "exit_indicators_json": json.dumps(engine.indicator_snapshot(rows, index, position.strategy), ensure_ascii=False),
        }
    )
    portfolio.last_exit_index = index
    portfolio.last_exit_reason = reason
    portfolio.last_exit_net_pnl = net
    portfolio.position = None


def strategy_should_exit(rows: list[dict], index: int, position: object) -> tuple[bool, str]:
    row = rows[index]
    close = row["close"]
    entry = position.entry_price
    profit_pct = (close - entry) / entry if entry > 0 else 0.0
    bars = index - position.entry_index
    macd, signal, _ = macd_state(row)
    prev_macd = rows[index - 1].get("macd_12_26") if index > 0 else None

    if position.strategy == "Reset Lower Band Hook Scalp":
        if profit_pct >= 0.002 and macd is not None and signal is not None and macd < signal:
            return True, "scalp_macd_line_failed_after_profit"
        if bars >= time_limit(position.strategy):
            return True, "scalp_time_exit"
    elif position.strategy == "Reset MACD Signal Reclaim To Mid":
        if bars >= 2 and macd is not None and signal is not None and macd < signal and profit_pct <= 0.002:
            return True, "mid_reclaim_macd_cross_failed"
        if bars >= time_limit(position.strategy):
            return True, "mid_reclaim_time_exit"
    elif position.strategy == "Reset Reclaim Pullback Continuation":
        if bars >= 2 and macd is not None and signal is not None and macd < signal and profit_pct <= 0.003:
            return True, "pullback_macd_signal_lost"
        if bars >= time_limit(position.strategy):
            return True, "pullback_time_exit"
    else:
        if bars >= 3 and None not in (macd, prev_macd) and macd < prev_macd and profit_pct <= 0:
            return True, "trend_pullback_macd_rollover"
        if bars >= time_limit(position.strategy):
            return True, "trend_pullback_time_exit"
    return False, ""


def replay(rows: list[dict]) -> dict[str, object]:
    portfolios = {name: engine.Portfolio(strategy=name) for name in STRATEGIES}
    for index, row in enumerate(rows):
        for portfolio in portfolios.values():
            if portfolio.pending_exit and portfolio.position:
                engine.close_position(portfolio, rows, index, portfolio.pending_exit)
                portfolio.pending_exit = None
            if portfolio.pending_entry and portfolio.position is None:
                engine.open_position(portfolio, rows, index, portfolio.pending_entry)
                portfolio.pending_entry = None
                apply_strategy_stop(portfolio, rows, index)

        for portfolio in portfolios.values():
            position = portfolio.position
            if position is None:
                continue
            if row["low"] <= position.stop_price:
                engine.close_position(portfolio, rows, index, "strategy_stop", stop_fill=True)
                portfolio.pending_exit = None
                continue
            target = target_price(row, position)
            if target is not None and row["high"] >= target:
                close_at_price(portfolio, rows, index, target, "strategy_target")
                portfolio.pending_exit = None

        if index >= len(rows) - 1:
            continue
        allow_new_entry = engine._can_signal_entry(row, rows[index + 1], None, None)
        for name, detector in STRATEGIES.items():
            portfolio = portfolios[name]
            if portfolio.position:
                should, reason = strategy_should_exit(rows, index, portfolio.position)
                if should:
                    portfolio.pending_exit = reason
            elif (
                allow_new_entry
                and not portfolio.pending_entry
                and engine.strategy_reentry_allowed(portfolio, index, name)
                and engine.symbol_reentry_allowed(portfolios, index)
            ):
                ok, reason = detector(rows, index)
                if ok:
                    portfolio.pending_entry = {
                        "reason": reason,
                        "strategy": name,
                        "signal_close": row.get("close"),
                        "reference_high": engine.recent_high(rows, index, lookback=18, include_current=False),
                        "indicators": engine.indicator_snapshot(rows, index, name),
                    }

    last_index = len(rows) - 1
    for portfolio in portfolios.values():
        if portfolio.position:
            close_at_price(portfolio, rows, last_index, rows[last_index]["close"], "end_of_replay_flatten")
    return portfolios


def parse_window_key(path_file: Path) -> tuple[str, str, str] | None:
    match = FILENAME_RE.match(path_file.name)
    if not match:
        return None
    return (match.group("symbol").upper(), match.group("date"), match.group("timerange"))


def dedup_windows(paths: list[Path]) -> dict[tuple[str, str, str], Path]:
    best: dict[tuple[str, str, str], Path] = {}
    for path_file in paths:
        key = parse_window_key(path_file)
        if key is None:
            continue
        current = best.get(key)
        if current is None or path_file.stat().st_mtime > current.stat().st_mtime:
            best[key] = path_file
    return best


def aggregate(summaries: list[dict]) -> dict:
    trades = sum(item["trades"] for item in summaries)
    wins = sum(item["wins"] for item in summaries)
    losses = sum(item["losses"] for item in summaries)
    net = round(sum(item["net_pnl_usd"] for item in summaries), 4)
    return {
        "trades": trades,
        "wins": wins,
        "losses": losses,
        "net_pnl": net,
        "return_pct": round(net / 2000.0 * 100, 4),
        "win_rate_pct": round(wins / trades * 100, 2) if trades else 0.0,
    }


def summary_row(portfolio: object) -> dict:
    trades = portfolio.trades
    wins = [trade for trade in trades if trade["net_pnl"] > 0]
    losses = [trade for trade in trades if trade["net_pnl"] < 0]
    gross_profit = sum(trade["net_pnl"] for trade in wins)
    gross_loss = abs(sum(trade["net_pnl"] for trade in losses))
    return {
        "strategy": portfolio.strategy,
        "trades": len(trades),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate_pct": round(len(wins) / len(trades) * 100, 2) if trades else 0.0,
        "net_pnl_usd": round(sum(trade["net_pnl"] for trade in trades), 4),
        "return_on_2000_pct": round(sum(trade["net_pnl"] for trade in trades) / engine.INITIAL_EQUITY * 100, 4),
        "avg_win_usd": round(mean([trade["net_pnl"] for trade in wins]), 4) if wins else 0.0,
        "avg_loss_usd": round(mean([trade["net_pnl"] for trade in losses]), 4) if losses else 0.0,
        "profit_factor": round(gross_profit / gross_loss, 4) if gross_loss else (999.0 if gross_profit > 0 else 0.0),
        "max_win_usd": round(max([trade["net_pnl"] for trade in trades], default=0.0), 4),
        "max_loss_usd": round(min([trade["net_pnl"] for trade in losses], default=0.0), 4),
    }


def replay_window(path_file: Path) -> tuple[list[dict], list[dict]]:
    rows = engine.load_rows(path_file)
    portfolios = replay(rows)
    summaries = [summary_row(portfolio) for portfolio in portfolios.values()]
    trades = [
        {"source_file": path_file.name, **trade}
        for portfolio in portfolios.values()
        for trade in portfolio.trades
    ]
    return summaries, trades


def build_report(windows: dict[tuple[str, str, str], Path]) -> tuple[dict, list[dict]]:
    window_reports: list[dict] = []
    all_trades: list[dict] = []
    total_summaries: list[dict] = []
    by_strategy_summaries: dict[str, list[dict]] = defaultdict(list)
    by_symbol_summaries: dict[str, list[dict]] = defaultdict(list)

    for key in sorted(windows):
        symbol, date, timerange = key
        path_file = windows[key]
        summaries, trades = replay_window(path_file)
        all_trades.extend(trades)
        total_summaries.extend(summaries)
        for summary in summaries:
            by_strategy_summaries[summary["strategy"]].append(summary)
            by_symbol_summaries[symbol].append(summary)
        total = aggregate(summaries)
        window_reports.append(
            {
                "key": [symbol, date, timerange],
                "file": path_file.name,
                **total,
                "by_strategy": {item["strategy"]: item for item in summaries},
            }
        )

    by_strategy = {}
    for name, items in by_strategy_summaries.items():
        stat = aggregate(items)
        stat.pop("return_pct", None)
        by_strategy[name] = stat

    report = {
        "engine": str(ENGINE_PATH.relative_to(PROJECT_ROOT)),
        "strategy_names_active": list(STRATEGIES.keys()),
        "dedup_windows": len(windows),
        "total": aggregate(total_summaries),
        "by_strategy": by_strategy,
        "by_symbol": {
            symbol: {
                "windows": sum(1 for item in window_reports if item["key"][0] == symbol),
                **aggregate(items),
            }
            for symbol, items in sorted(by_symbol_summaries.items())
        },
        "windows": window_reports,
    }
    return report, all_trades


def write_outputs(report: dict, trades: list[dict], output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / "chart_reset_replay_summary.json"
    trades_path = output_dir / "chart_reset_replay_trades.csv"
    summary_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if trades:
        fields = list(trades[0].keys())
        with trades_path.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader()
            writer.writerows(trades)
    return summary_path, trades_path


def print_console(report: dict) -> None:
    total = report["total"]
    print("=" * 92)
    print(f"Chart reset experiment strategies: {', '.join(report['strategy_names_active'])}")
    print(f"Windows replayed                : {report['dedup_windows']}")
    print(
        f"TOTAL                           : {total['trades']} trades | win {total['win_rate_pct']}% | "
        f"net ${total['net_pnl']} | return {total['return_pct']}% (on $2000/strategy)"
    )
    print("-" * 92)
    print(f"{'BY STRATEGY':<42}{'trades':>7}{'win%':>8}{'net$':>12}")
    for name, stat in sorted(report["by_strategy"].items(), key=lambda item: item[1]["net_pnl"], reverse=True):
        print(f"{name:<42}{stat['trades']:>7}{stat['win_rate_pct']:>8}{stat['net_pnl']:>12}")
    print("-" * 92)
    print(f"{'TOP SYMBOLS':<10}{'win':>5}{'trades':>8}{'win%':>8}{'net$':>12}{'ret%':>9}")
    for symbol, stat in sorted(report["by_symbol"].items(), key=lambda item: item[1]["net_pnl"], reverse=True)[:12]:
        print(f"{symbol:<10}{stat['windows']:>5}{stat['trades']:>8}{stat['win_rate_pct']:>8}{stat['net_pnl']:>12}{stat['return_pct']:>9}")
    print("=" * 92)


def main() -> None:
    parser = argparse.ArgumentParser(description="Replay reset chart strategies over enriched replay windows.")
    parser.add_argument(
        "--dir",
        action="append",
        required=True,
        help="Folder containing *_enriched.csv windows. Pass multiple times to combine sessions.",
    )
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--only-key", action="append", choices=sorted(ALIASES.keys()))
    args = parser.parse_args()

    if args.only_key:
        selected_names = [ALIASES[key] for key in args.only_key]
        selected = {name: STRATEGIES[name] for name in dict.fromkeys(selected_names)}
        STRATEGIES.clear()
        STRATEGIES.update(selected)

    paths: list[Path] = []
    for raw_dir in args.dir:
        paths.extend(sorted(Path(raw_dir).resolve().glob("*_enriched.csv")))
    windows = dedup_windows(paths)
    report, trades = build_report(windows)
    summary_path, trades_path = write_outputs(report, trades, Path(args.output_dir).resolve())
    print_console(report)
    print(f"raw files: {len(paths)}  ->  dedup windows: {len(windows)}")
    print(f"summary : {summary_path.relative_to(PROJECT_ROOT)}")
    print(f"trades  : {trades_path.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
