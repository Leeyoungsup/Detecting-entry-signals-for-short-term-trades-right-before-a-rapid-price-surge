"""Morning review of live buy/sell decisions and the 120-candle window each saw.

Reads exports/live_snapshots/live_<ET-date>.jsonl (written live during the US
session) and prints the buy/sell timeline. With --export, dumps each decision's
120-candle window to a CSV so you can chart it and compare against the replay.

Usage:
    python scripts/show_live_snapshots.py                # latest day
    python scripts/show_live_snapshots.py 2026-07-13     # a specific ET date
    python scripts/show_live_snapshots.py --export       # also write per-decision candle CSVs
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = PROJECT_ROOT / "exports" / "live_snapshots"
CANDLE_FIELDS = ["market_date", "market_time", "open", "high", "low", "close", "volume", "source", "is_live"]


def _latest_log() -> Path | None:
    files = sorted(LOG_DIR.glob("live_20*.jsonl"))
    return files[-1] if files else None


def main() -> None:
    parser = argparse.ArgumentParser(description="Review live buy/sell decisions + their 120-candle windows.")
    parser.add_argument("date", nargs="?", help="ET session date YYYY-MM-DD (default: latest)")
    parser.add_argument("--export", action="store_true", help="write each decision's candle window to a CSV")
    args = parser.parse_args()

    path = (LOG_DIR / f"live_{args.date}.jsonl") if args.date else _latest_log()
    if path is None or not path.exists():
        print(f"no live snapshot log found ({'for ' + args.date if args.date else 'any date'}) in {LOG_DIR}")
        return

    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    print(f"=== {path.name} — {len(rows)} live decisions ===")
    print(f"{'#':>3} {'ET time':<20}{'side':<5}{'symbol':<8}{'strategy':<34}{'price':>9}{'qty':>5}{'candles':>8}  reason")
    print("-" * 110)
    for i, r in enumerate(rows):
        et = str(r.get("logged_at_et", ""))[11:19]
        print(
            f"{i:>3} {et:<20}{str(r.get('side','')):<5}{str(r.get('symbol','')):<8}"
            f"{str(r.get('strategy',''))[:33]:<34}{(r.get('execution_price') or 0):>9.4f}"
            f"{(r.get('quantity') or 0):>5.0f}{(r.get('candle_count') or 0):>8}  {r.get('reason','')}"
        )

    if args.export:
        out_dir = LOG_DIR / f"{path.stem}_candles"
        out_dir.mkdir(parents=True, exist_ok=True)
        for i, r in enumerate(rows):
            window = r.get("candle_window") or []
            if not window:
                continue
            name = f"{i:02d}_{r.get('side')}_{r.get('symbol')}_{str(r.get('logged_at_et',''))[11:19].replace(':','')}.csv"
            with (out_dir / name).open("w", newline="", encoding="utf-8-sig") as file:
                writer = csv.DictWriter(file, fieldnames=CANDLE_FIELDS)
                writer.writeheader()
                for c in window:
                    writer.writerow({k: c.get(k) for k in CANDLE_FIELDS})
        print(f"\nexported {len(rows)} candle windows -> {out_dir.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
