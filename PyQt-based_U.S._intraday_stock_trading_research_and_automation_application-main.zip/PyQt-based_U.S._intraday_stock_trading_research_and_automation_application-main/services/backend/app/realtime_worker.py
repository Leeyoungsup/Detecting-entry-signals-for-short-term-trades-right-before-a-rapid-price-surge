import asyncio
import signal

from app.core.logging import configure_logging
from app.services.realtime_runtime import realtime_runtime


async def main() -> None:
    configure_logging()
    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except NotImplementedError:
            pass
    realtime_runtime.start()
    try:
        await stop_event.wait()
    finally:
        await realtime_runtime.stop()


if __name__ == "__main__":
    asyncio.run(main())
