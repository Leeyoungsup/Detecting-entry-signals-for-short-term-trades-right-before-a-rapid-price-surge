"use client";

import { Save, Settings2 } from "lucide-react";
import { useMemo, useState } from "react";
import { API_BASE_URL } from "@/lib/api";

type Field = {
  key: string;
  label: string;
  type: "float" | "int" | "pct" | "bool" | "text" | string;
  value: number | boolean | string;
  min?: number;
  max?: number;
  step?: number;
};

type Group = {
  key: string;
  label: string;
  fields: Field[];
};

export function RuntimeSettingsEditor({ groups }: { groups: Group[] }) {
  const [isPending, setIsPending] = useState(false);
  const initial = useMemo(
    () => Object.fromEntries(groups.flatMap((group) => group.fields.map((field) => [field.key, field.value]))),
    [groups],
  );
  const [values, setValues] = useState<Record<string, number | boolean | string>>(initial);
  const [message, setMessage] = useState("");

  async function save() {
    setMessage("");
    setIsPending(true);
    try {
      const response = await fetch(`${API_BASE_URL}/api/settings`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ values }),
      });
      if (!response.ok) {
        const text = await response.text();
        setMessage(`저장 실패: ${text.slice(0, 180)}`);
        return;
      }
      setMessage("운영 런타임 설정을 적용했습니다.");
    } finally {
      setIsPending(false);
    }
  }

  return (
    <div className="space-y-5">
      {groups.map((group) => (
        <section key={group.key} className="rounded border border-line bg-white">
          <div className="flex items-center justify-between border-b border-line px-5 py-4">
            <h2 className="text-base font-semibold text-ink">{group.label}</h2>
            <Settings2 className="h-5 w-5 text-info" aria-hidden />
          </div>
          <div className="grid gap-4 p-5 lg:grid-cols-2">
            {group.fields.map((field) => (
              <EditorField
                key={field.key}
                field={field}
                value={values[field.key]}
                onChange={(value) => setValues((current) => ({ ...current, [field.key]: value }))}
              />
            ))}
          </div>
        </section>
      ))}
      <div className="sticky bottom-4 rounded border border-line bg-white p-4 shadow-sm">
        <button
          type="button"
          onClick={save}
          disabled={isPending}
          className="inline-flex h-10 items-center gap-2 rounded bg-ink px-4 text-sm font-semibold text-white transition hover:bg-zinc-800 disabled:opacity-60"
        >
          <Save className="h-4 w-4" aria-hidden />
          운영 설정 적용
        </button>
        {message ? <span className="ml-3 text-sm font-medium text-zinc-600">{message}</span> : null}
      </div>
    </div>
  );
}

function EditorField({
  field,
  value,
  onChange,
}: {
  field: Field;
  value: number | boolean | string;
  onChange: (value: number | boolean | string) => void;
}) {
  if (field.type === "bool") {
    return (
      <label className="flex min-h-20 items-center justify-between gap-4 rounded border border-line px-4 py-3">
        <span>
          <span className="block text-sm font-semibold text-ink">{field.label}</span>
          <span className="block text-xs text-zinc-500">{field.key}</span>
        </span>
        <input
          type="checkbox"
          checked={Boolean(value)}
          onChange={(event) => onChange(event.target.checked)}
          className="h-5 w-5 accent-zinc-900"
        />
      </label>
    );
  }

  if (field.type === "text") {
    return (
      <label className="block rounded border border-line px-4 py-3">
        <span className="block text-sm font-semibold text-ink">{field.label}</span>
        <span className="mt-1 block text-xs text-zinc-500">{field.key}</span>
        <input
          type="text"
          value={String(value ?? "")}
          onChange={(event) => onChange(event.target.value)}
          className="mt-3 h-10 w-full rounded border border-line px-3 text-sm outline-none focus:border-ink"
        />
      </label>
    );
  }

  const numeric = typeof value === "number" ? value : Number(value) || 0;
  return (
    <div className="rounded border border-line px-4 py-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm font-semibold text-ink">{field.label}</div>
          <div className="mt-1 text-xs text-zinc-500">{field.key}</div>
        </div>
        <input
          type="number"
          value={numeric}
          min={field.min}
          max={field.max}
          step={field.step ?? 1}
          onChange={(event) => onChange(Number(event.target.value))}
          className="h-9 w-28 rounded border border-line px-2 text-right text-sm font-semibold outline-none focus:border-ink"
        />
      </div>
      <input
        type="range"
        value={numeric}
        min={field.min ?? 0}
        max={field.max ?? 100}
        step={field.step ?? 1}
        onChange={(event) => onChange(Number(event.target.value))}
        className="mt-3 w-full accent-zinc-900"
      />
      <div className="mt-1 flex justify-between text-[11px] text-zinc-400">
        <span>{field.min ?? 0}</span>
        <span>{field.type === "pct" ? `${numeric}%` : numeric}</span>
        <span>{field.max ?? 100}</span>
      </div>
    </div>
  );
}
