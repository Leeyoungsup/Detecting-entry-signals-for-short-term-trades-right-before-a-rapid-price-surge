import asyncio
from datetime import datetime, timedelta, timezone
from copy import deepcopy
from threading import Lock
from threading import Thread
from time import sleep
from typing import Literal

from app.adapters.market_data.base import MarketDataUnavailableError
from app.core.config import get_settings
from app.domain.enums import StatusLevel
from app.domain.models import ScannerSnapshot
from app.services.candle_builder import candle_builder
from app.services.event_log import record_event
from app.services.event_log import list_events
from app.services.execution_pricing import ExecutionPricingError, execution_quote_snapshot
from app.services.market_data import get_market_data_service
from app.services.market_session import realtime_session_allowed, us_equity_session
from app.services import shared_state
from app.services import realtime_state
from app.services.symbol_names import resolve_symbol_name

# screener/volume source markers that identify a Toss ranking seed row. These rows come
# straight from the official ranking (no live 1m-bar / mover metrics yet), so they bypass the
# liquidity-floor and directional-impulse gates as a "primary seed". Includes the legacy WTS
# webpage-crawl marker and the current /api/v1/rankings marker.
TOSS_SEED_SOURCES = frozenset({"toss_wts_biggest_total_amount", "toss_rankings_api"})


def _is_toss_seed_source(*values: object) -> bool:
    return any(str(value or "") in TOSS_SEED_SOURCES for value in values)


RANKING_CACHE_TTL_SEC = 60  # 1min: refresh the 거래대금 ranking often enough to catch new intraday movers (RANKING rate-limit group is 5/sec, so 1 call/min is trivial)
_ranking_cache: dict[str, dict] = {}
_ranking_cache_at: dict[str, datetime] = {}
_ranking_refresh_in_progress: set[str] = set()
_subscription_check_at: datetime | None = None
_last_desired_symbols: list[str] = []
_last_seed_at: datetime | None = None
_seed_in_progress = False
_last_session_pause_state: str | None = None
_candidate_seen_at: dict[str, datetime] = {}
_candidate_last_seen_at: dict[str, datetime] = {}
_candidate_reject_cooldown_until: dict[str, datetime] = {}
_candidate_pool_rows: dict[str, tuple[dict, datetime]] = {}
_manual_candidates: dict[str, dict] = {}
_funnel_cache: dict | None = None
_funnel_cache_at: datetime | None = None
_funnel_refresh_in_progress = False
_funnel_cache_lock = Lock()
FUNNEL_CACHE_KEY = "trading_lab:scanner:funnel"
MANUAL_CANDIDATES_KEY = "trading_lab:scanner:manual_candidates"
LEGACY_FUNNEL_CACHE_KEY = "kis:scanner:funnel"
LEGACY_MANUAL_CANDIDATES_KEY = "kis:scanner:manual_candidates"


class ScannerService:
    async def ensure_realtime(
        self,
    ) -> dict:
        global _subscription_check_at, _last_desired_symbols, _last_session_pause_state
        settings = get_settings()
        provider = get_market_data_service().provider
        ws_status = provider.realtime_status()
        session = us_equity_session()
        if not realtime_session_allowed(settings, session):
            if settings.scanner_stop_realtime_when_session_closed and ws_status["status"] in ("starting", "connected"):
                ws_status = await provider.stop_realtime()
            state = str(session.get("state") or "unknown")
            if _last_session_pause_state != state:
                _last_session_pause_state = state
                record_event(
                    level="INFO",
                    event_type="scanner.session_paused",
                    message="미국장 자동 실시간 구독을 세션 정책에 따라 일시 중지했습니다.",
                    severity=StatusLevel.NORMAL,
                    payload={
                        "session": session,
                        "regular_session_only": settings.scanner_regular_session_only,
                        "allow_premarket": settings.scanner_allow_premarket,
                        "allow_afterhours": settings.scanner_allow_afterhours,
                        "websocket_status": ws_status,
                    },
                )
            return ws_status
        _last_session_pause_state = None
        if not settings.scanner_auto_start_enabled:
            return ws_status
        now = datetime.now(timezone.utc)
        if (
            ws_status["status"] in ("starting", "connected")
            and _subscription_check_at is not None
            and (now - _subscription_check_at).total_seconds() < settings.scanner_subscription_refresh_sec
        ):
            return ws_status

        desired_symbols = await asyncio.to_thread(
            _desired_realtime_symbols,
            exchange=settings.scanner_websocket_exchange,
            top_n=settings.scanner_max_websocket_symbols,
        )
        subscribed_symbols = sorted(provider.subscribed_symbols())
        connection_stale = _websocket_connection_stale(
            ws_status,
            max_age_sec=settings.scanner_realtime_stale_restart_sec,
        )
        desired_changed = subscribed_symbols != sorted(desired_symbols) or _last_desired_symbols != desired_symbols
        should_restart = (
            ws_status["status"] not in ("starting", "connected")
            or connection_stale
        )
        _subscription_check_at = now
        _last_desired_symbols = desired_symbols
        if settings.app_process_role == "worker":
            realtime_state.publish_desired_subscriptions(
                desired_symbols,
                exchange=settings.scanner_websocket_exchange,
                key_mode=settings.scanner_websocket_key_mode,
                reason="scanner.ensure_realtime",
            )
            return realtime_state.realtime_status() or realtime_state.waiting_status(local_status=ws_status)
        if desired_changed and not should_restart and hasattr(provider, "update_realtime"):
            return await provider.update_realtime(
                symbols=desired_symbols,
                exchange=settings.scanner_websocket_exchange,
                key_mode=settings.scanner_websocket_key_mode,
                subscribe_quotes=True,
                subscribe_trades=True,
            )
        should_restart = should_restart or desired_changed
        if not should_restart:
            return ws_status
        if ws_status["status"] in ("starting", "connected"):
            await provider.stop_realtime()
        payload = await self.start_realtime(
            top_n=settings.scanner_max_websocket_symbols,
            exchange=settings.scanner_websocket_exchange,
            key_mode=settings.scanner_websocket_key_mode,
            restart=False,
        )
        return payload["websocket"]

    async def maintenance_tick(self) -> dict:
        settings = get_settings()
        session = us_equity_session()
        if not realtime_session_allowed(settings, session):
            await self.ensure_realtime()
            return _session_paused_snapshot(datetime.now(timezone.utc).isoformat(), session)
        await self.ensure_realtime()
        return await asyncio.to_thread(self.funnel_snapshot, record=False)

    async def cached_funnel_snapshot(self) -> dict:
        settings = get_settings()
        snapshot = _cached_funnel_snapshot()
        if snapshot is None:
            if settings.app_process_role == "api":
                return _lightweight_funnel_snapshot()
            asyncio.create_task(self.refresh_funnel_cache())
            return _lightweight_funnel_snapshot()
        if _funnel_cache_stale():
            if settings.app_process_role != "api":
                asyncio.create_task(self.refresh_funnel_cache())
        snapshot.setdefault("cache", {})
        snapshot["cache"].update({"served_from_cache": True})
        return snapshot

    async def refresh_funnel_cache(self) -> None:
        global _funnel_refresh_in_progress
        if _funnel_refresh_in_progress:
            return
        _funnel_refresh_in_progress = True
        try:
            await asyncio.to_thread(self.funnel_snapshot, record=False)
        finally:
            _funnel_refresh_in_progress = False

    def funnel_snapshot(self, *, record: bool = True) -> dict:
        updated_at = datetime.now(timezone.utc).isoformat()
        settings = get_settings()
        session = us_equity_session()
        if not realtime_session_allowed(settings, session):
            return _session_paused_snapshot(updated_at, session)
        try:
            rankings = _get_rankings(exchange="NAS")
        except MarketDataUnavailableError as exc:
            return _fallback_snapshot(updated_at, str(exc))
        except Exception as exc:
            return _fallback_snapshot(updated_at, f"Market data ranking error: {exc}")

        scanner_rows = _with_manual_candidate_rows(_combined_ranking_rows(rankings, top_n=30))
        scanner_rows = _ranking_rows_or_fallback(scanner_rows, top_n=settings.scanner_max_websocket_symbols)
        candidates = [
            _row_to_snapshot(row)
            for row in scanner_rows[:30]
        ]
        provider = get_market_data_service().provider
        ws_status = _runtime_realtime_status(provider)
        flow_by_symbol = _runtime_order_flow_snapshot(provider)
        price_by_symbol = _runtime_realtime_prices(provider)
        subscribed_symbols = _runtime_subscribed_symbols(provider, ws_status)
        signal_events = list_events(limit=500, event_type="strategy.signal_evaluation")
        paper_events = list_events(limit=500, event_type="paper.order_event")
        enriched_candidates = [
            _merge_realtime(
                candidate,
                flow_by_symbol.get(candidate.symbol),
                subscribed_symbols,
                _realtime_price_for(price_by_symbol, candidate.symbol),
            )
            for candidate in candidates
        ]
        _schedule_strategy_candle_seed(enriched_candidates)
        candle_status = candle_builder.status()
        enriched_candidates = _apply_realtime_liquidity_ranks(enriched_candidates)
        ws_passed = sum(1 for candidate in enriched_candidates if candidate.selected_for_ws)
        order_flow_passed = sum(1 for candidate in enriched_candidates if candidate.selected_for_strategy)
        subscription_waiting = sum(1 for candidate in enriched_candidates if not candidate.selected_for_ws)
        strategy_watch_passed = sum(
            1
            for candidate in enriched_candidates
            if candidate.selected_for_strategy and candle_builder.has_symbol(candidate.symbol)
        )
        signal_passed_symbols = {
            str(event.payload.get("symbol") or "").upper()
            for event in signal_events
            if event.payload.get("passed")
        }
        risk_passed = sum(1 for candidate in enriched_candidates if candidate.symbol in signal_passed_symbols)
        payload = {
            "updated_at": updated_at,
            "websocket": ws_status,
            "realtime": {
                "subscribed_symbols": sorted(subscribed_symbols),
                "symbols_with_quote": ws_status["latest_quote_symbols"],
                "symbols_with_trade": ws_status["latest_trade_symbols"],
                "last_realtime_at": ws_status["last_realtime_at"],
            },
            "stages": [
                {"name": "Universe", "passed": len(scanner_rows), "rejected": 0, "top_reject_reasons": []},
                {
                    "name": "External market-data coarse scanner",
                    "passed": len(candidates),
                    "rejected": 0,
                    "top_reject_reasons": _coarse_reject_reasons(candidates),
                },
                {
                    "name": "Realtime polling watchlist",
                    "passed": ws_passed,
                    "rejected": 0,
                    "top_reject_reasons": _ws_reject_reasons(ws_status, ws_passed),
                    "waiting": subscription_waiting,
                },
                {
                    "name": "Order flow",
                    "passed": order_flow_passed,
                    "rejected": max(ws_passed - order_flow_passed, 0),
                    "top_reject_reasons": _order_flow_reject_reasons(ws_status, order_flow_passed),
                },
                {
                    "name": "Strategy signal watch",
                    "passed": strategy_watch_passed,
                    "rejected": max(order_flow_passed - strategy_watch_passed, 0),
                    "top_reject_reasons": [] if strategy_watch_passed else ["Toss polling tick 또는 REST seed candle 생성 대기 중입니다."],
                },
                {
                    "name": "Strategy signal",
                    "passed": len(signal_passed_symbols),
                    "rejected": max(strategy_watch_passed - len(signal_passed_symbols), 0),
                    "top_reject_reasons": _latest_signal_reject_reasons(signal_events),
                },
                {
                    "name": "Risk check",
                    "passed": risk_passed,
                    "rejected": max(len(signal_passed_symbols) - risk_passed, 0),
                    "top_reject_reasons": [],
                },
                {
                    "name": "Order candidate",
                    "passed": len(paper_events),
                    "rejected": 0,
                    "top_reject_reasons": [],
                },
            ],
            "candidates": [candidate.model_dump() for candidate in enriched_candidates],
            "manual_candidates": list_manual_candidates(),
            "candle_builder": candle_status,
            "cache": {
                "generated_at": updated_at,
                "served_from_cache": False,
            },
        }
        _store_funnel_cache(payload)
        if record:
            record_event(
                level="INFO",
                event_type="scanner.snapshot",
                message="Scanner Funnel snapshot generated.",
                severity=StatusLevel.NORMAL if order_flow_passed else StatusLevel.CAUTION,
                payload={
                    "updated_at": updated_at,
                    "websocket_status": ws_status["status"],
                    "rest_candidates": len(candidates),
                    "ws_passed": ws_passed,
                    "order_flow_passed": order_flow_passed,
                    "top_reject_reasons": [
                        reason
                        for stage in payload["stages"]
                        for reason in stage["top_reject_reasons"]
                    ][:10],
                },
            )
        return payload

    async def start_realtime(
        self,
        *,
        top_n: int = 10,
        exchange: str = "NAS",
        key_mode: Literal["regular", "daytime"] = "regular",
        restart: bool = True,
    ) -> dict:
        settings = get_settings()
        session = us_equity_session()
        provider = get_market_data_service().provider
        if not realtime_session_allowed(settings, session):
            ws_status = provider.realtime_status()
            if settings.scanner_stop_realtime_when_session_closed and ws_status["status"] in ("starting", "connected"):
                ws_status = await provider.stop_realtime()
            payload = {
                "symbols": [],
                "requested_symbols": [],
                "top_n": 0,
                "exchange": exchange,
                "key_mode": key_mode,
                "websocket": ws_status,
                "reduced_reason": f"{session.get('label')} 세션이라 실시간 구독을 시작하지 않았습니다.",
                "session": session,
            }
            record_event(
                level="INFO",
                event_type="scanner.realtime_paused",
                message="미국장 세션 정책으로 실시간 구독 시작을 보류했습니다.",
                severity=StatusLevel.NORMAL,
                payload=payload,
            )
            return payload
        requested_symbols = await asyncio.to_thread(
            _requested_realtime_symbols,
            exchange=exchange,
            top_n=top_n,
        )
        if settings.app_process_role in ("api", "worker"):
            realtime_state.publish_desired_subscriptions(
                requested_symbols,
                exchange=exchange,
                key_mode=key_mode,
                reason="scanner.realtime_start",
            )
            ws_status = realtime_state.realtime_status() or realtime_state.waiting_status(
                local_status=provider.realtime_status()
            )
            payload = {
                "symbols": sorted(realtime_state.subscribed_symbols(ws_status)),
                "requested_symbols": requested_symbols,
                "top_n": len(requested_symbols),
                "exchange": exchange,
                "key_mode": key_mode,
                "websocket": ws_status,
                "reduced_reason": "Realtime subscription request delegated to realtime worker.",
            }
            record_event(
                level="INFO",
                event_type="scanner.realtime_request",
                message="Realtime subscription request delegated to realtime worker.",
                severity=StatusLevel.NORMAL,
                payload=payload,
            )
            return payload
        if restart and provider.realtime_status()["status"] in ("starting", "connected"):
            await provider.stop_realtime()
        symbols, ws_status, reduced_reason = await _start_with_adaptive_limit(
            symbols=requested_symbols,
            exchange=exchange,
            key_mode=key_mode,
        )
        payload = {
            "symbols": symbols,
            "requested_symbols": requested_symbols,
            "top_n": len(symbols),
            "exchange": exchange,
            "key_mode": key_mode,
            "websocket": ws_status,
            "reduced_reason": reduced_reason,
        }
        record_event(
            level="INFO",
            event_type="scanner.realtime_start",
            message="외부 market-data 상위 후보 실시간 구독을 시작했습니다.",
            severity=StatusLevel.NORMAL,
            payload=payload,
        )
        return payload


def _store_funnel_cache(payload: dict) -> None:
    global _funnel_cache, _funnel_cache_at
    with _funnel_cache_lock:
        _funnel_cache = deepcopy(payload)
        _funnel_cache_at = datetime.now(timezone.utc)
    shared_state.set_json(FUNNEL_CACHE_KEY, payload, ex=180)


def _invalidate_funnel_cache() -> None:
    global _funnel_cache, _funnel_cache_at
    with _funnel_cache_lock:
        _funnel_cache = None
        _funnel_cache_at = None


def _cached_funnel_snapshot() -> dict | None:
    with _funnel_cache_lock:
        if _funnel_cache is None:
            shared = shared_state.get_json_any(FUNNEL_CACHE_KEY, LEGACY_FUNNEL_CACHE_KEY)
            if not isinstance(shared, dict):
                return None
            # 파일 기반 shared_state는 TTL을 지원하지 않으므로 직접 나이를 확인한다.
            # 5분(300초) 넘은 캐시는 stale로 처리해 fresh scan을 트리거한다.
            updated_str = shared.get("updated_at") or (shared.get("cache") or {}).get("generated_at") or ""
            if updated_str:
                try:
                    dt = datetime.fromisoformat(str(updated_str).replace("Z", "+00:00"))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    if (datetime.now(timezone.utc) - dt).total_seconds() > 300:
                        return None
                except (ValueError, TypeError, AttributeError):
                    return None
            return _with_runtime_realtime(deepcopy(shared))
        return _with_runtime_realtime(deepcopy(_funnel_cache))


def _funnel_cache_stale() -> bool:
    settings = get_settings()
    with _funnel_cache_lock:
        if _funnel_cache_at is None:
            return True
        max_age = max(5, int(settings.scanner_background_loop_interval_sec * 2))
        return (datetime.now(timezone.utc) - _funnel_cache_at).total_seconds() > max_age


def _lightweight_funnel_snapshot() -> dict:
    updated_at = datetime.now(timezone.utc).isoformat()
    provider = get_market_data_service().provider
    ws_status = _runtime_realtime_status(provider)
    subscribed_symbols = sorted(_runtime_subscribed_symbols(provider, ws_status))
    return {
        "updated_at": updated_at,
        "websocket": ws_status,
        "realtime": {
            "subscribed_symbols": subscribed_symbols,
            "symbols_with_quote": ws_status.get("latest_quote_symbols", []),
            "symbols_with_trade": ws_status.get("latest_trade_symbols", []),
            "last_realtime_at": ws_status.get("last_realtime_at"),
        },
        "stages": [
            {
                "name": "Scanner cache",
                "passed": 0,
                "rejected": 0,
                "top_reject_reasons": ["스캐너 캐시 생성 중입니다. 백그라운드 갱신 후 후보가 표시됩니다."],
            }
        ],
        "candidates": [],
        "manual_candidates": list_manual_candidates(),
        "candle_builder": candle_builder.status(),
        "cache": {
            "generated_at": updated_at,
            "served_from_cache": False,
            "warming": True,
        },
    }


def _with_runtime_realtime(payload: dict) -> dict:
    provider = get_market_data_service().provider
    ws_status = _runtime_realtime_status(provider)
    subscribed_symbols = sorted(_runtime_subscribed_symbols(provider, ws_status))
    payload["websocket"] = ws_status
    payload["realtime"] = {
        "subscribed_symbols": subscribed_symbols,
        "symbols_with_quote": ws_status.get("latest_quote_symbols", []),
        "symbols_with_trade": ws_status.get("latest_trade_symbols", []),
        "last_realtime_at": ws_status.get("last_realtime_at"),
    }
    return payload


def _runtime_realtime_status(provider) -> dict:
    shared = realtime_state.realtime_status()
    if shared:
        return shared
    local = provider.realtime_status()
    if get_settings().app_process_role == "worker":
        return realtime_state.waiting_status(local_status=local)
    return local


def _runtime_order_flow_snapshot(provider) -> dict[str, dict]:
    shared = realtime_state.realtime_order_flow()
    if shared:
        return shared
    if get_settings().app_process_role == "worker":
        return {}
    return provider.order_flow_snapshot()


def _runtime_realtime_prices(provider) -> dict[str, dict]:
    shared = realtime_state.realtime_prices()
    if shared:
        return shared
    if get_settings().app_process_role == "worker":
        return {}
    return provider.latest_prices() if hasattr(provider, "latest_prices") else {}


def _realtime_price_for(price_by_symbol: dict[str, dict], symbol: str) -> float | None:
    row = price_by_symbol.get(symbol) or price_by_symbol.get(str(symbol or "").upper())
    return _to_float((row or {}).get("last"))


def _runtime_subscribed_symbols(provider, ws_status: dict) -> set[str]:
    shared_symbols = realtime_state.subscribed_symbols(ws_status)
    if shared_symbols:
        return shared_symbols
    if get_settings().app_process_role == "worker":
        return set()
    return provider.subscribed_symbols()


def _row_to_snapshot(row: dict) -> ScannerSnapshot:
    symbol = (row.get("symb") or "").upper()
    _touch_candidate_observation(symbol)
    rank = _to_int(row.get("rank"))
    trade_strength = _to_float(row.get("tpow") or row.get("powx") or row.get("trade_strength"))
    score = _to_float(row.get("scanner_score")) or max(0.0, 100.0 - float((rank or 100) - 1))
    market_data_error = str(row.get("market_data_error") or "").strip()
    notes = [market_data_error] if market_data_error else []
    if row.get("manual_candidate"):
        notes.append("수동 후보")
    if row.get("manual_pinned"):
        notes.append("고정 구독")
    liquidity_reject_reason = str(row.get("liquidity_reject_reason") or "").strip()
    reject_reason = (
        f"유동성 기준 미달: {liquidity_reject_reason}"
        if liquidity_reject_reason
        else (
            "최신 1분봉/tick 근거 조회 실패로 전략 평가를 보류합니다."
            if market_data_error
            else "외부 market-data 랭킹 연결됨. 실시간 order flow 연결 전이라 전략 평가는 보류됩니다."
        )
    )
    return ScannerSnapshot(
        symbol=symbol,
        company_name=resolve_symbol_name(symbol, row),
        rank_total=rank,
        trade_notional_rank=_to_int(row.get("trade_notional_rank")),
        trade_volume_rank=_to_int(row.get("trade_volume_rank")),
        realtime_liquidity_rank=_to_int(row.get("realtime_liquidity_rank")),
        realtime_volume_rank=_to_int(row.get("realtime_volume_rank")),
        volume_surge_rank=_to_int(row.get("volume_surge_rank")),
        trade_strength_rank=_to_int(row.get("trade_strength_rank")),
        scanner_score=score,
        volume_score=_to_float(row.get("volume_score")),
        volume_1m=_to_float(row.get("volume_1m")),
        volume_velocity_10s=_to_float(row.get("volume_velocity_10s")),
        volume_surge_rate=_to_float(row.get("volume_surge_rate")),
        screener_source=str(row.get("screener_source") or "") or None,
        volume_source=str(row.get("volume_source") or "provider_ranking"),
        last_price=_to_float(row.get("last")),
        prev_close_price=_to_float(row.get("prev_close_price")),
        day_change_pct=_to_float(row.get("day_change_pct")),
        industry=str(row.get("industry") or "") or None,
        market_cap_usd=_to_float(row.get("market_cap_usd")),
        market_cap_krw=_to_float(row.get("market_cap_krw")),
        toss_trade_amount_krw=_to_float(row.get("toss_trade_amount_krw")),
        toss_trade_volume=_to_float(row.get("toss_trade_volume")),
        toss_buy_volume=_to_float(row.get("toss_buy_volume")),
        toss_sell_volume=_to_float(row.get("toss_sell_volume")),
        toss_buy_ratio_pct=_to_float(row.get("toss_buy_ratio_pct")),
        daily_volume=_to_float(row.get("daily_volume")),
        trade_count=_to_float(row.get("trade_count")),
        notional_1m=_to_float(row.get("notional_1m")) or _estimated_notional(_to_float(row.get("volume_1m")), _to_float(row.get("last"))),
        volume_10m=_to_float(row.get("volume_10m")),
        notional_10m=_to_float(row.get("notional_10m")),
        change_1m_pct=_to_float(row.get("change_1m_pct")),
        change_10m_pct=_to_float(row.get("change_10m_pct")),
        latest_bar_age_sec=_to_float(row.get("latest_bar_age_sec")),
        notional_5m=None,
        notional_velocity_10s=_to_float(row.get("notional_velocity_10s")),
        trade_strength=trade_strength,
        bb_state="market_data_ranked",
        reclaim_state="waiting_for_realtime_bars",
        selected_for_ws=False,
        selected_for_strategy=False,
        reject_reason=reject_reason,
        order_flow_notes=notes,
        last_update_age_sec=None,
    )


def _desired_realtime_symbols(*, exchange: str, top_n: int) -> list[str]:
    return _candidate_table_symbols(exchange=exchange, top_n=top_n)


def _requested_realtime_symbols(*, exchange: str, top_n: int) -> list[str]:
    return _candidate_table_symbols(exchange=exchange, top_n=top_n)


def _candidate_table_symbols(*, exchange: str, top_n: int) -> list[str]:
    rankings = _get_rankings_for_realtime(exchange=exchange)
    rows = _with_manual_candidate_rows(_combined_ranking_rows(rankings, top_n=top_n))
    rows = _ranking_rows_or_fallback(rows, top_n=top_n)
    return _symbols_from_ranking_rows(rows[:top_n], top_n=top_n)


def list_manual_candidates() -> list[dict]:
    _load_manual_candidates()
    return _manual_candidate_rows()


def _manual_candidate_rows() -> list[dict]:
    rows = []
    for symbol, item in sorted(_manual_candidates.items(), key=lambda pair: (not pair[1].get("pinned"), pair[0])):
        rows.append(
            {
                "symbol": symbol,
                "pinned": bool(item.get("pinned")),
                "added_at": item.get("added_at"),
                "updated_at": item.get("updated_at"),
            }
        )
    return rows


def add_manual_candidate(symbol: str, *, pinned: bool = True) -> dict:
    global _subscription_check_at
    _load_manual_candidates()
    normalized = _normalize_manual_symbol(symbol)
    now = datetime.now(timezone.utc).isoformat()
    existing = _manual_candidates.get(normalized, {})
    _manual_candidates[normalized] = {
        "symbol": normalized,
        "pinned": bool(pinned),
        "added_at": existing.get("added_at") or now,
        "updated_at": now,
    }
    _candidate_reject_cooldown_until.pop(normalized, None)
    _subscription_check_at = None
    _persist_manual_candidates()
    _invalidate_funnel_cache()
    return {"manual_candidates": _manual_candidate_rows()}


def update_manual_candidate(symbol: str, *, pinned: bool) -> dict:
    global _subscription_check_at
    _load_manual_candidates()
    normalized = _normalize_manual_symbol(symbol)
    if normalized not in _manual_candidates:
        add_manual_candidate(normalized, pinned=pinned)
    else:
        _manual_candidates[normalized]["pinned"] = bool(pinned)
        _manual_candidates[normalized]["updated_at"] = datetime.now(timezone.utc).isoformat()
        _subscription_check_at = None
    _persist_manual_candidates()
    _invalidate_funnel_cache()
    return {"manual_candidates": _manual_candidate_rows()}


def remove_manual_candidate(symbol: str) -> dict:
    global _subscription_check_at
    _load_manual_candidates()
    normalized = _normalize_manual_symbol(symbol)
    _manual_candidates.pop(normalized, None)
    _subscription_check_at = None
    _persist_manual_candidates()
    _invalidate_funnel_cache()
    return {"manual_candidates": _manual_candidate_rows()}


def _load_manual_candidates() -> None:
    payload = shared_state.get_json_any(MANUAL_CANDIDATES_KEY, LEGACY_MANUAL_CANDIDATES_KEY)
    if not isinstance(payload, dict):
        return
    rows = payload.get("items")
    if not isinstance(rows, list):
        return
    _manual_candidates.clear()
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            symbol = _normalize_manual_symbol(str(row.get("symbol") or ""))
        except ValueError:
            continue
        _manual_candidates[symbol] = {
            "symbol": symbol,
            "pinned": bool(row.get("pinned")),
            "added_at": row.get("added_at"),
            "updated_at": row.get("updated_at"),
        }


def _persist_manual_candidates() -> None:
    shared_state.set_json(
        MANUAL_CANDIDATES_KEY,
        {
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "items": _manual_candidate_rows(),
        },
        ex=86400,
    )


def _normalize_manual_symbol(symbol: str) -> str:
    normalized = "".join(ch for ch in str(symbol or "").strip().upper() if ch.isalnum() or ch in {".", "-"})
    if not normalized:
        raise ValueError("Ticker를 입력해주세요.")
    if len(normalized) > 12:
        raise ValueError("Ticker가 너무 깁니다.")
    return normalized


def _is_manual_candidate_symbol(symbol: str | None) -> bool:
    _load_manual_candidates()
    normalized = str(symbol or "").strip().upper()
    return bool(normalized and normalized in _manual_candidates)


def _with_manual_candidate_rows(rows: list[dict]) -> list[dict]:
    _load_manual_candidates()
    active_symbols = _active_paper_symbols()
    if not _manual_candidates and not active_symbols:
        return rows
    by_symbol = {str(row.get("symb") or "").upper(): dict(row) for row in rows}
    now_ts = datetime.now(timezone.utc).timestamp()
    for symbol in active_symbols:
        row = by_symbol.get(symbol, {"symb": symbol})
        row["symb"] = symbol
        row["company_name"] = row.get("company_name") or resolve_symbol_name(symbol)
        row = _hydrate_manual_candidate_row(row, symbol)
        row["active_paper_position"] = True
        row["scanner_score"] = max(_to_float(row.get("scanner_score")) or 0.0, 100.0)
        row["volume_source"] = row.get("volume_source") or "active_paper_position"
        row["liquidity_floor_passed"] = True
        row["liquidity_reject_reason"] = ""
        row["candidate_pool_last_seen_ts"] = now_ts
        by_symbol[symbol] = row
    for item in list_manual_candidates():
        symbol = item["symbol"]
        row = by_symbol.get(symbol, {"symb": symbol})
        row["symb"] = symbol
        row["company_name"] = row.get("company_name") or resolve_symbol_name(symbol)
        row = _hydrate_manual_candidate_row(row, symbol)
        row["manual_candidate"] = True
        row["manual_pinned"] = item["pinned"]
        row["scanner_score"] = max(_to_float(row.get("scanner_score")) or 0.0, 95.0 if item["pinned"] else 80.0)
        row["volume_source"] = row.get("volume_source") or "manual_candidate"
        row["liquidity_floor_passed"] = True
        row["liquidity_reject_reason"] = ""
        row["candidate_pool_last_seen_ts"] = now_ts
        by_symbol[symbol] = row
    merged = list(by_symbol.values())
    merged.sort(
        key=lambda row: (
            0 if row.get("active_paper_position") else 1,
            0 if row.get("manual_pinned") else 1,
            0 if row.get("manual_candidate") else 1,
            -float(row.get("scanner_score") or 0),
            row.get("symb") or "",
        )
    )
    for index, row in enumerate(merged, start=1):
        row["rank"] = index
    return merged[:30]


def _hydrate_manual_candidate_row(row: dict, symbol: str) -> dict:
    hydrated = dict(row)
    has_recent_liquidity = (
        _to_float(hydrated.get("notional_10m")) is not None
        and _to_float(hydrated.get("volume_10m")) is not None
        and _to_float(hydrated.get("latest_bar_age_sec")) is not None
    )
    if has_recent_liquidity:
        return hydrated
    try:
        bars = (
            get_market_data_service()
            .provider
            .minute_bars(symbol=symbol, exchange="NAS", interval="1", limit=30)
            .get("output2")
            or []
        )
    except Exception as exc:
        hydrated["market_data_error"] = hydrated.get("market_data_error") or f"수동 후보 1분봉 조회 실패: {exc}"
        return hydrated
    if not bars:
        hydrated["market_data_error"] = hydrated.get("market_data_error") or "수동 후보 1분봉 데이터 없음"
        return hydrated

    bars = sorted(bars, key=_provider_bar_sort_key)
    latest = bars[-1]
    last_10 = bars[-10:]
    latest_close = _to_float(latest.get("last"))
    latest_volume = _to_float(latest.get("evol"))
    latest_notional = _to_float(latest.get("eamt")) or _estimated_notional(latest_volume, latest_close)
    volume_10m = _sum_provider_bar_values(last_10, "evol")
    notional_10m = _sum_provider_bar_values(last_10, "eamt")

    hydrated["last"] = hydrated.get("last") or latest_close
    hydrated["volume_1m"] = hydrated.get("volume_1m") or latest_volume
    hydrated["notional_1m"] = hydrated.get("notional_1m") or latest_notional
    hydrated["volume_10m"] = hydrated.get("volume_10m") or volume_10m
    hydrated["notional_10m"] = hydrated.get("notional_10m") or notional_10m
    hydrated["change_1m_pct"] = hydrated.get("change_1m_pct") or _provider_bar_change_pct(latest)
    hydrated["change_10m_pct"] = hydrated.get("change_10m_pct") or _provider_bars_change_pct(last_10)
    hydrated["latest_bar_age_sec"] = hydrated.get("latest_bar_age_sec") or _provider_bar_age_sec(latest)
    hydrated["volume_source"] = "manual_official_1m_bars"
    hydrated["manual_liquidity_backfilled"] = True
    return hydrated


def _websocket_connection_stale(ws_status: dict, *, max_age_sec: int) -> bool:
    if max_age_sec <= 0:
        return False
    if ws_status.get("status") == "starting":
        started_at = _parse_iso_datetime(str(ws_status.get("started_at") or ""))
        return bool(started_at and (datetime.now(timezone.utc) - started_at).total_seconds() > max_age_sec)
    if ws_status.get("status") != "connected":
        return False
    last_seen = _parse_iso_datetime(
        str(ws_status.get("last_realtime_at") or ws_status.get("last_message_at") or "")
    )
    if last_seen is None:
        return False
    return (datetime.now(timezone.utc) - last_seen).total_seconds() > max_age_sec


def _parse_iso_datetime(value: str) -> datetime | None:
    if not value:
        return None
    if value.endswith("Z"):
        value = f"{value[:-1]}+00:00"
    if "." in value:
        head, tail = value.split(".", 1)
        fraction = tail
        zone = ""
        for marker in ("+", "-"):
            if marker in tail:
                fraction, zone = tail.split(marker, 1)
                zone = marker + zone
                break
        value = f"{head}.{fraction[:6]}{zone}"
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _provider_bar_sort_key(row: dict) -> str:
    return f"{row.get('xymd') or row.get('market_date') or ''}{str(row.get('xhms') or row.get('market_time') or '').zfill(6)}"


def _sum_provider_bar_values(rows: list[dict], key: str) -> float | None:
    values: list[float] = []
    for row in rows:
        value = _to_float(row.get(key))
        if value is None and key == "eamt":
            value = _estimated_notional(_to_float(row.get("evol")), _to_float(row.get("last")))
        if value is not None:
            values.append(value)
    return sum(values) if values else None


def _provider_bar_change_pct(row: dict) -> float | None:
    open_price = _to_float(row.get("open"))
    close = _to_float(row.get("last"))
    if open_price is None or close is None or open_price <= 0:
        return None
    return (close - open_price) / open_price * 100.0


def _provider_bars_change_pct(rows: list[dict]) -> float | None:
    if not rows:
        return None
    first_open = _to_float(rows[0].get("open")) or _to_float(rows[0].get("last"))
    latest_close = _to_float(rows[-1].get("last"))
    if first_open is None or latest_close is None or first_open <= 0:
        return None
    return (latest_close - first_open) / first_open * 100.0


def _provider_bar_age_sec(row: dict) -> float | None:
    date_value = str(row.get("xymd") or "").strip()
    time_value = str(row.get("xhms") or "").strip().zfill(6)
    if len(date_value) != 8 or len(time_value) < 6:
        return None
    try:
        parsed = datetime.strptime(f"{date_value}{time_value[:6]}", "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    except ValueError:
        return None
    return max(0.0, (datetime.now(timezone.utc) - parsed).total_seconds())


def _active_paper_symbols() -> list[str]:
    try:
        from app.services.paper_broker import InternalPaperBroker

        positions = InternalPaperBroker().state().get("positions", [])
    except Exception:
        return []
    symbols: list[str] = []
    for position in positions:
        symbol = str(position.get("symbol") or "").upper()
        quantity = _to_float(position.get("quantity")) or 0.0
        if symbol and quantity > 0 and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _symbols_from_ranking_rows(rows: list[dict], *, top_n: int) -> list[str]:
    symbols = []
    source_rows = rows
    scan_limit = max(1, min(max(top_n * 3, top_n), len(source_rows), 150))
    for row in source_rows[:scan_limit]:
        symbol = (row.get("symb") or "").upper()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
        if len(symbols) >= max(1, min(top_n, 100)):
            break
    return symbols


def _combined_ranking_rows(rankings: dict, *, top_n: int) -> list[dict]:
    settings = get_settings()
    max_scan_rows = max(50, min(int(settings.scanner_candidate_universe_size or 250), 500))
    by_symbol: dict[str, dict] = {}
    source_specs = [
        ("trade_volume", "trade_volume_rank", 1.00),
    ]
    for source, rank_key, weight in source_specs:
        rows = rankings.get(source, {}).get("output2") or []
        for index, row in enumerate(rows[:max_scan_rows]):
            symbol = (row.get("symb") or "").upper()
            if not symbol:
                continue
            rank = _to_int(row.get("rank")) or index + 1
            item = by_symbol.setdefault(symbol, {"symb": symbol})
            item["company_name"] = item.get("company_name") or resolve_symbol_name(symbol, row)
            item["screener_source"] = item.get("screener_source") or row.get("screener_source")
            item["toss_wts_rank"] = item.get("toss_wts_rank") or _to_int(row.get("toss_wts_rank"))
            item["toss_wts_notional"] = item.get("toss_wts_notional") or _to_float(row.get("toss_wts_notional"))
            item["industry"] = item.get("industry") or row.get("industry")
            item["market_cap_usd"] = item.get("market_cap_usd") or _to_float(row.get("market_cap_usd"))
            item["market_cap_krw"] = item.get("market_cap_krw") or _to_float(row.get("market_cap_krw"))
            item["toss_trade_amount_krw"] = item.get("toss_trade_amount_krw") or _to_float(row.get("toss_trade_amount_krw"))
            item["toss_trade_volume"] = item.get("toss_trade_volume") or _to_float(row.get("toss_trade_volume"))
            item["toss_buy_volume"] = item.get("toss_buy_volume") or _to_float(row.get("toss_buy_volume"))
            item["toss_sell_volume"] = item.get("toss_sell_volume") or _to_float(row.get("toss_sell_volume"))
            item["toss_buy_ratio_pct"] = item.get("toss_buy_ratio_pct") or _to_float(row.get("toss_buy_ratio_pct"))
            item["volume_source"] = item.get("volume_source") or row.get("volume_source")
            item["daily_volume"] = item.get("daily_volume") or _to_float(row.get("daily_volume"))
            item["trade_count"] = item.get("trade_count") or _to_float(row.get("trade_count"))
            item["last"] = item.get("last") or _to_float(row.get("last"))
            item["prev_close_price"] = item.get("prev_close_price") or _to_float(row.get("prev_close_price"))
            item["day_change_pct"] = item.get("day_change_pct") if item.get("day_change_pct") is not None else _to_float(row.get("day_change_pct"))
            item["latest_bar_age_sec"] = item.get("latest_bar_age_sec") or _to_float(row.get("latest_bar_age_sec"))
            item["market_data_error"] = item.get("market_data_error") or row.get("market_data_error")
            item["provider_scanner_score"] = max(
                _to_float(item.get("provider_scanner_score")) or 0.0,
                _to_float(row.get("scanner_score")) or 0.0,
            )
            item["volume_10m"] = item.get("volume_10m") or _to_float(row.get("volume_10m"))
            item["notional_1m"] = item.get("notional_1m") or _to_float(row.get("notional_1m"))
            item["notional_10m"] = item.get("notional_10m") or _to_float(row.get("notional_10m"))
            item["notional_velocity_10s"] = item.get("notional_velocity_10s") or _to_float(row.get("notional_velocity_10s"))
            item["change_1m_pct"] = item.get("change_1m_pct") or _to_float(row.get("change_1m_pct"))
            item["change_10m_pct"] = item.get("change_10m_pct") or _to_float(row.get("change_10m_pct"))
            # mover_change_pct/mover_side: legacy mover API 당일 변동률 — 전달 필수
            # _passes_candidate_directional_impulse 및 _liquidity_first_score에서 사용
            item["mover_change_pct"] = item.get("mover_change_pct") or _to_float(row.get("mover_change_pct"))
            item["mover_abs_change_pct"] = item.get("mover_abs_change_pct") or abs(_to_float(row.get("mover_abs_change_pct") or row.get("mover_change_pct")) or 0.0)
            item["mover_abs_rank"] = item.get("mover_abs_rank") or _to_int(row.get("mover_abs_rank"))
            item["mover_side"] = item.get("mover_side") or row.get("mover_side")
            item["mover_rank"] = item.get("mover_rank") or _to_float(row.get("mover_rank"))
            item["liquidity_impulse_score"] = max(
                _to_float(item.get("liquidity_impulse_score")) or 0.0,
                _to_float(row.get("liquidity_impulse_score")) or 0.0,
            )
            item["trade_notional_rank"] = item.get("trade_notional_rank") or _to_int(row.get("trade_notional_rank"))
            item["realtime_liquidity_rank"] = item.get("realtime_liquidity_rank") or _to_int(row.get("realtime_liquidity_rank"))
            item[rank_key] = rank
            item[f"{source}_score"] = _rank_score(rank) * weight
            if source == "trade_volume":
                item["volume_1m"] = _first_float(row, ["volume_1m", "tvol", "evol", "vol", "acml_vol", "shrn_iscd_tvol"])
            elif source == "volume_surge":
                item["volume_surge_rate"] = _first_float(row, ["rate", "vol_inrt", "prdy_vrss_vol_rate", "vol_rate"])
            elif source == "trade_strength":
                item["trade_strength"] = _first_float(row, ["tpow", "powx", "trade_strength"])

    rows = []
    min_candidate_score = get_settings().scanner_min_candidate_score
    for item in by_symbol.values():
        source_score = sum(_to_float(item.get(key)) or 0.0 for key in ("trade_volume_score",))
        is_mover_seed = bool(item.get("mover_abs_rank") or item.get("mover_change_pct"))
        is_toss_seed = _is_toss_seed_source(item.get("screener_source"))
        is_primary_seed = is_mover_seed or is_toss_seed
        scanner_score = _to_float(item.get("provider_scanner_score")) or 0.0
        if scanner_score <= 0 and not is_primary_seed:
            scanner_score = _liquidity_first_score(item)
        if scanner_score <= 0:
            scanner_score = source_score
        volume_score = (_to_float(item.get("volume_surge_score")) or 0.0) + (_to_float(item.get("trade_volume_score")) or 0.0)
        item["notional_1m"] = _to_float(item.get("notional_1m")) or _estimated_notional(_to_float(item.get("volume_1m")), _to_float(item.get("last")))
        item["scanner_score"] = round(scanner_score, 4)
        item["volume_score"] = round(volume_score, 4)
        if not _passes_instrument_filter(item) or _outside_scanner_price_range(item):
            continue
        liquidity_reject_reason = _liquidity_floor_reject_reason(item)
        if liquidity_reject_reason and not is_primary_seed:
            continue
        if not is_primary_seed and not _passes_candidate_directional_impulse(item):
            continue
        if scanner_score < min_candidate_score:
            continue
        item["liquidity_floor_passed"] = liquidity_reject_reason is None
        rows.append(item)
    rows = _merge_candidate_pool(rows)
    rows.sort(
        key=lambda row: (
            _to_int(row.get("toss_wts_rank")) or 9999,
            _to_int(row.get("mover_abs_rank")) or 9999,
            -abs(_to_float(row.get("mover_abs_change_pct") or row.get("mover_change_pct")) or 0.0),
            -float(row.get("scanner_score") or 0),
            -float(row.get("candidate_pool_last_seen_ts") or 0),
            row.get("symb") or "",
        )
    )
    for index, row in enumerate(rows, start=1):
        row["rank"] = index
    return rows[: max(1, min(top_n, 30))]


def _ranking_rows_or_fallback(rows: list[dict], *, top_n: int) -> list[dict]:
    if rows:
        return rows
    if not get_settings().scanner_use_fallback_when_no_rankings:
        return []
    return [
        {
            "rank": str(index + 1),
            "symb": symbol,
            "company_name": resolve_symbol_name(symbol),
            "scanner_score": max(0.0, 100.0 - index),
            "volume_score": None,
            "fallback": "true",
        }
        for index, symbol in enumerate(_fallback_symbols(top_n))
    ]


def _merge_candidate_pool(rows: list[dict]) -> list[dict]:
    now = datetime.now(timezone.utc)
    settings = get_settings()
    memory_sec = max(60, int(settings.scanner_candidate_memory_sec or 300))
    expired = [
        symbol
        for symbol, (_, last_seen_at) in _candidate_pool_rows.items()
        if (now - last_seen_at).total_seconds() > memory_sec
    ]
    for symbol in expired:
        _candidate_pool_rows.pop(symbol, None)

    for row in rows:
        symbol = str(row.get("symb") or "").upper()
        if not symbol:
            continue
        pooled = dict(row)
        pooled["candidate_pool_last_seen_at"] = now.isoformat()
        pooled["candidate_pool_last_seen_ts"] = now.timestamp()
        _candidate_pool_rows[symbol] = (pooled, now)

    merged: list[dict] = []
    for row, last_seen_at in _candidate_pool_rows.values():
        pooled = dict(row)
        pooled["candidate_pool_age_sec"] = max(0.0, (now - last_seen_at).total_seconds())
        pooled["candidate_pool_last_seen_ts"] = last_seen_at.timestamp()
        merged.append(pooled)
    return merged


def _fallback_symbols(top_n: int) -> list[str]:
    raw = get_settings().scanner_fallback_symbols
    symbols = []
    for part in raw.split(","):
        symbol = part.strip().upper()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols[: max(1, min(top_n, 20))]


async def _start_with_adaptive_limit(
    *,
    symbols: list[str],
    exchange: str,
    key_mode: Literal["regular", "daytime"],
) -> tuple[list[str], dict, str | None]:
    reduced_reason = None
    provider = get_market_data_service().provider
    if not symbols:
        return [], provider.realtime_status(), None
    for count in range(len(symbols), 0, -1):
        selected = symbols[:count]
        ws_status = await provider.start_realtime(
            symbols=selected,
            exchange=exchange,
            key_mode=key_mode,
            subscribe_quotes=True,
            subscribe_trades=True,
        )
        await asyncio.sleep(1.5)
        ws_status = provider.realtime_status()
        last_error = str(ws_status.get("last_error") or "")
        if ws_status["status"] != "error" or "MAX SUBSCRIBE OVER" not in last_error.upper():
            return selected, ws_status, reduced_reason
        await provider.stop_realtime()
        reduced_reason = f"Market data realtime 감시 제한으로 {count}개 종목 감시 실패: {last_error}"
    return [symbols[0]], await provider.start_realtime(symbols=[symbols[0]], exchange=exchange), reduced_reason


def _get_rankings(exchange: str) -> dict:
    global _ranking_cache, _ranking_cache_at
    now = datetime.now(timezone.utc)
    if (
        exchange in _ranking_cache
        and exchange in _ranking_cache_at
        and (now - _ranking_cache_at[exchange]).total_seconds() < RANKING_CACHE_TTL_SEC
    ):
        return _ranking_cache[exchange]
    _schedule_rankings_refresh(exchange)
    if exchange in _ranking_cache:
        return _ranking_cache[exchange]
    return _fallback_rankings(top_n=get_settings().scanner_max_websocket_symbols)


def _get_rankings_for_realtime(exchange: str) -> dict:
    global _ranking_cache, _ranking_cache_at
    now = datetime.now(timezone.utc)
    cached = _ranking_cache.get(exchange)
    cached_at = _ranking_cache_at.get(exchange)
    if cached and cached_at and (now - cached_at).total_seconds() < RANKING_CACHE_TTL_SEC:
        return cached
    try:
        rankings = get_market_data_service().provider.scanner_rankings(exchange=exchange)
    except Exception:
        return _get_rankings(exchange)
    _ranking_cache[exchange] = rankings
    _ranking_cache_at[exchange] = now
    return rankings


def _schedule_rankings_refresh(exchange: str) -> None:
    if exchange in _ranking_refresh_in_progress:
        return
    _ranking_refresh_in_progress.add(exchange)
    Thread(target=_refresh_rankings, args=(exchange,), daemon=True).start()


def _refresh_rankings(exchange: str) -> None:
    try:
        _ranking_cache[exchange] = get_market_data_service().provider.scanner_rankings(exchange=exchange)
        _ranking_cache_at[exchange] = datetime.now(timezone.utc)
    except Exception as exc:
        record_event(
            level="INFO",
            event_type="scanner.ranking_refresh_failed",
            message="외부 market-data 랭킹 백그라운드 갱신 실패",
            severity=StatusLevel.CAUTION,
            payload={"exchange": exchange, "reason": str(exc)[:200]},
        )
    finally:
        _ranking_refresh_in_progress.discard(exchange)


def _fallback_rankings(*, top_n: int) -> dict:
    rows = _ranking_rows_or_fallback([], top_n=top_n)
    return {
        "trade_volume": {"output2": rows},
        "volume_surge": {"output2": rows},
        "trade_strength": {"output2": []},
    }


def _schedule_strategy_candle_seed(candidates: list[ScannerSnapshot]) -> None:
    global _last_seed_at, _seed_in_progress
    settings = get_settings()
    if not settings.scanner_seed_minute_bars_enabled:
        return
    now = datetime.now(timezone.utc)
    if _last_seed_at and (now - _last_seed_at).total_seconds() < settings.scanner_seed_minute_bars_interval_sec:
        return
    if _seed_in_progress:
        return
    symbols = [
        candidate.symbol
        for candidate in candidates
        if candidate.selected_for_ws
    ][: settings.scanner_seed_minute_bars_max_symbols]
    if not symbols:
        _last_seed_at = now
        return
    seed_at, seed_key = _minute_boundary_seed_schedule(
        now,
        max_wait_sec=max(0, int(settings.scanner_seed_minute_bars_align_wait_sec or 0)),
    )
    if seed_at is None or seed_key is None:
        return
    _seed_in_progress = True
    _last_seed_at = seed_key
    Thread(target=_seed_strategy_candles_at, args=(symbols, seed_at, seed_key), daemon=True).start()


def _minute_boundary_seed_schedule(now: datetime, *, max_wait_sec: int) -> tuple[datetime | None, datetime | None]:
    boundary = now.replace(second=0, microsecond=0)
    seconds_after_boundary = (now - boundary).total_seconds()
    if seconds_after_boundary <= max_wait_sec:
        return now, boundary
    next_boundary = boundary + timedelta(minutes=1)
    seconds_until_next = (next_boundary - now).total_seconds()
    if seconds_until_next <= max_wait_sec:
        return next_boundary, next_boundary
    return None, None


def _seed_strategy_candles_at(symbols: list[str], seed_at: datetime, scheduled_for: datetime) -> None:
    delay = max(0.0, (seed_at - datetime.now(timezone.utc)).total_seconds())
    if delay > 0:
        sleep(delay)
    _seed_strategy_candles(symbols, scheduled_for=scheduled_for)


def _seed_strategy_candles(symbols: list[str], *, scheduled_for: datetime | None = None) -> None:
    global _seed_in_progress
    seeded: list[dict] = []
    failed: list[dict] = []
    try:
        # Inside the try: if resolving the provider throws (e.g. a transient DNS
        # "getaddrinfo failed" or network blip), the finally below must still run.
        # Otherwise _seed_in_progress stays True forever and every future seed is
        # blocked — leaving symbols stuck with only tick candles.
        provider = get_market_data_service().provider
        for symbol in symbols:
            try:
                rows = provider.minute_bars(symbol=symbol, exchange="NAS", interval="1", limit=120).get("output2") or []
                candles = _provider_bars_to_candles(symbol, rows)
                if candles:
                    candle_builder.seed(symbol, candles, source="provider_minute_scanner_seed")
                    seeded.append(
                        {
                            "symbol": symbol,
                            "count": len(candles),
                            "latest": _candle_key(candles[-1]),
                        }
                    )
            except Exception as exc:
                failed.append({"symbol": symbol, "reason": str(exc)[:160]})
        if seeded or failed:
            record_event(
                level="INFO",
                event_type="scanner.minute_seed",
                message="스캐너 후보 공식 1분봉 최신 갱신 완료" if seeded else "스캐너 후보 공식 1분봉 최신 갱신 실패",
                severity=StatusLevel.NORMAL if seeded else StatusLevel.CAUTION,
                payload={
                    "seeded": seeded,
                    "failed": failed[:5],
                    "scheduled_for": scheduled_for.isoformat() if scheduled_for else None,
                    "aligned_to_minute_boundary": True,
                },
            )
    finally:
        _seed_in_progress = False


def _provider_bars_to_candles(symbol: str, rows: list[dict]) -> list[dict]:
    candles = [
        {
            "symbol": symbol,
            "market_date": row.get("xymd") or row.get("tymd"),
            "market_time": row.get("xhms"),
            "korea_date": row.get("kymd"),
            "korea_time": row.get("khms"),
            "open": _to_float(row.get("open")),
            "high": _to_float(row.get("high")),
            "low": _to_float(row.get("low")),
            "close": _to_float(row.get("last")),
            "volume": _to_float(row.get("evol")),
            "notional": _to_float(row.get("eamt")),
        }
        for row in rows
    ]
    return sorted(candles, key=lambda row: f"{row.get('market_date') or ''}{str(row.get('market_time') or '').zfill(6)}")


def _candle_key(candle: dict) -> str:
    return f"{candle.get('market_date') or ''} {str(candle.get('market_time') or '').zfill(6)}".strip()


def _merge_realtime(
    candidate: ScannerSnapshot,
    flow: dict | None,
    subscribed_symbols: set[str],
    realtime_price: float | None = None,
) -> ScannerSnapshot:
    data = candidate.model_dump()
    # 1s batched /prices poll (all subscribed symbols) keeps 현재가 fresh even for symbols the
    # orderbook/trade round-robin hasn't reached yet. A live trade/quote tick below still wins
    # when present (it is at least as fresh and carries direction/volume).
    if realtime_price is not None:
        data["last_price"] = realtime_price
        data["current_price_source"] = "toss_prices_1s"
    manual_candidate = _is_manual_candidate_symbol(candidate.symbol)
    data["selected_for_ws"] = candidate.symbol in subscribed_symbols
    warmup_reject_reason = _candidate_warmup_reject_reason(candidate.symbol) if data["selected_for_ws"] else None
    if not data["selected_for_ws"]:
        data["selected_for_strategy"] = False
        data["reclaim_state"] = "waiting_for_subscription"
        data["reject_reason"] = "Toss 실시간 polling 감시 슬롯 대기 중인 후보입니다. 상위 랭킹 또는 보유/수동/상세 관심 종목이면 감시 대상으로 승격됩니다."
        data["order_flow_notes"] = [
            *data.get("order_flow_notes", []),
            "후보와 Toss polling 감시는 별도 단계입니다. 감시 전에는 실시간 order-flow 평가를 보류합니다.",
        ]
        return ScannerSnapshot(**data)
    if not flow:
        if data["selected_for_ws"]:
            data["reject_reason"] = None
            data["order_flow_notes"] = ["참고: Toss polling 구독 성공, trade tick 수신 전"]
            data["selected_for_strategy"] = False
            data["reclaim_state"] = "waiting_for_realtime_tick"
        return ScannerSnapshot(**data)

    has_realtime_trade = bool(flow.get("trade"))
    has_realtime_quote = bool(flow.get("quote"))
    if not has_realtime_trade and not has_realtime_quote:
        data["trade_strength"] = None
        data["sell_pressure"] = None
        data["spread_pct"] = None
        data["bid_ask_imbalance"] = None
        data["last_update_age_sec"] = None
        data["reject_reason"] = None
        data["order_flow_notes"] = ["참고: Toss polling 구독 성공, trade/quote tick 수신 전"]
        data["selected_for_strategy"] = False
        data["reclaim_state"] = "waiting_for_realtime_tick"
        return ScannerSnapshot(**data)

    realtime_volume = _none_if_zero(flow.get("volume_60s"))
    if realtime_volume is not None:
        official_volume = _to_float(data.get("volume_1m"))
        official_age = _to_float(data.get("latest_bar_age_sec"))
        use_official_until_tick_window_ready = (
            manual_candidate
            and official_volume is not None
            and official_age is not None
            and official_age <= max(300, get_settings().scanner_max_latest_bar_age_sec)
            and realtime_volume < official_volume
        )
        if use_official_until_tick_window_ready:
            data["volume_source"] = data.get("volume_source") or "manual_official_1m_bars"
        else:
            data["volume_1m"] = realtime_volume
            data["volume_source"] = "provider_ws_tick_60s"
    data["volume_velocity_10s"] = flow.get("volume_velocity_10s")
    data["trade_strength"] = flow.get("trade_strength") if has_realtime_trade else None
    data["sell_pressure"] = flow.get("sell_pressure")
    data["aggressive_buy_volume"] = flow.get("aggressive_buy_volume")
    data["aggressive_sell_volume"] = flow.get("aggressive_sell_volume")
    data["unknown_trade_volume"] = flow.get("unknown_trade_volume")
    data["spread_pct"] = flow.get("spread_pct")
    data["bid_ask_imbalance"] = flow.get("bid_ask_imbalance")
    data["last_update_age_sec"] = flow.get("last_update_age_sec")
    quote = flow.get("quote") or {}
    bid = _to_float(quote.get("bid"))
    ask = _to_float(quote.get("ask"))
    quote_mid = (bid + ask) / 2 if bid is not None and ask is not None else None
    data["bid_price"] = bid
    data["ask_price"] = ask
    data["quote_mid_price"] = quote_mid
    latest_trade_price = _to_float((flow.get("trade") or {}).get("last"))
    latest_price = latest_trade_price or quote_mid or ask or bid or data.get("last_price")
    if latest_price is not None:
        data["last_price"] = latest_price
        data["current_price_source"] = "toss_trade" if latest_trade_price is not None else "toss_orderbook_mid"
        if data.get("volume_1m") is not None:
            data["notional_1m"] = _estimated_notional(_to_float(data.get("volume_1m")), latest_price)
    data["order_flow_notes"] = _order_flow_notes(data)
    if warmup_reject_reason:
        data["order_flow_notes"] = [*data["order_flow_notes"], warmup_reject_reason]
    realtime_liquidity_passed = _passes_liquidity_floor(data)
    spread_limit = _dynamic_spread_limit(data)
    spread_failed = _spread_failed(data.get("spread_pct"), max_spread_pct=spread_limit)
    order_flow_without_spread = data["selected_for_ws"] and realtime_liquidity_passed and has_realtime_trade and _passes_order_flow_values(
        trade_strength=data["trade_strength"],
        spread_pct=data["spread_pct"],
        bid_ask_imbalance=data["bid_ask_imbalance"],
        ignore_spread=True,
        max_spread_pct=spread_limit,
    )
    toss_spread_note: str | None = None
    if order_flow_without_spread and spread_failed:
        toss_passed, toss_spread_note = _apply_toss_spread_verification(data)
        if toss_spread_note:
            data["order_flow_notes"] = [*data["order_flow_notes"], toss_spread_note]
        order_flow_passed = toss_passed
    else:
        order_flow_passed = (
            data["selected_for_ws"]
            and realtime_liquidity_passed
            and has_realtime_trade
            and _passes_order_flow_values(
                trade_strength=data["trade_strength"],
                spread_pct=data["spread_pct"],
                bid_ask_imbalance=data["bid_ask_imbalance"],
                max_spread_pct=spread_limit,
            )
        )
    impulse_passed = _passes_realtime_impulse_gate(data)
    if not impulse_passed:
        data["order_flow_notes"] = [
            *data["order_flow_notes"],
            "거래대금은 크지만 단타용 가격충격/가속이 부족해 전략 평가는 보류",
        ]
    order_flow_passed = order_flow_passed and impulse_passed
    # Order-flow gate is advisory unless explicitly required: by default hand every subscribed
    # candidate straight to the strategy stage (notes above are kept for context only), letting
    # the strategy signal do the real filtering instead of dropping symbols here.
    if not get_settings().scanner_require_order_flow_for_strategy:
        order_flow_passed = data["selected_for_ws"]
    data["selected_for_strategy"] = order_flow_passed and not warmup_reject_reason
    data["bb_state"] = "realtime_ranked" if flow.get("trade") or flow.get("quote") else data["bb_state"]
    data["reclaim_state"] = (
        "ready_for_indicator_engine" if data["selected_for_strategy"] else "waiting_for_order_flow"
    )
    if warmup_reject_reason:
        data["reclaim_state"] = "candidate_warmup"
    if not data["selected_for_ws"]:
        data["reclaim_state"] = "not_subscribed"
    if data["selected_for_strategy"]:
        data["reject_reason"] = "오더플로우 기준 통과. 볼린저 리클레임 전략 평가 대기."
    elif warmup_reject_reason:
        data["reject_reason"] = warmup_reject_reason
    elif not data["selected_for_ws"]:
        data["reject_reason"] = _flow_reject_reason(data)
    else:
        data["reject_reason"] = _flow_reject_reason(data)
        if (
            data["reject_reason"]
            and not _candidate_warmup_reject_reason(candidate.symbol)
            and not _is_spread_only_reject(data)
        ):
            _mark_candidate_reject_cooldown(candidate.symbol, reason=data["reject_reason"])
    return ScannerSnapshot(**data)


def _candidate_warmup_reject_reason(symbol: str) -> str | None:
    settings = get_settings()
    warmup_sec = max(0, int(settings.scanner_candidate_warmup_sec or 0))
    if warmup_sec <= 0:
        return None
    normalized = str(symbol or "").strip().upper()
    if not normalized or normalized in _active_paper_symbols():
        return None
    age_sec = _candidate_observation_age_sec(normalized)
    if age_sec is None or age_sec >= warmup_sec:
        return None
    return f"신규 후보 차트 관찰 중({age_sec:.0f}/{warmup_sec}초). tick/candle 축적 후 전략 평가"


def _touch_candidate_observation(symbol: str | None) -> None:
    normalized = str(symbol or "").strip().upper()
    if not normalized:
        return
    now = datetime.now(timezone.utc)
    _purge_candidate_state(now)
    _candidate_seen_at.setdefault(normalized, now)
    _candidate_last_seen_at[normalized] = now


def _candidate_observation_age_sec(symbol: str | None) -> float | None:
    normalized = str(symbol or "").strip().upper()
    if not normalized:
        return None
    _touch_candidate_observation(normalized)
    started_at = _candidate_seen_at.get(normalized)
    if started_at is None:
        return None
    return max(0.0, (datetime.now(timezone.utc) - started_at).total_seconds())


def _mark_candidate_reject_cooldown(symbol: str | None, *, reason: str | None = None) -> None:
    normalized = str(symbol or "").strip().upper()
    if not normalized or normalized in _active_paper_symbols():
        return
    settings = get_settings()
    cooldown_sec = max(0, int(settings.scanner_candidate_reject_cooldown_sec or 0))
    if cooldown_sec <= 0:
        return
    now = datetime.now(timezone.utc)
    if _candidate_reject_cooldown_until.get(normalized, now) > now:
        return
    _candidate_reject_cooldown_until[normalized] = now + timedelta(seconds=cooldown_sec)
    if reason:
        record_event(
            level="INFO",
            event_type="scanner.candidate_cooldown",
            message="탈락 후보 재구독 반복을 줄이기 위해 짧은 cooldown을 적용했습니다.",
            severity=StatusLevel.CAUTION,
            payload={"symbol": normalized, "reason": reason, "cooldown_sec": cooldown_sec},
        )


def _purge_candidate_state(now: datetime | None = None) -> None:
    settings = get_settings()
    now = now or datetime.now(timezone.utc)
    memory_sec = max(60, int(settings.scanner_candidate_memory_sec or 300))
    stale_symbols = [
        symbol
        for symbol, last_seen_at in _candidate_last_seen_at.items()
        if (now - last_seen_at).total_seconds() > memory_sec
    ]
    for symbol in stale_symbols:
        _candidate_seen_at.pop(symbol, None)
        _candidate_last_seen_at.pop(symbol, None)
        _candidate_reject_cooldown_until.pop(symbol, None)
    expired_cooldowns = [
        symbol for symbol, until in _candidate_reject_cooldown_until.items() if until <= now
    ]
    for symbol in expired_cooldowns:
        _candidate_reject_cooldown_until.pop(symbol, None)


def _apply_realtime_liquidity_ranks(candidates: list[ScannerSnapshot]) -> list[ScannerSnapshot]:
    realtime_rows = [
        candidate
        for candidate in candidates
        if candidate.selected_for_ws
        and candidate.volume_source == "provider_ws_tick_60s"
        and (candidate.notional_1m is not None or candidate.volume_1m is not None)
        and _passes_realtime_impulse_gate(candidate.model_dump())
    ]
    ranked_symbols = {
        candidate.symbol: index
        for index, candidate in enumerate(
            sorted(
                realtime_rows,
                key=lambda item: (
                    -_realtime_liquidity_impulse_score(item),
                    -abs(item.change_1m_pct or 0),
                    -abs(item.change_10m_pct or 0),
                    item.symbol,
                ),
            ),
            start=1,
        )
    }
    updated: list[ScannerSnapshot] = []
    for candidate in candidates:
        data = candidate.model_dump()
        data["realtime_liquidity_rank"] = ranked_symbols.get(candidate.symbol)
        data["realtime_volume_rank"] = ranked_symbols.get(candidate.symbol)
        updated.append(ScannerSnapshot(**data))
    return sorted(
        updated,
        key=lambda candidate: (
            candidate.realtime_liquidity_rank is None,
            candidate.realtime_liquidity_rank or 9999,
            candidate.rank_total or 9999,
            candidate.symbol,
        ),
    )


def _realtime_liquidity_impulse_score(candidate: ScannerSnapshot) -> float:
    notional_1m = candidate.notional_1m or _estimated_notional(candidate.volume_1m, candidate.last_price) or 0.0
    notional_10m = candidate.notional_10m or 0.0
    avg_1m_notional = notional_10m / 10.0 if notional_10m > 0 else 0.0
    notional_acceleration = notional_1m / avg_1m_notional if avg_1m_notional > 0 else 0.0
    flow_acceleration = candidate.volume_velocity_10s or candidate.notional_velocity_10s or notional_acceleration
    change_1m = candidate.change_1m_pct or 0.0
    change_10m = candidate.change_10m_pct or 0.0
    positive_change_1m = max(change_1m, 0.0)
    positive_change_10m = max(change_10m, 0.0)
    downside_flush = abs(min(change_10m, 0.0))
    spread_pct = candidate.spread_pct
    spread_quality = 1.0
    if spread_pct is not None:
        spread_quality = max(0.0, min(1.0, 1.0 - (spread_pct / max(_scanner_thresholds()["max_spread_pct"] * 4, 0.01))))

    acceleration_score = min(max(flow_acceleration, 0.0), 6.0) * 8.0
    price_impact_score = min(positive_change_1m, 8.0) * 6.0 + min(positive_change_10m, 20.0) * 1.0
    if downside_flush >= 0.75 and positive_change_1m >= 0.15:
        price_impact_score += min(downside_flush, 5.0) * 0.8
    spread_score = spread_quality * 8.0

    slow_large_cap_penalty = 0.0
    if notional_1m >= 250_000 and positive_change_1m < 0.20 and positive_change_10m < 0.60:
        slow_large_cap_penalty = 35.0
    weak_price_response_penalty = 0.0
    if flow_acceleration >= 1.2 and positive_change_1m < 0.25 and positive_change_10m < 0.75:
        weak_price_response_penalty = 25.0

    return max(
        0.0,
        acceleration_score
        + price_impact_score
        + spread_score
        - slow_large_cap_penalty
        - weak_price_response_penalty,
    )


def _passes_realtime_impulse_gate(data: dict) -> bool:
    symbol = str(data.get("symbol") or data.get("symb") or "").upper()
    manual_candidate = bool(data.get("manual_candidate") or data.get("manual_pinned") or _is_manual_candidate_symbol(symbol))
    is_toss_seed = _is_toss_seed_source(data.get("screener_source"), data.get("volume_source"))
    notional_1m = _to_float(data.get("notional_1m")) or _estimated_notional(
        _to_float(data.get("volume_1m")),
        _to_float(data.get("last_price")),
    ) or 0.0
    notional_10m = _to_float(data.get("notional_10m")) or 0.0
    avg_1m_notional = notional_10m / 10.0 if notional_10m > 0 else 0.0
    notional_acceleration = notional_1m / avg_1m_notional if avg_1m_notional > 0 else 0.0
    volume_velocity = _to_float(data.get("volume_velocity_10s"))
    velocity = volume_velocity if volume_velocity is not None else notional_acceleration
    change_1m = _to_float(data.get("change_1m_pct")) or 0.0
    change_10m = _to_float(data.get("change_10m_pct")) or 0.0

    if not manual_candidate and not is_toss_seed and notional_10m < get_settings().scanner_min_10m_notional_usd:
        return False
    has_price_impulse = change_1m >= 0.25 or change_10m >= 0.75
    has_strong_price_impulse = change_1m >= 0.35 or change_10m >= 1.0
    has_reclaim_after_flush = change_10m <= -0.75 and change_1m >= 0.20

    if velocity >= 1.2 and has_price_impulse:
        return True
    if has_strong_price_impulse:
        return True
    if velocity >= 1.2 and has_reclaim_after_flush:
        return True
    return notional_1m < 250_000 and velocity >= 1.0 and change_1m >= 0.20


def _passes_order_flow_values(
    *,
    trade_strength: float | None,
    spread_pct: float | None,
    bid_ask_imbalance: float | None,
    ignore_spread: bool = False,
    max_spread_pct: float | None = None,
) -> bool:
    thresholds = _scanner_thresholds()
    settings = get_settings()
    spread_limit = max_spread_pct if max_spread_pct is not None else thresholds["max_spread_pct"]
    if not ignore_spread and spread_pct is not None and spread_pct > spread_limit:
        return False
    if settings.scanner_require_trade_strength and (
        trade_strength is None or trade_strength < thresholds["min_trade_strength"]
    ):
        return False
    if settings.scanner_require_bid_ask_imbalance and (
        bid_ask_imbalance is None or bid_ask_imbalance < thresholds["min_bid_ask_imbalance"]
    ):
        return False
    return True


def _spread_failed(spread_pct: float | None, *, max_spread_pct: float | None = None) -> bool:
    spread_limit = max_spread_pct if max_spread_pct is not None else _scanner_thresholds()["max_spread_pct"]
    return spread_pct is not None and spread_pct > spread_limit


def _dynamic_spread_limit(data: dict) -> float:
    base = _scanner_thresholds()["max_spread_pct"]
    notional_1m = _to_float(data.get("notional_1m")) or _estimated_notional(
        _to_float(data.get("volume_1m")),
        _to_float(data.get("last_price")),
    ) or 0.0
    notional_10m = _to_float(data.get("notional_10m")) or 0.0
    avg_1m_notional = notional_10m / 10.0 if notional_10m > 0 else 0.0
    notional_acceleration = notional_1m / avg_1m_notional if avg_1m_notional > 0 else 0.0
    velocity = _to_float(data.get("volume_velocity_10s"))
    if velocity is None:
        velocity = _to_float(data.get("notional_velocity_10s"))
    if velocity is None:
        velocity = notional_acceleration
    change_1m = abs(_to_float(data.get("change_1m_pct")) or 0.0)
    change_10m = abs(_to_float(data.get("change_10m_pct")) or 0.0)

    limit = base
    if (notional_10m >= 25_000 or notional_1m >= 8_000) and (
        velocity >= 1.2 or change_1m >= 0.25 or change_10m >= 0.75
    ):
        limit = max(limit, 0.80)
    if (notional_10m >= 100_000 or notional_1m >= 25_000) and (
        velocity >= 1.5 or change_1m >= 0.50 or change_10m >= 1.25
    ):
        limit = max(limit, 1.00)
    if (notional_10m >= 250_000 or notional_1m >= 60_000) and (
        velocity >= 2.0 or change_1m >= 0.80 or change_10m >= 2.0
    ):
        limit = max(limit, 1.20)
    return min(limit, 1.20)


def _apply_toss_spread_verification(data: dict) -> tuple[bool, str | None]:
    symbol = str(data.get("symbol") or "").upper()
    if not symbol:
        return False, None
    spread_limit = _dynamic_spread_limit(data)
    realtime_spread = _to_float(data.get("spread_pct"))
    try:
        quote = execution_quote_snapshot(symbol, max_cache_age_sec=0.5)
    except ExecutionPricingError as exc:
        data["toss_spread_verification"] = {
            "status": "error",
            "realtime_spread_pct": realtime_spread,
            "error": str(exc),
            "payload": exc.payload,
        }
        return True, "경고: 실시간 스프레드가 스캐너 기준을 초과했지만 Toss 호가 확인에 실패했습니다. 주문 직전에 Toss 호가로 재검증합니다."

    toss_spread = _to_float(quote.get("spread_pct"))
    data["toss_spread_verification"] = {
        "status": "checked",
        "realtime_spread_pct": realtime_spread,
        "toss_spread_pct": toss_spread,
        "max_spread_pct": spread_limit,
        "bid": quote.get("bid"),
        "ask": quote.get("ask"),
        "source": quote.get("source"),
    }
    if toss_spread is None:
        return True, "경고: 실시간 스프레드가 스캐너 기준을 초과했지만 Toss bid/ask를 받지 못했습니다. 주문 직전에 Toss 호가로 재검증합니다."
    if toss_spread > spread_limit:
        data["spread_pct"] = toss_spread
        data["execution_spread_source"] = "toss_orderbook_quote"
        return True, f"경고: Toss 스프레드가 유동성 보정 스캐너 기준을 초과({toss_spread:.3f}% > {spread_limit:.3f}%). 주문 직전에 hard block 재검증."

    data["spread_pct"] = toss_spread
    data["execution_spread_source"] = "toss_orderbook_quote"
    return True, f"실시간 스프레드 초과({realtime_spread:.3f}%)는 Toss 호가 기준 통과({toss_spread:.3f}%)"


def _is_spread_only_reject(data: dict) -> bool:
    spread_limit = _dynamic_spread_limit(data)
    if not _spread_failed(_to_float(data.get("spread_pct")), max_spread_pct=spread_limit):
        verification = data.get("toss_spread_verification")
        if not isinstance(verification, dict):
            return False
        return verification.get("status") in {"checked", "error"}
    return _passes_order_flow_values(
        trade_strength=data.get("trade_strength"),
        spread_pct=data.get("spread_pct"),
        bid_ask_imbalance=data.get("bid_ask_imbalance"),
        ignore_spread=True,
        max_spread_pct=spread_limit,
    ) and _passes_liquidity_floor(data)


def _flow_reject_reason(data: dict) -> str | None:
    thresholds = _scanner_thresholds()
    spread_limit = _dynamic_spread_limit(data)
    reasons = []
    settings = get_settings()
    liquidity_reason = _liquidity_floor_reject_reason(data)
    if liquidity_reason:
        reasons.append(f"실시간 유동성 기준 미달: {liquidity_reason}")
    if data.get("volume_source") == "provider_ws_tick_60s" and not _passes_realtime_impulse_gate(data):
        reasons.append("가격충격/거래대금 가속 기준 미달")
    verification = data.get("toss_spread_verification")
    if data.get("spread_pct") is not None and data["spread_pct"] > spread_limit:
        if not isinstance(verification, dict):
            reasons.append(f"스프레드 기준 초과({data['spread_pct']:.3f}% > {spread_limit:.3f}%)")
    if settings.scanner_require_trade_strength and data.get("trade_strength") is None:
        reasons.append("체결강도 산출 불가")
    elif settings.scanner_require_trade_strength and data["trade_strength"] < thresholds["min_trade_strength"]:
        reasons.append(f"체결강도 기준 미달({data['trade_strength']:.2f} < {thresholds['min_trade_strength']:.2f})")
    if settings.scanner_require_bid_ask_imbalance and data.get("bid_ask_imbalance") is None:
        reasons.append("실시간 bid/ask 잔량 미수신")
    elif settings.scanner_require_bid_ask_imbalance and data["bid_ask_imbalance"] < thresholds["min_bid_ask_imbalance"]:
        reasons.append(
            f"bid/ask imbalance 기준 미달({data['bid_ask_imbalance']:.2f} < {thresholds['min_bid_ask_imbalance']:.2f})"
        )
    return ", ".join(reasons) if reasons else None


def _order_flow_notes(data: dict) -> list[str]:
    thresholds = _scanner_thresholds()
    notes: list[str] = []
    trade_strength = data.get("trade_strength")
    imbalance = data.get("bid_ask_imbalance")
    if data.get("selected_for_ws") and data.get("volume_source") != "provider_ws_tick_60s":
        if data.get("volume_source") in ("provider_latest_1m_bar", "provider_snapshot_1m_bar"):
            notes.append("참고: Toss trade tick 미수신, 1분봉 거래량 기준 감시")
        elif data.get("volume_source") == "provider_delayed_1m_bar":
            notes.append("참고: 최신 SIP 권한 오류로 지연 1분봉만 수신")
        elif data.get("volume_source") == "provider_snapshot_trade":
            notes.append("참고: Toss 최신 체결은 있으나 polling tick 집계 전")
        elif data.get("volume_source") == "provider_recent_data_error":
            notes.append("참고: Toss 최신 시세/1분봉 권한 오류")
        elif data.get("volume_source") == "provider_most_actives":
            notes.append("참고: Toss trade tick 미수신, 거래대금 랭킹 기준 감시")
        else:
            notes.append("참고: Toss trade tick 수신 전")
    if trade_strength is None:
        if data.get("volume_source") == "provider_ws_tick_60s":
            notes.append("참고: 체결 tick은 있으나 매수/매도 방향 추정 불가")
    if imbalance is None:
        if data.get("spread_pct") is not None:
            notes.append("참고: 호가 잔량 imbalance 산출 불가")
        elif data.get("volume_source") == "provider_ws_tick_60s":
            notes.append("참고: 실시간 bid/ask 미수신, 주문 전 Toss 호가 확인 필요")
    elif imbalance < thresholds["min_bid_ask_imbalance"]:
        notes.append(f"참고: bid/ask imbalance 낮음({imbalance:.2f})")
    return notes


def _scanner_thresholds() -> dict[str, float | str]:
    settings = get_settings()
    session_state = us_equity_session().get("state")
    if session_state == "regular":
        return {
            "session": "regular",
            "min_trade_strength": settings.scanner_min_trade_strength_regular,
            "max_spread_pct": settings.scanner_max_spread_pct_regular,
            "min_bid_ask_imbalance": settings.scanner_min_bid_ask_imbalance_regular,
        }
    return {
        "session": str(session_state or "extended"),
        "min_trade_strength": settings.scanner_min_trade_strength_extended,
        "max_spread_pct": settings.scanner_max_spread_pct_extended,
        "min_bid_ask_imbalance": settings.scanner_min_bid_ask_imbalance_extended,
    }


def _ws_reject_reasons(ws_status: dict, ws_passed: int) -> list[str]:
    if ws_status.get("last_error"):
        return [ws_status["last_error"]]
    if ws_status["status"] in ("starting", "connected"):
        return [] if ws_passed else ["Toss polling은 연결됐지만 스캐너 감시 후보가 없습니다."]
    return ["스캐너 자동 루프가 Toss 상위 후보를 realtime polling 감시하기 전입니다."]


def _order_flow_reject_reasons(ws_status: dict, order_flow_passed: int) -> list[str]:
    if order_flow_passed:
        return []
    if ws_status.get("last_realtime_at"):
        return ["실시간 tick은 수신 중이나 스프레드/데이터 신선도 기준 통과 종목이 없습니다."]
    if ws_status["status"] == "starting":
        return ["Toss polling 감시 목록 준비 중입니다."]
    if ws_status["status"] == "connected":
        return []
    return ["Toss polling 미시작으로 order flow 계산 대기 중입니다."]


def _coarse_reject_reasons(candidates: list[ScannerSnapshot]) -> list[str]:
    if candidates:
        return []
    settings = get_settings()
    market_status = get_market_data_service().status()
    data_error = market_status.get("last_data_error")
    reasons = [
        "실시간 후보는 Toss 거래대금 랭킹을 우선하며, 외부 일일/누적 랭킹은 보조로만 취급합니다.",
        "후보 선정 단계에서는 1분/10분 거래대금으로 다시 자르지 않고, 현재가/스프레드/체결 흐름은 Toss polling으로 갱신합니다.",
    ]
    if data_error:
        reasons.insert(0, str(data_error))
    if not settings.scanner_allow_ranking_only_for_ws:
        reasons.append("랭킹-only 후보는 오래된 후보일 수 있어 Toss polling 감시에서도 제외합니다.")
    return reasons


def _latest_signal_reject_reasons(signal_events: list) -> list[str]:
    reasons = []
    for event in reversed(signal_events[-50:]):
        reason = event.payload.get("reject_reason")
        if reason and reason not in reasons:
            reasons.append(reason)
        if len(reasons) >= 5:
            break
    return reasons


def _none_if_zero(value: float | None) -> float | None:
    if value is None or value == 0:
        return None
    return value


def _fallback_snapshot(updated_at: str, reason: str) -> dict:
    return {
        "updated_at": updated_at,
        "stages": [
            {"name": "Universe", "passed": 0, "rejected": 0, "top_reject_reasons": [reason]},
            {"name": "External market-data coarse scanner", "passed": 0, "rejected": 0, "top_reject_reasons": [reason]},
            {"name": "Realtime polling watchlist", "passed": 0, "rejected": 0, "top_reject_reasons": []},
            {"name": "Order flow", "passed": 0, "rejected": 0, "top_reject_reasons": []},
            {"name": "Strategy signal watch", "passed": 0, "rejected": 0, "top_reject_reasons": []},
            {"name": "Strategy signal", "passed": 0, "rejected": 0, "top_reject_reasons": []},
            {"name": "Risk check", "passed": 0, "rejected": 0, "top_reject_reasons": []},
            {"name": "Order candidate", "passed": 0, "rejected": 0, "top_reject_reasons": []},
        ],
        "candidates": [],
    }


def _session_paused_snapshot(updated_at: str, session: dict) -> dict:
    provider = get_market_data_service().provider
    ws_status = provider.realtime_status()
    label = session.get("label") or session.get("state") or "장마감"
    reason = f"{label} 세션이라 Toss realtime polling 감시와 scanner 갱신을 일시 중지했습니다."
    return {
        "updated_at": updated_at,
        "session": session,
        "websocket": ws_status,
        "realtime": {
            "subscribed_symbols": [],
            "symbols_with_quote": [],
            "symbols_with_trade": [],
            "last_realtime_at": ws_status.get("last_realtime_at"),
        },
        "stages": [
            {"name": "Universe", "passed": 0, "rejected": 0, "top_reject_reasons": [reason]},
            {"name": "External market-data coarse scanner", "passed": 0, "rejected": 0, "top_reject_reasons": [reason]},
            {"name": "Realtime polling watchlist", "passed": 0, "rejected": 0, "top_reject_reasons": [reason]},
            {"name": "Order flow", "passed": 0, "rejected": 0, "top_reject_reasons": ["세션 재개 후 실시간 tick 기준으로 다시 계산합니다."]},
            {"name": "Strategy signal watch", "passed": 0, "rejected": 0, "top_reject_reasons": []},
            {"name": "Strategy signal", "passed": 0, "rejected": 0, "top_reject_reasons": []},
            {"name": "Risk check", "passed": 0, "rejected": 0, "top_reject_reasons": []},
            {"name": "Order candidate", "passed": 0, "rejected": 0, "top_reject_reasons": []},
        ],
        "candidates": [],
        "candle_builder": candle_builder.status(),
        "paused": True,
        "pause_reason": reason,
    }


def _to_float(value: str | int | float | None) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _to_int(value: str | int | None) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(str(value).replace(",", "").strip())
    except ValueError:
        return None


def _rank_score(rank: int | None) -> float:
    if rank is None:
        return 0.0
    return max(0.0, 101.0 - float(rank))


def _liquidity_first_score(row: dict) -> float:
    notional_1m = _to_float(row.get("notional_1m")) or _estimated_notional(
        _to_float(row.get("volume_1m")),
        _to_float(row.get("last")),
    )
    notional_10m = _to_float(row.get("notional_10m"))
    velocity = _to_float(row.get("notional_velocity_10s"))
    change_1m = _to_float(row.get("change_1m_pct")) or 0.0
    change_10m = _to_float(row.get("change_10m_pct")) or 0.0
    positive_change_1m = max(change_1m, 0.0)
    positive_change_10m = max(change_10m, 0.0)
    downside_flush = abs(min(change_10m, 0.0))
    trade_count = _to_float(row.get("trade_count"))

    score = 0.0
    if velocity is not None:
        score += min(max(velocity, 0.0), 5.0) * 8.0
    if positive_change_1m:
        score += min(positive_change_1m, 8.0) * 3.5
    if positive_change_10m:
        score += min(positive_change_10m, 20.0) * 0.8
    if downside_flush >= 0.75 and positive_change_1m >= 0.15:
        score += min(downside_flush, 5.0) * 0.5
    if trade_count is not None:
        score += min(trade_count / 100.0, 2.0) * 5.0
    if notional_10m and notional_10m >= get_settings().scanner_min_10m_notional_usd:
        score += 3.0
    # 당일 급등주(mover_change_pct ≥ 3%)는 눌림/횡보 중이어도 slow large-cap 페널티를 면제한다.
    # Surge Pullback Reclaim 전략에서 눌림 구간은 핵심 설정 국면이므로 퇴출하면 안 된다.
    mover_change_pct = abs(_to_float(row.get("mover_change_pct")) or 0.0)
    is_daily_mover = mover_change_pct >= 3.0
    if not is_daily_mover and (notional_1m or 0.0) >= 250_000 and positive_change_1m < 0.20 and positive_change_10m < 0.60:
        score -= 20.0
    return min(score, 100.0)


def _passes_candidate_directional_impulse(row: dict) -> bool:
    change_1m = _to_float(row.get("change_1m_pct")) or 0.0
    change_10m = _to_float(row.get("change_10m_pct")) or 0.0
    positive_change_1m = max(change_1m, 0.0)
    positive_change_10m = max(change_10m, 0.0)
    # 단기 모멘텀: 지금 이 순간 움직이는 종목
    if positive_change_1m >= 0.20 or positive_change_10m >= 0.75:
        return True
    # 하락 후 반등: flush + reclaim 패턴
    if change_10m <= -0.75 and positive_change_1m >= 0.15:
        return True
    # 당일 모버: 오늘 3% 이상 급등/급락한 종목은 지금 눌림/조정 중이어도 관찰 대상
    # (Surge Pullback Reclaim 전략의 핵심 설정 - 급등 후 눌림 구간이 바로 이 상태)
    mover_change_pct = abs(_to_float(row.get("mover_change_pct")) or 0.0)
    if mover_change_pct >= 3.0:
        return True
    return False


def _first_float(row: dict, keys: list[str]) -> float | None:
    for key in keys:
        value = _to_float(row.get(key))
        if value is not None:
            return value
    return None


def _estimated_notional(volume: float | None, price: float | None) -> float | None:
    if volume is None or price is None:
        return None
    return volume * price


FUND_LIKE_NAME_KEYWORDS = (
    " ETF",
    " ETF ",
    "ETN",
    "FUND",
    "TRUST",
    "PROSHARES",
    "DIREXION",
    "ISHARES",
    "SPDR",
    "INVESCO QQQ",
    "ULTRAPRO",
    "ULTRA ",
    "2X",
    "3X",
    "INVERSE",
    "SHORT ",
    "TREASURY",
    "BITCOIN ETF",
    "ETHER ETF",
)


def _passes_instrument_filter(row: dict) -> bool:
    settings = get_settings()
    symbol = str(row.get("symb") or "").strip().upper()
    excluded = {
        part.strip().upper()
        for part in settings.scanner_excluded_symbols.split(",")
        if part.strip()
    }
    if symbol and symbol in excluded:
        return False
    if not settings.scanner_exclude_fund_like_symbols:
        return True
    name = str(row.get("company_name") or resolve_symbol_name(symbol, row) or "").upper()
    return not any(keyword in f" {name} " for keyword in FUND_LIKE_NAME_KEYWORDS)


def _outside_scanner_price_range(row: dict) -> bool:
    settings = get_settings()
    price = _to_float(row.get("last"))
    if price is None:
        return False
    if settings.scanner_min_price_usd > 0 and price < settings.scanner_min_price_usd:
        return True
    return bool(settings.scanner_max_price_usd > 0 and price >= settings.scanner_max_price_usd)


def _passes_liquidity_floor(row: dict) -> bool:
    return _liquidity_floor_reject_reason(row) is None


def _liquidity_floor_reject_reason(row: dict) -> str | None:
    symbol = str(row.get("symbol") or row.get("symb") or "").upper()
    if row.get("manual_candidate") or row.get("manual_pinned") or _is_manual_candidate_symbol(symbol):
        return None
    settings = get_settings()
    volume_1m = _to_float(row.get("volume_1m"))
    volume_10m = _to_float(row.get("volume_10m"))
    notional_10m = _to_float(row.get("notional_10m"))
    trade_count = _to_float(row.get("trade_count"))
    latest_bar_age_sec = _to_float(row.get("latest_bar_age_sec"))
    volume_source = str(row.get("volume_source") or "")
    daily_volume = _to_float(row.get("daily_volume"))
    if _is_toss_seed_source(volume_source, row.get("screener_source")):
        return None

    if (
        settings.scanner_allow_ranking_only_for_ws
        and volume_source == "provider_most_actives"
        and volume_1m is None
    ):
        if settings.scanner_min_ranking_daily_volume > 0 and (
            daily_volume is None or daily_volume < settings.scanner_min_ranking_daily_volume
        ):
            return f"일일 거래량 {daily_volume or 0:,.0f} < {settings.scanner_min_ranking_daily_volume:,.0f}"
        return None

    if settings.scanner_min_1m_volume > 0 and volume_1m is None:
        return "1분 거래량 없음"
    if volume_1m is not None and volume_1m < settings.scanner_min_1m_volume:
        return f"1분 거래량 {volume_1m:,.0f} < {settings.scanner_min_1m_volume:,.0f}"
    if settings.scanner_min_10m_volume > 0 and volume_10m is None:
        return "10분 거래량 없음"
    if volume_10m is not None and volume_10m < settings.scanner_min_10m_volume:
        return f"10분 거래량 {volume_10m:,.0f} < {settings.scanner_min_10m_volume:,.0f}"
    if settings.scanner_min_10m_notional_usd > 0 and notional_10m is None:
        return "10분 거래대금 없음"
    if (
        settings.scanner_min_10m_notional_usd > 0
        and notional_10m is not None
        and notional_10m < settings.scanner_min_10m_notional_usd
    ):
        return f"10분 거래대금 ${notional_10m:,.0f} < ${settings.scanner_min_10m_notional_usd:,.0f}"
    if (
        settings.scanner_max_latest_bar_age_sec > 0
        and latest_bar_age_sec is not None
        and latest_bar_age_sec > settings.scanner_max_latest_bar_age_sec
    ):
        return f"최신 분봉 지연 {latest_bar_age_sec:.0f}초 > {settings.scanner_max_latest_bar_age_sec}초"
    if settings.scanner_min_trade_count > 0 and trade_count is not None and trade_count < settings.scanner_min_trade_count:
        return f"체결 수 {trade_count:,.0f} < {settings.scanner_min_trade_count:,.0f}"
    return None
