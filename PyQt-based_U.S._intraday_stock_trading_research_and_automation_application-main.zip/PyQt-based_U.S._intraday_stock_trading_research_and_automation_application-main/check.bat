@echo off
setlocal
cd /d "%~dp0"
call scripts\check-conda.cmd
if errorlevel 1 (
  echo.
  echo Check failed.
  pause
  exit /b %errorlevel%
)
echo.
echo Check complete.
pause
