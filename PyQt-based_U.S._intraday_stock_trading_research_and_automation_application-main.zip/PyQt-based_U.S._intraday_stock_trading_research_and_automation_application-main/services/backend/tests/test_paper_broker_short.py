import pytest

from app.core.config import get_settings
from app.domain.enums import OrderState
from app.domain.models import OrderRequest
from app.services.paper_broker import InternalPaperBroker


@pytest.fixture(autouse=True)
def clean_paper_state() -> None:
    broker = InternalPaperBroker()
    broker.reset()
    yield
    broker.reset()


def _open_short(broker: InternalPaperBroker, symbol: str, quantity: float, *, bid: float, ask: float):
    return broker.submit_order(
        OrderRequest(symbol=symbol, side="sell", position_side="short", quantity=quantity, mode="internal_paper"),
        market_snapshot={"ask": ask, "bid": bid, "last": (ask + bid) / 2, "spread_pct": 0.02},
    )


def _cover_short(broker: InternalPaperBroker, symbol: str, quantity: float, *, bid: float, ask: float):
    return broker.submit_order(
        OrderRequest(symbol=symbol, side="buy", position_side="short", quantity=quantity, mode="internal_paper"),
        market_snapshot={"ask": ask, "bid": bid, "last": (ask + bid) / 2, "spread_pct": 0.02},
    )


def test_short_open_creates_short_position_with_stop_above_entry() -> None:
    broker = InternalPaperBroker()
    _, events = _open_short(broker, "SOBR", 10, bid=10.00, ask=10.05)

    assert events[-1].new_state == OrderState.FILLED
    position = broker.state()["positions"][0]
    assert position["direction"] == "short"
    assert position["quantity"] == 10
    # short entry fills near the bid (you sell to open)
    assert position["average_price"] <= 10.01
    # stop sits ABOVE entry, take-profit BELOW
    assert position["stop_loss_price"] > position["average_price"]
    assert position["take_profit_price"] < position["average_price"]
    assert position["low_watermark"] is not None
    assert position["high_watermark"] is None
    assert position["entry_fees_usd"] > 0


def test_short_cover_records_profit_when_price_falls() -> None:
    broker = InternalPaperBroker()
    _open_short(broker, "SOBR", 10, bid=10.00, ask=10.05)
    _, events = _cover_short(broker, "SOBR", 10, bid=9.50, ask=9.55)

    assert events[-1].new_state == OrderState.FILLED
    state = broker.state()
    assert state["positions"] == []
    closed = state["closed_trades"][0]
    assert closed["direction"] == "short"
    assert closed["gross_pnl_usd"] > 0  # covered lower than we shorted
    assert closed["fees_usd"] > 0
    assert closed["net_pnl_usd"] < closed["gross_pnl_usd"]


def test_short_cover_records_loss_when_price_rises() -> None:
    broker = InternalPaperBroker()
    _open_short(broker, "SOBR", 10, bid=10.00, ask=10.05)
    _, events = _cover_short(broker, "SOBR", 10, bid=10.50, ask=10.55)

    assert events[-1].new_state == OrderState.FILLED
    closed = broker.state()["closed_trades"][0]
    assert closed["direction"] == "short"
    assert closed["gross_pnl_usd"] < 0  # squeezed up, covered higher


def test_short_partial_cover_preserves_direction_and_watermark() -> None:
    broker = InternalPaperBroker()
    _open_short(broker, "SOBR", 10, bid=10.00, ask=10.05)
    _cover_short(broker, "SOBR", 4, bid=9.50, ask=9.55)

    positions = broker.state()["positions"]
    assert len(positions) == 1
    remaining = positions[0]
    assert remaining["direction"] == "short"
    assert remaining["quantity"] == 6
    assert remaining["low_watermark"] is not None
    assert remaining["stop_loss_price"] > remaining["average_price"]


def test_short_cover_without_position_is_rejected() -> None:
    broker = InternalPaperBroker()
    _, events = _cover_short(broker, "SOBR", 5, bid=9.50, ask=9.55)
    assert events[-1].new_state == OrderState.REJECTED


def test_short_open_respects_max_open_positions_risk(monkeypatch) -> None:
    settings = get_settings()
    monkeypatch.setattr(settings, "paper_risk_hard_caps_enabled", True)
    monkeypatch.setattr(settings, "paper_max_open_positions", 2)
    monkeypatch.setattr(settings, "paper_max_total_exposure_pct", 10.0)
    broker = InternalPaperBroker()

    _open_short(broker, "S0", 1, bid=9.99, ask=10.00)
    _open_short(broker, "S1", 1, bid=9.99, ask=10.00)
    _, events = _open_short(broker, "S2", 1, bid=9.99, ask=10.00)

    assert events[-1].new_state == OrderState.REJECTED
    assert events[-1].payload["reason"] == "max_open_positions_exceeded"
    assert len(broker.state()["positions"]) == 2


def test_long_roundtrip_still_profits_after_short_support() -> None:
    # Backward compatibility: default position_side="long" keeps the long path.
    broker = InternalPaperBroker()
    broker.submit_order(
        OrderRequest(symbol="AAPL", side="buy", quantity=10, limit_price=10.02, mode="internal_paper"),
        market_snapshot={"ask": 10.00, "bid": 9.99, "last": 10.00, "spread_pct": 0.02},
    )
    position = broker.state()["positions"][0]
    assert position["direction"] == "long"
    assert position["high_watermark"] is not None

    _, events = broker.submit_order(
        OrderRequest(symbol="AAPL", side="sell", quantity=10, limit_price=10.48, mode="internal_paper"),
        market_snapshot={"ask": 10.51, "bid": 10.50, "last": 10.50, "spread_pct": 0.02},
    )
    assert events[-1].new_state == OrderState.FILLED
    closed = broker.state()["closed_trades"][0]
    assert closed["direction"] == "long"
    assert closed["gross_pnl_usd"] > 0
