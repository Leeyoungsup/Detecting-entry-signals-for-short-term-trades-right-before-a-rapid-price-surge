# 미장 유동성 기반 단타 알고리즘 트레이딩 전략 정리

## 0. 문서 목적

본 문서는 미국 주식시장 단타 알고리즘 트레이딩에서 활용 가능한 **유동성 기반 전략**을 정리한 개발 기획 문서이다.  
핵심 목표는 단순 가격 예측 모델이 아니라, **거래대금, 호가 잔량, 체결 흐름, VWAP, 스프레드, 슬리피지**를 기반으로 진입 가능한 구간을 필터링하는 자동매매 시스템을 설계하는 것이다.

> 본 전략은 백테스트와 페이퍼트레이딩으로 기대값이 검증되기 전까지 수익 전략으로 간주하지 않는다.

---

## 1. 전체 전략 방향

미장 단타 알고리즘 트레이딩에서 개인 또는 소규모 개발자가 현실적으로 접근할 수 있는 방향은 다음과 같다.

```text
종목 스캐너
→ 유동성 필터
→ 가격 위치 필터
→ 체결 흐름 확인
→ 진입 판단
→ 자동 손절/익절
→ 체결 로그 저장
→ 전략별 기대값 재평가
```

단순히 1분봉 가격 방향을 예측하는 방식은 실전에서 불리할 가능성이 높다.  
따라서 본 문서에서는 **가격 신호 + 유동성 신호 + 체결 신호 + 리스크 관리**를 결합하는 구조를 기본 방향으로 한다.

---

## 2. 핵심 데이터 구성

### 2.1 필수 데이터

| 데이터 | 설명 | 활용 목적 |
|---|---|---|
| OHLCV | 1분봉 또는 초 단위 가격/거래량 | 기본 가격 흐름 파악 |
| 거래대금 | Price × Volume | 종목 스캐닝 |
| VWAP | 거래량 가중 평균 가격 | 기관성 기준선 및 추세 판단 |
| Bid / Ask | 최우선 매수·매도 호가 | 스프레드 및 방향성 판단 |
| Bid Size / Ask Size | 최우선 호가 잔량 | 유동성 불균형 판단 |
| 체결 데이터 | 실제 매수/매도 체결 흐름 | 체결강도, 흡수 여부 판단 |
| 스프레드 | Ask - Bid | 거래비용 및 진입 가능성 판단 |

### 2.2 있으면 좋은 데이터

| 데이터 | 설명 | 활용 목적 |
|---|---|---|
| Level 2 Order Book | 복수 호가 단계별 잔량 | OFI, liquidity wall 분석 |
| Premarket 데이터 | 정규장 전 거래 흐름 | 장초반 후보 종목 선정 |
| 뉴스/실적 이벤트 | 급등락 원인 | 이벤트성 변동성 필터 |
| Short volume / borrow data | 공매도 관련 데이터 | squeeze 가능성 참고 |
| 옵션 거래량 | 콜/풋 수급 | 대형주 단타 참고 |

---

# 3. 전략 1: Order Flow Imbalance, OFI 전략

## 3.1 개념

Order Flow Imbalance, OFI는 호가창에서 매수 측 유동성과 매도 측 유동성 변화의 차이를 계산하는 지표이다.  
짧은 시간 동안 매수 호가가 강해지고 매도 호가가 소진되면 단기 상승 압력이 커질 수 있고, 반대로 매도 호가가 강해지고 매수 호가가 사라지면 단기 하락 압력이 커질 수 있다.

OFI는 단순 거래량보다 시장 미시구조를 더 직접적으로 반영한다.

## 3.2 기본 공식

단순화된 개념은 다음과 같다.

```text
OFI = Bid size 증가분
    - Ask size 증가분
    + Ask size 감소분
    - Bid size 감소분
```

해석은 다음과 같다.

```text
OFI > 0  → 매수 압력 우세
OFI < 0  → 매도 압력 우세
OFI ≈ 0  → 방향성 약함
```

## 3.3 진입 조건 예시

### Long 조건

```text
- 거래대금 상위 종목
- 스프레드가 일정 기준 이하
- 가격이 VWAP 위에 위치
- OFI가 최근 N초 또는 N분 기준 강한 양수
- Ask 잔량이 빠르게 소진
- 체결강도가 매수 우위
- 최근 고점 돌파 또는 VWAP reclaim 발생
```

### Short 또는 Long 회피 조건

```text
- OFI가 강한 음수
- Bid 잔량 급감
- 매수 체결이 약화
- VWAP 아래에서 반등 실패
- 스프레드 확대
```

## 3.4 청산 조건

```text
- OFI 양수 흐름 약화
- Bid depth 급감
- VWAP 재이탈
- 고정 손절 도달
- 목표 수익률 도달
- 일정 시간 내 추가 상승 실패
```

## 3.5 장점

- 단순 이동평균보다 실제 수급 변화를 빠르게 반영한다.
- 짧은 시간 단위 가격 변화와 연결될 가능성이 높다.
- AI 모델의 입력 feature로 활용하기 좋다.

## 3.6 단점

- Level 1 데이터만으로는 정밀도가 제한된다.
- Level 2 데이터 품질이 중요하다.
- 호가 취소, spoofing성 잔량에 취약하다.
- 실시간 처리 속도가 중요하다.

## 3.7 참고 문헌

- Cont, R., Kukanov, A., & Stoikov, S. **The Price Impact of Order Book Events**.
- 핵심 내용: order book event와 order flow imbalance가 단기 가격 변화와 관련됨.

---

# 4. 전략 2: Liquidity Imbalance, 호가 잔량 불균형 전략

## 4.1 개념

Liquidity Imbalance 전략은 현재 호가창에서 매수 잔량과 매도 잔량의 상대적 차이를 이용한다.  
Bid depth가 Ask depth보다 훨씬 크면 단기적으로 매수 방어가 강하다고 볼 수 있고, 반대로 Ask depth가 크면 매도 압력이 강하다고 볼 수 있다.

## 4.2 기본 공식

```text
Liquidity Imbalance = (Bid Depth - Ask Depth) / (Bid Depth + Ask Depth)
```

해석은 다음과 같다.

```text
+0.6 이상 → 매수 호가 우세
-0.6 이하 → 매도 호가 우세
0 근처 → 균형 상태
```

## 4.3 Long 조건 예시

```text
- Bid depth / Ask depth 비율이 2배 이상
- 스프레드가 좁음
- Bid 잔량이 몇 초 이상 유지됨
- 실제 체결도 위쪽 가격에서 발생
- 가격이 VWAP 위 또는 주요 저항선 돌파 직전
```

## 4.4 회피 조건

```text
- Bid 잔량이 갑자기 사라짐
- 큰 Bid 잔량이 있는데도 가격이 상승하지 못함
- Ask에 반복적으로 큰 매도 물량 출현
- 스프레드 확대
```

## 4.5 장점

- OFI보다 구현이 쉽다.
- Level 1 또는 간단한 Level 2 데이터로도 시작 가능하다.
- 종목 필터링 지표로 활용하기 좋다.

## 4.6 단점

- 가짜 잔량에 취약하다.
- 단순 잔량만 보고 진입하면 손실 가능성이 높다.
- 실제 체결 흐름과 함께 봐야 한다.

## 4.7 구현 팁

단순히 현재 Bid/Ask 잔량만 보지 말고, 다음 값을 함께 저장한다.

```text
- 잔량 유지 시간
- 잔량 증가/감소 속도
- 체결 동반 여부
- 가격 반응 여부
- 스프레드 변화
```

---

# 5. 전략 3: 유동성 흡수 후 돌파 전략

## 5.1 개념

특정 가격대에 큰 매도벽 또는 매수벽이 존재할 때, 그 물량이 반복적으로 체결되면서 소진되는 현상을 이용하는 전략이다.  
큰 매도벽이 여러 번 흡수된 뒤 가격이 해당 구간을 돌파하면 단기 상승 모멘텀이 발생할 수 있다.

## 5.2 예시 상황

```text
- $100.00에 큰 Ask wall 존재
- 매수 체결이 반복적으로 발생
- 가격이 크게 밀리지 않음
- Ask wall이 점점 감소
- $100.00 위로 체결 발생
- 돌파 후 거래량 증가
```

## 5.3 Long 조건 예시

```text
- 고정된 Ask wall이 존재
- 해당 가격대에서 반복 체결 발생
- Ask 잔량이 점진적으로 감소
- Bid depth는 유지 또는 증가
- 체결량 증가
- Wall 가격 위로 체결 발생
```

## 5.4 손절 조건

```text
- 돌파 후 다시 wall 아래로 하락
- Bid depth 급감
- 체결강도 약화
- VWAP 또는 직전 돌파 가격 이탈
```

## 5.5 익절 조건

```text
- 다음 유동성 wall 도달
- 단기 목표 수익률 도달
- OFI 약화
- 거래량 급감
- trailing stop 작동
```

## 5.6 장점

- 실제 체결 기반 전략이라 단순 차트 전략보다 구조적이다.
- 장초반 급등주나 뉴스 종목에서 활용 가능하다.
- breakout 전략과 결합하기 좋다.

## 5.7 단점

- 호가 데이터 품질이 중요하다.
- 돌파 실패 시 손실이 빠르게 커질 수 있다.
- 슬리피지가 커질 수 있다.

---

# 6. 전략 4: VWAP Reclaim / Rejection 전략

## 6.1 개념

VWAP은 거래량 가중 평균 가격으로, 단타에서 중요한 기준선으로 사용된다.  
기관 주문 알고리즘에서도 VWAP은 중요한 실행 기준으로 활용되기 때문에, 가격이 VWAP 위에 있는지 아래에 있는지는 단기 수급 판단에 도움이 된다.

다만 VWAP 단독 사용은 위험하다.  
VWAP 근처에서 **호가, 체결강도, 거래량, OFI**가 함께 확인되어야 한다.

---

## 6.2 VWAP Reclaim 전략

### 개념

가격이 VWAP 아래에 있다가 다시 VWAP 위로 회복하는 구간을 매수 후보로 보는 전략이다.

### Long 조건

```text
- 장초반 급락 또는 눌림 발생
- 가격이 VWAP 아래에서 회복
- VWAP 재돌파
- VWAP 위에서 일정 시간 유지
- OFI 양수 전환
- 체결강도 매수 우위
- 거래량 증가
```

### 손절 조건

```text
- VWAP 재이탈
- 돌파 캔들 저점 이탈
- Bid depth 급감
- 체결강도 약화
```

### 익절 조건

```text
- 직전 고점 도달
- Premarket high 도달
- 고정 수익률 도달
- OFI 약화
```

---

## 6.3 VWAP Rejection 전략

### 개념

가격이 VWAP 아래에 머물다가 VWAP 근처에서 저항을 받고 다시 하락하는 구간을 이용하는 전략이다.  
Long 진입 회피 또는 short 전략에 활용할 수 있다.

### Short 또는 Long 회피 조건

```text
- 가격이 VWAP 아래
- VWAP 접근
- Ask 잔량 증가
- 매수 체결 약화
- OFI 음수 전환
- VWAP 돌파 실패
```

## 6.4 장점

- 구현이 비교적 쉽다.
- OHLCV 기반으로도 1차 구현 가능하다.
- 유동성 지표와 결합하면 실전성이 높아진다.

## 6.5 단점

- VWAP 단독 신호는 false signal이 많다.
- 횡보장에서 잦은 손절 가능성이 있다.
- 장초반 변동성 구간에서는 기준선이 불안정할 수 있다.

## 6.6 참고 문헌

- Guéant, O. **VWAP Execution and Guaranteed VWAP**.
- Kato, T. **VWAP Execution as an Optimal Strategy**.

---

# 7. 전략 5: Opening Liquidity Imbalance 전략

## 7.1 개념

미국 주식시장은 장 시작 직후 유동성 재편이 빠르게 발생한다.  
프리마켓에서 거래대금이 몰린 종목은 정규장 시작 후 강한 order imbalance가 발생할 수 있다.

이 전략은 장 시작 전후의 유동성 불균형, 거래대금, VWAP, opening range를 함께 활용한다.

## 7.2 대상 종목

```text
- Premarket 거래대금 상위
- Gap up 또는 gap down 종목
- 실적, 뉴스, FDA, M&A, 가이던스 등 이벤트 존재
- 상대거래량 RVOL 증가
- 스프레드가 과도하게 넓지 않음
```

## 7.3 Long 조건 예시

```text
- 장 시작 후 첫 1~5분 고점 돌파
- 가격이 VWAP 위 유지
- 매수 체결 우위
- Bid depth 유지
- Ask 잔량 소진
- 거래량 증가
```

## 7.4 회피 조건

```text
- 돌파 후 거래량 감소
- 스프레드 확대
- Bid wall 붕괴
- VWAP 재이탈
- 첫 돌파 후 즉시 되돌림
```

## 7.5 장점

- 변동성과 거래량이 크기 때문에 기회가 많다.
- 종목 스캐너와 결합하기 좋다.
- 장초반 급등주 전략으로 확장 가능하다.

## 7.6 단점

- 슬리피지가 크다.
- 장초반 fake breakout이 많다.
- 뉴스 해석이 잘못되면 급락 위험이 크다.

---

# 8. 전략 6: Market Making / Spread Capture 전략

## 8.1 개념

Market Making 전략은 bid에 매수 주문을 걸고 ask에 매도 주문을 걸어 스프레드를 얻는 전략이다.  
이론적으로는 가장 정통적인 유동성 공급 전략이지만, 개인 투자자에게는 난이도가 매우 높다.

## 8.2 기본 구조

```text
Bid 근처에 limit buy 주문
→ 체결 후 Ask 근처에 limit sell 주문
→ 스프레드 차익 확보
```

## 8.3 적용 조건

```text
- 대형주 또는 ETF
- 스프레드 안정적
- 급뉴스 없음
- 변동성 낮음
- VWAP 근처 횡보
- Bid/Ask imbalance가 중립
```

## 8.4 위험 요소

```text
- HFT보다 체결 우선순위가 낮음
- 불리한 정보가 있을 때만 체결될 수 있음
- 급격한 방향성 발생 시 손실 확대
- inventory risk 발생
```

## 8.5 개인용 활용 방향

개인이 이 전략을 수익 전략으로 직접 쓰기보다는, **진입 주문 방식 최적화**에 활용하는 것이 더 현실적이다.

```text
- market order 남발 방지
- limit order로 체결비용 절감
- 스프레드가 넓을 때 진입 금지
- 일정 시간 미체결 시 주문 취소
```

## 8.6 참고 문헌

- Avellaneda, M., & Stoikov, S. **High-frequency trading in a limit order book**.

---

# 9. 추천 조합 전략

개인 또는 소규모 SaaS 자동매매 시스템에서는 단일 전략보다 조합 전략이 적합하다.

## 9.1 추천 베이스 전략

```text
VWAP + OFI + 거래대금 + 스프레드 필터 + 체결강도
```

## 9.2 Long 진입 후보 조건

```text
- 거래대금 상위 종목
- RVOL 증가
- 스프레드 기준 이하
- 가격이 VWAP 위
- OFI > 0
- Bid depth 유지
- Ask 잔량 소진
- 최근 1~3분 고점 돌파
- 체결강도 매수 우위
```

## 9.3 진입 금지 조건

```text
- 스프레드 과도하게 확대
- 거래량 급감
- Bid 잔량 급감
- OFI 음수 전환
- VWAP 아래 위치
- 프리마켓 급등 후 정규장 거래량 미동반
- 뉴스 원인 불명확
```

## 9.4 청산 조건

```text
- 고정 손절 도달
- VWAP 재이탈
- OFI 약화
- Bid depth 붕괴
- 목표 수익률 도달
- 일정 시간 내 상승 실패
- 1일 최대 손실 도달
```

---

# 10. 백테스트 및 페이퍼트레이딩 기준

## 10.1 반드시 반영할 요소

```text
- 수수료
- 스프레드
- 슬리피지
- 미체결 주문
- 부분 체결
- 주문 지연
- 프리마켓/정규장/애프터마켓 구분
```

## 10.2 핵심 성능 지표

| 지표 | 의미 | 해석 |
|---|---|---|
| Win Rate | 승률 | 단독으로는 의미 약함 |
| Profit Factor | 총이익 / 총손실 | 1.2 이상부터 검토 |
| Average Trade PnL | 1회 평균 기대값 | 비용 반영 후 양수여야 함 |
| Max Drawdown | 최대 낙폭 | 계좌 생존성 핵심 |
| Sharpe Ratio | 변동성 대비 수익 | 단타에서는 과대평가 주의 |
| Slippage Sensitivity | 슬리피지 민감도 | 단타에서 매우 중요 |
| Out-of-Sample PnL | 미사용 구간 성능 | 과최적화 검증 핵심 |
| Trade Count | 거래 횟수 | 통계적 신뢰도 판단 |

## 10.3 기대값 계산

```text
Expected Value = (승률 × 평균이익)
               - (패율 × 평균손실)
               - 거래비용
               - 슬리피지
```

전략이 실전 가능하려면 이 값이 장기간 양수여야 한다.

---

# 11. 로그 저장 설계

전략 업데이트를 위해 체결 로그는 상세하게 저장해야 한다.

## 11.1 주문 로그

```text
- timestamp
- symbol
- strategy_name
- signal_type
- side
- order_type
- order_price
- filled_price
- quantity
- filled_quantity
- status
- latency_ms
```

## 11.2 시장 상태 로그

```text
- timestamp
- symbol
- price
- volume
- dollar_volume
- VWAP
- EMA
- bid_price
- ask_price
- bid_size
- ask_size
- spread
- OFI
- liquidity_imbalance
- trade_strength
- RVOL
```

## 11.3 결과 로그

```text
- entry_time
- exit_time
- holding_seconds
- entry_price
- exit_price
- gross_pnl
- net_pnl
- slippage
- max_favorable_excursion
- max_adverse_excursion
- exit_reason
```

---

# 12. 개발 우선순위

| 우선순위 | 전략 | 구현 난이도 | 개인 적합성 | 비고 |
|---|---:|---:|---:|---|
| 1 | VWAP + 거래대금 + 스프레드 필터 | 낮음~중간 | 높음 | 1차 베이스 |
| 2 | Liquidity Imbalance | 중간 | 높음 | Level 1/2 필요 |
| 3 | Opening Liquidity Imbalance | 중간 | 높음 | 장초반 특화 |
| 4 | OFI | 높음 | 높음 | 데이터 품질 중요 |
| 5 | 유동성 흡수 후 돌파 | 높음 | 중간~높음 | 체결 데이터 중요 |
| 6 | Market Making | 매우 높음 | 낮음 | 개인 수익전략으로는 비추천 |

---

# 13. 1차 MVP 전략 설계안

## 13.1 목적

수익 자동매매 이전에, 유동성 기반 단타 전략의 기대값을 검증하는 MVP를 구축한다.

## 13.2 MVP 구성

```text
1. 종목 스캐너
   - 거래대금 상위
   - RVOL 증가
   - 프리마켓 변동률
   - 스프레드 제한

2. 실시간 지표 계산
   - VWAP
   - EMA
   - Spread
   - Liquidity Imbalance
   - 체결강도
   - 가능하면 OFI

3. 진입 시그널
   - VWAP 위
   - 최근 고점 돌파
   - Bid depth 우세
   - Ask 잔량 감소
   - 체결강도 매수 우위

4. 리스크 관리
   - 고정 손절
   - 고정 익절
   - 시간 손절
   - 1일 최대 손실 제한

5. 로그 저장
   - 모든 시그널, 주문, 체결, 청산 사유 저장
```

## 13.3 MVP에서 제외할 것

```text
- 복잡한 딥러닝 모델
- 순수 market making
- 옵션 데이터 기반 전략
- 뉴스 NLP 자동판단
- 과도한 파라미터 최적화
```

---

# 14. 향후 ML 적용 방향

처음부터 AI가 매수/매도를 직접 예측하게 하기보다, 아래와 같이 **진입 가능성 필터**로 사용하는 것이 현실적이다.

## 14.1 Feature 후보

```text
- VWAP deviation
- EMA slope
- RVOL
- dollar_volume
- spread
- liquidity_imbalance
- OFI
- trade_strength
- bid_size_change
- ask_size_change
- recent_breakout 여부
- premarket_gap
- time_from_open
```

## 14.2 Label 후보

```text
- 진입 후 1분 수익률 > 기준값
- 진입 후 3분 수익률 > 기준값
- MFE > MAE 여부
- 손절보다 익절이 먼저 도달했는지
- 슬리피지 반영 후 net PnL 양수 여부
```

## 14.3 추천 모델

```text
- Logistic Regression
- Random Forest
- XGBoost / LightGBM
- CatBoost
- 단순 MLP
```

딥러닝 시계열 모델보다 먼저 tree-based model로 feature importance와 전략 구조를 확인하는 것이 좋다.

---

# 15. 최종 정리

미장 유동성 단타 알고리즘의 핵심은 다음과 같다.

```text
가격을 맞히는 것보다
진입해도 되는 유동성 환경을 찾는 것이 중요하다.
```

가장 현실적인 시작 전략은 다음 조합이다.

```text
거래대금 상위 종목
+ VWAP 위치
+ 스프레드 제한
+ Liquidity Imbalance
+ 체결강도
+ OFI 가능 시 추가
+ 자동 손절/익절
+ 상세 로그 저장
```

초기 목표는 수익이 아니라, **전략별 기대값을 통계적으로 검증할 수 있는 자동화 환경 구축**이다.

---

# 16. 참고 자료

1. Cont, R., Kukanov, A., & Stoikov, S. *The Price Impact of Order Book Events*.
2. Avellaneda, M., & Stoikov, S. *High-frequency trading in a limit order book*.
3. Guéant, O. *VWAP Execution and Guaranteed VWAP*.
4. Kato, T. *VWAP Execution as an Optimal Strategy*.
5. Limit Order Book liquidity imbalance 관련 시장미시구조 연구.
6. SEC / FINRA algorithmic trading 및 market structure 관련 자료.

