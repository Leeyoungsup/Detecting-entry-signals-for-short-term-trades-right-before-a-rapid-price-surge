@echo off
setlocal

cd /d "%~dp0.."

set CONDA_ENV_DIR=%USERPROFILE%\.conda\envs\kis-trading-research
if not exist "%CONDA_ENV_DIR%\python.exe" set CONDA_ENV_DIR=C:\ProgramData\anaconda3\envs\kis-trading-research
set PATH=%CONDA_ENV_DIR%;%CONDA_ENV_DIR%\Library\bin;%CONDA_ENV_DIR%\Scripts;%PATH%

python -c "from app.main import app; from app.api.routes.health import health; h=health(); assert h['trading_mode'] == 'internal_paper'; assert h['live_enabled'] is False; assert any(getattr(r, 'path', '') == '/api/health' for r in app.routes); print('backend_check_ok')"
if errorlevel 1 exit /b %errorlevel%

npm --version
if errorlevel 1 exit /b %errorlevel%

echo conda_check_ok
