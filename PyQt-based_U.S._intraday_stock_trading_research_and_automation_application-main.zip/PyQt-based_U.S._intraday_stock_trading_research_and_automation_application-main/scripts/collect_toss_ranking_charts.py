"""Collect replay-style enriched charts for Toss 거래대금순 (trading-amount) leaders.

Pulls the Toss Open API trading-amount ranking (no browser crawl), filters by
max price and (optionally) common-stock-only, then for each symbol exports the
same two-stage bars -> enriched CSVs the replay set uses, into a dedicated
session folder. Resumable: symbols whose enriched CSV already exists are skipped.

Usage (from repo root, backend on PYTHONPATH):
    python scripts/collect_toss_ranking_charts.py \
        --start-kst "2026-07-07 17:00" --end-kst "2026-07-08 08:00" \
        --max-price 20 --out-dir exports/strategy_replay/session_2026-07-07
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
import uuid
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
BACKEND_ROOT = PROJECT_ROOT / "services" / "backend"
SCRIPTS_DIR = PROJECT_ROOT / "scripts"

# Alpaca fetches occasionally hit transient connection resets on high-volume symbols;
# retry a few times before marking a symbol failed so one hiccup doesn't abort the run.
MAX_FETCH_ATTEMPTS = 3
RETRY_BACKOFF_SEC = 3


def _load_script_module(name: str):
    spec = importlib.util.spec_from_file_location(name, SCRIPTS_DIR / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _to_float(value) -> float | None:
    try:
        return float(str(value).replace(",", "").replace("$", "").strip())
    except (TypeError, ValueError):
        return None


def fetch_ranking(max_price: float, common_only: bool, keep: set[str]) -> list[dict]:
    if str(BACKEND_ROOT) not in sys.path:
        sys.path.insert(0, str(BACKEND_ROOT))
    from app.core.config import Settings
    from app.adapters.toss.client import TossExecutionClient
    from app.adapters.market_data.toss import _is_common_stock

    client = TossExecutionClient(Settings())

    def _rankings(duration: str) -> list[dict]:
        result = client.rankings(
            ranking_type="TOSS_SECURITIES_TRADING_AMOUNT",
            market_country="US",
            duration=duration,
            count=100,
        )
        return result.get("rankings") or []

    rows = _rankings("realtime") or _rankings("1d")

    under: list[dict] = []
    for row in rows:
        symbol = str(row.get("symbol") or "").upper()
        price = _to_float((row.get("price") or {}).get("lastPrice"))
        if not symbol or price is None or price > max_price:
            continue
        under.append(
            {
                "symbol": symbol,
                "rank": row.get("rank"),
                "price": price,
                "trade_amount_usd": _to_float(row.get("tradingAmount")),
            }
        )

    if not common_only:
        return under

    meta = {str(m.get("symbol") or "").upper(): m for m in client.stocks(symbols=[u["symbol"] for u in under])}
    filtered: list[dict] = []
    for item in under:
        symbol = item["symbol"]
        if symbol in keep or _is_common_stock(meta.get(symbol)):
            item["security_type"] = (meta.get(symbol) or {}).get("securityType")
            filtered.append(item)
    return filtered


def load_ranking_file(path: Path, max_price: float) -> list[dict]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload.get("universe") or []
    universe: list[dict] = []
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        price = _to_float(row.get("price"))
        if max_price > 0 and price is not None and price > max_price:
            continue
        universe.append(
            {
                "symbol": symbol,
                "rank": row.get("rank"),
                "price": price if price is not None else float("nan"),
                "trade_amount_usd": _to_float(row.get("trade_amount_usd")),
                "security_type": row.get("security_type"),
            }
        )
    return universe


def collect(args) -> None:
    bars_mod = _load_script_module("export_alpaca_bars_csv")
    enrich_mod = _load_script_module("export_alpaca_enriched_bars_csv")

    if args.ranking_file:
        # Reproduce a specific day's session from a saved ranking snapshot (captured at
        # market close) instead of the current live ranking. Preserves rank/price/
        # trade_amount metadata so the manifest matches the live-ranking format.
        universe = load_ranking_file(Path(args.ranking_file), args.max_price)
    elif args.symbols:
        # Fixed universe (e.g. reuse a prior session's symbols for a different-day
        # out-of-sample) — skip the live ranking fetch entirely.
        universe = [
            {"symbol": s.strip().upper(), "rank": i, "price": float("nan"), "trade_amount_usd": None}
            for i, s in enumerate(args.symbols.split(","), start=1)
            if s.strip()
        ]
    else:
        keep = {token.strip().upper() for token in (args.always_keep or "").split(",") if token.strip()}
        universe = fetch_ranking(args.max_price, not args.include_etf, keep)
    if args.limit:
        universe = universe[: args.limit]

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    start_kst = bars_mod.parse_kst(args.start_kst)
    end_kst = bars_mod.parse_kst(args.end_kst)
    date_tag = start_kst.strftime("%Y-%m-%d")
    time_tag = f"{start_kst.strftime('%H%M')}-{end_kst.strftime('%H%M')}"

    if args.ranking_file:
        src = f"ranking file {args.ranking_file} (max_price=${args.max_price})"
    elif args.symbols:
        src = "fixed --symbols"
    else:
        src = f"ranking (max_price=${args.max_price}, include_etf={args.include_etf})"
    print(f"universe: {len(universe)} symbols from {src}")
    for item in universe:
        price = item["price"]
        price_str = f"${price:.2f}" if price == price else "n/a"  # NaN check
        print(f"  #{item['rank']:>3} {item['symbol']:<7} {price_str}")

    manifest: list[dict] = []
    for index, item in enumerate(universe, start=1):
        symbol = item["symbol"]
        stem = f"{symbol.lower()}_{date_tag}_{time_tag}_kst_{uuid.uuid4().hex[:8]}"
        enriched_path = out_dir / f"{stem}_enriched.csv"

        existing = list(out_dir.glob(f"{symbol.lower()}_{date_tag}_{time_tag}_kst_*_enriched.csv"))
        if existing:
            print(f"[{index}/{len(universe)}] {symbol}: skip (exists {existing[0].name})")
            manifest.append({**item, "enriched": existing[0].name, "status": "skipped"})
            continue

        bars_path = out_dir / f"{stem}_bars.csv"
        last_error: Exception | None = None
        bars_summary = enrich_summary = None
        for attempt in range(1, MAX_FETCH_ATTEMPTS + 1):
            try:
                bars_summary = bars_mod.export_csv(
                    symbol=symbol,
                    start_kst=start_kst,
                    end_kst=end_kst,
                    output=bars_path,
                    env_path=Path(args.env),
                )
                enrich_summary = enrich_mod.enrich_csv(
                    bars_path=bars_path,
                    output_path=enriched_path,
                    env_path=Path(args.env),
                    symbol=symbol,
                )
                last_error = None
                break
            except (SystemExit, Exception) as exc:  # noqa: BLE001 - batch collector must keep going
                last_error = exc if isinstance(exc, Exception) else RuntimeError(str(exc))
                if attempt < MAX_FETCH_ATTEMPTS:
                    print(f"[{index}/{len(universe)}] {symbol}: retry {attempt}/{MAX_FETCH_ATTEMPTS - 1} after error ({exc})")
                    time.sleep(RETRY_BACKOFF_SEC * attempt)
        if last_error is not None:
            print(f"[{index}/{len(universe)}] {symbol}: FAIL ({last_error})")
            manifest.append({**item, "status": "failed", "error": str(last_error)})
            continue

        print(
            f"[{index}/{len(universe)}] {symbol}: {bars_summary['rows']} bars, "
            f"{enrich_summary['quotes']} quotes, {enrich_summary['trades']} trades -> {enriched_path.name}"
        )
        manifest.append(
            {
                **item,
                "enriched": enriched_path.name,
                "bars": bars_summary["rows"],
                "quotes": enrich_summary["quotes"],
                "trades": enrich_summary["trades"],
                "status": "ok",
            }
        )

    manifest_path = out_dir / "collection_manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "window_kst": [args.start_kst, args.end_kst],
                "max_price": args.max_price,
                "include_etf": args.include_etf,
                "symbols": manifest,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    ok = sum(1 for m in manifest if m["status"] == "ok")
    print(f"\ndone: {ok} fetched, {len(manifest) - ok} skipped/failed. manifest -> {manifest_path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start-kst", required=True, help="YYYY-MM-DD HH:MM")
    parser.add_argument("--end-kst", required=True, help="YYYY-MM-DD HH:MM")
    parser.add_argument("--max-price", type=float, default=20.0)
    parser.add_argument("--limit", type=int, default=0, help="0 = no limit")
    parser.add_argument("--include-etf", action="store_true", help="keep leveraged/inverse ETFs too")
    parser.add_argument("--symbols", default="", help="fixed comma list; bypasses live ranking (for reusing a universe on another date)")
    parser.add_argument("--ranking-file", default="", help="saved ranking JSON snapshot (exports/strategy_replay/rankings/ranking_YYYY-MM-DD.json); reproduces that day's universe with rank/price metadata")
    parser.add_argument("--always-keep", default="TC", help="comma symbols to keep even if flagged non-common")
    parser.add_argument("--out-dir", default="exports/strategy_replay/session_2026-07-07")
    parser.add_argument("--env", default=".env")
    collect(parser.parse_args())


if __name__ == "__main__":
    main()
