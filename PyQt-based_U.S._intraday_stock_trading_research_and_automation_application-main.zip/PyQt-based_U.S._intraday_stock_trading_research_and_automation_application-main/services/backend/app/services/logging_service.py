from app.domain.enums import StatusLevel
from app.domain.models import StructuredLogEvent

SENSITIVE_KEYS = {
    "app_key",
    "app_secret",
    "authorization",
    "client_id",
    "client_secret",
    "token",
    "access_token",
    "refresh_token",
    "account_id",
    "account_no",
    "account_number",
    "hts_id",
    "secret",
}


def redact_payload(payload: dict) -> dict:
    redacted = {}
    for key, value in payload.items():
        if _is_sensitive_key(key):
            redacted[key] = "***REDACTED***"
        elif isinstance(value, dict):
            redacted[key] = redact_payload(value)
        elif isinstance(value, list):
            redacted[key] = [
                redact_payload(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            redacted[key] = value
    return redacted


def _is_sensitive_key(key: str) -> bool:
    normalized = key.lower().replace("-", "_")
    return normalized in SENSITIVE_KEYS or any(part in normalized for part in ("secret", "token", "authorization"))


def build_log_event(
    *,
    level: str,
    event_type: str,
    message: str,
    severity: StatusLevel = StatusLevel.NORMAL,
    payload: dict | None = None,
    symbol: str | None = None,
    order_id: str | None = None,
    correlation_id: str | None = None,
    mode: str = "internal_paper",
) -> StructuredLogEvent:
    return StructuredLogEvent(
        level=level,
        event_type=event_type,
        message=message,
        severity=severity,
        payload=redact_payload(payload or {}),
        symbol=symbol,
        order_id=order_id,
        correlation_id=correlation_id,
        mode=mode,
    )
