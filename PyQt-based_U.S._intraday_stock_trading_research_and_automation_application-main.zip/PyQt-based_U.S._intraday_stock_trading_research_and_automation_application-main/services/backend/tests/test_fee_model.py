from app.core.config import get_settings
from app.services import strategy_runtime as strategy_runtime_module
from app.services.fee_model import toss_fee_breakdown


def _pin_path_fee_settings(monkeypatch):
    settings = get_settings()
    monkeypatch.setattr(settings, "paper_fee_model_enabled", True)
    monkeypatch.setattr(settings, "paper_commission_pct", 0.001)
    monkeypatch.setattr(settings, "paper_commission_per_share", 0.0)
    monkeypatch.setattr(settings, "paper_min_commission_usd", 0.0)
    monkeypatch.setattr(settings, "paper_sec_fee_pct", 0.0000278)
    monkeypatch.setattr(settings, "paper_taf_fee_per_share", 0.000166)
    monkeypatch.setattr(settings, "paper_taf_fee_cap_usd", 8.30)
    return settings


def test_toss_fee_model_matches_path_one_share_live_response(monkeypatch) -> None:
    settings = _pin_path_fee_settings(monkeypatch)

    buy = toss_fee_breakdown(side="buy", quantity=1, price=11.57, settings=settings)
    sell = toss_fee_breakdown(side="sell", quantity=1, price=11.56, settings=settings)

    assert buy["commission_usd"] == 0.01
    assert buy["total_fees_usd"] == 0.01
    assert sell["commission_usd"] == 0.01
    assert sell["regulatory_fee_usd"] == 0.01
    assert sell["total_fees_usd"] == 0.02
    assert round(float(buy["total_fees_usd"]) + float(sell["total_fees_usd"]), 2) == 0.03


def test_strategy_runtime_uses_toss_cent_rounded_fee_model(monkeypatch) -> None:
    _pin_path_fee_settings(monkeypatch)

    assert strategy_runtime_module._estimated_entry_fees(quantity=1, price=11.57) == 0.01
    assert strategy_runtime_module._estimated_exit_fees(quantity=1, price=11.56) == 0.02
