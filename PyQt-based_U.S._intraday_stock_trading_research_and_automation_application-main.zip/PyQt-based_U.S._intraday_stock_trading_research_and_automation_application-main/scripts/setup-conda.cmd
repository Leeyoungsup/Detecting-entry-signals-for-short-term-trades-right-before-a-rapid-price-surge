@echo off
setlocal

cd /d "%~dp0.."

echo [1/5] Updating conda environment: kis-trading-research
call conda env update -f environment.yml --prune
if errorlevel 1 exit /b %errorlevel%

set CONDA_ENV_DIR=%USERPROFILE%\.conda\envs\kis-trading-research
if not exist "%CONDA_ENV_DIR%\python.exe" set CONDA_ENV_DIR=C:\ProgramData\anaconda3\envs\kis-trading-research
set PATH=%CONDA_ENV_DIR%;%CONDA_ENV_DIR%\Library\bin;%CONDA_ENV_DIR%\Scripts;%PATH%

echo [2/5] Installing backend package in editable mode
python -m pip install -e "services/backend[dev]"
if errorlevel 1 exit /b %errorlevel%

echo [3/5] Installing browser runtime for Toss WTS crawler
python -m playwright install chromium
if errorlevel 1 exit /b %errorlevel%

echo [4/5] Installing frontend dependencies
npm install
if errorlevel 1 exit /b %errorlevel%

echo [5/5] Preparing local env file
if not exist ".env" (
  copy ".env.conda.example" ".env" > nul
  echo Created .env from .env.conda.example
) else (
  echo .env already exists; keeping your current file
)

echo.
echo Conda setup complete.
echo Start PostgreSQL: scripts\start-postgres.cmd
echo Run backend: scripts\run-backend.cmd
echo Run web:     scripts\run-web.cmd
echo Or both:     scripts\run-dev.cmd
